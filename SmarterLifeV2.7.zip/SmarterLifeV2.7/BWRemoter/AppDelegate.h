//
//  AppDelegate.h
//  BWRemoter
//
//  Created by JianBo He on 14/11/23.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


+ (id)sharedAppDelegate;
@end

