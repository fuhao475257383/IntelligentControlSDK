//
//  FXW_SafeInfoVC.h
//  BWRemoter
//
//  Created by 6602_Loop on 15-2-7.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "HE_BaseViewController.h"

@interface FXW_SafeInfoVC : HE_BaseViewController<UITableViewDataSource,UITableViewDelegate>
{
    NSMutableArray *arySafeInfo;
}
@property UITableView *table;
@end
