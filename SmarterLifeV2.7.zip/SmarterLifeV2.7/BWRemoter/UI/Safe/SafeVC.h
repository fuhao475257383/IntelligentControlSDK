//
//  SafeVC.h
//  BWRemoter
//
//  Created by JianBo He on 14/12/5.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "HE_BaseViewController.h"
#import "FXW_AlertView.h"
#import "SecurityContent_zone.h"
#import "SecurityContent_sensor.h"
@interface SafeVC :  HE_BaseViewController<UITableViewDataSource,UITableViewDelegate,UIAlertViewDelegate,FXW_alertDelegate>
{
    NSArray *aryimgzone;
    NSArray *aryimgsensor;
    NSMutableArray * aryZone;
    NSMutableArray * arySensor;
    UISwitch *switmp;
}
@property(nonatomic,retain) UITableView *table;
@end

