//
//  SafeVC.m
//  BWRemoter
//
//  Created by JianBo He on 14/12/5.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//
#import <AudioToolbox/AudioToolbox.h>
#import "SafeVC.h"
#import "FXW_alertView.h"
#import "CYM_Engine.h"
#import "FXW_SafeInfoVC.h"
#import "ZJSwitch.h"
#import "DoorLockVC.h"

#define TAG_ZONE    1000
#define TAG_SENSOR  2000
#define TAG_IMG     9999

@interface SafeVC ()
{
    UILabel         *labNoteCount;
    NSMutableArray  *arySensorImgView;
    NSArray         *aryNewSecurtyNote;
}

@property (nonatomic, strong) NSTimer *timer;
//如果消息文件传输失败，那么xmpp很快就会自动断开
@property (nonatomic, assign) BOOL isUpFail;

@end

@implementation SafeVC
@synthesize table;

- (void)viewWillAppear:(BOOL)animated{
    appManager.isZoneView = YES;
    //注册上传失败的通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(restoreFile) name:@"TheFileDidNotUpload" object:nil];
    //注册消息发送失败的通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(msgSendFail) name:@"MSGSendFail" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(stopTimer) name:@"SceneNeedDelTime" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(stopTimer) name:@"FileUpSuc" object:nil];
    [super viewWillAppear:animated];
    [self reciveSecrityMsg];
    
}
//界面即将消失时，取消对文件上传和消息发送的监听通知
- (void)viewWillDisappear:(BOOL)animated {
    appManager.isZoneView = NO;
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"TheFileDidNotUpload" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"MSGSendFail" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"SceneNeedDelTime" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"FileUpSuc" object:nil];
    NSFileManager *fileManager =[NSFileManager defaultManager];
    NSString *documentsStr   = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    NSString *databaseCopy =[NSString stringWithFormat:@"%@/BWDatabase_SceneCopy.sqlite",documentsStr];
    [self stopTimer];
    if ([fileManager fileExistsAtPath:databaseCopy])
    {
        [fileManager removeItemAtPath:databaseCopy error:nil];
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    ///////////////////Data
    arySensorImgView  = [NSMutableArray array];
    aryNewSecurtyNote = [self getNewSecurityNote];
    aryZone           = [CYM_Engine getZoneContentInfo];
    arySensor         = [CYM_Engine getAllSensorInfo];
    aryimgzone        = @[@"key.png",@"house.png",@"out.png",@"diyzoneicon"];
    aryimgsensor      = @[@"safe_gas_icon.png",@"safe_smoke_icon.png",@"safe_red_icon.png",
                          @"safe_red_icon.png",@"safe_door_icon.png",@"safe_urgent_icon.png",@"safe_door_icon.png"];

    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(reciveSecrityMsg) name:@"ROOM_UPDATE" object:nil];
    /////////////////View
    /////右侧按钮
    UIButton *btnWarnlight = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 40, 40)];
    [btnWarnlight setBackgroundImage:[UIImage imageNamed:@"safe_info_icon.png"] forState:UIControlStateNormal];
    [btnWarnlight addTarget:self action:@selector(btnSafeInfo) forControlEvents:UIControlEventTouchUpInside];
    //////////Num
    labNoteCount = [[UILabel alloc] initWithFrame:CGRectMake(btnWarnlight.frameW - 10, 0, 20, 20)];
    [labNoteCount setFont:[UIFont systemFontOfSize:10.f]];
    [labNoteCount setBackgroundColor:[UIColor redColor]];
    [labNoteCount setTextColor:[UIColor whiteColor]];
    [labNoteCount setTextAlignment:NSTextAlignmentCenter];
    [labNoteCount setClipsToBounds:YES];
    labNoteCount.layer.cornerRadius = labNoteCount.frameW/2.f;
    [btnWarnlight addSubview:labNoteCount];
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithCustomView:btnWarnlight];
    self.navigationItem.rightBarButtonItem =item;
    
    self.navigationItem.leftBarButtonItem = nil;
    
    table = [[UITableView alloc]initWithFrame:CGRectMake(0.0f,0, curScreenSize.width, curScreenSize.height-130) style:UITableViewStylePlain];
    [table setBackgroundColor:[UIColor clearColor]];
    table.separatorInset = UIEdgeInsetsMake(0, 3, 0, 17);
    [table setDelegate:self];
    [table setDataSource:self];
    [self.view addSubview:table];
    UIButton *btnCancel = [UIButton buttonWithType:UIButtonTypeSystem];
    [btnCancel setFrame:CGRectMake(curScreenSize.width*0.35, table.frameSumY_H+20, 80, 30)];
    [btnCancel setTitle:@"撤防" forState:UIControlStateNormal];
    [btnCancel.titleLabel setFont:[UIFont systemFontOfSize:20]];
    [btnCancel setBackgroundColor:[UIColor grayColor]];
    [btnCancel setTintColor:[UIColor whiteColor]];
    btnCancel.layer.cornerRadius = 5.0f;
    [self.view addSubview:btnCancel];
    [btnCancel addTarget:self action:@selector(btnCancelClick) forControlEvents:UIControlEventTouchUpInside];
    //////////通知报警信息通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reciveSecrityMsg) name:@"DATABASE_UPDATE" object:nil];
    
    //分割线
    CGRect separateRect = CGRectMake(0, curScreenSize.height-130, curScreenSize.width, 1);
    UIView *separateView = [[UIView alloc]initWithFrame:separateRect];
    separateView.backgroundColor = [UIColor grayColor];
    [self.view addSubview:separateView];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    switch (section) {
        case 0:
            return aryZone.count;
            break;
        case 1:
            return arySensor.count;
        default:
            break;
    }
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section == 1)
        return 20;
    return 0;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    if (section == 1) {
        UIView *line = [[UIView alloc]initWithFrame:CGRectMake(0, 70.0f, curScreenSize.width, 0)];
        line.backgroundColor = [UIColor colorWithWhite:0.5 alpha:0.2];
        return line;
    }
    return nil;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell= [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    if (cell==nil) {
        cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"qe"];
    }
    
    UIView *backView = [[UIView alloc] initWithFrame: CGRectMake(0.0f, 0.0f, curScreenSize.width, 90.0f)];
    UILabel *ListName = [[UILabel alloc]initWithFrame:CGRectMake(curScreenSize.width*0.35, 25.0f, 80.0f, 30.0f)];
    [ListName setTextAlignment:NSTextAlignmentCenter];
    ListName.adjustsFontSizeToFitWidth=YES;
    UIImageView *logo = [[UIImageView alloc]initWithFrame:CGRectMake(curScreenSize.width*0.1, 17.0f, 40.0f, 40.0f)];
    ZJSwitch *switches = [[ZJSwitch alloc]initWithFrame:CGRectMake(curScreenSize.width*0.7,25.0f, 70.0f, 30.0f)];
    [switches setOnTintColor:[UIColor colorWithRed: 35/255.0 green:167/255.0 blue:230/255.0 alpha:1]];
    [switches setTintColor:[UIColor colorWithRed:230/255.0f green:230/255.0f blue:230/255.0f alpha:1]];
    
    switches.onText=@"ON";
    switches.offText=@"OFF";
    [switches setTextFont:[UIFont boldSystemFontOfSize:14]];
    [switches setOffTextColor:[UIColor grayColor]];
    [switches addTarget:self action:@selector(switchAction:) forControlEvents:UIControlEventValueChanged];
    
    /////////////防区Section
    if (indexPath.section == 0) {
        [ListName setText:((SecurityContent_zone *)aryZone[indexPath.row]).name];
        [logo setImage:[UIImage imageNamed:aryimgzone[[((SecurityContent_zone *)aryZone[indexPath.row]).type integerValue]]]];
        [switches setOn:[((SecurityContent_zone *)aryZone[indexPath.row]).state isEqualToString:@"0"]?NO:YES animated:NO];
        switches.tag = TAG_ZONE+indexPath.row;
    }
    ////////////传感器
    else{
        SecurityContent_sensor *sensor     = arySensor[indexPath.row];
        [ListName setText:sensor.sensorName];
        ListName.layer.borderWidth =1.0f;
        ListName.layer.cornerRadius = 5.0f;
        ListName.layer.borderColor = [[UIColor grayColor]CGColor];
        [logo setImage:[UIImage imageNamed:aryimgsensor[[sensor.sensorType integerValue]]]];
        [switches setOn:[sensor.isAlarm isEqualToString:@"0"]?NO:YES animated:NO];
        switches.tag = TAG_SENSOR+indexPath.row;
        arySensorImgView[indexPath.row] = logo;
        
        for (SecurityNote *note in aryNewSecurtyNote) {
            NSString               *sensorName = [CYM_DatabaseTable getDeviceNameById:note.devMac];
            if ([sensor.sensorName isEqualToString:sensorName]) {
                UIImageView *imgViewWarning = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"icSafeWarning"]];
                [imgViewWarning setContentMode:UIViewContentModeScaleAspectFit];
                [imgViewWarning setFrame:CGRectMake(logo.frameW - 10, 0, 10, 10)];
                [logo setTag:TAG_IMG];
                [logo addSubview:imgViewWarning];
                break;
            }
        }

        /////////////无权限变灰
//        if(![self isPermissionwithDevicePrio:[CYM_Engine getSensorOrAlarmPriowithName:sensor.sensorName] andPermission:appManager.User.strPermission]){
//            [cell setUserInteractionEnabled:NO];
//            CALayer *maskLayer = [CALayer layer];
//            maskLayer.frame    = backView.bounds;
//            maskLayer.contents = (__bridge id)([UIImage imageNamed:@"tv_backMask"].CGImage);
//            backView.layer.mask = maskLayer;
//        }
    }
    [backView addSubview:ListName];

    [backView addSubview:logo];
    [backView addSubview:switches];
    [cell addSubview:backView];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    [cell setAccessoryType:UITableViewCellAccessoryNone];
    [cell setBackgroundColor:[UIColor clearColor]];
    

    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 80;
}
/*  点击事件 */
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
//    if(indexPath.row>=aryZone.count){//如果是传感器设备
//        FXW_alertView *alert = [[FXW_alertView alloc]initWithFrame:self.view.frame Delegate:self Datasourse:self];
//        [self.view addSubview:alert];
//        //绑定数据
//        [alert setContent:safe andTitle:((SecurityContent_sensor *)arySensor[indexPath.row-aryZone.count]).sensorName];
//        [alert setSensor:(SecurityContent_sensor *)arySensor[indexPath.row-aryZone.count]];
//        [alert SetdeviceIson:[((SecurityContent_sensor *)arySensor[indexPath.row-aryZone.count]).sensor24h isEqualToString:@"0"]?NO:YES  withSignal:        [((SecurityContent_sensor *)arySensor[indexPath.row-aryZone.count]).sensorSignal isEqualToString:@"0"]?NO:YES];
//    }
    if(indexPath.section == 1){//如果是传感器设备
        FXW_alertView *alert = [[FXW_alertView alloc]initWithFrame:self.view.frame Delegate:self Datasourse:self];
        [self.view addSubview:alert];
        //绑定数据
        [alert setContent:safe andTitle:((SecurityContent_sensor *)arySensor[indexPath.row]).sensorName];
        [alert setSensor:(SecurityContent_sensor *)arySensor[indexPath.row]];
        [alert SetdeviceIson:[((SecurityContent_sensor *)arySensor[indexPath.row]).sensor24h isEqualToString:@"0"]?NO:YES  withSignal:        [((SecurityContent_sensor *)arySensor[indexPath.row]).sensorSignal isEqualToString:@"0"]?NO:YES];
    }
    
}
#pragma mark --事件
-(BOOL)saveBtn:(Alerttype)content withareatext:(NSString *)text withsignal:(BOOL)signal withdeviceIson:(BOOL)Ison withSensor:(SecurityContent_sensor *)sensor{
    switch (content) {
        case defineArea:
            break;
        case addArea:
            if(text==nil||[text isEqual:@""]){
                return false;
            }
            else{
                NSLog(@"%@",text);
            }
            break;
        case safe:
            if (self.isUpFail == YES) {
                [appManager logout];
                [appManager handleAPPOffLineWithMsg:@"与网关断开连接，请重新登录！"];
                self.isUpFail = NO;
                return true;
            }
            sensor.sensorSignal = signal?@"1":@"0";
            sensor.sensor24h    = Ison?@"1":@"0";
            if (Ison) {
                sensor.isAlarm      = Ison?@"1":@"0";
                [table reloadData];
            }
            [self copyData];
            [CYM_Engine updeteSensorInfo:sensor];
            [self generateJSONFileAndUpload];
            break;
        default:
            break;
    }
    return true;
}

-(void)btnCancelClick{
    if (self.isUpFail == YES) {
        [appManager logout];
        [appManager handleAPPOffLineWithMsg:@"与网关断开连接，请重新登录！"];
        self.isUpFail = NO;
        return;
    }
    BOOL isZone = NO;
    for (SecurityContent_zone *zone in aryZone) {
        if ([zone.state isEqualToString:@"1"]) {
            isZone = YES;
            break;
        }
    }
    for (SecurityContent_sensor *sensor in arySensor) {
        if (isZone == YES) {
            break;
        }
        if ([sensor.isAlarm isEqualToString:@"1"]&&[sensor.sensor24h isEqualToString:@"0"]) {
            isZone = YES;
            break;
        }
    }
    
    if (isZone == NO) {
        NSArray *aryAlarmName = [CYM_Engine getAlarmNameWithNot24H];
        for (NSString *alarmName in aryAlarmName) {
            //////////获取该设备的详情
            ControlDeviceContentValue *devDetails = [CYM_Engine getDeviceDetailsWithDeviceName:alarmName];
            NSString *mac = [cmdP getDeviceNumWithBindCMD:devDetails.value];
            NSString *strData = [NSString stringWithFormat:@"%@0000",mac];
            NSString *cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:A4_DEVICE_ALARM Data:strData];
            NSString *msg = [msgB getMessageWithType:[devDetails.com longLongValue] action:ACTION_TRANSMIT commond:cmd];
            [appManager SendMsg:msg withNameSpace:@"control" isShowLoading:NO];
        }
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示！" message:@"操作成功！" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alert show];
        return;
    }
    
    [self copyData];
    
    //////////更新 数据库、并上传文件
    ///撤防防区、非24h传感器
    [CYM_Engine cancelSecrityNot24H];
//    aryZone = [CYM_Engine getZoneContentInfo];
//    arySensor = [CYM_Engine getAllSensorInfo];
    for (SecurityContent_zone *zone in aryZone) {
        zone.state = @"0";
    }
    for (SecurityContent_sensor *sensor in arySensor) {
        if ([sensor.sensor24h isEqualToString:@"0"]) {
            sensor.isAlarm = @"0";
        }
    }
    [table reloadData];
    
    //////////发送 取消报警消息
    NSArray *aryAlarmName = [CYM_Engine getAlarmNameWithNot24H];
    for (NSString *alarmName in aryAlarmName) {
        //////////获取该设备的详情
        ControlDeviceContentValue *devDetails = [CYM_Engine getDeviceDetailsWithDeviceName:alarmName];
        NSString *mac = [cmdP getDeviceNumWithBindCMD:devDetails.value];
        NSString *strData = [NSString stringWithFormat:@"%@0000",mac];
        NSString *cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:A4_DEVICE_ALARM Data:strData];
        NSString *msg = [msgB getMessageWithType:[devDetails.com longLongValue] action:ACTION_TRANSMIT commond:cmd];
        [appManager SendMsg:msg withNameSpace:@"control" isShowLoading:NO];
    }
    ////////更新配置文件到网关
    [self generateJSONFileAndUpload];
}

-(void)switchAction:(id)sender{
    switmp = (UISwitch *)sender;

    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:@"确定此操作？" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    [alert show];

}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
  
    
    if(buttonIndex==1){
        if (self.isUpFail == YES) {
            [appManager logout];
            [appManager handleAPPOffLineWithMsg:@"与网关断开连接，请重新登录！"];
            self.isUpFail = NO;
            return;
        }
        
        [self copyData];
        
        NSString *strtmp =@"";//保存该开关的状态
        if(switmp.tag < aryZone.count + TAG_ZONE){//如果是防区
            //假如是布放，先关闭所有防区
            if (switmp.on) {
                [CYM_Engine cancelSecrityNot24H];
//                aryZone = [CYM_Engine getZoneContentInfo];
//                arySensor = [CYM_Engine getAllSensorInfo];
//                [table reloadData];
                
                //////////发送 取消报警消息
                NSArray *aryAlarmName = [CYM_Engine getAlarmNameWithNot24H];
                for (NSString *alarmName in aryAlarmName) {
                    //////////获取该设备的详情
                    ControlDeviceContentValue *devDetails = [CYM_Engine getDeviceDetailsWithDeviceName:alarmName];
                    NSString *mac = [cmdP getDeviceNumWithBindCMD:devDetails.value];
                    NSString *strData = [NSString stringWithFormat:@"%@0000",mac];
                    NSString *cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:A4_DEVICE_ALARM Data:strData];
                    NSString *msg = [msgB getMessageWithType:[devDetails.com longLongValue] action:ACTION_TRANSMIT commond:cmd];
                    NSLog(@"msg------%@",msg);
                    [appManager SendMsg:msg withNameSpace:@"control" isShowLoading:NO];
                }
            }
            SecurityContent_zone *zoneTmp = (SecurityContent_zone *)aryZone[switmp.tag-TAG_ZONE];
            zoneTmp.state =[zoneTmp.state isEqualToString:@"0"]?@"1":@"0";
            strtmp =  zoneTmp.state;
            [CYM_Engine updateZoneInfo:zoneTmp];
            ////////////////////若为撤防、则发送 关闭报警 消息
            if(!switmp.on){
                NSArray *aryAlarmName = [CYM_Engine getAlarmNameWithZoneID:zoneTmp.ID];
                for (NSString *alarmName in aryAlarmName) {
                    //////////获取该设备的详情
                    ControlDeviceContentValue *devDetails = [CYM_Engine getDeviceDetailsWithDeviceName:alarmName];
                    NSString *mac = [cmdP getDeviceNumWithBindCMD:devDetails.value];
                    NSString *strData = [NSString stringWithFormat:@"%@0000",mac];
                    NSString *cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:A4_DEVICE_ALARM Data:strData];
                    NSString *msg = [msgB getMessageWithType:[devDetails.com longLongValue] action:ACTION_TRANSMIT commond:cmd];
                    NSLog(@"msg------%@",msg);
                    [appManager SendMsg:msg withNameSpace:@"control" isShowLoading:NO];
                }
            }
            ///////////////////布防则延时
            else{
                CGFloat delayTime = zoneTmp.delay.floatValue;
                NSLog(@"布防延时:%lf", delayTime);
                if (delayTime < 0.5)
                    delayTime = 0.5;
                
//                self.viewHUD = [[MBProgressHUD alloc] initWithView:self.view];
//                self.viewHUD.removeFromSuperViewOnHide = YES;
//                self.viewHUD.labelFont      = [UIFont systemFontOfSize:14.f];
//                self.viewHUD.labelText      = @"正在布防...";
//                [self.viewHUD show:YES];
//                [self.viewHUD hide:YES afterDelay:delayTime];
//                [[[AppDelegate sharedAppDelegate] window] addSubview:self.viewHUD];
//                [appManager addHUDToViewWithDetails:@"正在布防"];
                
                //如果需要延时，可以用线程延时delayTime的方法延时
                [self timeUpdate];
                

                NSData *cronData = [CYM_Engine generateSecuritySensorArr:arySensor zoneArr:aryZone];
                [[HE_APPManager sharedManager] uploadFileWithName:@"security.json" andData:cronData isShowHUD:YES];
                [self beginTimer];
                return;
            }
        }
        else{//如果是传感器
            ///24小时不能撤防
            SecurityContent_sensor *sensorTmp = (SecurityContent_sensor *)arySensor[switmp.tag - TAG_SENSOR];
            if([sensorTmp.sensor24h isEqualToString:@"1"]){
                if(!switmp.on){
                    UIAlertView *aler = [[UIAlertView alloc]initWithTitle:@"提示" message:@"24小时设备不能撤防" delegate:self cancelButtonTitle:@"确定" otherButtonTitles: nil];
                    [aler show];
                    return;
                }
            }
            sensorTmp.isAlarm = [sensorTmp.isAlarm isEqualToString:@"0"]?@"1":@"0";
            [CYM_Engine updeteSensorInfo:sensorTmp];
            ////////////////////若为撤防、则发送 关闭报警 消息
            if(!switmp.on){
                NSArray *aryAlarmName = [CYM_Engine getAlarmNameWithSensorMAC:sensorTmp.sensorMac];
                for (NSString *alarmName in aryAlarmName) {
                    //////////获取该设备的详情
                    ControlDeviceContentValue *devDetails = [CYM_Engine getDeviceDetailsWithDeviceName:alarmName];
                    NSString *mac = [cmdP getDeviceNumWithBindCMD:devDetails.value];
                    NSString *strData = [NSString stringWithFormat:@"%@0000",mac];
                    NSString *cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:A4_DEVICE_ALARM Data:strData];
                    NSString *msg = [msgB getMessageWithType:[devDetails.com longLongValue] action:ACTION_TRANSMIT commond:cmd];
                    [appManager SendMsg:msg withNameSpace:@"control" isShowLoading:NO];
                }
            }
        }
        [self timeUpdate];
        [self generateJSONFileAndUpload];
    }
    else{
        [switmp setOn:!switmp.on animated:YES];
    }
}
//延时布防，先写上，如果没发现，就不使用该方法
- (void)sleepThread {
    NSData *cronData = [CYM_Engine generateSecuritySensorArr:arySensor zoneArr:aryZone];
    [[HE_APPManager sharedManager] uploadFileWithName:@"security.json" andData:cronData isShowHUD:YES];
}
-(void)btnSafeInfo{
    FXW_SafeInfoVC *safeinfovc =[[FXW_SafeInfoVC alloc]init];
    safeinfovc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:safeinfovc animated:YES];
}
- (void)generateJSONFileAndUpload{
    //1.根据数据库生成JSON文件
    //2.上传JSON文件
    //3.上传成功->更新本地信息、 否则下载服务器文件更新本地数据库
    NSData *cronData = [CYM_Engine generateSecuritySensorArr:arySensor zoneArr:aryZone];
    
    [[HE_APPManager sharedManager] uploadFileWithName:@"security.json" andData:cronData isShowHUD:YES];
    [self beginTimer];
}
- (void)timeUpdate{
    aryZone = [CYM_Engine getZoneContentInfo];
    arySensor = [CYM_Engine getAllSensorInfo];
    [table reloadData];
}
- (void)reciveSecrityMsg{
    
    [self stopTimer];
    
    aryZone = [CYM_Engine getZoneContentInfo];
    arySensor = [CYM_Engine getAllSensorInfo];
    
    //////查询报警信息
    aryNewSecurtyNote = [self getNewSecurityNote];
    NSString *noteCount = [NSString stringWithFormat:@"%ld",(long)aryNewSecurtyNote.count];
    NSLog(@"%@  报警消息...", noteCount);
    labNoteCount.hidden = NO;
    labNoteCount.text = noteCount;
    if ([noteCount isEqualToString:@"0"]) {
        labNoteCount.hidden = YES;
        //////将所有红色小点消除
        for (UIImageView *imgView in arySensorImgView) {
            UIView *warnView = [imgView viewWithTag:TAG_IMG];
            [warnView removeFromSuperview];
        }
        UITabBarItem *tabBarItem = [[[self.tabBarController tabBar]items]objectAtIndex:2];
        [tabBarItem setBadgeValue:nil];
    }
    else{
        AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
        //tabbar加上提示数字
        UITabBarItem *tabBarItem = [[[self.tabBarController tabBar]items]objectAtIndex:2];
        [tabBarItem setBadgeValue:noteCount];
        
        //////报警将红色的小点加上
        for (int i=0; i< arySensorImgView.count; i++) {
            BOOL         hasContains = NO;
            UIImageView *imgView     = arySensorImgView[i];
            for (SecurityNote *note in aryNewSecurtyNote) {
                SecurityContent_sensor *sensor     = arySensor[i];
                NSString               *sensorName = [CYM_DatabaseTable getDeviceNameById:note.devMac];
                if ([sensor.sensorName isEqualToString:sensorName]) {
                    hasContains = YES;
                    UIImageView *imgViewWarning = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"icSafeWarning"]];
                    [imgViewWarning setContentMode:UIViewContentModeScaleAspectFit];
                    [imgViewWarning setFrame:CGRectMake(imgView.frameW - 10, 0, 10, 10)];
                    [imgView setTag:TAG_IMG];
                    [imgView addSubview:imgViewWarning];
                    break;
                }
            }
        }
    }
    dispatch_async(dispatch_get_main_queue(),^{
        [table reloadData];
    });
}

#pragma mark - Private Method
- (NSArray *)getNewSecurityNote{
    
    NSString *lastDate = [[NSUserDefaults standardUserDefaults] objectForKey:@"LastSecrityDate"];
    if (lastDate == nil || [lastDate isEqualToString:@""]) {
        lastDate = @"1970-1-1";
    }
    return [CYM_Engine getNewSecurtyNote:lastDate];
}
////检查用户是否有权限
-(BOOL)isPermissionwithDevicePrio:(NSString *)pri andPermission:(NSString *)permission{
    if(!([permission integerValue]==0)){
        UInt64 prioH = [pri IntString].longLongValue;
        prioH =  prioH >> ([permission IntString].intValue -1);
        return prioH&1;
    }
    else{
        return YES;
    }
}
#pragma mark - 开启定时
- (void)beginTimer {
    self.timer = [NSTimer scheduledTimerWithTimeInterval:20 target:self selector:@selector(restoreFile) userInfo:nil repeats:NO];
}
//回复信号量，恢复数据
- (void)restore {
    [[NSNotificationCenter defaultCenter] postNotificationName:@"RestoreSemaphore" object:nil];
    [self restoreFile];
}
- (void)stopTimer {
    if (self.timer) {
        [self.timer invalidate];
        self.timer = nil;
    }
}
#pragma mark - 恢复数据

//消息发送失败
- (void)msgSendFail {
//    [self restoreFile];
}
//拷贝数据库
- (void)copyData {
    NSFileManager *fileManager =[NSFileManager defaultManager];
    
    NSString *documentsStr   = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    
    NSString *databasePath     =[NSString stringWithFormat:@"%@/BWDatabase_V2.sqlite",documentsStr];
    NSString *databaseCopy =[NSString stringWithFormat:@"%@/BWDatabase_SceneCopy.sqlite",documentsStr];
    
    if (![fileManager fileExistsAtPath:databaseCopy])
    {
        [fileManager copyItemAtPath:databasePath toPath:databaseCopy error:nil];
    }
    else
    {
        [fileManager removeItemAtPath:databaseCopy error:nil];
        [fileManager copyItemAtPath:databasePath toPath:databaseCopy error:nil];
    }
}
//恢复数据
- (void)restoreFile {
    self.isUpFail = YES;
    [self stopTimer];
    NSFileManager *fileManager =[NSFileManager defaultManager];
    
    NSString *documentsStr   = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    
    NSString *databasePath     =[NSString stringWithFormat:@"%@/BWDatabase_V2.sqlite",documentsStr];
    NSString *databaseCopy =[NSString stringWithFormat:@"%@/BWDatabase_SceneCopy.sqlite",documentsStr];
    
    if (![fileManager fileExistsAtPath:databaseCopy])
    {
        return;
    }
    
    if (![fileManager fileExistsAtPath:databasePath])
    {
        [fileManager copyItemAtPath:databaseCopy toPath:databasePath error:nil];
    }
    else
    {
        [fileManager removeItemAtPath:databasePath error:nil];
        [fileManager copyItemAtPath:databaseCopy toPath:databasePath error:nil];
    }
    [self reciveSecrityMsg];
}
@end
