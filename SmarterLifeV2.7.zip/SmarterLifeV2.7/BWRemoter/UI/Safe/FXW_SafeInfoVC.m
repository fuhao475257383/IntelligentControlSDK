//
//  FXW_SafeInfoVC.m
//  BWRemoter
//
//  Created by 6602_Loop on 15-2-7.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "FXW_SafeInfoVC.h"
#import "SecurityNote.h"
@interface FXW_SafeInfoVC ()

@end

@implementation FXW_SafeInfoVC
@synthesize table;
- (void)viewDidLoad {
    [super viewDidLoad];
    [self setTitle:@"报警信息"];
    ///////////Data
    arySafeInfo = [[NSMutableArray alloc]init];
    arySafeInfo = [CYM_Engine getTop500SecurityNoteInfo];
    [[NSUserDefaults standardUserDefaults] setObject:[CYM_Engine getNewNoteDate] forKey:@"LastSecrityDate"];
    
    //////////View
    table = [[UITableView alloc]initWithFrame:CGRectMake(0,50, curScreenSize.width, curScreenSize.height-50)];
    table.tableFooterView = [[UIView alloc] init];
    table.delegate = self;
    table.dataSource = self;
    [self.view addSubview:table];
    UIView *header = [[UIView alloc]initWithFrame:CGRectMake(0, self.NavgationBarHeight, curScreenSize.width, 50)];
    [header setBackgroundColor:[UIColor whiteColor]];
    UIView *lineBottom = [[UIButton alloc]initWithFrame:CGRectMake(0, 40, curScreenSize.width, 10)];
    [lineBottom setBackgroundColor:[UIColor colorWithRed:220/255.0f green:220/255.0f blue:220.0/255.0f alpha:1]];
    [header addSubview:lineBottom];
    UIView *leftline =[[UIView alloc]initWithFrame:CGRectMake(curScreenSize.width*0.4, 0, 1, 40)];
    [leftline setBackgroundColor:lineBottom.backgroundColor];
    UIView *rightline =[[UIView alloc]initWithFrame:CGRectMake(curScreenSize.width*0.7+1, 0, 1, 40)];
    [rightline setBackgroundColor:lineBottom.backgroundColor];
    UILabel *labTime = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, curScreenSize.width*0.4, 40)];
    [labTime setText:@"时间"];
    [labTime setTextAlignment:NSTextAlignmentCenter];
    [labTime setFont:[UIFont boldSystemFontOfSize:17.f]];
    
    UILabel *labDevice = [[UILabel alloc]initWithFrame:CGRectMake(curScreenSize.width*0.4+1, 0, curScreenSize.width*0.3, 40)];
    [labDevice setText:@"设备"];
    [labDevice setTextAlignment:NSTextAlignmentCenter];
    [labDevice setFont:[UIFont boldSystemFontOfSize:17.f]];
    
    UILabel *labType = [[UILabel alloc]initWithFrame:CGRectMake(curScreenSize.width*0.7+2, 0, curScreenSize.width*0.3-2, 40)];
    [labType setText:@"状态"];
    [labType setTextAlignment:NSTextAlignmentCenter];
    [labType setFont:[UIFont boldSystemFontOfSize:17.f]];
    
    [header addSubview:labType];
    [header addSubview:labDevice];
    [header addSubview:labTime];
    [header addSubview:rightline];
    [header addSubview:leftline];
    [self.view addSubview:header];
    
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell= [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    if (cell==nil) {
        cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"qe"];
    }
    UILabel *labTime = [[UILabel alloc]initWithFrame:CGRectMake(20, 0, curScreenSize.width*0.4-20, 60)];
    [labTime setText:((SecurityNote *)arySafeInfo[indexPath.row]).alarmTime];
    labTime.lineBreakMode = NSLineBreakByWordWrapping;
    labTime.numberOfLines = 0;
    [labTime setFont:[UIFont systemFontOfSize:14]];
    [labTime setTextAlignment:NSTextAlignmentCenter];
    [cell addSubview:labTime];
    
    //devive
    UILabel *labDevice = [[UILabel alloc]initWithFrame:CGRectMake(curScreenSize.width*0.4, 0, curScreenSize.width*0.3, 60)];
    [labDevice setText:[CYM_DatabaseTable getDeviceNameById:((SecurityNote *)arySafeInfo[indexPath.row]).devMac]];
    [labDevice setFont:[UIFont systemFontOfSize:14]];
    [labDevice setTextAlignment:NSTextAlignmentCenter];
    [cell addSubview:labDevice];
    ///type
    UILabel *labType = [[UILabel alloc]initWithFrame:CGRectMake(curScreenSize.width*0.7, 0, curScreenSize.width*0.3, 60)];
    [labType setText:[((SecurityNote *)arySafeInfo[indexPath.row]).alarmType isEqualToString:@"0"]?[CYM_DatabaseTable getSecurityNoteType:((SecurityNote *)arySafeInfo[indexPath.row]).devMac]:@"电量不足!"];
    [labType setTextAlignment:NSTextAlignmentCenter];
    labType.lineBreakMode = NSLineBreakByWordWrapping;
    labType.numberOfLines = 0;
    [labType setFont:[UIFont systemFontOfSize:14]];
 
    [cell addSubview:labType];

    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return arySafeInfo.count;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 60;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
