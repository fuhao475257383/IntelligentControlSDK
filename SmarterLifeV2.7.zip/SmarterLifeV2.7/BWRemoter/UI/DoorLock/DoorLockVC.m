//
//  DoorLockVC.m
//  BWRemoter
//
//  Created by tc on 15/11/12.
//  Copyright © 2015年 ReSun. All rights reserved.
//

#import "DoorLockVC.h"
#import "SafeHistroyVC.h"
#import "DoorView.h"
#import "CYM_Engine.h"
#import <AVFoundation/AVFoundation.h>
#import "DoorlockNoteModel.h"

@interface DoorLockVC () <UIAlertViewDelegate>

//报警数字
@property (nonatomic,strong) UILabel *alarmNumberLabel;
//右侧报警按钮
@property (nonatomic,strong) UIButton *alarmButton;

//所有UI界面上的门VIEW的数组
@property (nonatomic,strong) NSMutableArray *allDoorViewArray;
//所有的报警
@property (nonatomic,strong) NSMutableArray *allDetailNote;

//添加一个滚动视图，防止门太多，导致超出
@property (nonatomic,strong) UIScrollView *backScrollView;

@end

@implementation DoorLockVC

- (NSMutableArray *)allDoorViewArray {
    if (_allDoorViewArray == nil) {
        _allDoorViewArray = [[NSMutableArray alloc]init];
    }
    return _allDoorViewArray;
}
- (NSMutableArray *)allDetailNote {
    if (!_allDetailNote) {
        _allDetailNote = [[NSMutableArray alloc]init];
    }
    return _allDetailNote;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    //添加一个滚动视图
    self.backScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, curScreenSize.width, curScreenSize.height)];
    [self.view addSubview:self.backScrollView];
    
    //监听通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reciveDoorlockMsg) name:@"DATABASE_UPDATE" object:nil];
    
    //右侧报警按钮
    self.alarmButton = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 40, 40)];
    [self.alarmButton setBackgroundImage:[UIImage imageNamed:@"safe_info_icon.png"] forState:UIControlStateNormal];
    [self.alarmButton addTarget:self action:@selector(btnSafeInfo) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithCustomView:self.alarmButton];
    self.navigationItem.rightBarButtonItem =item;
    
    //按钮上的数字
    [self alarmButtonAddAlarmNumber];
    
    self.title = @"门锁";
    
    //门锁
//    self.allDoorArray = [self getDoorlockInfo];
    NSLog(@"有门锁%lu个",(unsigned long)self.allDoorArray.count);
    CGFloat width      = curScreenSize.width / 5;
    //按照一行两个门，计算有多少行
//    for (int x = 0; x < 9; x++) {
//        [self.allDoorArray addObject:self.allDoorArray[0]];
//    }
    NSInteger x = self.allDoorArray.count % 2 + self.allDoorArray.count / 2;
    
    self.backScrollView.contentSize = CGSizeMake(curScreenSize.width, width * (x * 2 + 1));
    
    for (int row = 0; row < x; row++) {
        for (int y = 0; y < 2; y++) {
            CGRect DRDoorRect  = CGRectMake(width * (y * 2 + 1), width * (row * 2 + 1), width, width * 5 / 4);
            if (row * 2 + y >= self.allDoorArray.count) {
                break;
            }
            [self addDoorlockWith:self.allDoorArray[row * 2 + y] andFrame:DRDoorRect];
        }
    }
}
#pragma mark -界面事件
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self reciveDoorlockMsg];
}
//报警按钮添加数字
- (void)alarmButtonAddAlarmNumber{
    self.alarmNumberLabel= [[UILabel alloc]initWithFrame:CGRectMake(20, 20, 20, 20)];
    self.alarmNumberLabel.backgroundColor = [UIColor redColor];
    self.alarmNumberLabel.layer.cornerRadius = 10;
    self.alarmNumberLabel.layer.masksToBounds = YES;
    self.alarmNumberLabel.font = [UIFont systemFontOfSize:10];
    self.alarmNumberLabel.textAlignment = NSTextAlignmentCenter;
    self.alarmNumberLabel.textColor = [UIColor whiteColor];
    [self.alarmNumberLabel setHidden:YES];
    [self.alarmButton addSubview:self.alarmNumberLabel];
}
//添加门
- (void)addDoorlockWith:(ControlDeviceContentValue *)lock andFrame:(CGRect)frame{
    
//    NSLog(@"lockName %@",lockName);
    
//    ControlDeviceContentValue *value = [CYM_Engine getDeviceDetailsWithDeviceName:lockName];
    DoorView *doorView = [[DoorView alloc]initWithFrame:frame];
    [doorView setAttrWithCtrlValue:lock];
//    [doorView setIsNeedQuery:YES];
    [self.allDoorViewArray addObject:doorView];
    [appManager.aryActiveDevice addObject:doorView];
//    [self.view addSubview:doorView];
    [self.backScrollView addSubview:doorView];
}
//报警按钮点击
- (void)btnSafeInfo {
    SafeHistroyVC *safeHistoryVC = [[SafeHistroyVC alloc]init];
    safeHistoryVC.allNoBroseNote = self.allDetailNote;
    [self.navigationController pushViewController:safeHistoryVC animated:YES];
}

#pragma mark -数据处理
- (NSMutableArray *)getDoorlockInfo {
    return [CYM_Engine getAllDoorlockName];
}
- (NSMutableArray *)getDoorNoteInfo {
    NSString *lastDate = [[NSUserDefaults standardUserDefaults] objectForKey:@"LastDoorlockDate"];
    if (lastDate == nil || [lastDate isEqualToString:@""]) {
        lastDate = @"1970-1-1";
    }
    return [CYM_Engine getNewDoorlockNote:lastDate];
}
- (void)reciveDoorlockMsg{
    
    //解析警告
    NSMutableArray *allDoorNote = [self getDoorNoteInfo];
    //解析具体的通知内容，显示通知数字
    self.allDetailNote = [DoorlockNoteModel paserDoorlockNoteModelWithNote:allDoorNote];
    NSLog(@"有的新的报警%lu个",(unsigned long)self.allDetailNote.count);
    if (allDoorNote.count > 0) {
        AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
        [self.alarmNumberLabel setHidden:NO];
        self.alarmNumberLabel.text = [NSString stringWithFormat:@"%lu",(unsigned long)self.allDetailNote.count];
        for (DoorView *lock in self.allDoorViewArray) {
            for (DoorlockNote *note in allDoorNote) {
                if ([lock.num isEqualToString:note.devID]) {
                    [lock showExclamationMarkView];
                }
            }
        }
    }else {
        [self.alarmNumberLabel setHidden:YES];
        for (DoorView *lock in self.allDoorViewArray) {
            [lock removeExclamationMarkView];
        }
    }
}

@end
