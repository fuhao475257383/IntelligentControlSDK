//
//  DoorRemindCell.m
//  BWRemoter
//
//  Created by tc on 15/11/13.
//  Copyright © 2015年 ReSun. All rights reserved.
//

#import "DoorRemindCell.h"

@implementation DoorRemindCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.time = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, self.frame.size.width/4, 40)];
        self.name = [[UILabel alloc]initWithFrame:CGRectMake(self.frame.size.width/4, 0, self.frame.size.width/4, 40)];
        self.door = [[UILabel alloc]initWithFrame:CGRectMake(self.frame.size.width/2, 0, self.frame.size.width/4, 40)];
        self.info = [[UILabel alloc]initWithFrame:CGRectMake(self.frame.size.width*3/4, 0, self.frame.size.width/4, 40)];
        self.time.textColor = [UIColor blackColor];
        self.time.font      = [UIFont systemFontOfSize:13];
        self.time.textAlignment = NSTextAlignmentCenter;
        self.time.numberOfLines = 2;
        self.name.textColor = [UIColor blackColor];
        self.name.font      = [UIFont systemFontOfSize:13];
        self.name.textAlignment = NSTextAlignmentCenter;
        self.door.textColor = [UIColor blackColor];
        self.door.font      = [UIFont systemFontOfSize:13];
        self.door.textAlignment = NSTextAlignmentCenter;
        self.info.textColor = [UIColor blackColor];
        self.info.font      = [UIFont systemFontOfSize:13];
        self.info.textAlignment = NSTextAlignmentCenter;
        [self addSubview:self.time];
        [self addSubview:self.name];
        [self addSubview:self.door];
        [self addSubview:self.info];
    }
    return self;
}

- (void)awakeFromNib {
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
