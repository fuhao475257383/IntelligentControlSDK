//
//  SafeHistroyVC.h
//  BWRemoter
//
//  Created by tc on 15/11/12.
//  Copyright © 2015年 ReSun. All rights reserved.
//

#import "HE_BaseViewController.h"

@interface SafeHistroyVC : HE_BaseViewController

//所有没有看过的数据数组
@property (nonatomic,strong) NSMutableArray *allNoBroseNote;

@end
