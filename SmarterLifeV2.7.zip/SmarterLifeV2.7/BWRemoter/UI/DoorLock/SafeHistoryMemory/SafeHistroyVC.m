//
//  SafeHistroyVC.m
//  BWRemoter
//
//  Created by tc on 15/11/12.
//  Copyright © 2015年 ReSun. All rights reserved.
//

#import "SafeHistroyVC.h"
#import "DoorRemindCell.h"
#import "DoorlockMsg.h"
#import "DoorlockNoteModel.h"

@interface SafeHistroyVC () <UITableViewDataSource,UITableViewDelegate>

//表视图
@property (nonatomic,strong) UITableView *table;
//所有通知,该数据只是表示数据库中的通知个数，由于数据设计的问题，导致一个数据里可能有几个报警或者通知信息
@property (nonatomic,strong) NSMutableArray *allNote;
//报警指示代号
@property (nonatomic,strong) NSArray *alarm;
//电压指示
@property (nonatomic,strong) NSArray *power;
//操作指示
@property (nonatomic,strong) NSArray *operate;
//所有应该显示的数据数组，包括了所有的报警和通知信息
@property (nonatomic,strong) NSMutableArray *allNoteMSG;

@end

@implementation SafeHistroyVC

- (NSArray *)alarm {
    if (!_alarm) {
        _alarm = @[@"正常",@"挟持报警",@"防撬报警",@"密码输入错误报警",@"其它报警"];
    }
    return _alarm;
}
- (NSArray *)power {
    if (!_power) {
        _power = @[@"正常",@"低压警告",@"低压严重警告"];
    }
    return _power;
}
- (NSArray *)operate {
    if (!_operate) {
        _operate = @[@"钥匙开门",@"密码开门",@"指纹开门",@"家庭网关开门",@"卡开门",@"关门",@"门未关好",@"离家"];
    }
    return _operate;
}
- (NSMutableArray *)allNoteMSG {
    if (!_allNoteMSG) {
        _allNoteMSG = [NSMutableArray new];
    }
    return _allNoteMSG;
}
- (NSMutableArray *)allNoBroseNote {
    if (!_allNoBroseNote) {
        _allNoBroseNote = [NSMutableArray new];
    }
    return _allNoBroseNote;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    //获取前500条信息
    self.allNote = [CYM_Engine getTop500DoorlockNoteInfo];
    //将note解析成数据
    [self parserAllNote];
    
    self.title = @"门锁历史记录";
    [self addViewInfo];
    [self addTableView];
    
    
    [[NSUserDefaults standardUserDefaults] setObject:[CYM_Engine getNewDoorlockNoteDate] forKey:@"LastDoorlockDate"];
//    NSLog(@"最新的时间%@",[[NSUserDefaults standardUserDefaults] objectForKey:@"LastDoorlockDate"]);
}
#pragma mark - 界面事件
//添加分段label
- (void)addViewInfo {
    [self addLabelWithWidth:0 andTitle:@"时间"];
    [self addLabelWithWidth:curScreenSize.width/4 andTitle:@"成员"];
    [self addLabelWithWidth:curScreenSize.width/2 andTitle:@"门锁"];
    [self addLabelWithWidth:curScreenSize.width*3/4 andTitle:@"事件"];
}
//添加label
- (void)addLabelWithWidth:(CGFloat)rectX andTitle:(NSString *)title{
    CGFloat width       = curScreenSize.width / 4;
    UILabel *label      = [[UILabel alloc]initWithFrame:CGRectMake(rectX, 64, width, 40)];
    label.text          = title;
    label.textColor     = [UIColor blackColor];
    label.textAlignment = NSTextAlignmentCenter;
    label.font          = [UIFont systemFontOfSize:15];
    
    label.layer.borderWidth = 1;
    label.layer.borderColor = [UIColor blackColor].CGColor;
    [self.view addSubview:label];
}
//增加tableView
- (void)addTableView {
    //tableView的背景view
    UIView *tableBackView = [[UIView alloc]initWithFrame:CGRectMake(0, 104, curScreenSize.width, curScreenSize.height - 104)];
    [self.view addSubview:tableBackView];
    
    //增加内容
    self.table = [[UITableView alloc]initWithFrame:tableBackView.bounds style:UITableViewStylePlain];
    self.table.delegate = self;
    self.table.dataSource = self;
    self.table.allowsSelection = NO;
    self.table.tableFooterView = [UIView new];
    [self.table registerClass:[DoorRemindCell class] forCellReuseIdentifier:@"doorCell"];
    [tableBackView addSubview:self.table];
}
#pragma mark -tabelview
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.allNoteMSG.count;
}
- (DoorRemindCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    DoorRemindCell *cell = [tableView dequeueReusableCellWithIdentifier:@"doorCell" forIndexPath:indexPath];
    DoorlockNoteModel *model = self.allNoteMSG[indexPath.row];
    
    if (model.isNeedShowRedWord == YES) {
        cell.time.textColor = [UIColor redColor];
        cell.name.textColor = [UIColor redColor];
        cell.door.textColor = [UIColor redColor];
        cell.info.textColor = [UIColor redColor];
    }else {
        cell.time.textColor = [UIColor blackColor];
        cell.name.textColor = [UIColor blackColor];
        cell.door.textColor = [UIColor blackColor];
        cell.info.textColor = [UIColor blackColor];
    }
    cell.time.text = model.time;
    cell.name.text = model.role;
    cell.door.text = model.doorlock;
    cell.info.text = model.event;
    
    //根据是否进入看过报警，显示字体颜色,如果是未看的数据，显示为正常颜色，否则字体呈灰色
    for (DoorlockNoteModel *note in self.allNoBroseNote) {
//        NSLog(@"note.time %@    model.time %@",note.time,model.time);
        if ([note.time isEqualToString:model.time]) {
            cell.time.alpha = 1;
            cell.name.alpha = 1;
            cell.door.alpha = 1;
            cell.info.alpha = 1;
            return cell;
        }
    }
    cell.time.alpha = 0.5;
    cell.name.alpha = 0.5;
    cell.door.alpha = 0.5;
    cell.info.alpha = 0.5;
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 40;
}
#pragma mark -数据处理
//解析所有数据
- (void)parserAllNote {
    self.allNoteMSG = [DoorlockNoteModel paserDoorlockNoteModelWithNote:self.allNote];
}

@end
