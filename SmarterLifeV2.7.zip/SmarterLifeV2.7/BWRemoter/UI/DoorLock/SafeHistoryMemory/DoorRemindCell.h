//
//  DoorRemindCell.h
//  BWRemoter
//
//  Created by tc on 15/11/13.
//  Copyright © 2015年 ReSun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DoorRemindCell : UITableViewCell
//时间
@property (nonatomic,strong) UILabel *time;
//成员
@property (nonatomic,strong) UILabel *name;
//门锁
@property (nonatomic,strong) UILabel *door;
//操作
@property (nonatomic,strong) UILabel *info;

@end
