//
//  FXW_SetVC.h
//  BWRemoter
//
//  Created by 6602_Loop on 15-1-2.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "HE_BaseViewController.h"

@interface FXW_SetVC : HE_BaseViewController<UITextFieldDelegate,UIAlertViewDelegate>
{
    BOOL isChecked;
    BOOL notClear;
    UITextField *password;
    UITextField *num;
    UITextField *sn;
    NSString *Chooseimg;
    NSString *Choosenimg;
    UIImageView *remimg;
}
@property (nonatomic,strong)UIView *backview;
-(void)Checked;
-(void)BtnClick;
@end
