//
//  HE_ScanTwoCodeVC.h
//  BWRemoter
//
//  Created by HeJianBo on 15/3/12.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "HE_BaseViewController.h"

@interface HE_ScanTwoCodeVC : HE_BaseViewController

@end
