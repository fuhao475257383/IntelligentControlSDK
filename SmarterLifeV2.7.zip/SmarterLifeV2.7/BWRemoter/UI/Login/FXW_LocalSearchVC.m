//
//  FXW_LocalSearchVC.m
//  BWRemoter
//
//  Created by 6602_Loop on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "FXW_LocalSearchVC.h"
#import "FXW_TableViewCell.h"


@interface FXW_LocalSearchVC ()

@end

@implementation FXW_LocalSearchVC
@synthesize table;
@synthesize logo;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    if(IP==nil){
        IP=@[@"192.168.0.150",@"192.168.0.151"];
        SN = @[@"00",@"01"];
        
    }
    if(IsChecked==false){
        checkimg = @"radiobox_uncheck.png";
        checkedimg = @"radiobox_checked.png";
    }
    table = [[UITableView alloc]initWithFrame:CGRectMake(0.0f,0.0f, curScreenSize.width,400) style:UITableViewStylePlain];
    
    [table setBackgroundColor:[UIColor clearColor]];
//    table.SeparatorStyle = YES;
    [table setDelegate:self];
    [table setDataSource:self];
    [self.view addSubview:table];
    table.tableFooterView = [[UIView alloc]init];
    
    UIButton *Btn = [[UIButton alloc]initWithFrame:CGRectMake(curScreenSize.width*0.35, 430, 100, 35)];
    Btn.layer.cornerRadius = 5.f;
    [Btn setBackgroundColor:[UIColor grayColor]];
    [Btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    Btn.titleLabel.font = [UIFont systemFontOfSize:24.0f];
    [Btn setTitle:@"确定" forState:UIControlStateNormal];
    [self.view addSubview:Btn];
    [Btn addTarget:self action:@selector(BtnClick) forControlEvents:UIControlEventTouchUpInside];
    
    //HE
    //搜索网关
    [appManager hudDisplayLoadingWithTitle:nil details:@"网关搜索中..."];
    [appManager discoverGateway];
    IP = appManager.soktMangaer.aryGateway;
    SN = appManager.soktMangaer.aryGatewaySN;
    

    
}
- (void)reloadData:(NSString *)strCMD{
    [super reloadData:strCMD];
    [self.table reloadData];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return IP.count;
}
///table点击
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if(path!=nil){
        FXW_TableViewCell *cell2 = (FXW_TableViewCell *)[tableView cellForRowAtIndexPath:path];
        [cell2 changeBG:nil];
    }
    FXW_TableViewCell *cell = (FXW_TableViewCell *)[tableView cellForRowAtIndexPath:indexPath];
    [cell changeBG:nil];
    tmpSN = SN[indexPath.row];
    tmpSN = [tmpSN substringFromIndex:tmpSN.length - 8];
    path = indexPath;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    FXW_TableViewCell *cell= [tableView dequeueReusableCellWithIdentifier:@"123"];
    
    if (cell==nil) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"FXW_TableViewCell" owner:self options:nil] objectAtIndex:0];
    }
    NSInteger indx    = indexPath.row + 1;
    NSString *strName = [NSString stringWithFormat:@"网关%ld",(long)indx];
    NSString *strSN   = SN[indexPath.row];
    NSString *strIP   = IP[indexPath.row];
    
    strSN = [strSN substringFromIndex:strSN.length - 8];
    [cell setTitle:strName IP:strIP SN:strSN  Logo:[UIImage imageNamed:@"radiobox_uncheck.png"]];
    if([strSN isEqualToString:tmpSN]){
        [cell changeBG:nil];
    }
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    [cell setAccessoryType:UITableViewCellAccessoryNone];
    [cell setBackgroundColor:[UIColor clearColor]];
    
    return cell;
}
-(void)BtnClick{
    @try {
        appManager.User.strSN =  SN[path.row];
        [self.navigationController popToRootViewControllerAnimated:YES];
    }
    @catch (NSException *exception) {
        [self.navigationController popToRootViewControllerAnimated:YES];
    }
    @finally {
        
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 100.0f;
}
@end
