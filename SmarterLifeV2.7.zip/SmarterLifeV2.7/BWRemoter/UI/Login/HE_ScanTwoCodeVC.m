//
//  HE_ScanTwoCodeVC.m
//  BWRemoter
//
//  Created by HeJianBo on 15/3/12.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "HE_ScanTwoCodeVC.h"
#import "ZBarSDK.h"

@interface HE_ScanTwoCodeVC ()<ZBarReaderViewDelegate>
{
    ZBarReaderView *readerView;
    
    ///////////////Test
    UILabel        *labReslt;
}
@end

@implementation HE_ScanTwoCodeVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"二维码扫描";
    ZBarImageScanner *scanner = [[ZBarImageScanner alloc] init];
    readerView                = [[ZBarReaderView alloc] initWithImageScanner:scanner];
    readerView.frame          = CGRectMake(0, 0, curScreenSize.width, curScreenSize.height);
    readerView.tracksSymbols  = NO; //////取消扫描跟踪框
    readerView.torchMode      = 0;  //////关闭闪光灯
    readerView.readerDelegate = self;
    [readerView start];
    /////////////////局部区域
    UIView *scanView            = [[UIView alloc] initWithFrame:CGRectMake((readerView.frameW - 200)/2.f, (readerView.frameH - 200)/2.f, 200, 200)];
    scanView.layer.cornerRadius = 3.f;
    scanView.layer.borderWidth  = 2.f;
    scanView.layer.borderColor  = [UIColor colorWithWhite:0.9 alpha:1].CGColor;
    scanView.backgroundColor    = [UIColor clearColor];
    scanView.clipsToBounds      = YES;
    readerView.scanCrop         = [self getScanCrop:scanView.frame readerViewBounds:readerView.bounds];
    [readerView addSubview:scanView];
    UILabel *labTip = [[UILabel alloc]initWithFrame:CGRectMake(scanView.frameX, scanView.frameSumY_H+5, scanView.frameW, 20)];
    [labTip setText:@"将二维码/条形码放置框内，即开始扫描"];
    [labTip setTextColor:[UIColor whiteColor]];
    labTip.adjustsFontSizeToFitWidth = YES;
    [readerView addSubview:labTip];
    /////////////////Test
    labReslt = [[UILabel alloc] initWithFrame:CGRectMake(self.view.frameW/2.f - 50, curScreenSize.height * 0.75, 100, 30)];
    
    /////////////////ScanerLine
    CALayer *scanLine        = [CALayer layer];
    scanLine.frame           = CGRectMake(scanView.frameX + 15 , 10, scanView.frameW - 20, 3);
    scanLine.cornerRadius    = 10;
    scanLine.backgroundColor = [UIColor colorWithWhite:0.9 alpha:0.8].CGColor;
    
    CAKeyframeAnimation *animation = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    
    animation.values = @[[NSValue valueWithCGPoint:scanLine.frame.origin],
                         [NSValue valueWithCGPoint:CGPointMake(scanLine.frame.origin.x, scanView.frameH - 10)],
                         [NSValue valueWithCGPoint:scanLine.frame.origin]];
    animation.duration    = 3.f;
    animation.repeatCount = MAXFLOAT;
    animation.calculationMode = kCAAnimationLinear;
    [scanLine addAnimation:animation forKey:@"SCAN"];
    [scanView.layer addSublayer:scanLine];
    
    
    
    
    
    [self.view addSubview:readerView];
    [self.view insertSubview:labReslt aboveSubview:readerView];
}

- (void)readerView:(ZBarReaderView *)readerView didReadSymbols:(ZBarSymbolSet *)symbols fromImage:(UIImage *)image{
    ZBarSymbol *symbol = nil;
    for (symbol in symbols) {
        break;
    }
    labReslt.text = symbol.data;
    appManager.User.strSN = symbol.data;
    [self.navigationController popViewControllerAnimated:YES];
    
}

#pragma mark - Private
//设置可扫描区的scanCrop的方法
-(CGRect)getScanCrop:(CGRect)rect readerViewBounds:(CGRect)readerViewBounds
{
    CGFloat x,y,width,height;
    x = rect.origin.x / readerViewBounds.size.width;
    y = rect.origin.y / readerViewBounds.size.height;
    width = rect.size.width / readerViewBounds.size.width;
    height = rect.size.height / readerViewBounds.size.height;
    return CGRectMake(x, y, width, height);
}
@end
