//
//  FXW_SetVC.m
//  BWRemoter
//
//  Created by 6602_Loop on 15-1-2.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "FXW_SetVC.h"
#import "FXW_ShowVC.h"
#import "FXW_LocalSearchVC.h"
#import "HE_ScanTwoCodeVC.h"

#define TAG_VIEW_NUM 10000
#define TAG_VIEW_PWD 10001
#define TAG_VIEW_SN  10002

@implementation FXW_SetVC
@synthesize backview;
- (CGRect)textRectForBounds:(CGRect)bounds {
    return CGRectInset( bounds , 20 , 0 );
}
- (id)init{
    self = [super init];
    if (self) {
        self.title = @"";
    }
    return self;
}
- (void)viewDidLoad {

    [super viewDidLoad];
//    self.navigationItem.leftBarButtonItem = nil;

    Chooseimg = @"no.png";
    Choosenimg = @"yes.png";
    isChecked = false;
    [self.view setBackgroundColor:[UIColor colorWithRed:245/255.0 green: 245/255.0 blue:245/255.0 alpha:255/255.0]];
    backview = [[UIView alloc]initWithFrame:CGRectMake(curScreenSize.width*0.05, 100, curScreenSize.width*0.9, 100)];
    backview.layer.cornerRadius = 8.f;
    backview.layer.borderColor = [[UIColor grayColor] CGColor];//Border颜色
    backview.layer.borderWidth = 1.f;//Border宽度
    [backview setBackgroundColor:[UIColor whiteColor]];
    [self.view addSubview:backview];
    

    //账号
    num = [[UITextField alloc]initWithFrame:CGRectMake(5, 0, curScreenSize.width*0.9, 45)];
    UIImageView *user = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"userlogin.png"]];
    [user setFrame:CGRectMake(0, 0, 35, 35)];
    num.leftView = user;
    num.delegate = self;
    num.leftViewMode = UITextFieldViewModeAlways;
    num.clearButtonMode = UITextFieldViewModeWhileEditing;
    num.returnKeyType = UIReturnKeyNext;
    num.keyboardType = UIKeyboardTypeDefault;
    num.keyboardAppearance = UIKeyboardAppearanceDefault;
    num.tag = TAG_VIEW_NUM;
    [backview addSubview:num];
    //线线
    UIView *line = [[UIView alloc]initWithFrame:CGRectMake(0, 50,curScreenSize.width*0.9, 1)];
    line.layer.borderWidth = 1.f;
    line.layer.borderColor = [[UIColor grayColor]CGColor];
    [backview addSubview:line];
    
    //password
    password = [[UITextField alloc]initWithFrame:CGRectMake(5, 55, curScreenSize.width*0.9, 45)];
    password.secureTextEntry = YES;
    UIImageView *pwd = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"pwd.png"]];
    [pwd setFrame:CGRectMake(0, 0, 35, 35)];
    password.leftView=pwd;
    password.leftViewMode = UITextFieldViewModeAlways;
    password.delegate = self;
    password.clearButtonMode = UITextFieldViewModeWhileEditing;
    password.returnKeyType = UIReturnKeyNext;
    password.keyboardType = UIKeyboardTypeDefault;
    password.keyboardAppearance = UIKeyboardAppearanceDefault;
    password.tag = TAG_VIEW_PWD;
    [backview addSubview:password];
    
    ///记住密码
    remimg = [[UIImageView alloc]initWithFrame:CGRectMake(curScreenSize.width*0.1, 220, 30, 30)];
    [remimg setImage:[UIImage imageNamed:Chooseimg]];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(Checked)];
    remimg.userInteractionEnabled = YES;
    [remimg addGestureRecognizer:tap];
    
    //清空缓存数据
    UIButton *clear = [[UIButton alloc]initWithFrame:CGRectMake(curScreenSize.width-80-curScreenSize.width*0.1-40, 220, 80, 30)];
    [clear setTitle:@"清空缓存" forState:UIControlStateNormal];
    [clear setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [clear addTarget:self action:@selector(clearCache) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:clear];
    
    [self.view addSubview:remimg];
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(curScreenSize.width*0.1+40, 220, 80, 30)];
    [label setText:@"记住密码"];
    [self.view addSubview:label];
    
    //网关sn
    sn = [[UITextField alloc]initWithFrame:CGRectMake(curScreenSize.width*0.05, 280, curScreenSize.width*0.9, 50)];
    sn.delegate           = self;
    sn.tag                = TAG_VIEW_SN;
    sn.backgroundColor    = [UIColor whiteColor];
    sn.layer.cornerRadius = 8.f;
    sn.layer.borderColor  = [UIColor grayColor].CGColor;
    sn.layer.borderWidth  = 1.f;
    sn.placeholder        = @"网关SN号";
    sn.clearButtonMode    = UITextFieldViewModeWhileEditing;
    sn.returnKeyType      = UIReturnKeyDone;
    sn.keyboardType       = UIKeyboardTypeDefault;
    sn.leftViewMode       = UITextFieldViewModeAlways;
    sn.leftView           = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, sn.frameH)];
    
    [self.view addSubview:sn];
    
    //本地搜索
    UIButton *search = [[UIButton alloc]initWithFrame:CGRectMake(curScreenSize.width*0.2, 350, 100, 30)];
    search.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [search setTitle:@"本地搜索" forState:UIControlStateNormal];
    [search setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [search addTarget:self action:@selector(SearchLocal) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview: search];
    //放大镜
    UIImageView *img = [[UIImageView alloc]initWithFrame:CGRectMake(80, 5, 20, 20)];
    [img setImage:[UIImage imageNamed:@"login_icon_search.png"]];
    [search addSubview:img];
    //分割线
    UIView *line2 = [[UIView alloc]initWithFrame:CGRectMake(curScreenSize.width*0.55,355, 2, 20)];
    line2.layer.borderWidth = 1.f;
    line2.layer.borderColor = [[UIColor blackColor]CGColor];
    [self.view addSubview:line2];
    //二维码扫描
    UIButton *search2 = [[UIButton alloc]initWithFrame:CGRectMake(curScreenSize.width*0.6, 350, 100, 30)];
    [search2 setTitle:@"二维码扫描" forState:UIControlStateNormal];
    [search2 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [search2 addTarget:self action:@selector(touchedScaner:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:search2];
    
    //确定按钮
    UIButton *Btn = [[UIButton alloc]initWithFrame:CGRectMake(curScreenSize.width*0.35, 430, 100, 35)];
    Btn.layer.cornerRadius = 5.f;
    [Btn setBackgroundColor:[UIColor grayColor]];
    [Btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    Btn.titleLabel.font = [UIFont systemFontOfSize:24.0f];
    [Btn setTitle:@"确定" forState:UIControlStateNormal];
    [self.view addSubview:Btn];
    [Btn addTarget:self action:@selector(BtnClick) forControlEvents:UIControlEventTouchUpInside];
    //////
    
}
//清空缓存
- (void)clearCache {
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示！" message:@"该操作会清空APP的缓存！\n是否清空？" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确认清空", nil];
    [alert show];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 1) {
        NSString *sourcePath     =[[NSBundle mainBundle]pathForResource:@"BWDatabase_V2"  ofType: @"sqlite"];
        NSFileManager *fileManager =[NSFileManager defaultManager];
        NSString *documentsStr   = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
        NSString *toFilePath     =[NSString stringWithFormat:@"%@/BWDatabase_V2.sqlite",documentsStr];
        
        [fileManager removeItemAtPath:toFilePath error:nil];
        [fileManager copyItemAtPath:sourcePath toPath:toFilePath error:nil];
        
        [appManager hudShowMsg:@"清空成功！" andInterval:1];
    }
}
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    num.text            = appManager.User.strName;
    sn.text             = appManager.User.strSN;
    
    if (appManager.User.isRememberPWD && ![appManager.User.strPwd isEqualToString:@""]) {
        password.text       = appManager.User.strPwd;
        [remimg setImage:[UIImage imageNamed:Choosenimg]];
        isChecked = true;
    }
    ///////////
//    NSString *strDeviceToken = [[NSUserDefaults standardUserDefaults] objectForKey:@"DEVICE_TOKEN"];
//    sn.text = strDeviceToken;
//    sn.text = @"0013010103010100000000000702";
}

- (void)touchedBackButton:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}

///点击确定
 -(void)BtnClick{

     appManager.User.strName       = num.text;
     appManager.User.strPwd        = password.text;
//     appManager.User.strName = @"admin";
//     appManager.User.strPwd = @"admin";
     appManager.User.strSN         = sn.text;
     appManager.User.isRememberPWD = isChecked;
     
     [self dismissViewControllerAnimated:YES completion:nil];
}
-(void)SearchLocal{
    notClear                = YES;
    appManager.User.strName = num.text;
    appManager.User.strPwd  = password.text;
    appManager.User.strSN   = sn.text;
    appManager.User.isRememberPWD = isChecked;
    
    FXW_LocalSearchVC *searchlocal = [[FXW_LocalSearchVC alloc]init];
    [self.navigationController pushViewController:searchlocal animated:YES];
}
- (void)touchedScaner:(UIButton *)btnSender{
    HE_ScanTwoCodeVC *vc = [[HE_ScanTwoCodeVC alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
}

///收起键盘
-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}
//记住密码
-(void) Checked{
    if(isChecked){
        [remimg setImage:[UIImage imageNamed:Chooseimg]];
        isChecked = false;
    }
    else{
        [remimg setImage:[UIImage imageNamed:Choosenimg]];
        isChecked = true;
    }
    appManager.User.isRememberPWD = isChecked;
}

- (void)setFeild:(UITextField *)feild forKey:(NSString *)key{
    if (feild.text != nil) {
        [[NSUserDefaults standardUserDefaults] setObject:feild.text forKey:key];
    }
    else
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:key];
}

@end
