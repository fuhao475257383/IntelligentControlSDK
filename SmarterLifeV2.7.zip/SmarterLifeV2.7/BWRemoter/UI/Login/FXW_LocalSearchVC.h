//
//  FXW_LocalSearchVC.h
//  BWRemoter
//
//  Created by 6602_Loop on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "HE_BaseViewController.h"

@interface FXW_LocalSearchVC : HE_BaseViewController<UITableViewDataSource,UITableViewDelegate>
{
    NSArray *IP;
    NSArray *SN;
    NSString *checkimg;
    NSString *checkedimg;
    BOOL IsChecked;
    NSIndexPath *path;
    NSString *tmpSN;
}
@property(nonatomic,retain) IBOutlet UITableView *table;
@property UIImageView *logo;


@end
