//
//  CommondVC.m
//  BWRemoter
//
//  Created by JianBo He on 14/12/5.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//
#import "CommondVC.h"
#import "HE_NavgationController.h"

#import "SetdateVC.h"
#import "FXW_LightVC.h"
#import "Curtain/FXW_CurtainVC.h"
#import "ScenoMode/FXW_ScenoModeVC.h"
#import "Condition/FXW_ConditionVC.h"
#import "Fxw_Room.h"
#import "Room.h"
#import "RoomDevice.h"
#import "PagedScrollView.h"
#import "DoorLockVC.h"
#import "SafeHistroyVC.h"
#import "DoorlockNoteModel.h"
#import <AVFoundation/AVFoundation.h>

@interface CommondVC (){
//    UIScrollView *srcollView;
    PagedScrollView *srcollView;
    NSArray *aryLeftImg;
    NSArray *aryRightImg;
}

//报警数字
@property (nonatomic,strong) UILabel *alarmNumberLabel;
//报警按钮
@property (nonatomic,strong) UIButton *alarmButton;
//所有未阅读的报警
@property (nonatomic,strong) NSMutableArray *allNoBroseNote;

@end

@implementation CommondVC
@synthesize aryroom;
@synthesize arydevice;
@synthesize arycontent,btnleft,btnright;
- (NSMutableArray *)allNoBroseNote {
    if (!_allNoBroseNote) {
        _allNoBroseNote = [NSMutableArray new];
    }
    return _allNoBroseNote;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    //监听通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reciveDoorlockMsg) name:@"DATABASE_UPDATE" object:nil];
    
    //设置左上角门锁图案
    self.alarmButton = [[UIButton alloc]initWithFrame:CGRectMake(0, 17, 40, 40)];
    [self.alarmButton setImage:[UIImage imageNamed:@"icon_alarm_doorlock.png"] forState:UIControlStateNormal];
    [self.alarmButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.alarmButton addTarget:self action:@selector(jumpToGateLockVC:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *gateButton = [[UIBarButtonItem alloc]initWithCustomView:self.alarmButton];
    //按钮上的数字
    [self alarmButtonAddAlarmNumber];
    
    aryLeftImg = @[[UIImage imageNamed:@"left1.png"],[UIImage imageNamed:@"left2.png"],[UIImage imageNamed:@"left3.png"]];
    aryRightImg = @[[UIImage imageNamed:@"right1.png"],[UIImage imageNamed:@"right2.png"],[UIImage imageNamed:@"right3.png"]];
    imgIndex = 0;
 

    
    ///定时按钮
    /***********右侧按钮************/
    UIButton *btnTime = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 40, 40)];
    [btnTime setBackgroundImage:[UIImage imageNamed:@"time_icon.png"] forState:UIControlStateNormal];
    UIBarButtonItem *timeitem = [[UIBarButtonItem alloc] initWithCustomView:btnTime];
    [btnTime addTarget:self action:@selector(btnTimeClick) forControlEvents:UIControlEventTouchUpInside];    
    ////////走马灯右
    btnright = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 40, 40/2.5)];
    [btnright setBackgroundImage:[UIImage imageNamed:@"right1.png"] forState:UIControlStateNormal];
    UIBarButtonItem *rig = [[UIBarButtonItem alloc] initWithCustomView:btnright];
    NSArray *aryBtn = [NSArray arrayWithObjects:timeitem,rig, nil];
    self.navigationItem.rightBarButtonItems =aryBtn;
    btnright.tag = 1111;
    [btnright addTarget:self action:@selector(roomTurn:) forControlEvents:UIControlEventTouchUpInside];
    /******************************/
    ///////走马灯左
//    UIView *viewLeft = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 40, 40)];
//    UIBarButtonItem *btnLeft1 = [[UIBarButtonItem alloc]initWithCustomView:viewLeft];
    btnleft = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 40, 40/2.5)];
    [btnleft setBackgroundImage:[UIImage imageNamed:@"left1.png"] forState:UIControlStateNormal];
    UIBarButtonItem *btnLeft = [[UIBarButtonItem alloc] initWithCustomView:btnleft];
    NSArray *aryBtnLeft = [NSArray arrayWithObjects:gateButton,btnLeft,nil];
    self.navigationItem.leftBarButtonItems =aryBtnLeft;
    
    btnleft.tag = 2222;
    [btnleft addTarget:self action:@selector(roomTurn:) forControlEvents:UIControlEventTouchUpInside];
    /////////////走马灯循环Timer
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        pictureTimer=[NSTimer scheduledTimerWithTimeInterval:1.0
                                                           target:self
                                                         selector:@selector(ChangeImgwithTimer)
                                                         userInfo:nil
                                                          repeats:YES] ;
        [[NSRunLoop currentRunLoop] addTimer:pictureTimer forMode:NSDefaultRunLoopMode];
        [[NSRunLoop currentRunLoop] run];
    });
    if(aryroom.count>0){
        roomname = [NSMutableArray arrayWithObject:((Room *)aryroom[0]).name];
        for(int i =1;i<aryroom.count;i++){
            [roomname addObject:((Room *)aryroom[i]).name];
        }
    }
    
    NSMutableArray *aryRoomView = [NSMutableArray array];
    for(int i=0;i<roomname.count;i++){
        Fxw_Room *room = [[Fxw_Room alloc] init];
        self.navigationItem.title = roomname[0];
        [room SetName:((Room *)aryroom[i]).deviceArr];
        [room setDelegate:self.navigationController];
        [room setTag:9001];
        [aryRoomView addObject:room];
    }
    self.automaticallyAdjustsScrollViewInsets = NO;
    srcollView = [[PagedScrollView alloc] initWithFrame:CGRectMake(0,self.NavgationBarHeight ,curScreenSize.width,
                                                                   curScreenSize.height-self.NavgationBarHeight-self.tabBarController.tabBar.frameH)
                                                                   andViews:aryRoomView
                                                               pagedHanlder:^(PagedScrollView *pageView, NSInteger toIndex) {
                                                                   UINavigationItem *title = [self navigationItem];
                                                                   [title setTitle:roomname[toIndex]];
                                                                   NSDictionary *attr = [NSDictionary dictionaryWithObjectsAndKeys:[UIColor blackColor], NSForegroundColorAttributeName, nil];
                                                                   [self.navigationController.navigationBar setTitleTextAttributes:attr];
    
                                                               }];
    [self.view addSubview:srcollView];
    
    
    /////////通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reciveDataBaseUpdate) name:@"DATABASE_UPDATE" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reciveDataBaseUpdate) name:@"ROOM_UPDATE" object:nil];
}
//报警按钮添加数字
- (void)alarmButtonAddAlarmNumber{
    self.alarmNumberLabel= [[UILabel alloc]initWithFrame:CGRectMake(20, 20, 20, 20)];
    self.alarmNumberLabel.backgroundColor = [UIColor redColor];
    self.alarmNumberLabel.layer.cornerRadius = 10;
    self.alarmNumberLabel.layer.masksToBounds = YES;
    self.alarmNumberLabel.font = [UIFont systemFontOfSize:10];
    self.alarmNumberLabel.textAlignment = NSTextAlignmentCenter;
    self.alarmNumberLabel.textColor = [UIColor whiteColor];
    [self.alarmNumberLabel setHidden:YES];
    [self.alarmButton addSubview:self.alarmNumberLabel];
}
//跳转报警页面，不要在意方法名
- (void)jumpToGateLockVC:(id)sender {
    SafeHistroyVC *gateVC = [[SafeHistroyVC alloc]init];
    gateVC.hidesBottomBarWhenPushed = YES;
    gateVC.allNoBroseNote = self.allNoBroseNote;
    [self.navigationController pushViewController:gateVC animated:YES];
}
// 注销
- (void)touchedLoginOut:(id)sender {
    [self dismissViewControllerAnimated:true completion:nil];
}

////走马灯
-(void)ChangeImgwithTimer{
    [btnleft setBackgroundImage:aryLeftImg[imgIndex] forState:UIControlStateNormal];
    [btnright setBackgroundImage:aryRightImg[imgIndex] forState:UIControlStateNormal];
    imgIndex = imgIndex==2?0 :imgIndex+1;
}
-(void)roomTurn:(UIButton *)sender{
    if (sender.tag == 1111) {
        [srcollView toNextPage];
    }
    else{
        [srcollView toPrePage];
    }
}
-(void)btnTimeClick{
    SetdateVC *clock = [[SetdateVC alloc]init];
    clock.hidesBottomBarWhenPushed=YES;
    [self.navigationController pushViewController:clock animated:YES];
}

#pragma mark - ScrollView Delegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    int page = scrollView.contentOffset.x/curScreenSize.width;
    UINavigationItem *title = [self navigationItem];
    [title setTitle:roomname[page]];
    NSDictionary *attr = [NSDictionary dictionaryWithObjectsAndKeys:[UIColor blackColor], NSForegroundColorAttributeName, nil];
    [self.navigationController.navigationBar setTitleTextAttributes:attr];
}
#pragma mark - 收到文件更新
- (void)reciveDataBaseUpdate{
    aryroom = [CYM_Engine getRoomAllDevice];
    roomname = nil;
    /////重新布局
    if(aryroom.count>0){
        roomname = [NSMutableArray arrayWithObject:((Room *)aryroom[0]).name];
        for(int i =1;i<aryroom.count;i++){
            [roomname addObject:((Room *)aryroom[i]).name];
        }
    }
    [srcollView removeFromSuperview];
    NSMutableArray *aryRoomView = [NSMutableArray array];
    for(int i=0;i<roomname.count;i++){
        Fxw_Room *room = [[Fxw_Room alloc] init];
        self.navigationItem.title = roomname[0];
        [room SetName:((Room *)aryroom[i]).deviceArr];
        [room setDelegate:self.navigationController];
        [room setTag:9001];
        [aryRoomView addObject:room];
    }
    self.automaticallyAdjustsScrollViewInsets = NO;
    srcollView = [[PagedScrollView alloc] initWithFrame:CGRectMake(0,self.NavgationBarHeight ,curScreenSize.width,
                                                                   curScreenSize.height-self.NavgationBarHeight-self.tabBarController.tabBar.frameH)
                                               andViews:aryRoomView
                                           pagedHanlder:^(PagedScrollView *pageView, NSInteger toIndex) {
                                               UINavigationItem *title = [self navigationItem];
                                               [title setTitle:roomname[toIndex]];
                                               NSDictionary *attr = [NSDictionary dictionaryWithObjectsAndKeys:[UIColor blackColor], NSForegroundColorAttributeName, nil];
                                               [self.navigationController.navigationBar setTitleTextAttributes:attr];
                                               
                                           }];
    [self.view addSubview:srcollView];
}
#pragma mark -界面事件
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self reciveDoorlockMsg];
}
#pragma mark -数据处理
- (NSMutableArray *)getDoorlockInfo {
    return [CYM_Engine getAllDoorlockName];
}
- (NSMutableArray *)getDoorNoteInfo {
    NSString *lastDate = [[NSUserDefaults standardUserDefaults] objectForKey:@"LastDoorlockDate"];
    if (lastDate == nil || [lastDate isEqualToString:@""]) {
        lastDate = @"1970-1-1";
    }
    return [CYM_Engine getNewDoorlockNote:lastDate];
}
- (void)reciveDoorlockMsg{
    
    //解析出来的新的报警
    NSMutableArray *allNote = [self getDoorNoteInfo];
    //解析报警后得的最终结果，因为一条报警包含了开门关门操作和门的状态报警
    self.allNoBroseNote = [DoorlockNoteModel paserDoorlockNoteModelWithNote:allNote];
//    NSLog(@"有的新的报警%lu个",(unsigned long)self.allNoBroseNote.count);
    if (self.allNoBroseNote.count > 0) {
        AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
        [self.alarmNumberLabel setHidden:NO];
        self.alarmNumberLabel.text = [NSString stringWithFormat:@"%lu",(unsigned long)self.allNoBroseNote.count];
        //tabbar加上提示数字
        UITabBarItem *tabBarItem = [[[self.tabBarController tabBar]items]objectAtIndex:0];
        [tabBarItem setBadgeValue:[NSString stringWithFormat:@"%lu",(unsigned long)self.allNoBroseNote.count]];
    }else {
        UITabBarItem *tabBarItem = [[[self.tabBarController tabBar]items]objectAtIndex:0];
        [tabBarItem setBadgeValue:nil];
        [self.alarmNumberLabel setHidden:YES];
    }
    //解析安防报警
    NSArray *securityNote = [self getNewSecurityNote];
    if (securityNote.count > 0) {
        //tabbar加上提示数字
        UITabBarItem *tabBarItem = [[[self.tabBarController tabBar]items]objectAtIndex:2];
        [tabBarItem setBadgeValue:[NSString stringWithFormat:@"%lu",(unsigned long)securityNote.count]];
    }else {
        UITabBarItem *tabBarItem = [[[self.tabBarController tabBar]items]objectAtIndex:2];
        [tabBarItem setBadgeValue:nil];
    }
}
- (NSArray *)getNewSecurityNote{
    
    NSString *lastDate = [[NSUserDefaults standardUserDefaults] objectForKey:@"LastSecrityDate"];
    if (lastDate == nil || [lastDate isEqualToString:@""]) {
        lastDate = @"1970-1-1";
    }
    return [CYM_Engine getNewSecurtyNote:lastDate];
}
@end
