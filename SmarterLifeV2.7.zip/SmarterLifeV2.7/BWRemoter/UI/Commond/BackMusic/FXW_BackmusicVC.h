//
//  FXW_BackmusicVC.h
//  BWRemoter
//
//  Created by 6602_Loop on 14-12-23.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "HE_BaseViewController.h"
#import "HE_UIDevice.h"

@interface FXW_BackmusicVC : HE_BaseViewController

@property NSArray *aryMuiscDev;
@end
