//
//  FXW_BackmusicVC.m
//  BWRemoter
//
//  Created by 6602_Loop on 14-12-23.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "FXW_BackmusicVC.h"
#import "FXW_BackMusic.h"


@interface FXW_BackmusicVC ()

@property (nonatomic,strong) FXW_BackMusic *music;

@end

@implementation FXW_BackmusicVC
@synthesize aryMuiscDev;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"背景音乐";
    self.music = [[FXW_BackMusic alloc]initWithFrame:self.view.frame];
    if (aryMuiscDev.count > 0) {
        [self.music setAttrWithCtrlValue:aryMuiscDev[0]];
        [self.music setIsNeedQuery:YES];
        [appManager.aryActiveDevice addObject:self.music];
        self.title = ((ControlDeviceContentValue *)aryMuiscDev[0]).name;
    }
    [self.view addSubview:self.music];
}
- (void)viewWillDisappear:(BOOL)animated {
    [appManager.aryActiveDevice removeObject:self.music];
}
@end
