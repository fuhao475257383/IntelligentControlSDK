//
//  FXW_ConditionVC.h
//  BWRemoter
//
//  Created by 6602_Loop on 14-12-15.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "HE_BaseViewController.h"
#import "HE_UIDevice.h"
@interface FXW_ConditionVC : HE_BaseViewController

@property (nonatomic)   BOOL isStudyMode;
@property (nonatomic,retain) ControlDeviceContentValue * singleAircondition;

@end
