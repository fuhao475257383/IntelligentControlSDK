//
//  FXW_ConditionVC.m
//  BWRemoter
//
//  Created by 6602_Loop on 14-12-15.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "FXW_ConditionVC.h"
#import "FXW_SingleCondition.h"
@interface FXW_ConditionVC ()
{
    FXW_SingleCondition *singleConditionVC;
}
@end

@implementation FXW_ConditionVC
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = _singleAircondition.name;
//    singleConditionVC = [[FXW_SingleCondition alloc] initWithFrame:self.view.frame];
    self.automaticallyAdjustsScrollViewInsets = NO;
    singleConditionVC = [[FXW_SingleCondition alloc] initWithFrame:CGRectMake(0, self.NavgationBarHeight, curScreenSize.width, curScreenSize.height - self.NavgationBarHeight)];
    [singleConditionVC setAttrWithCtrlValue:_singleAircondition];
    ////////////若为学习模式
    if (_isStudyMode && singleConditionVC.deviceType == A4_DEVICE_MUTIL) {
        [singleConditionVC enterStudyMode];
    }
    [singleConditionVC setIsNeedQuery:YES];
    [appManager.aryActiveDevice addObject:singleConditionVC];
    [self.view addSubview:singleConditionVC];
}

- (void)touchedBackButton:(id)sender{
    if (_isStudyMode && singleConditionVC.deviceType == A4_DEVICE_MUTIL) {
        [singleConditionVC saveAsStateToGateway];
    }
    [super touchedBackButton:sender];
}
@end
