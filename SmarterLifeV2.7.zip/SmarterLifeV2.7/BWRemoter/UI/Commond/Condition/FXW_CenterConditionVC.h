//
//  FXW_CenterConditionVC.h
//  BWRemoter
//
//  Created by 6602_Loop on 14-12-23.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "HE_BaseViewController.h"

@interface FXW_CenterConditionVC : HE_BaseViewController
{

}
@property(nonatomic,retain) ControlDeviceContentValue* conditionValue;
@property(nonatomic)        BOOL isStudyMode;
@end
