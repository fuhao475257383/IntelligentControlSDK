//
//  FXW_CenterConditionVC.m
//  BWRemoter
//
//  Created by 6602_Loop on 14-12-23.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "FXW_CenterConditionVC.h"
#import "HE_CenterCodition.h"

@interface FXW_CenterConditionVC ()
{
    HE_CenterCodition *conditionView;
}
@end

@implementation FXW_CenterConditionVC
@synthesize conditionValue;

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = conditionValue.name;
    if (conditionValue!= nil) {
//        conditionView = [[HE_CenterCodition alloc] initWithFrame:self.view.bounds];
        self.automaticallyAdjustsScrollViewInsets = NO;
        conditionView = [[HE_CenterCodition alloc] initWithFrame:CGRectMake(0, self.NavgationBarHeight, curScreenSize.width, curScreenSize.height - self.NavgationBarHeight)];
        [conditionView setAttrWithCtrlValue:conditionValue];
        ////////////若为学习模式 且为 多功能控制器
        if (_isStudyMode && conditionView.deviceType == A4_DEVICE_MUTIL) {
            [conditionView enterStudyMode];
        }

        [conditionView setIsNeedQuery:YES];
        [appManager.aryActiveDevice addObject:conditionView];
        [self.view addSubview:conditionView];
        
    }
}

- (void)touchedBackButton:(id)sender{
    if (_isStudyMode && conditionView.deviceType == A4_DEVICE_MUTIL) {
        [conditionView saveAsStateToGateway];
    }
    [super touchedBackButton:sender];
}
@end