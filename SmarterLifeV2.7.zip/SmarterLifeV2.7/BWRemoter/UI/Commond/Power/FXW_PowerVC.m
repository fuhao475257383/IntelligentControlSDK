//
//  FXW_PowerVC.m
//  BWRemoter
//
//  Created by 6602_Loop on 14-12-29.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "FXW_PowerVC.h"
#import "FXW_Power.h"
#import "HE_UIDevice.h"
#define POWER_WIDTH curScreenSize.width/4
#define POWER_ORIGIN_Y POWER_WIDTH/4
@interface FXW_PowerVC ()
@end

@implementation FXW_PowerVC
@synthesize aryPower;
- (void)viewDidLoad {
    [super viewDidLoad];
    [self setTitle:@"电源"];
    if (aryPower==nil) {
        aryPower = @[@"客厅空调", @"空调3", @"空调4",@"冰箱", @"洗衣机", @"客厅电视",@"洗衣机",@"客厅电视",@"空调2",@"风扇"];
    }
    UIScrollView *scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0,0, curScreenSize.width, curScreenSize.height)];
    [self.view addSubview:scrollView];
    
    float lastViewH = curScreenSize.height-self.NavgationBarHeight;
    [appManager.aryActiveDevice removeAllObjects];
    
    for(int i=0;i<aryPower.count;i++){
        FXW_Power *power = [[FXW_Power alloc]initWithFrame:CGRectMake(POWER_ORIGIN_Y + i%3*(POWER_ORIGIN_Y+POWER_WIDTH), (i/3 * (POWER_ORIGIN_Y+POWER_WIDTH))+POWER_ORIGIN_Y, POWER_WIDTH, POWER_WIDTH)];
        [appManager.aryActiveDevice addObject:power];
        lastViewH = lastViewH>(power.frame.origin.y+power.frame.size.height)?lastViewH:(power.frame.origin.y+power.frame.size.height +POWER_ORIGIN_Y);
        power.isNeedQuery = NO;
        [power setName:((ControlDeviceContentValue *)aryPower[i]).name];
        [power setAttrWithCtrlValue:aryPower[i]];
        [scrollView addSubview:power];
    }
    [scrollView setContentSize:CGSizeMake(0, lastViewH)];
}

@end
