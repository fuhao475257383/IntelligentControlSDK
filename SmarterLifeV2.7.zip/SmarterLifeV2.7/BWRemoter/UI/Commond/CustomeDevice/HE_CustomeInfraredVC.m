//
//  HE_CustomeInfraredVC.m
//  BWRemoter
//
//  Created by HeJianBo on 15/3/28.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "HE_CustomeInfraredVC.h"
#import "HE_CustomeInfrared.h"


@interface HE_CustomeInfraredVC ()
{
    HE_CustomeInfrared *costomeInfrared;
}
@end

@implementation HE_CustomeInfraredVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = _deviceValue.name;
    costomeInfrared = [[HE_CustomeInfrared alloc] initWithFrame:self.view.frame];
    [costomeInfrared setAttrWithCtrlValue:_deviceValue];
    [costomeInfrared setIsNeedQuery:YES];
    if (_isStudyMode && costomeInfrared.deviceType == A4_DEVICE_MUTIL) {
        [costomeInfrared enterStudyMode];
    }
    [appManager.aryActiveDevice addObject:costomeInfrared];
    [self.view addSubview:costomeInfrared];
}
- (void)touchedBackButton:(id)sender{
    if (_isStudyMode && costomeInfrared.deviceType == A4_DEVICE_MUTIL) {
        [costomeInfrared saveAsStateToGateway];
    }
    [super touchedBackButton:sender];
}
@end
