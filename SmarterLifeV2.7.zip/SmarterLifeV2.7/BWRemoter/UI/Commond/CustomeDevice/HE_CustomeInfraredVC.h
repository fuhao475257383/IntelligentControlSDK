//
//  HE_CustomeInfraredVC.h
//  BWRemoter
//
//  Created by HeJianBo on 15/3/28.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "HE_BaseViewController.h"

@interface HE_CustomeInfraredVC : HE_BaseViewController


@property ControlDeviceContentValue *deviceValue;
@property BOOL                      isStudyMode;

@end
