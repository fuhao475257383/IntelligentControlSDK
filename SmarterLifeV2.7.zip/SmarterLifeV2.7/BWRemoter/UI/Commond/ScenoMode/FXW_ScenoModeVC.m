      //
//  FXW_ScenoModeVC.m
//  BWRemoter
//
//  Created by 6602_Loop on 14-12-15.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "FXW_ScenoModeVC.h"
#import "FXW_Scene.h"
#import "HE_UIDevice.h"
#import "Scene.h"
#import "SceneDevice.h"
#import "FXW_SceneMode.h"
@interface FXW_ScenoModeVC ()

@end

@implementation FXW_ScenoModeVC
@synthesize table;
@synthesize SceneList;
@synthesize scene;
- (void)viewDidLoad {
    [super viewDidLoad];
    table = [[UITableView alloc]initWithFrame:CGRectMake(0.0f,0, curScreenSize.width, curScreenSize.height) style:UITableViewStylePlain];
    [table setBackgroundColor:[UIColor clearColor]];
    table.tableFooterView = [[UIView alloc] init];
    [table setDelegate:self];
    [table setDataSource:self];
    [self.view addSubview:table];
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return SceneList.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell= [tableView dequeueReusableCellWithIdentifier:@"wb_Cell"];
    if (cell==nil) {
        cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"qe"];
    }
    UIView *backView = [[UIView alloc] initWithFrame: CGRectMake(0.0f, 0.0f, curScreenSize.width, 90.0f)];
    
    UIImageView *logo = [[UIImageView alloc]initWithFrame:CGRectMake(curScreenSize.width*0.1, 17.0f, 40.0f, 40.0f)];
    [logo setImage:[UIImage imageNamed:@"scenomode.png"]];
    [backView addSubview:logo];
    
    UILabel *ListName = [[UILabel alloc]initWithFrame:CGRectMake(logo.frameSumX_W + 30, 25.0f, tableView.frameW - logo.frameSumX_W - 60 , 30.0f)];
    [ListName setText:[NSString stringWithFormat:@"%@",((HE_UIDevice *)SceneList[indexPath.row]).name]];
    [backView addSubview:ListName];
    
    [cell addSubview:backView];
    [cell setAccessoryType:UITableViewCellAccessoryNone];
    [cell setBackgroundColor:[UIColor clearColor]];
    /////////////无权限变灰
    if(![self isPermissionwithDevicePrio:((HE_UIDevice *)SceneList[indexPath.row]).prio andPermission:appManager.User.strPermission]){
        [cell setUserInteractionEnabled:NO];
        CALayer *maskLayer = [CALayer layer];
        maskLayer.frame    = backView.bounds;
        maskLayer.contents = (__bridge id)([UIImage imageNamed:@"tv_backMask"].CGImage);
        backView.layer.mask = maskLayer;
        return cell;
    }
    
    if (![self isHavePrio:((Scene *)SceneList[indexPath.row]).deviceArr]){
        [cell setUserInteractionEnabled:NO];
        CALayer *maskLayer = [CALayer layer];
        maskLayer.frame    = backView.bounds;
        maskLayer.contents = (__bridge id)([UIImage imageNamed:@"tv_backMask"].CGImage);
        backView.layer.mask = maskLayer;
    }
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}
/*  点击事件 */
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    indexpath = indexPath.row;
    scene = [[FXW_Scene alloc]initWithFrame:CGRectMake(0, 0, curScreenSize.width, curScreenSize.height) Delegate:self Datasourse:self];
    [scene setIsNeedQuery:NO];
    [scene SetsceneList:SceneList andindex:indexpath];
    [self.view addSubview:scene];
    [self timerAction];
}
-(void)timerAction{
    NSTimeInterval time=0;
    for(int i =0;i<((Scene *)SceneList[indexpath]).deviceArr.count;i++){
        time=time+ [((SceneDevice *)((Scene *)SceneList[indexpath]).deviceArr[i]).interval doubleValue];
        [NSTimer scheduledTimerWithTimeInterval:time target:self selector:@selector(timerAction2) userInfo:nil repeats:NO];
    }
    if(((Scene *)SceneList[indexpath]).deviceArr.count==0){
            [scene runtime];
    }
    
}
-(void)timerAction2{
    [scene runtime];
}


-(NSString *)SenceTitle:(NSInteger)index{
    return ((SceneDevice *)((Scene *)SceneList[indexpath]).deviceArr[index]).name;
}
-(NSInteger)numberOfRowsInSection{
    @try {
        return ((Scene *)SceneList[indexpath]).deviceArr.count;
    }
    @catch (NSException *exception) {
        return 1;
    }
    @finally {
    }
}
-(NSTimer *)SenceTime:(NSInteger)index{
    return (NSTimer *)((SceneDevice *)((Scene *)SceneList[indexpath]).deviceArr[index]).interval;
}
-(NSString *)SenceOperaton:(NSInteger)index{
 return ((SceneDevice *)((Scene *)SceneList[indexpath]).deviceArr[index]).operation;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
////检查用户是否有权限
-(BOOL)isPermissionwithDevicePrio:(NSString *)pri andPermission:(NSString *)permission{
    if (pri == nil || [pri isEqualToString:@""] || [pri isEqualToString:@"null"] || [pri isEqualToString:@"FFFFFFFFFFFFF"]) {
        return YES;
    }
    if(!([permission integerValue]==0)){
        UInt64 prioH = [pri IntString].longLongValue;
        prioH =  prioH >> ([permission IntString].intValue -1);
        return prioH&1;
    }
    else{
        return YES;
    }
    return YES;
}
- (BOOL)isHavePrio:(NSArray *)scenes {
    for (SceneDevice *device in scenes) {
//        NSLog(@"设备名称%@",device.name);
        ControlDeviceContentValue *value = [CYM_Engine getDeviceDetailsWithDeviceName:device.name];
//        NSLog(@"设备权限%@",value.prio);
        NSString *permission = [[HE_APPManager sharedManager] User].strPermission;
        if(![permission integerValue]==0){
            UInt64 prioH = [value.prio IntString].longLongValue;
            prioH =  prioH >> ([permission IntString].intValue -1);
            if (!(prioH&1)) {
                return NO;
            }
        }
        else{
            return YES;
        }
    }
    return YES;
}
@end
