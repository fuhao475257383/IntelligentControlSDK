//
//  FXW_ScenoModeVC.h
//  BWRemoter
//
//  Created by 6602_Loop on 14-12-15.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "HE_BaseViewController.h"
#import "FXW_TableProtocol.h"
#import "FXW_Scene.h"
#import "FXW_SceneMode.h"

@interface FXW_ScenoModeVC : HE_BaseViewController<UITableViewDataSource,UITableViewDelegate,FXW_tableDelegate,FXW_tableDataSourse>
{
    NSArray *ary;
    NSInteger indexpath;
    CGFloat ti;
//    NSMutableArray *
}
@property(nonatomic,retain) FXW_Scene *scene;
@property(nonatomic,retain) UITableView *table;
@property(nonatomic,retain) NSMutableArray *SceneList;
@end
