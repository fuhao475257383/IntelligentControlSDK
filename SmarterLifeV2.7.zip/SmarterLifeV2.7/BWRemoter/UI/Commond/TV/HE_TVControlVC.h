//
//  HE_TVControlVC.h
//  BWRemoter
//
//  Created by HeJianBo on 15/3/13.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "HE_BaseViewController.h"
#import "HE_UIDevice.h"

@interface HE_TVControlVC : HE_BaseViewController


@property (nonatomic) BOOL                       isStudyMode;
@property (nonatomic) ControlDeviceContentValue *deviceTV;
@end
