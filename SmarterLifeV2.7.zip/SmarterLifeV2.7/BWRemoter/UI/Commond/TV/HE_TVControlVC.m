//
//  HE_TVControlVC.m
//  BWRemoter
//
//  Created by HeJianBo on 15/3/13.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "HE_TVControlVC.h"
#import "HE_TV.h"

@interface HE_TVControlVC ()
{
    HE_TV *viewTV;
}
@end

@implementation HE_TVControlVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = _deviceTV.name;
    viewTV = [[HE_TV alloc] initWithFrame:self.view.frame];
    [viewTV setAttrWithCtrlValue:_deviceTV];
    [viewTV setIsNeedQuery:YES];
    if (_isStudyMode && viewTV.deviceType == A4_DEVICE_MUTIL) {
        [viewTV enterStudyMode];
    }
    [appManager.aryActiveDevice addObject:viewTV];
    [self.view addSubview:viewTV];
}
- (void)touchedBackButton:(id)sender{
    if (_isStudyMode && viewTV.deviceType == A4_DEVICE_MUTIL) {
        [viewTV saveAsStateToGateway];
    }
    [super touchedBackButton:sender];
}
@end
