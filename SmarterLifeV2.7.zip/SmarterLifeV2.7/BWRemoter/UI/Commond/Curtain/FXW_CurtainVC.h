//
//  FXW_CurtainVC.h
//  BWRemoter
//
//  Created by 6602_Loop on 14-12-14.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "HE_BaseViewController.h"
//typedef enum{
//    CurtainFrameTypeforRoom = 0,//房间
//    CurtainFrameTypeforHouse,//房型
//}CurtainFrameType;
@interface FXW_CurtainVC : HE_BaseViewController
{
    NSArray *aryLable;
}
@property NSInteger  frameType ;
@property NSMutableArray *aryCurtain1;
@property NSMutableArray *aryCurtain2;
@end
