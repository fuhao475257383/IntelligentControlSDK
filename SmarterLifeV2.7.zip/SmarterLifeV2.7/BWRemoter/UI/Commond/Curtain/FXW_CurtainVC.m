//
//  FXW_CurtainVC.m
//  BWRemoter
//
//  Created by 6602_Loop on 14-12-14.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "FXW_CurtainVC.h"
#import "FXW_Curtain.h"
#import "HE_UIDevice.h"
#define CURTAIN_HEIGHT curScreenSize.height/7
#define CURTAIN_GAP curScreenSize.height/30
@interface FXW_CurtainVC ()

@end

@implementation FXW_CurtainVC
@synthesize aryCurtain1;
@synthesize aryCurtain2;
@synthesize frameType;
- (void)viewDidLoad {
    [super viewDidLoad];
    //升降窗帘
    UIScrollView *scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0,0, curScreenSize.width, curScreenSize.height)];
    [self.view addSubview:scrollView];
    float lastViewH = curScreenSize.height-self.NavgationBarHeight;
    [[[HE_APPManager sharedManager] aryActiveDevice] removeAllObjects];
    for(int i=0;i<aryCurtain1.count;i++){
        ControlDeviceContentValue *device = (ControlDeviceContentValue *)aryCurtain1[i];
        FXW_Curtain *curtain = [[FXW_Curtain alloc]initWithFrame:CGRectMake(curScreenSize.width*0.25, i*(CURTAIN_HEIGHT+CURTAIN_GAP)+20,curScreenSize.width*0.5, CURTAIN_HEIGHT)];
        lastViewH = lastViewH>(curtain.frame.origin.y+curtain.frame.size.height)?lastViewH:(curtain.frame.origin.y+curtain.frame.size.height +CURTAIN_GAP);
        [curtain setBackgroundColor:[UIColor whiteColor]];
        curtain.isNeedQuery = NO;
        [curtain setCategoryType:CurtainCategoryTypefUp_Down andFrameType:frameType];
        if ([device.property isEqualToString:@"开合窗帘"]) {
            [curtain setCategoryType:CurtainCategoryTypeOpenClose andFrameType:frameType];
        }
        [curtain setAttrWithCtrlValue:device];
        
        
        [[[HE_APPManager sharedManager] aryActiveDevice] addObject:curtain];
        [scrollView addSubview:curtain];
    }
    //开合窗帘
    for(NSInteger i = aryCurtain1.count;i<aryCurtain2.count+aryCurtain1.count;i++){
        ControlDeviceContentValue *device = (ControlDeviceContentValue *)aryCurtain2[i - aryCurtain1.count];
        FXW_Curtain *curtain = [[FXW_Curtain alloc]initWithFrame:CGRectMake(curScreenSize.width*0.25, i*(CURTAIN_HEIGHT+CURTAIN_GAP)+20,curScreenSize.width*0.5, CURTAIN_HEIGHT)];
        lastViewH = lastViewH>(curtain.frame.origin.y+curtain.frame.size.height)?lastViewH:(curtain.frame.origin.y+curtain.frame.size.height +CURTAIN_GAP);
        [curtain setBackgroundColor:[UIColor whiteColor]];
        [curtain setAttrWithCtrlValue:device];
        curtain.isNeedQuery = NO;
        
        [curtain setCategoryType:CurtainCategoryTypefUp_Down andFrameType:frameType];
        if ([device.property isEqualToString:@"开合窗帘"]) {
            [curtain setCategoryType:CurtainCategoryTypeOpenClose andFrameType:frameType];
        }
        
        [[[HE_APPManager sharedManager] aryActiveDevice] addObject:curtain];
        [scrollView addSubview:curtain];
    }
    [scrollView setContentSize:CGSizeMake(0, lastViewH)];
}
@end
