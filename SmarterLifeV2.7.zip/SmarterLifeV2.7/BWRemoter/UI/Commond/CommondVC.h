//
//  CommondVC.h
//  BWRemoter
//
//  Created by JianBo He on 14/12/5.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "HE_BaseViewController.h"

@interface CommondVC : HE_BaseViewController<UIScrollViewDelegate>
{
    
    NSMutableArray *roomname;
    NSTimer *pictureTimer;
    NSInteger imgIndex;///播放到第几张了
}
@property NSArray *aryroom;
@property NSMutableArray *arydevice;
@property NSMutableArray *arycontent;
@property (strong,nonatomic)UIButton *btnleft;
@property (strong,nonatomic)UIButton *btnright;
@end
