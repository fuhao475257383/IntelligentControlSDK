//
//  SetdateVC.h
//  BWRemoter
//
//  Created by 6602_Loop on 14-12-7.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "HE_BaseViewController.h"

@interface SetdateVC :HE_BaseViewController <UITableViewDataSource,UITableViewDelegate>
{
    NSArray *weeks;
    NSMutableArray *crontabary;
//    NSMutableArray *tmpcrontabary;
    UISwitch *switmp;
    BOOL IsEdited;//是否修改过
}
@property(nonatomic,retain) IBOutlet UITableView *table;
@end
