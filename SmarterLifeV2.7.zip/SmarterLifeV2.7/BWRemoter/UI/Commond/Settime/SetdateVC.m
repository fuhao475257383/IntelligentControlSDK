//
//  SetdateVC.m
//  BWRemoter
//
//  Created by 6602_Loop on 14-12-7.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "SetdateVC.h"
#import "HE_NavgationController.h"
#import "Crontab.h"
#import "ZJSwitch.h"

@interface SetdateVC ()
@end

@implementation SetdateVC
@synthesize table;
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    if(crontabary){
        [crontabary removeAllObjects];
        [crontabary addObject:[CYM_Engine getAllTimeInfo]];
    }
//    tmpcrontabary = [[NSMutableArray alloc]initWithObjects:crontabary,nil];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setTitle:@"定时"];
    weeks = @[@"周一",@"周二",@"周三",@"周四",@"周五",@"周六",@"周日",];
    crontabary = [[NSMutableArray alloc]init];
    [crontabary addObject:[CYM_Engine getAllTimeInfo]];
    table = [[UITableView alloc]initWithFrame:CGRectMake(0.0f, 0.0f, curScreenSize.width, curScreenSize.height-self.NavgationBarHeight) style:UITableViewStylePlain];
    table.separatorStyle = NO;
    [table setDelegate : self];
    [table setDataSource : self];
    [self.view addSubview:table];
    //////////通知报警信息通知
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reciveCrontabMsg) name:@"DATABASE_UPDATE" object:nil];
}
#pragma mark - UITableViewDelegate And DataSourse

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *cell= [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    if (cell==nil) {
        cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"qe"];
    }
    
    Crontab *crontab = crontabary[0][indexPath.row];
    
    UIView *backView = [[UIView alloc] initWithFrame: CGRectMake(curScreenSize.width*0.05, 10.0f, curScreenSize.width*0.9, 70.0f)];
    backView.layer.borderWidth = 1;
    backView.layer.borderColor = [[UIColor colorWithRed:220/255.0f green:220/255.0f blue:220/255.0f alpha:1]CGColor];
    backView.layer.cornerRadius = 5.0f;
    
    UILabel *ListName = [[UILabel alloc]initWithFrame:CGRectMake(100, 5, 200.0f, 30.0f)];
    [ListName setFont:[UIFont boldSystemFontOfSize:20]];
    [ListName setText:crontab.name];
    [backView addSubview:ListName];
    
    UIImageView *logo = [[UIImageView alloc]initWithFrame:CGRectMake(20, 5, 30.0f, 30.0f)];
    [logo setImage:[UIImage imageNamed:@"settimeicon.png"]];
    [backView addSubview:logo];
    UILabel *labTime = [[UILabel alloc]initWithFrame:CGRectMake(15, 40, 80, 30)];
    [labTime setText:crontab.time];
    [backView addSubview:labTime];

    UILabel *labDate = [[UILabel alloc]initWithFrame:CGRectMake(100, 40, backView.frameW*0.7, 30)];
    if([crontab.repeat isEqualToString:@"0"]){//单次
        [labDate setText:crontab.date];
    }
    else{
        NSArray *tmp = [crontab.repeat componentsSeparatedByString:@","];
        NSString *week=@"";
        for(int i=0;i<tmp.count;i++){
            week = [week stringByAppendingFormat:@"周%@",tmp[i]];
        }
        [labDate setText:week];
    }
    [backView addSubview:labDate];
    ZJSwitch *switchs = [[ZJSwitch alloc]initWithFrame:CGRectMake(backView.frame.size.width*0.7, 10, 70, 30)];
    [switchs setOnText:@"ON"];
    [switchs setOffText:@"OFF"];
    [switchs setTextFont:[UIFont boldSystemFontOfSize:14]];
    [switchs setOffTextColor:[UIColor grayColor]];
    switchs.tag=1000+indexPath.row;
    [switchs setOnTintColor:[UIColor colorWithRed: 35/255.0 green:167/255.0 blue:230/255.0 alpha:1]];
    [switchs setTintColor:[UIColor colorWithRed:230/255.0f green:230/255.0f blue:230/255.0f alpha:1]];
    [switchs setOn:[crontab.status isEqualToString:@"off"]?NO:YES animated:NO];
    [switchs addTarget:self action:@selector(switchCrontab:) forControlEvents:UIControlEventValueChanged];
    [backView addSubview:switchs];
    [cell addSubview:backView];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    [cell setAccessoryType:UITableViewCellAccessoryNone];
    [cell setBackgroundColor:[UIColor clearColor]];
    
    NSString *strDeviceName = [crontab.scene componentsSeparatedByString:@"-"][0];
    ControlDeviceContentValue *val = [CYM_Engine getDeviceDetailsWithDeviceName:strDeviceName];
    
    //////如果为空则 定时的是场景
    if (val == nil){
        val = [CYM_Engine getSenceWithSenceName:strDeviceName];
    }
    if (![self isHavePermission:val]) {
        backView.alpha                  = 0.4;
        backView.userInteractionEnabled = NO;
    }
    return cell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return ((NSArray *)crontabary[0]).count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}
#pragma mark switchAction
-(void)switchCrontab:(id)sender{
    IsEdited = YES;
    switmp = (UISwitch *)sender;
    ((Crontab *)crontabary[0][switmp.tag-1000]).status = switmp.on?@"on":@"off";
}

///重写后退事件
- (void)touchedBackButton:(id)sender{
    if(IsEdited){
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:@"退出并保存？" delegate:self cancelButtonTitle:@"不保存" otherButtonTitles:@"保存", nil];
        [alert show];
    }
    else{
      [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(buttonIndex ==1){
        [CYM_Engine UpdeteAllCrontab:crontabary[0]];
        [self generateJSONFileAndUpload];
    }
    else{
      //  switmp.on = !switmp.on;
    }
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)generateJSONFileAndUpload{
    //1.根据数据库生成JSON文件
    //2.上传JSON文件
    //3.上传成功->更新本地信息、 否则下载服务器文件更新本地数据库
    NSData *cronData = [CYM_Engine generateJSONFileWithName:@"crontab.json"];
    [[HE_APPManager sharedManager] uploadFileWithName:@"crontab.json" andData:cronData isShowHUD:YES];
}

-(BOOL)isHavePermission:(ControlDeviceContentValue *)value{
    NSString *permission = [[HE_APPManager sharedManager] User].strPermission;
    if(![permission integerValue]==0){
        UInt64 prioH = [value.prio IntString].longLongValue;
        prioH =  prioH >> ([permission IntString].intValue -1);
        if (prioH&1) {
            return YES;
        }
    }
    else{
        return YES;
    }
    return NO;
}

@end
