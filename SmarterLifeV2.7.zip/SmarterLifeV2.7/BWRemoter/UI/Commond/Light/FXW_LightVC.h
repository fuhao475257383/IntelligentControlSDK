//
//  FXW_LightVC.h
//  BWRemoter
//
//  Created by 6602_Loop on 14-12-9.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "HE_BaseViewController.h"

@interface FXW_LightVC : HE_BaseViewController
{
    CGFloat laDLight_Framey_h;
}
///普通灯光
@property NSMutableArray *aryLight;
///可调灯光
@property NSMutableArray *aryLight2;
@end
