//
//  FXW_LightVC.m
//  BWRemoter
//
//  Created by 6602_Loop on 14-12-9.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "FXW_LightVC.h"
#import "HE_DLight.h"
#import "FXW_DChangeLight.h"
#import "HE_UIDevice.h"
#define LIGHT_WIDTH curScreenSize.width/4
#define LIGHT_ORIGIN_Y LIGHT_WIDTH/4

@interface FXW_LightVC ()

@end

@implementation FXW_LightVC
@synthesize aryLight;
@synthesize aryLight2;
- (void)viewDidLoad {
    [super viewDidLoad];
    laDLight_Framey_h = LIGHT_ORIGIN_Y;
    
    UIScrollView *scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0,0, curScreenSize.width, curScreenSize.height)];
    [self.view addSubview:scrollView];
    
    float lastViewH = curScreenSize.height-self.NavgationBarHeight;
    
    for(int i=0;i<aryLight2.count;i++){
        FXW_DChangeLight *flight = [[FXW_DChangeLight alloc]initWithFrame:CGRectMake(LIGHT_ORIGIN_Y,i*(LIGHT_WIDTH+LIGHT_ORIGIN_Y)+LIGHT_ORIGIN_Y, curScreenSize.width-LIGHT_ORIGIN_Y*2, LIGHT_WIDTH)];
        [flight setName:((ControlDeviceContentValue *)aryLight2[i]).name];
        [flight setIsNeedQuery:NO];
        [flight setAttrWithCtrlValue:aryLight2[i]];
        [scrollView addSubview:flight];
        [appManager.aryActiveDevice addObject:flight];
        laDLight_Framey_h = flight.frameSumY_H;
    }
    CGFloat view_Y = laDLight_Framey_h;
    NSMutableArray *ary1 = [NSMutableArray array];
    NSMutableArray *ary2 = [NSMutableArray array];
    for (ControlDeviceContentValue *deivce in aryLight) {
        if ([deivce.property isEqualToString:@"可调灯"]) {
            [ary1 addObject:deivce];
        }
        else{
//            [ary2 addObject:@"非可调灯"]; 原代码
            [ary2 addObject:deivce];
        }
    }
    
    for(int i=0;i<ary1.count;i++){
        FXW_DChangeLight *flight = [[FXW_DChangeLight alloc]initWithFrame:CGRectMake(LIGHT_ORIGIN_Y,i*(LIGHT_WIDTH+LIGHT_ORIGIN_Y)+view_Y, curScreenSize.width-LIGHT_ORIGIN_Y*2, LIGHT_WIDTH)];
        [flight setName:((ControlDeviceContentValue *)ary1[i]).name];
        [flight setIsNeedQuery:NO];
        [flight setAttrWithCtrlValue:ary1[i]];
        [scrollView addSubview:flight];
        [appManager.aryActiveDevice addObject:flight];
        laDLight_Framey_h = flight.frameSumY_H;
        
        lastViewH = flight.frameSumY_H;
    }
    for (int j=0; j<ary2.count;j++) {
//        ControlDeviceContentValue *device = aryLight[j]; 原代码
        ControlDeviceContentValue *device = ary2[j];
        CGRect frame = CGRectMake(LIGHT_ORIGIN_Y + j%3*(LIGHT_ORIGIN_Y + LIGHT_WIDTH),
                                  laDLight_Framey_h + LIGHT_ORIGIN_Y+ j/3 * (LIGHT_WIDTH + LIGHT_ORIGIN_Y), LIGHT_WIDTH, LIGHT_WIDTH);
        
        HE_DLight *light = [[HE_DLight alloc] initWithFrame:frame];
        [light setAttrWithCtrlValue:device];
        [light setIsNeedQuery:NO];
        [appManager.aryActiveDevice addObject:light];
        
        lastViewH = light.frameSumY_H;
        
        [scrollView addSubview:light];
    }
    [scrollView setContentSize:CGSizeMake(0, lastViewH + 50)];
    
}


@end
