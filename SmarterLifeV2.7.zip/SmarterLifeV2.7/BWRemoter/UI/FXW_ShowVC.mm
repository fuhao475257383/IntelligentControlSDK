//
//  FXW_ShowVC.m
//  BWRemoter
//
//  Created by 6602_Loop on 14-12-6.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "FXW_ShowVC.h"
#import "Commond/CommondVC.h"
#import "VideoVC.h"
#import "SafeVC.h"
#import "SettingVC.h"

#import "Login/FXW_SetVC.h"
#import "CYM_Engine.h"


#import "HE_TabBarController.h"
#import "HE_NavgationController.h"
@interface FXW_ShowVC ()<MBProgressHUDDelegate>
{
    MBProgressHUD *hudTMP;
}
@end

@implementation FXW_ShowVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.leftBarButtonItem = nil;
    [appManager setDelegateViewCtrl:self];
    
    
    // Do any additional setup after loading the view from its nib.
    UIImageView *Showpage = [[UIImageView alloc]initWithFrame:CGRectMake(0.0f, 0.0f, curScreenSize.width,curScreenSize.height)];
    [Showpage setImage:[UIImage imageNamed:@"Login_icon.png"]];
    [Showpage setUserInteractionEnabled:YES];
    [self.view addSubview:Showpage];
    
    //本地登录按钮
    UIButton *LocalLogin = [[UIButton alloc]initWithFrame:CGRectMake(curScreenSize.width*0.175, curScreenSize.height*0.785, curScreenSize.width*0.375, curScreenSize.height*0.065)];
    [LocalLogin setBackgroundColor:[UIColor colorWithRed:240/255.0f green:240/255.0f blue:240/255.0f alpha:1]];
    [LocalLogin addTarget:self action:@selector(Logclick:) forControlEvents:UIControlEventTouchUpInside];
    LocalLogin.layer.cornerRadius = 17.0f;
    LocalLogin.layer.borderWidth = 1.0f;
    LocalLogin.clipsToBounds = YES;
    [LocalLogin setTitleEdgeInsets:UIEdgeInsetsMake(0, -25, 0, 0)];
    [LocalLogin setBackgroundImage:[UIImage createImageWithColor:[UIColor colorWithRed:220/255.0f green:220/255.0f blue:220/255.0f alpha:1]] forState:UIControlStateHighlighted];
    [LocalLogin setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    LocalLogin.layer.borderColor = [[UIColor colorWithRed:220/255.0f green:220/255.0f blue:220/255.0f alpha:1] CGColor];
    [LocalLogin setTitle:@"本地登录" forState:UIControlStateNormal];
    [LocalLogin.titleLabel setTextAlignment:NSTextAlignmentLeft];
    [Showpage addSubview:LocalLogin];

    
    //远程登录按钮
    UIButton *RemoteLogin = [[UIButton alloc]initWithFrame:CGRectMake(curScreenSize.width*0.46, curScreenSize.height*0.785, curScreenSize.width*0.375, curScreenSize.height*0.065)];
    RemoteLogin.layer.cornerRadius = 17.0f;
    RemoteLogin.layer.borderWidth = 1.0f;
    [RemoteLogin setTitleEdgeInsets:UIEdgeInsetsMake(0, 25, 0, 0)];
    [RemoteLogin setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    RemoteLogin.layer.borderColor = [[UIColor colorWithRed:220/255.0f green:220/255.0f blue:220/255.0f alpha:1] CGColor];
    [RemoteLogin setBackgroundColor:[UIColor colorWithRed:240/255.0f green:240/255.0f blue:240/255.0f alpha:1]];
    RemoteLogin.clipsToBounds=YES;
    [RemoteLogin setBackgroundImage:[UIImage createImageWithColor:[UIColor colorWithRed:220/255.0f green:220/255.0f blue:220/255.0f alpha:1]] forState:UIControlStateHighlighted];
    [RemoteLogin setTitle:@"远程登录" forState:UIControlStateNormal];
    [RemoteLogin.titleLabel setTextAlignment:NSTextAlignmentRight];
    [RemoteLogin addTarget:self action:@selector(touchedRemoteLogin:) forControlEvents:UIControlEventTouchUpInside];
    [Showpage addSubview:RemoteLogin];
    //设置
    UIButton *Set = [[UIButton alloc]initWithFrame:CGRectMake(curScreenSize.width*0.45, curScreenSize.height*0.785+1, curScreenSize.height*0.065-2, curScreenSize.height*0.065-2)];
    Set.layer.cornerRadius = Set.frameW/2;
    Set.clipsToBounds=YES;
    [Set setBackgroundImage:[UIImage imageNamed:@"Login_setting_icon.png"] forState:UIControlStateNormal];
    [Set setBackgroundColor:[UIColor colorWithRed:240/255.0f green:240/255.0f blue:240/255.0f alpha:1]];
    [Set addTarget:self action:@selector(Setclick) forControlEvents:UIControlEventTouchUpInside];
    [Showpage addSubview:Set];
    //演示按钮
    UIButton *Showbtn = [[UIButton alloc]initWithFrame:CGRectMake(curScreenSize.width*0.035, curScreenSize.height*0.935, curScreenSize.width*0.175, curScreenSize.height*0.05)];
    [Showbtn setBackgroundColor:[UIColor clearColor]];

    [Showbtn addTarget:self action:@selector(touchedToDemoMode:) forControlEvents:UIControlEventTouchUpInside];
    [Showpage addSubview:Showbtn];
    /////////////
    FXW_User *savedUser = [FXW_User initUserWithUserDefault];
    if (savedUser) {
        appManager.User = savedUser;
    }
}

#pragma mark -
#pragma mark Action
- (void)touchedToDemoMode:(UIButton *)sender{
    [appManager connectToHost:NET_DEMO ];
}
-(void)Setclick{
    FXW_SetVC *set1 = [[FXW_SetVC alloc]init];
    HE_NavgationController *nav = [[HE_NavgationController alloc] init];
    [nav addChildViewController:set1];
    [self presentViewController:nav animated:YES completion:nil];
}
-(void)Logclick:(id)sender{
    if ([self isNilOrEmpty:NET_WAN_SOCKET]) {
        [appManager connectToHost:NET_WAN_SOCKET];
        NSLog(@"Name: %@, uPWD: %@", appManager.User.strName, appManager.User.strPwd);
    }
}
-(void)touchedRemoteLogin:(id)sender{
    if ([self isNilOrEmpty:NET_XMPP]) {
        [appManager connectToHost:NET_XMPP];
        NSLog(@"Name: %@, uPWD: %@", appManager.User.strName, appManager.User.strPwd);
    }
}


#pragma mark - Private Method
//////////////////nil、Empty 判断
- (BOOL)isNilOrEmpty:(NET_STATE) netState{
    if(![appManager IsEnableWIFI]){
        if (![appManager IsEnable3G]) {
            [appManager hudShowMsg:@"网络连接异常，请检查网络设置" andInterval:1.0];
            return false;
        }
    }
    
    if (appManager.User.strName == nil || [appManager.User.strName isEqualToString:@""]) {
        [appManager hudShowMsg:@"请在登录设置界面输入用户名" andInterval:1.0];
    }
    else if (appManager.User.strPwd == nil || [appManager.User.strPwd isEqualToString:@""]){
        [appManager hudShowMsg:@"请在登录界面输入密码" andInterval:1.0];
    }
    else if((appManager.User.strSN == nil || [appManager.User.strSN isEqualToString:@""])){
        [appManager hudShowMsgTitle:nil details:@"无网关设备信息,请确认" andInterval:1];
    }
    else{
        
        return YES;
    }
    return NO;
}
////////////////// 登录成功
- (void)hudWasHidden:(MBProgressHUD *)hud{
    [hud removeFromSuperview];
    CommondVC *cmdVC = [[CommondVC alloc] init];
    NSArray *aryRoom = [CYM_Engine getRoomAllDevice];
    [cmdVC setAryroom:aryRoom];
    
    VideoVC *videoVC = [[VideoVC alloc] init];
    SafeVC *safeVC = [[SafeVC alloc] init];
//    HouseVC *houseVC = [[HouseVC alloc] init];
    SettingVC *setVC = [[SettingVC alloc] init];
    
    cmdVC.title = @"控  制";
    videoVC.title = @"视  频";
    safeVC.title = @"安  全";
//    houseVC.title = @"房  型";
    setVC.title = @"设  置";
    
    HE_NavgationController *nav1 = [[HE_NavgationController alloc] initWithRootViewController:cmdVC];
    HE_NavgationController *nav2 = [[HE_NavgationController alloc] initWithRootViewController:videoVC];
    HE_NavgationController *nav3 = [[HE_NavgationController alloc] initWithRootViewController:safeVC];
//    HE_NavgationController *nav4 = [[HE_NavgationController alloc] initWithRootViewController:houseVC];
    HE_NavgationController *nav5 = [[HE_NavgationController alloc] initWithRootViewController:setVC];
    
    NSArray *aryVC = [[NSArray alloc] initWithObjects:nav1, nav2, nav3, /*nav4,*/ nav5, nil];
    
    HE_TabBarController *tab = [[HE_TabBarController alloc] init];
    [tab setViewControllers:aryVC];
    
    NSString * imgnames[4] = {
        @"ic_tabCtrl.png",
        @"ic_tabVideo.png",
        @"ic_tabSafe.png",
        /*@"ic_tabHouse.png",*/
        @"ic_tabSet.png"
    };
    for(int i=0; i<4; i++){
        UIViewController *vc = aryVC[i];
        vc.tabBarItem.image = [UIImage imageNamed:imgnames[i]];
    }
    
    [self presentViewController:tab animated:YES completion:nil];
}
#pragma mark - 配置文件更新完成
//////////////////登录成功
- (void)dataBaseDidUpdate{
//    hudTMP = [[MBProgressHUD alloc] initWithView:self.view];
//    hudTMP.detailsLabelText = @"获取网络设备状态...";
//    hudTMP.delegate = self;
//    [hudTMP show:YES];
//    [hudTMP hide:YES afterDelay:6.];
//    [self.view addSubview:hudTMP];
    
    [self hudWasHidden:nil];
}
//- (void)reloadData:(NSString *)strCMD{
//    hudTMP.detailsLabelText = [NSString stringWithFormat:@"获取网络设备状态(%lu)...",(unsigned long)appManager.aryRoomCtrlValue.count];
//}

-(NSUInteger)supportedInterfaceOrientations{
    return UIInterfaceOrientationMaskAll;
}

- (BOOL)shouldAutorotate{
    return NO;
}
@end
