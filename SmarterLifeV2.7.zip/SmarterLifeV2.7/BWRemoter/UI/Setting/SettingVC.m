//
//  SettingVC.m
//  BWRemoter
//
//  Created by JianBo He on 14/12/5.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "SettingVC.h"
#import "HouseSetVC.h"
#import "ProjectSetVC.h"
#import "SoftwareEditionVC.h"
#import "UserSetVC.h"
#import "TimeSetVC.h"
#import "DoorLockVC.h"

@interface SettingVC ()
{
    NSArray *arySetting;
    NSArray *aryIcon;
}
@end

@implementation SettingVC

@synthesize table;

- (void)viewDidLoad {
    [super viewDidLoad];
    //门锁
//    UIButton *gateLockButton = [[UIButton alloc]initWithFrame:CGRectMake(0, 17, 40, 40)];
//    [gateLockButton setImage:[UIImage imageNamed:@"icon_alarm_doorlock.png"] forState:UIControlStateNormal];
//    [gateLockButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
//    [gateLockButton addTarget:self action:@selector(jumpToGateLockVC:) forControlEvents:UIControlEventTouchUpInside];
//    UIBarButtonItem *gateButton = [[UIBarButtonItem alloc]initWithCustomView:gateLockButton];
//    self.navigationItem.leftBarButtonItem = gateButton;
    self.navigationItem.leftBarButtonItem = nil;
    //////////////Data
    arySetting = @[@"定时设置", /*@"房型设置",*/ @"用户信息", @"软件版本", @"返回登录"];
    aryIcon    = @[@"settimeicon.png", /*@"house.png",*/ @"user.png", @"versionicon.png", @"user.png"];
    if ([appManager.User.strName isEqualToString:@"admin"]) {
        arySetting = @[@"定时设置", /*@"房型设置",*/ @"用户设置", @"工程设置", @"软件版本", @"返回登录"];
        aryIcon    = @[@"settimeicon.png", /*@"house.png",*/ @"user.png", @"projecticon.png", @"versionicon.png", @"user.png"];
    }
    if ([appManager netState] == NET_DEMO) {
        
        arySetting = @[@"软件版本", @"返回登录"];
        aryIcon    = @[@"versionicon.png", @"user.png"];
    }
    //////////////View
    table = [[UITableView alloc]initWithFrame:CGRectMake(0.0f, 10.0f, curScreenSize.width, curScreenSize.height-80.0f) style:UITableViewStylePlain];
    [table setBackgroundColor:[UIColor clearColor]];
    table.tableFooterView = [[UIView alloc] init];
    table.separatorInset = UIEdgeInsetsMake(0, 3, 0, 17);
    [table setDelegate:self];
    [table setDataSource:self];
    [self.view addSubview:table];
}
//跳转门锁
//- (void)jumpToGateLockVC:(id)sender {
//    DoorLockVC *gateVC = [[DoorLockVC alloc]init];
//    gateVC.hidesBottomBarWhenPushed = YES;
//    gateVC.isNeedShowAlarmButton = YES;
//    [self.navigationController pushViewController:gateVC animated:YES];
//}
#pragma mark - UITableViewDelegate And DataSourse
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arySetting.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *cell= [tableView dequeueReusableCellWithIdentifier:@"wb_Cell"];
    
    if (cell==nil) {
        cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"qe"];
    }

    UIView *backView = [[UIView alloc] initWithFrame: CGRectMake(0.0f, 0.0f, curScreenSize.width, 90.0f)];
    ////////////Title
    UILabel *ListName = [[UILabel alloc]initWithFrame:CGRectMake(curScreenSize.width*0.3, 25.0f, 100.0f, 30.0f)];
    [ListName setTag:10001];
    [ListName setText:arySetting[indexPath.row]];
    [backView addSubview:ListName];
    ////////////ICON
    UIImageView *logo = [[UIImageView alloc]initWithFrame:CGRectMake(curScreenSize.width*0.1, 17.0f, 40.0f, 40.0f)];
    [logo setImage:[UIImage imageNamed:aryIcon[indexPath.row]]];
    [backView addSubview:logo];
    ////////////Right
    UIImageView *rightgogo = [[UIImageView alloc] initWithFrame: CGRectMake(curScreenSize.width*0.8,30.0f, 20.0f, 20.0f)];
    [rightgogo setImage:[UIImage imageNamed:@"arrowicon.png"]];
    [backView addSubview:rightgogo];
    [cell addSubview:backView];
    [cell setBackgroundColor:[UIColor clearColor]];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}
/*  点击事件 */
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    /* 跳转页面 */
    UILabel *labName = (UILabel *)[[tableView cellForRowAtIndexPath:indexPath] viewWithTag:10001];
    UIViewController *vc;
    if([labName.text isEqualToString:@"定时设置"]){
        vc = [[TimeSetVC alloc] init];
        [vc setTitle:@"定时设置"];
    }
    /*else if([labName.text isEqualToString:@"房型设置"]){
        vc = [[HouseSetVC alloc] init];
        [vc setTitle:@"房型设置"];
    }*/
    else if([labName.text isEqualToString:@"用户设置"] || [labName.text isEqualToString:@"用户信息"]){
        vc = [[UserSetVC alloc] init];
        [vc setTitle:@"用户设置"];
    }
    else if([labName.text isEqualToString:@"工程设置"]){
        vc = [[ProjectSetVC alloc] init];
        [vc setTitle:@"工程设置"];
    }
    else if([labName.text isEqualToString:@"软件版本"]){
        vc = [[SoftwareEditionVC alloc] init];
        [vc setTitle:@"软件版本"];
    } else if ([labName.text isEqualToString:@"返回登录"]) {
        [CYM_DatabaseTable logoutDataBase];
        [appManager logout];
        [self.tabBarController dismissViewControllerAnimated:true completion:nil];
        return;
    }
    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
}
@end
