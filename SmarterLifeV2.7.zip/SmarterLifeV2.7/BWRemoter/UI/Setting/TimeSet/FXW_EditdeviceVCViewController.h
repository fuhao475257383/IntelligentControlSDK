//
//  FXW_EditdeviceVCViewController.h
//  BWRemoter
//
//  Created by 6602_Loop on 15-1-28.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "HE_BaseViewController.h"
#import "HE_BaseViewController.h"
#import "HE_DropDownProtocol.h"
#import "HE_DropDownListView.h"
@interface FXW_EditdeviceVCViewController : HE_BaseViewController<HE_DDDataSource,HE_DDDelegate,UITableViewDataSource,UITableViewDelegate>
{
    UIView *backView;
    NSMutableArray *aryRoomName;
    NSMutableArray *aryDeviceName;
    NSMutableArray *aryOperation;
    NSMutableArray *aryValue;
    
    //DropDownList
    HE_DropDownListView *ddRoom;
    HE_DropDownListView *ddDevice;
    UITableView *table;
    UITextField *txtInerval;
    NSString *opertion;
    NSString *opValue;
    //编辑、添加功能
    //重用所需
    NSString *defaultRoomName;
    NSString *selectedDevice;
}
/////////////
@property BOOL IsEdit;
@property (retain) Crontab *crontab;
////////////

///Type = 0->ADD.   1->Edit
@end
