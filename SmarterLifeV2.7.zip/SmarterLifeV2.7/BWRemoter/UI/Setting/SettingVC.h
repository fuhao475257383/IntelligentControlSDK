//
//  SettingVC.h
//  BWRemoter
//
//  Created by JianBo He on 14/12/5.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "HE_BaseViewController.h"

@interface SettingVC : HE_BaseViewController<UITableViewDelegate,UITableViewDataSource>

@property(nonatomic,retain) IBOutlet UITableView *table;

@end
