//
//  SoftwareEditionVC.m
//  BWRemoter
//
//  Created by wangbin on 14/12/7.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "SoftwareEditionVC.h"

@interface SoftwareEditionVC ()

@end

@implementation SoftwareEditionVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UILabel *AppEdition = [[UILabel alloc]initWithFrame:CGRectMake(40.0f, curScreenSize.height*0.2, curScreenSize.width-60.0f, 45.0f)];
    [AppEdition setText:@"App版本号：v2.7.1_t3_20160429"];
    [self.view addSubview:AppEdition];
    
    UIButton *btnDownLoadConfig = [[UIButton alloc] initWithFrame:CGRectMake(50, AppEdition.frameSumY_H + 10, 100, 30)];
    [btnDownLoadConfig setBackgroundColor:[UIColor clearColor]];
    [btnDownLoadConfig addTarget:self action:@selector(touchedConfig:) forControlEvents:UIControlEventTouchUpInside];
    
//    [self.view addSubview:btnDownLoadConfig];
}

- (void)touchedConfig:(UIButton *)sender{
    [appManager.xmppManager sendMsgToRoot:@"@#$%1002000E03"];
}
@end
