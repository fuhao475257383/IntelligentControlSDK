//
//  HE_SceneDeviceAdd.m
//  BWRemoter
//
//  Created by JianBo He on 15/1/25.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "HE_SceneDeviceAdd.h"
#define TAG_ROOM 10001
#define TAG_DEVICE 10002
#define CELL_HEIGHT 44
#define VIEW_MARGIN 30


@interface HE_SceneDeviceAdd()
{
    UIScrollView *mainView;
}
@end

@implementation HE_SceneDeviceAdd
@synthesize scene,defaultRoomName;

- (void)viewWillAppear:(BOOL)animated{
    if (controlType == 0) {
        NSString *strTitle = [NSString stringWithFormat:@"%@-%@",scene.name,@"添加设备"];
        [self.navigationItem setTitle:strTitle];
    }
    else{
        NSString *strTitle = [NSString stringWithFormat:@"%@-%@",scene.name,@"编辑设备"];
        [self.navigationItem setTitle:strTitle];
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    mainView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, curScreenSize.width, curScreenSize.height)];
    [mainView setShowsVerticalScrollIndicator:NO];
    [mainView setShowsVerticalScrollIndicator:NO];
    [self.view addSubview:mainView];
    if (controlType == 1) {
        SceneDevice *sd = [[scene deviceArr] objectAtIndex:deviceIndex];
        defaultRoomName = [CYM_Engine getRoomNameWithRoomDeviceName:sd.name];
    }
    else{
        defaultRoomName = @"全部";
    }
    aryRoomName = [self getAllRoomName];
    [self BuildView];
    if (controlType == 1) {
        SceneDevice *sd = [[scene deviceArr] objectAtIndex:deviceIndex];
        txtInerval.text = sd.interval;
        opertion = sd.operation;
        opValue = sd.value;
        
        //Table默认选中
        NSIndexPath *DefaultIndex;
        for (int i=0; i<aryOperation.count; i++) {
            NSString *opName = [aryOperation objectAtIndex:i];
            if ([opName isEqualToString:opertion]) {
                DefaultIndex =[NSIndexPath indexPathForRow:i inSection:0];
                [table selectRowAtIndexPath:DefaultIndex animated:YES scrollPosition:UITableViewScrollPositionBottom];
                break;
            }
        }
    }
}

- (void)setControlType:(NSInteger)type deviceIndex:(NSInteger) index{
    controlType = type;
    deviceIndex = index;
}

- (void)BuildView{
    
    //BackView 1
    //1.
    backView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, curScreenSize.width, curScreenSize.height)];
    UILabel *labRoom = [[UILabel alloc] initWithFrame:CGRectMake(curScreenSize.width * 0.1, 10, curScreenSize.width * 0.3, 30)];
    ddRoom = [[HE_DropDownListView alloc] initWithFrame:CGRectMake(labRoom.frameSumX_W, labRoom.frameY, curScreenSize.width *0.5, 30) dataSource:self delegate:self ddTag:TAG_ROOM];
    [labRoom setText:@"房间区域:"];
    [labRoom setTextAlignment:NSTextAlignmentLeft];
    ddRoom.mSuperView = self.view;
    //2.
    UILabel *labDevice = [[UILabel alloc] initWithFrame:CGRectMake(labRoom.frameX, labRoom.frameSumY_H + VIEW_MARGIN, curScreenSize.width * 0.3, 30)];
    ddDevice = [[HE_DropDownListView alloc] initWithFrame:CGRectMake(labDevice.frameSumX_W, labDevice.frameY, curScreenSize.width *0.5, 30) dataSource:self delegate:self ddTag:TAG_DEVICE];
    [labDevice setText:@"设备名称:"];
    [labDevice setTextAlignment:NSTextAlignmentLeft];
    ddDevice.mSuperView = self.view;
    
    
    //3.
    UILabel *labOperate = [[UILabel alloc] initWithFrame:CGRectMake(labDevice.frameX, labDevice.frameSumY_H + VIEW_MARGIN, curScreenSize.width *0.3f, 30)];
    table = [[UITableView alloc] initWithFrame:CGRectMake(labOperate.frameSumX_W, labOperate.frameY, curScreenSize.width*0.5f, 150) style:UITableViewStylePlain];
    table.tableFooterView = [[UIView alloc] init];
    table.separatorInset = UIEdgeInsetsMake(0, 3, 0, 17);
    
    [labOperate setText:@"指令操作:"];
    [labOperate setTextAlignment:NSTextAlignmentLeft];
    table.layer.cornerRadius = 3.f;
    table.layer.borderColor = [[UIColor grayColor] CGColor];
    table.layer.borderWidth = 1.f;
    [table setDelegate:self];
    [table setDataSource:self];
    
    
    //4.
    UILabel *labInterval = [[UILabel alloc] initWithFrame:CGRectMake(labOperate.frameX, table.frameSumY_H + VIEW_MARGIN, curScreenSize.width *0.3f, 30)];
    txtInerval = [[UITextField alloc] initWithFrame:CGRectMake(labInterval.frameSumX_W, labInterval.frameY, curScreenSize.width * 0.5f, 30)];

    [labInterval setText:@"指令间隔:"];
    [labInterval setTextAlignment:NSTextAlignmentLeft];
    
    [txtInerval setReturnKeyType:UIReturnKeyDone];
    [txtInerval setKeyboardType:UIKeyboardTypeDefault];
    txtInerval.placeholder = @"单位:秒(如: 0.1)";
    txtInerval.text        = @"0.5";
    txtInerval.layer.cornerRadius = 3.f;
    txtInerval.layer.borderColor = [[UIColor grayColor] CGColor];
    txtInerval.layer.borderWidth = 1.f;
    [txtInerval setDelegate:self];
    
    UIView *left = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 6.f, txtInerval.frameH)];
    [txtInerval setLeftViewMode:UITextFieldViewModeAlways];
    txtInerval.leftView = left;
    
    //5.
//    UIButton *btnDeleteScene = [[UIButton alloc] initWithFrame:CGRectMake(curScreenSize.width*0.2, table.frameSumY_H + 20, curScreenSize.width *0.22, 30)];
//    UIButton *btnSubmit = [[UIButton alloc] initWithFrame:CGRectMake(btnDeleteScene.frameSumX_W + curScreenSize.width*0.2,
//                                                                     table.frameSumY_H + 20, curScreenSize.width *0.22, 30)];
    UIButton *btnCancel = [[UIButton alloc] initWithFrame:CGRectMake(curScreenSize.width*0.2, txtInerval.frameSumY_H + VIEW_MARGIN + 30,
                                                                     curScreenSize.width *0.22, 30)];
    UIButton *btnSubmit = [[UIButton alloc] initWithFrame:CGRectMake(btnCancel.frameSumX_W + curScreenSize.width*0.2,btnCancel.frameY,
                                                                     curScreenSize.width *0.22f, 30)];
    UIButton *btnDelete = [[UIButton alloc] initWithFrame:CGRectMake(btnCancel.frameX + btnCancel.frameW/2.f, btnSubmit.frameSumY_H + VIEW_MARGIN,
                                                                     (curScreenSize.width - 2*(btnCancel.frameX + btnCancel.frameW/2.f) ), 30)];
    [btnCancel addTarget:self action:@selector(touchedCancel:) forControlEvents:UIControlEventTouchUpInside];
    [btnSubmit addTarget:self action:@selector(touchedSubmit:) forControlEvents:UIControlEventTouchUpInside];
    [btnDelete addTarget:self action:@selector(touchedDelete:) forControlEvents:UIControlEventTouchUpInside];
    
    [btnCancel setTitle:@"取消" forState:UIControlStateNormal];
    [btnSubmit setTitle:@"确定" forState:UIControlStateNormal];
    [btnDelete setTitle:@"删除指令" forState:UIControlStateNormal];
    
    [btnCancel setBackgroundColor:[UIColor colorOfTurnToUIColor:@"#848484"]];
    [btnSubmit setBackgroundColor:[UIColor colorOfTurnToUIColor:@"#848484"]];
    [btnDelete setBackgroundColor:[UIColor colorOfTurnToUIColor:@"#FFFFFF"]];
    
    [btnCancel setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btnSubmit setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btnDelete setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    
    btnCancel.layer.cornerRadius = 3.f;
    btnCancel.layer.borderColor = [[UIColor grayColor] CGColor];
    btnCancel.layer.borderWidth = 0.5f;

    btnSubmit.layer.cornerRadius = 3.f;
    btnSubmit.layer.borderColor = [[UIColor grayColor] CGColor];
    btnSubmit.layer.borderWidth = 0.5f;
    
    btnDelete.layer.cornerRadius = 3.f;
    btnDelete.layer.borderColor = [[UIColor grayColor] CGColor];
    btnDelete.layer.borderWidth = 0.5f;
    if (controlType == 0) {
        btnDelete.hidden = YES;
    }

    [backView addSubview:labRoom];
    [backView addSubview:ddRoom];
    [backView addSubview:labDevice];
    [backView addSubview:ddDevice];
    [backView addSubview:labOperate];
    [backView addSubview:table];
    [backView addSubview:labInterval];
    [backView addSubview:txtInerval];
    [backView addSubview:btnCancel];
    [backView addSubview:btnSubmit];
    [backView addSubview:btnDelete];
    [mainView addSubview:backView];
    [mainView setContentSize:CGSizeMake(mainView.frameW, btnDelete.frameSumY_H + 10)];
}

- (NSMutableArray *)getAllRoomName{
    NSMutableArray *result = [[NSMutableArray alloc] init];
    NSArray *tmp = [[HE_APPManager sharedManager] aryRoom];
    
    [result addObject:@"全部"];
    for (Room *r in tmp) {
        [result addObject:r.name];
    }
    
    return result;
}
- (NSMutableArray *)getAllDeviceNameWitnRoomName:(NSString *)room{
    NSMutableArray *result = [[NSMutableArray alloc] init];
    
    //////////////1。获取该房间的设备列表
    NSMutableArray *roomDevice = nil;
    if ([room isEqualToString:@"全部"]) {
        roomDevice = [NSMutableArray array];
        NSArray *aryAllDeviceName = [CYM_Engine getAlldeviceContentName];
        for (NSString *strName in aryAllDeviceName) {
            ControlDeviceContentValue * tmpDeviceValue = [CYM_Engine getDeviceDetailsWithDeviceName:strName];
            ////////////////不能控制的设备 -》 不予显示
            if ([tmpDeviceValue.property isEqualToString:@"I/O输入"] ||
                [tmpDeviceValue.category isEqualToString:@"传感器"]  ||
                [tmpDeviceValue.category isEqualToString:@"报警设备"]){
                continue;
            }
            [roomDevice addObject:tmpDeviceValue];
        }
    }
    else{
        roomDevice = [CYM_Engine getRoomDeviceValueWithName:room];
    }
    
    //////////2.将场景筛选走
    for (ControlDeviceContentValue *dv in roomDevice) {
        A4_DeviceTypeCode devCategory = [cmdB getDeviceTypeCodeWithCNString:dv.category];
        if (devCategory != A4_DEVICE_SENCE) {
            [result addObject:dv.name];
        }
    }
    return result;
}

- (void)setAllOperationWithDeviceName:(NSString *)name{
    if (!aryOperation) {
        aryOperation = [[NSMutableArray alloc] init];
        aryValue = [[NSMutableArray alloc] init];
    }
    [aryOperation removeAllObjects];
    [aryValue removeAllObjects];
    /*************获取该设备所有操作*****************/
    //1.获取该设备Model
    ControlDeviceContentValue *deviceDetail = [CYM_Engine getDeviceDetailsWithDeviceName:name];
    NSArray *aryOPVale = [self getAllOperationWithDevice:deviceDetail];
    aryOperation       = aryOPVale[0];
    aryValue           = aryOPVale[1];
    [table reloadData];
}
///获取该设备的操作列表 ary[0] = aryOperation ary[1] = aryValue
- (NSArray *)getAllOperationWithDevice:(ControlDeviceContentValue *)deviceDetail{
    NSMutableArray   *aryOp       = [NSMutableArray array];
    NSMutableArray   *aryVa       = [NSMutableArray array];
    A4_DeviceTypeCode devCategory = [cmdB getDeviceTypeCodeWithCNString:deviceDetail.category];
    deviceDetail.keyArr = [CYM_Engine getContrlKeyWithValueID:deviceDetail.ID];
    //2.Key数组存在值、 则使用Key数组作为操作数据
    //  或者 判断设备类型 写入操作值
    if (deviceDetail.keyArr != nil &&
        deviceDetail.keyArr.count >0) {
        for (ControlDeviceContentValueKey *ctrlKey in deviceDetail.keyArr) {
            ///////为bwenterqu 则不添入操作列表
            //[ctrlKey.name isEqualToString:@"bwenterqu"] ||
            if ([ctrlKey.name myContainsString:@"bw"]) {
                continue;
            }
            
            ///////填入操作列表
            [aryOp addObject:ctrlKey.name];
            NSString *cmd;
            switch (devCategory) {
                case A4_DEVICE_UART:{
                    cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:A4_DEVICE_UART Data:[NSString stringWithFormat:@"%@%02X%@",[cmdP getDeviceNumWithBindCMD:deviceDetail.value], (int)ctrlKey.value.length/2,ctrlKey.value]];
                }break;
                default:
                    cmd = ctrlKey.value;
                    break;
            }
            NSString *msg = [msgB getMessageWithType:[deviceDetail.com longLongValue] action:ACTION_TRANSMIT commond:cmd];
            [aryVa addObject:msg];
        }
    }
    else{
        
        switch (devCategory) {
            case A4_DEVICE_LIGHT:{
                [aryOp addObject:@"开"];
                [aryOp addObject:@"关"];
                
                NSString *deviceNum = [cmdP getDeviceNumWithBindCMD:deviceDetail.value];
                NSString *cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:devCategory Data:[NSString stringWithFormat:@"%@64",deviceNum]];
                NSString *msg = [msgB getMessageWithType:[deviceDetail.com longLongValue] action:ACTION_TRANSMIT commond:cmd];
                [aryVa addObject:msg];
                
                cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:devCategory Data:[NSString stringWithFormat:@"%@00", deviceNum]];
                msg = [msgB getMessageWithType:[deviceDetail.com longLongValue] action:ACTION_TRANSMIT commond:cmd];
                [aryVa addObject:msg];
                if ([deviceDetail.property isEqualToString:@"可调灯"]) {
                    [aryOp removeAllObjects];
                    [aryVa removeAllObjects];
                    for (int i=0; i<=100; i += 10) {
                        cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:devCategory Data:[NSString stringWithFormat:@"%@%02X",deviceNum,i]];
                        msg = [msgB getMessageWithType:[deviceDetail.com longLongValue] action:ACTION_TRANSMIT commond:cmd];
                        [aryOp addObject:[NSString stringWithFormat:@"亮度%d%%", i]];
                        [aryVa addObject:msg];
                    }
                }
            }break;
            case A4_DEVICE_CURTAIN:{
                
                if ([deviceDetail.property isEqualToString:@"开合窗帘"]) {
                    [aryOp addObject:@"开"];
                    [aryOp addObject:@"合"];
                }
                else if([deviceDetail.property isEqualToString:@"升降窗帘"]) {
                    [aryOp addObject:@"升"];
                    [aryOp addObject:@"降"];
                }
                else{
                    [aryOp addObject:@"开"];
                    [aryOp addObject:@"关"];
                }
                NSString *deviceNum = [cmdP getDeviceNumWithBindCMD:deviceDetail.value];
                NSString *cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:devCategory Data:[NSString stringWithFormat:@"%@64",deviceNum]];
                NSString *msg = [msgB getMessageWithType:[deviceDetail.com longLongValue] action:ACTION_TRANSMIT commond:cmd];
                [aryVa addObject:msg];
                
                cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:devCategory Data:[NSString stringWithFormat:@"%@00", deviceNum]];
                msg = [msgB getMessageWithType:[deviceDetail.com longLongValue] action:ACTION_TRANSMIT commond:cmd];
                [aryVa addObject:msg];
            }break;
            case A4_DEVICE_SENCE:{
                [aryOp addObject:@"场景开"];
            }break;
            case A4_DEVICE_SOCKET:{
                [aryOp addObject:@"开"];
                [aryOp addObject:@"关"];
                
                
                NSString *deviceNum = [cmdP getDeviceNumWithBindCMD:deviceDetail.value];
                NSString *cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:devCategory Data:[NSString stringWithFormat:@"%@64",deviceNum]];
                NSString *msg = [msgB getMessageWithType:[deviceDetail.com longLongValue] action:ACTION_TRANSMIT commond:cmd];
                [aryVa addObject:msg];
                
                cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:devCategory Data:[NSString stringWithFormat:@"%@00", deviceNum]];
                msg = [msgB getMessageWithType:[deviceDetail.com longLongValue] action:ACTION_TRANSMIT commond:cmd];
                [aryVa addObject:msg];
            }break;
            case A4_DEVICE_AIR_CONDITION:{
                NSString *deviceNum         = [cmdP getDeviceNumWithBindCMD:deviceDetail.value];
                NSString *strBackCMD        = [[HE_APPManager sharedManager] dicRoomDeviceState][deviceNum];
                NSString *strDataWithoutNum = [cmdP getDataWithoutNum:strBackCMD];
                if (strDataWithoutNum == nil || [strDataWithoutNum isEqualToString:@""]) {
                    break;
                }
                //////////////写上空调控制器的操作列表
                aryOp = [NSMutableArray arrayWithObjects:@"开", @"关",
                         @"制冷", @"制热", @"除湿",
                         @"自动", @"睡眠", @"送风",
                         @"低速", @"中速", @"高速",
                         @"制热16℃", @"制热17℃", @"制热18℃", @"制热19℃", @"制热20℃", @"制热21℃", @"制热22℃", @"制热23℃", @"制热24℃", @"制热25℃",
                         @"制热26℃", @"制热27℃", @"制热28℃", @"制热29℃", @"制热30℃",
                         @"制冷16℃", @"制冷17℃", @"制冷18℃", @"制冷19℃", @"制冷20℃", @"制冷21℃", @"制冷22℃", @"制冷23℃", @"制冷24℃", @"制冷25℃",
                         @"制冷26℃", @"制冷27℃", @"制冷28℃", @"制冷29℃", @"制冷30℃",nil];
                for (int i=0; i<aryOp.count; i++) {
                    NSString *strData = [NSString stringWithFormat:@"%@%@",deviceNum, strDataWithoutNum];
                    switch (i) {
                        case 0:{///开
                            strData = [cmdB airConditionMode:@"03" WithData:strData];
                        }break;
                        case 1:{///关
                            strData = [cmdB airConditionMode:@"00" WithData:strData];
                        }break;
                        case 2:{///制冷
                            strData = [cmdB airConditionMode:@"01" WithData:strData];
                        }break;
                        case 3:{///制热
                            strData = [cmdB airConditionMode:@"02" WithData:strData];
                        }break;
                        case 4:{///除湿
                            strData = [cmdB airConditionMode:@"05" WithData:strData];
                        }break;
                        case 5:{///自动
                            strData = [cmdB airConditionMode:@"03" WithData:strData];
                        }break;
                        case 6:{///睡眠
                        }break;
                        case 7:{///送风
                            strData = [cmdB airConditionMode:@"04" WithData:strData];
                        }break;
                        case 8:{///低速
                            strData = [cmdB airConditionWindSpeed:@"01" WithData:strData];
                        }break;
                        case 9:{///中速
                            strData = [cmdB airConditionWindSpeed:@"02" WithData:strData];
                        }break;
                        case 10:{///高速
                            strData = [cmdB airConditionWindSpeed:@"03" WithData:strData];
                        }break;
                        default:{///温度
                            NSString *strOpear  = [aryOp[i] componentsSeparatedByString:@"℃"][0];
                            if ([strOpear myContainsString:@"制热"]) {
                                strOpear = [strOpear componentsSeparatedByString:@"制热"][1];
                            }
                            if ([strOpear myContainsString:@"制冷"]) {
                                strOpear = [strOpear componentsSeparatedByString:@"制冷"][1];
                            }
                            strData   = [cmdB airConditionTemperature:[NSString stringWithFormat:@"%02X",strOpear.intValue*2]
                                                             WithData:[NSString stringWithFormat:@"%@%@",deviceNum, strDataWithoutNum]];
                        }break;
                    }
                    NSString *strCMD = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:A4_DEVICE_AIR_CONDITION Data:strData];
                    NSString *strMsg = [msgB getMessageWithType:[deviceDetail.com longLongValue] action:ACTION_TRANSMIT commond:strCMD];
                    
                    [aryVa addObject:strMsg];
                }
            }break;
            case A4_DEVICE_IO:{
                [aryOp addObject:@"开"];
                [aryOp addObject:@"关"];
                
                
                NSString *deviceNum = [cmdP getDeviceNumWithBindCMD:deviceDetail.value];
                NSString *cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:devCategory Data:[NSString stringWithFormat:@"%@0300", deviceNum]];
                NSString *msg = [msgB getMessageWithType:[deviceDetail.com longLongValue] action:ACTION_TRANSMIT commond:cmd];
                [aryVa addObject:msg];
                
                cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:devCategory Data:[NSString stringWithFormat:@"%@0200", deviceNum]];
                msg = [msgB getMessageWithType:[deviceDetail.com longLongValue] action:ACTION_TRANSMIT commond:cmd];
                
                [aryVa addObject:msg];
            }break;
            case A4_DEVICE_MUTIL:{
                NSString *deviceNum         = [cmdP getDeviceNumWithBindCMD:deviceDetail.value];
                if ([deviceDetail.property isEqualToString:@"电源控制"]) {
                    [aryOp addObject:@"开"];
                    [aryOp addObject:@"关"];
                    
                    NSString *tmpData = [NSString stringWithFormat:@"%@00FFFF",deviceNum];
                    NSString *cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:devCategory Data:tmpData];
                    NSString *msg = [msgB getMessageWithType:[deviceDetail.com longLongValue] action:ACTION_TRANSMIT commond:cmd];
                    
                    [aryVa addObject:msg];
                    
                    tmpData = [NSString stringWithFormat:@"%@01FFFF",deviceNum];
                    cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:devCategory Data:tmpData];
                    msg = [msgB getMessageWithType:[deviceDetail.com longLongValue] action:ACTION_TRANSMIT commond:cmd];
                    [aryVa addObject:msg];
                }
            }break;
            default:{
                [aryOp addObject:@"空操作"];
                [aryVa addObject:@""];
            }break;
        }
    }
    return @[aryOp, aryVa];
}
#pragma mark -
#pragma mark DropDownList Delegate
- (NSInteger)numberOfSections:(HE_DropDownListView *)dropDown{
    return 1;
}
- (NSInteger)dropDownList:(HE_DropDownListView *)dropDown defaultShowSection:(NSInteger)section{
    if (dropDown.tag == TAG_ROOM) {
        for (int i=0; i< aryRoomName.count; i++) {
            if ([defaultRoomName isEqualToString:[aryRoomName objectAtIndex:i]]) {
                aryDeviceName = [self getAllDeviceNameWitnRoomName:defaultRoomName];
                return i;
            }
        }
    }
    else if (dropDown.tag == TAG_DEVICE){
        @try {
            SceneDevice *sd = [[scene deviceArr] objectAtIndex:deviceIndex];
            for (int i=0; i< aryDeviceName.count; i++) {
                if ([sd.name isEqualToString:[aryDeviceName objectAtIndex:i]]) {
                    //获取指令列表
                    [self setAllOperationWithDeviceName:sd.name];
                    return i;
                }
            }
        }
        @catch (NSException *exception) {
            [self setAllOperationWithDeviceName:aryDeviceName[0]];
            return 0;
        }
//        @finally {
//            
//        }
    }
    return -1;
}

- (NSInteger)dropDownList:(HE_DropDownListView *)dropDown numberOfRowsInSection:(NSInteger)section{
    if (dropDown.tag == TAG_ROOM && aryRoomName.count >0) {
        return aryRoomName.count;
    }
    else if (dropDown.tag == TAG_DEVICE && aryDeviceName.count > 0) {
        return aryDeviceName.count;
    }
    return 0;
}
- (NSString *)dropDownList:(HE_DropDownListView *)dropDown titleInSection:(NSInteger)section index:(NSInteger)index{
    if (dropDown.tag == TAG_ROOM) {
        return aryRoomName[index];
    }
    else if (dropDown.tag == TAG_DEVICE) {
        return aryDeviceName[index];
    }
    return @"";
}
- (void)dropDownList:(HE_DropDownListView *)dropDown chooseAtSection:(NSInteger)section index:(NSInteger)index{
    //Choose
    if (dropDown.tag == TAG_ROOM) {
        aryDeviceName = [self getAllDeviceNameWitnRoomName:dropDown.sectionBtn.titleLabel.text];
        [ddDevice.sectionBtn setTitle:@"--" forState:UIControlStateNormal];
    }
    if (dropDown.tag == TAG_DEVICE) {
        [self setAllOperationWithDeviceName:dropDown.sectionBtn.titleLabel.text];
    }
}
#pragma mark - 
#pragma mark UITableView Delegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return aryOperation.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return CELL_HEIGHT;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"HE_SCENCE_DEVICE"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"HE_SCENCE_DEVICE"];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleGray;
    [cell.textLabel setText:aryOperation[indexPath.row]];
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    opertion = aryOperation[indexPath.row];
    opValue = aryValue[indexPath.row];
}

#pragma mark -
#pragma mark ACITON
- (void)tapedHideKeyBord:(id)sender{
    [super hideKeyBord];
}
- (void)touchedCancel:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)touchedDelete:(id)sender{
    if (controlType == 1) {
        [scene.deviceArr removeObjectAtIndex:deviceIndex];
    }
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)touchedSubmit:(id)sender{
    if (![ddDevice.sectionBtn.titleLabel.text isEqualToString:@"--"]) {
        NSLog(@"%@", controlType == 0? @"ADD":@"Modify");
        if (controlType == 0) {
            SceneDevice *scDevice = [[SceneDevice alloc] init];
            scDevice.name = ddDevice.sectionBtn.titleLabel.text;
            scDevice.interval = txtInerval.text;
            scDevice.operation = opertion == nil?@"" : opertion;
            scDevice.value = opValue == nil?@"" : opValue;
            [scene.deviceArr addObject:scDevice];
        }
        else{
            SceneDevice *scDevice = [scene.deviceArr objectAtIndex:deviceIndex];
            scDevice.name = ddDevice.sectionBtn.titleLabel.text;
            scDevice.interval = txtInerval.text;
            scDevice.operation = opertion == nil?@"" : opertion;
            scDevice.value = opValue == nil?@"" : opValue;
        }
        [self.navigationController popViewControllerAnimated:YES];
    }
}



@end
