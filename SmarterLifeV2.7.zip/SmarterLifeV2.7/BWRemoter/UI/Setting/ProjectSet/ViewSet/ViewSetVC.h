//
//  ViewSetVC.h
//  BWRemoter
//
//  Created by wangbin on 14/12/6.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "HE_BaseViewController.h"

@interface ViewSetVC : HE_BaseViewController<UITableViewDelegate,UITableViewDataSource>
{
    UITableView *table;
    NSMutableArray *aryScene;
}


@end
