//
//  HE_SceneDeviceAdd.h
//  BWRemoter
//
//  Created by JianBo He on 15/1/25.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "HE_BaseViewController.h"
#import "HE_DropDownProtocol.h"
#import "HE_DropDownListView.h"

@interface HE_SceneDeviceAdd : HE_BaseViewController<HE_DDDataSource,HE_DDDelegate,UITableViewDataSource,UITableViewDelegate>
{
    //
    UIView *backView;
    NSMutableArray *aryRoomName;
    NSMutableArray *aryDeviceName;
    NSMutableArray *aryOperation;
    NSMutableArray *aryValue;
    
    //DropDownList
    HE_DropDownListView *ddRoom;
    HE_DropDownListView *ddDevice;
    UITableView *table;
    UITextField *txtInerval;
    NSString *opertion;
    NSString *opValue;
    //编辑、添加功能
    //重用所需
    NSInteger controlType;
    NSInteger deviceIndex;
}
@property    NSString   *defaultRoomName;
@property(retain) Scene *scene;


///Type = 0->ADD.   1->Edit
- (void)setControlType:(NSInteger)type deviceIndex:(NSInteger) index;
@end
