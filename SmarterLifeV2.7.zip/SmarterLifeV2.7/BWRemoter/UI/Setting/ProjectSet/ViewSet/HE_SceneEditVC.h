//
//  HE_SceneEditVC.h
//  BWRemoter
//
//  Created by JianBo He on 15/1/25.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "HE_BaseViewController.h"
#import "DropDownListView.h"
#import "DropDownChooseProtocol.h"

@interface HE_SceneEditVC : HE_BaseViewController<DropDownChooseDataSource, DropDownChooseDelegate,UITableViewDataSource,UITableViewDelegate, UIAlertViewDelegate>
{
    UITextField *txtSceneName;
    DropDownListView *ddRoomName;
    UITableView *table;
}
//1.为新增  0 为编辑
@property NSInteger controlType;
@property(copy) Scene *scene;
@property(retain) NSMutableArray *aryScene;
@property NSInteger editIndex;
@end
