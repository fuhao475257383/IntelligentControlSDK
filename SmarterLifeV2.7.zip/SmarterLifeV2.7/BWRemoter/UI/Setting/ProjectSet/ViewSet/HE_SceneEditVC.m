//
//  HE_SceneEditVC.m
//  BWRemoter
//
//  Created by JianBo He on 15/1/25.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "HE_SceneEditVC.h"
#import "HE_SceneDeviceAdd.h"
#import "HE_SceneDevice.h"
#import "HE_FileOperation.h"

#define CELL_HEIGHT 50

@interface HE_SceneEditVC(){
    UIScrollView *mainView;
}

@end

@implementation HE_SceneEditVC
@synthesize scene, aryScene, editIndex, controlType;

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [table reloadData];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    mainView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, curScreenSize.width, curScreenSize.height)];
    [mainView setShowsVerticalScrollIndicator:NO];
    [mainView setShowsVerticalScrollIndicator:NO];
    [self.navigationItem setTitle:@"编辑场景"];
    if (controlType == 1) {
        //////新增场景、 房间默认为控制页面第一个房间
        [self.navigationItem setTitle:@"新增场景"];
        NSArray *aryRoom = [[HE_APPManager sharedManager] aryRoom];
        if (aryRoom.count > 0) {
            Room *r = aryRoom[0];
            scene.room = r.name;
        }
    }
    [self BuildView];
}

- (void)BuildView{
    UIView *backView1 = [[UIView alloc] initWithFrame:CGRectMake(0, 0, curScreenSize.width, 190.f)];
    UIView *backView3 = [[UIView alloc] initWithFrame:CGRectMake(0, backView1.frameSumY_H, backView1.frameW, 15)];
    UIView *backView2 = [[UIView alloc] initWithFrame:CGRectMake(0, backView3.frameSumY_H, curScreenSize.width, curScreenSize.height - backView1.frameH)];
    
    
    [backView1 setBackgroundColor:[UIColor whiteColor]];
    [backView2 setBackgroundColor:[UIColor whiteColor]];
    [backView3 setBackgroundColor:[UIColor colorWithWhite:0.5 alpha:0.2]];
    
    //BackView1
    //1.
    UILabel *labTitle = [[UILabel alloc] initWithFrame:CGRectMake(40, 20, 80, 30)];
    txtSceneName = [[UITextField alloc] initWithFrame:CGRectMake(labTitle.frameSumX_W + 10, labTitle.frameY, 150, 30)];
    
    [labTitle setTextAlignment:NSTextAlignmentLeft];
    [txtSceneName setTextAlignment:NSTextAlignmentCenter];
    [labTitle setText:@"场景名:"];
    [txtSceneName setText:scene.name];

    txtSceneName.returnKeyType = UIReturnKeyDone;
    txtSceneName.layer.cornerRadius = 3.f;
    txtSceneName.layer.borderColor = [[UIColor colorOfTurnToUIColor:@"#808080"] CGColor];
    txtSceneName.layer.borderWidth = 1.f;
    [txtSceneName setDelegate:self];
    
    //2.
    UILabel *labRoom = [[UILabel alloc] initWithFrame:CGRectMake(40, labTitle.frameSumY_H + 20, labTitle.frameW, labTitle.frameH)];
    ddRoomName = [[DropDownListView alloc] initWithFrame:CGRectMake(labRoom.frameSumX_W + 10, labRoom.frameY, 150, 30) dataSource:self delegate:self];

    
    ddRoomName.mSuperView = self.view;
    [labRoom setTextAlignment:NSTextAlignmentLeft];
    [labRoom setText:@"房间区域:"];
    //硬场景不能修改名称 和房间
    if ([scene.type isEqualToString:@"0"]) {
        [txtSceneName setUserInteractionEnabled:NO];
        [ddRoomName setUserInteractionEnabled:NO];
        UILabel *label = [[UILabel alloc]initWithFrame:ddRoomName.bounds];
        label.text = scene.room;
        label.backgroundColor = [UIColor whiteColor];
        label.textColor = [UIColor blackColor];
        [ddRoomName addSubview:label];
//        txtSceneName.backgroundColor = [UIColor colorOfTurnToUIColor:@"#E8E8E8"];
//        ddRoomName.backgroundColor = [UIColor colorOfTurnToUIColor:@"#E8E8E8"];
    }
    //3.
    UIButton *btnAddDevice = [[UIButton alloc] initWithFrame:CGRectMake(ddRoomName.frameX, ddRoomName.frameSumY_H + 20, 150, 35)];
    [btnAddDevice addTarget:self action:@selector(touchedAddDevice:) forControlEvents:UIControlEventTouchUpInside];
    [btnAddDevice setTitle:@"添加设备到场景" forState:UIControlStateNormal];
    [btnAddDevice setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [btnAddDevice setTitleColor:[UIColor whiteColor] forState:UIControlStateHighlighted];
    [btnAddDevice setBackgroundColor:[UIColor colorWithRed:230/255.0f green:230/255.0f blue:230/255.0f alpha:1]];
    [btnAddDevice.titleLabel setFont:[UIFont boldSystemFontOfSize:16.f]];
    
    btnAddDevice.layer.cornerRadius = 3.f;
    btnAddDevice.layer.borderColor = [btnAddDevice.backgroundColor CGColor];
    btnAddDevice.layer.borderWidth = 1.f;
    
    [backView1 addSubview:labTitle];
    [backView1 addSubview:txtSceneName];
    [backView1 addSubview:labRoom];
    [backView1 addSubview:ddRoomName];
    [backView1 addSubview:btnAddDevice];
    //BackView2
    UILabel *labDevName = [[UILabel alloc] initWithFrame:CGRectMake(5.f, 5, (curScreenSize.width)*0.27, 30)];
    UILabel *labOperation = [[UILabel alloc] initWithFrame:CGRectMake(labDevName.frameSumX_W, 5, (curScreenSize.width)*0.27, 30)];
    UILabel *labInterval = [[UILabel alloc] initWithFrame:CGRectMake(labOperation.frameSumX_W, 5, (curScreenSize.width)*0.27, 30)];

    [labDevName setText:@"设备名"];
    [labOperation setText:@"操作指令"];
    [labInterval setText:@"指令间隔"];
    
    [labDevName setTextAlignment:NSTextAlignmentCenter];
    [labOperation setTextAlignment:NSTextAlignmentCenter];
    [labInterval setTextAlignment:NSTextAlignmentCenter];
    
    labDevName.textColor = [UIColor colorOfTurnToUIColor:@"#1EA4E9"];
    labOperation.textColor = [UIColor colorOfTurnToUIColor:@"#1EA4E9"];
    labInterval.textColor = [UIColor colorOfTurnToUIColor:@"#1EA4E9"];
    
    table = [[UITableView alloc] initWithFrame:CGRectMake(labDevName.frameX, labInterval.frameSumY_H + 5, curScreenSize.width - (labDevName.frameX * 2.f), curScreenSize.height * 0.35) style:UITableViewStylePlain];
    table.tableFooterView = [[UIView alloc] init];
    table.separatorInset = UIEdgeInsetsMake(0, 3, 0, 17);
    [table setDelegate:self];
    [table setDataSource:self];
    
    UIButton *btnDeleteScene = [[UIButton alloc] initWithFrame:CGRectMake(curScreenSize.width*0.2, table.frameSumY_H + 20, curScreenSize.width *0.22, 30)];
    UIButton *btnSubmit = [[UIButton alloc] initWithFrame:CGRectMake(btnDeleteScene.frameSumX_W + curScreenSize.width*0.2,
                                                                     table.frameSumY_H + 20, curScreenSize.width *0.22, 30)];
    
    [btnDeleteScene addTarget:self action:@selector(touchedDeleteScene:) forControlEvents:UIControlEventTouchUpInside];
    [btnSubmit addTarget:self action:@selector(touchedSubmitScene:) forControlEvents:UIControlEventTouchUpInside];
    
    [btnDeleteScene setTitle:@"删除场景" forState:UIControlStateNormal];
    if (controlType == 1) {
       [btnDeleteScene setTitle:@"取消" forState:UIControlStateNormal];
    }
    [btnSubmit setTitle:@"应用" forState:UIControlStateNormal];
    btnDeleteScene.layer.cornerRadius = 5.f;
    btnDeleteScene.layer.borderColor = [[UIColor grayColor] CGColor];
    btnDeleteScene.layer.borderWidth = 1.f;
    btnSubmit.layer.cornerRadius = 5.f;
    btnSubmit.layer.borderColor = [[UIColor grayColor] CGColor];
    btnSubmit.layer.borderWidth = 1.f;
    
    btnDeleteScene.backgroundColor = [UIColor grayColor];
    btnSubmit.backgroundColor = [UIColor grayColor];
    [btnDeleteScene setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btnSubmit setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    btnDeleteScene.titleLabel.font = [UIFont systemFontOfSize:15.f];
    btnSubmit.titleLabel.font      = [UIFont systemFontOfSize:15.f];
    
    [backView2 addSubview:labDevName];
    [backView2 addSubview:labOperation];
    [backView2 addSubview:labInterval];
    [backView2 addSubview:table];
    [backView2 addSubview:btnDeleteScene];
    [backView2 addSubview:btnSubmit];
    //End
    [mainView addSubview:backView1];
    [mainView addSubview:backView3];
    [mainView addSubview:backView2];
    [mainView setContentSize:CGSizeMake(mainView.frameW, backView2.frameSumY_H)];
    [self.view addSubview:mainView];
}

#pragma mark -
#pragma mark UITableView Delegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return scene.deviceArr.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return CELL_HEIGHT;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *reuseStr = @"HE_SCENEDEVICE";
    HE_SceneDevice *cell = [tableView dequeueReusableCellWithIdentifier:reuseStr];
    if (!cell) {
        cell = [[HE_SceneDevice alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseStr];
    }
    SceneDevice *sDev = [scene.deviceArr objectAtIndex:indexPath.row];
    [cell.labName setText:sDev.name];
    [cell.labOperation setText:sDev.operation];
    [cell.labInterval setText:[NSString stringWithFormat:@"%@ s",sDev.interval]];
    [cell.btnEdit setTag:indexPath.row];
    [cell.btnEdit addTarget:self action:@selector(touchedEditSceneDevice:) forControlEvents:UIControlEventTouchUpInside];
    cell.selectionStyle = UITableViewCellAccessoryNone;
    return cell;
}

///滑动 删除
- (NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath{
    return @"删除";
}
- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewCellEditingStyleDelete;
}
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    [scene.deviceArr removeObjectAtIndex:indexPath.row];
    [tableView reloadData];
}

#pragma mark -
#pragma mark dropDownListDelegate  
-(void)chooseAtSection:(NSInteger)section index:(NSInteger)index{
    Room *r = [[[HE_APPManager sharedManager] aryRoom] objectAtIndex:index];
    scene.room = r.name;
}

#pragma mark dropdownList DataSource
-(NSInteger)numberOfSections{
    return 1;
}
-(NSInteger)numberOfRowsInSection:(NSInteger)section{
    return [[HE_APPManager sharedManager] aryRoom].count ;
}
-(NSString *)titleInSection:(NSInteger)section index:(NSInteger) index{
    Room *r = [[[HE_APPManager sharedManager] aryRoom] objectAtIndex:index];

    return r.name;
}
-(NSInteger)defaultShowSection:(NSInteger)section{
    NSArray *aryRoom = [[HE_APPManager sharedManager] aryRoom];
    for(int i=0; i< aryRoom.count; i++){
        Room *r = [aryRoom objectAtIndex:i];
        if ([r.name isEqualToString:scene.room]) {
            return i;
        }
    }
    return -1;
}

#pragma mark - 
#pragma mark UIAlertView
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag == 10001 && buttonIndex ==1 ) {
        
        if (controlType == 0) {//删除场景
            //修改Scene数据库
            [aryScene removeObjectAtIndex:editIndex];
            [CYM_Engine deleteSceneWithSceneName:scene.name];
            //修改Room数据库
            [CYM_Engine deleteRoomDeviceContentWithName:scene.name];
            [self generateJSONFileAndUpload];
        }
        [self.navigationController popViewControllerAnimated:YES];
    }
    else if (alertView.tag == 10002 && buttonIndex == 1){
        //应用
        if (controlType == 0) {
            //修改Scene数据库
            scene.isedit = @"1";
            aryScene[editIndex] = [scene copy];
            [CYM_Engine updateSceneWithName:scene];
            //修改Room数据库 修改名称之类的
            [CYM_Engine addRoomDeviceContentWithName:scene.name room:ddRoomName.sectionBtn.titleLabel.text];
        }
        else if (controlType == 1){//新增
            scene.prio = @"FFFFFFFFFFFF";
            scene.type = @"1";
            scene.isedit = @"1";
            scene.status = @"on";
            scene.delay = @"0";
            scene.scene = @"null";
            [aryScene addObject:[scene copy]];
            [CYM_Engine updateSceneWithName:scene];
            //修改Room数据库
            [CYM_Engine addRoomDeviceContentWithName:scene.name room:ddRoomName.sectionBtn.titleLabel.text];
        }
        [self generateJSONFileAndUpload];
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)generateJSONFileAndUpload{
    //1.根据数据库生成JSON文件
    //2.上传JSON文件
    //3.上传成功->更新本地信息、 否则下载服务器文件更新本地数据库
    NSData *roomData = [CYM_Engine generateJSONFileWithName:@"room.json"];
    NSData *sceneData = [CYM_Engine generateJSONFileWithName:@"scene.json"];
    [[HE_APPManager sharedManager] uploadFileWithName:@"room.json" andData:roomData isShowHUD:YES];
    [[HE_APPManager sharedManager] uploadFileWithName:@"scene.json" andData:sceneData isShowHUD:YES];
}

#pragma mark -
#pragma mark  ACtion
///新增设备指令
- (void)touchedAddDevice:(id)sender{
    if(![txtSceneName.text isEqualToString:@""]){
        scene.name            = txtSceneName.text;
        SceneDevice *lastObj  = [[scene deviceArr] lastObject];
        NSString    *roomName = [CYM_Engine getRoomNameWithRoomDeviceName:lastObj.name];
        if (roomName == nil || [roomName isEqualToString:@""]) {
            roomName = @"全部房间";
        }
        HE_SceneDeviceAdd *vc = [[HE_SceneDeviceAdd alloc] init];
        [vc setControlType:0 deviceIndex:[scene deviceArr].count - 1];
        [vc setDefaultRoomName:roomName];
        [vc setScene:scene];
        [self.navigationController pushViewController:vc animated:YES];
    }
    else{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示"
                                                        message:@"请输入场景名"
                                                       delegate:nil
                                              cancelButtonTitle:@"确认"
                                              otherButtonTitles: nil];
        [alert show];
    }
}
///编辑设备指令
- (void)touchedEditSceneDevice:(UIButton *) button{
    HE_SceneDeviceAdd *vc = [[HE_SceneDeviceAdd alloc] init];
    [vc setControlType:1 deviceIndex:button.tag];
    [vc setScene:scene];
    [self.navigationController pushViewController:vc animated:YES];
}
///删除场景
- (void)touchedDeleteScene:(id)sender{
    scene.name = txtSceneName.text;
    scene.room = ddRoomName.sectionBtn.titleLabel.text;
    if (controlType == 1) {
        [self.navigationController popViewControllerAnimated:YES];
        return;
    }
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:[NSString stringWithFormat:@"是否确认删除场景: %@",scene.name] delegate:self cancelButtonTitle:@"取消" otherButtonTitles: @"确认",nil];
    alert.tag = 10001;
    [alert show];
}
///提交场景
- (void)touchedSubmitScene:(id)sender{
    scene.name = txtSceneName.text;
    scene.room = ddRoomName.sectionBtn.titleLabel.text;
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:[NSString stringWithFormat:@"是否确认提交场景: %@",scene.name] delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确认", nil];
    alert.tag = 10002;
    [alert show];
}
@end
