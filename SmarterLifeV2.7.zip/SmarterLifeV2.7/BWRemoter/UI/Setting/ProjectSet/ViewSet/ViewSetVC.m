//
//  ViewSetVC.m
//  BWRemoter
//
//  Created by wangbin on 14/12/6.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "ViewSetVC.h"
#import "HE_SceneEditVC.h"

#define CELL_HEIGHT 80
#define MAX_HEIGHT (curScreenSize.height * 0.7)

@implementation ViewSetVC

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [table reloadData];
}

- (void)viewDidLoad {
    
    [super viewDidLoad];
    [self.navigationItem setTitle:@"场景设置"];
    aryScene = [CYM_Engine getAllSoftHardScene];
//    CGFloat height = CELL_HEIGHT * aryScene.count + 20;
    table = [[UITableView alloc]initWithFrame:CGRectMake(0.0f, self.NavgationBarHeight, curScreenSize.width, /*height>=MAX_HEIGHT?MAX_HEIGHT:height*/MAX_HEIGHT) style:UITableViewStylePlain];
    [table setBackgroundColor:[UIColor clearColor]];
    [table setContentSize:CGSizeMake(table.frameW, /*height*/MAX_HEIGHT)];
    [table setDelegate:self];
    [table setDataSource:self];
    table.tableFooterView = [[UIView alloc] init];
    table.separatorInset = UIEdgeInsetsMake(0, 3, 0, 17);
    
    UIButton *AddViewModel = [[UIButton alloc]initWithFrame:CGRectMake(curScreenSize.width*0.1,self.view.frame.size.height - 75, 80.0f, 35.0f)];
    [AddViewModel setBackgroundImage:[UIImage imageNamed:@"add_icon.png"] forState:UIControlStateNormal];
    [AddViewModel addTarget:self action:@selector(AddModelClick:) forControlEvents:UIControlEventTouchUpInside];

    [self.view addSubview:AddViewModel];
    [self.view addSubview:table];
}

#pragma mark - UITableViewDelegate And DataSourse
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return CELL_HEIGHT;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return aryScene.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *cell= [tableView dequeueReusableCellWithIdentifier:@"wb_Cell"];
    
    if (cell==nil) {
        cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"wb_Cell"];
    }
    UIView *backView = [[UIView alloc] initWithFrame: CGRectMake(0.0f, 0.0f, curScreenSize.width, 90.0f)];
    UILabel *ListName = [[UILabel alloc]initWithFrame:CGRectMake(curScreenSize.width*0.3, 25.0f, curScreenSize.width * 0.4, 30.0f)];
    
    Scene *s = [aryScene objectAtIndex:indexPath.row];
    [ListName setText:s.name];
    [backView setTag:10001];
    [backView addSubview:ListName];
    UIImageView *logo = [[UIImageView alloc]initWithFrame:CGRectMake(curScreenSize.width*0.1, 17.0f, 40.0f, 40.0f)];
    
    [logo setImage:[UIImage imageNamed:@"scenomode.png"]];
    [backView addSubview:logo];
    UIButton *editBtn = [[UIButton alloc]initWithFrame:CGRectMake(curScreenSize.width*0.7, 25.0f, 70.0f, 30.0f)];
    [editBtn setTitle:@"编辑" forState:UIControlStateNormal];
    [editBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [editBtn.layer setBorderWidth:1.0];   //边框宽度
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    CGColorRef colorref = CGColorCreate(colorSpace,(CGFloat[]){ 0, 0, 0, 1 });
    [editBtn.layer setBorderColor:colorref];//边框颜色
    [editBtn.layer setMasksToBounds:YES];
    [editBtn.layer setCornerRadius:5.0f];
    [backView addSubview:editBtn];
    [editBtn setTag:indexPath.row];
    [editBtn addTarget:self action:@selector(touchedEditButton:) forControlEvents:UIControlEventTouchUpInside];
    UIView *tmp = [cell viewWithTag:10001];
    if (tmp) {
        [tmp removeFromSuperview];
    }
    [cell addSubview:backView];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    [cell setAccessoryType:UITableViewCellAccessoryNone];
    [cell setBackgroundColor:[UIColor clearColor]];
    
    return cell;
}

- (void)touchedEditButton:(UIButton *)sender{
    HE_SceneEditVC *vc = [[HE_SceneEditVC alloc] init];
    [vc setScene:aryScene[sender.tag]];
    [vc setAryScene:aryScene];
    [vc setControlType:0];
    [vc setEditIndex:sender.tag];
    [self.navigationController pushViewController:vc animated:YES];
}

-(void)AddModelClick:(id)sender{
    HE_SceneEditVC *vc = [[HE_SceneEditVC alloc] init];
    [vc setScene:[[Scene alloc] init]];
    [vc setAryScene:aryScene];
    [vc setControlType:1];
    [vc setEditIndex:aryScene.count];
    [self.navigationController pushViewController:vc animated:YES];
}
@end
