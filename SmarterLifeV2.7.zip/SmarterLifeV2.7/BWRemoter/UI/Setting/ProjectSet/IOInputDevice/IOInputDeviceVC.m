//
//  IOInputDeviceVC.m
//  BWRemoter
//
//  Created by wangbin on 14/12/6.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "IOInputDeviceVC.h"
#import "CYM_Engine.h"
#import "IOInputEditVC.h"
#import "ZJSwitch.h"
@interface IOInputDeviceVC ()
{
    UITableView *table;
    NSMutableArray *aryIOScene;
    /////////////State
    BOOL        hasModifty;
}
@end

@implementation IOInputDeviceVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"I/O输入设备";

    table = [[UITableView alloc]initWithFrame:CGRectMake(0.0f, 10.0f, curScreenSize.width, curScreenSize.height - self.NavgationBarHeight) style:UITableViewStylePlain];
    table.tableFooterView = [[UIView alloc] init];
    table.separatorInset = UIEdgeInsetsMake(0, 3, 0, 17);
    [table setDelegate:self];
    [table setDataSource:self];
    [self.view addSubview:table];
    /////////////获取 数据
    NSMutableArray *aryTMP = [CYM_Engine getAllOtherScene];
    
    aryIOScene = [NSMutableArray array];
    NSMutableArray *aryIODevice = [CYM_Engine getContrlValueWithProperty:@"I/O输入"];
    for (ControlDeviceContentValue *v in aryIODevice) {
        Scene *curScene = nil;
        for (Scene *s in aryTMP) {
            if ([s.name isEqualToString:v.name]) {
                curScene = s;
                break;
            }
        }
        
        //////I/O设备在场景中不存在配置-》则初始化
        if (curScene == nil) {
            NSLog(@"新增");
            curScene = [[Scene alloc] init];
            curScene.room  = @"null";
            curScene.type  = @"2";
            curScene.prio  = @"FFFFFFFFFFFFFF";
            curScene.delay = @"1.0";
            curScene.scene = @"null";
            curScene.deviceArr = nil;
            curScene.name = v.name;
            curScene.status = @"off";
            curScene.isedit = @"0";
            
            curScene.sceneId = [NSString stringWithFormat:@"%@01",[cmdP getDeviceNumWithBindCMD:v.value]];
            hasModifty = YES;
        }
        [aryIOScene addObject:curScene];
    }
    
}
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [table reloadData];
}

#pragma mark - UITableViewDelegate And DataSourse
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return aryIOScene.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *cell= [tableView dequeueReusableCellWithIdentifier:@"IOSetxxx"];
    
    if (cell==nil) {
        cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"IOSet"];
    }
    Scene *ioDevice = aryIOScene[indexPath.row];
    
    UIView *backView = [[UIView alloc] initWithFrame: CGRectMake(0.0f, 0.0f, curScreenSize.width, 90.0f)];
    
    ////////////Name
    UILabel *ListName = [[UILabel alloc]initWithFrame:CGRectMake(curScreenSize.width*0.05, 25.0f, 150.0f, 30.0f)];
    [ListName setText:ioDevice.name];
    [backView addSubview:ListName];
    ////////////Switch
    ZJSwitch *switchView = [[ZJSwitch alloc] initWithFrame:CGRectMake(curScreenSize.width*0.5, 25.0f, 70.0f, 30.0f)];
    [switchView setOnText:@"ON"];
    [switchView setOffText:@"OFF"];
    [switchView setTextFont:[UIFont boldSystemFontOfSize:14]];
    [switchView setOffTextColor:[UIColor grayColor]];
    [switchView addTarget:self action:@selector(switchAction:) forControlEvents:UIControlEventValueChanged];
    [backView addSubview:switchView];
    [switchView setTag:indexPath.row];
    [switchView setOn:NO];
    if ([ioDevice.status isEqualToString:@"on"]) {
        [switchView setOn:YES];
    }
    //////////Btn-Edit
    UIButton *editBtn = [[UIButton alloc]initWithFrame:CGRectMake(curScreenSize.width*0.8, 25.0f, 50.0f, 30.0f)];
    [editBtn setTitle:@"编辑" forState:UIControlStateNormal];
    [editBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [editBtn setTag:indexPath.row];
    [editBtn addTarget:self action:@selector(touchedToEditDeivice:) forControlEvents:UIControlEventTouchUpInside];
    [editBtn.layer setBorderWidth:1.0];   //边框宽度
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    CGColorRef colorref = CGColorCreate(colorSpace,(CGFloat[]){ 0, 0, 0, 1 });
    [editBtn.layer setBorderColor:colorref];//边框颜色
    [editBtn.layer setMasksToBounds:YES];
    [editBtn.layer setCornerRadius:5.0f];
    [backView addSubview:editBtn];
    
    [cell addSubview:backView];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    [cell setAccessoryType:UITableViewCellAccessoryNone];
    [cell setBackgroundColor:[UIColor clearColor]];
    
    return cell;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 80;
}
/*  点击事件 */
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}
- (void)touchedToEditDeivice:(UIButton *)btn{
    IOInputEditVC *vc = [[IOInputEditVC alloc] init];
    [vc setIODevice:aryIOScene[btn.tag]];
    hasModifty = YES;
    [self.navigationController pushViewController:vc animated:YES];
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(buttonIndex ==1){
        for (Scene *s in aryIOScene) {
            [CYM_Engine updateSceneWithName:s];
        }
        NSData *sceneData = [CYM_Engine generateJSONFileWithName:@"scene.json"];
        [[HE_APPManager sharedManager] uploadFileWithName:@"scene.json" andData:sceneData isShowHUD:YES];
//        FIXME: New UU
//        [[HE_APPManager sharedManager] uploadFileWithName:@"scene.json"
//                                                  andData:sceneData
//                                                isShowHUD:YES
//                                                handler:^(NSString *fileName, NSError *error) {
//                                                    [[HE_APPManager sharedManager] hudShowMsg:@"保存成功" andInterval:1];
//                                                    [self.navigationController popViewControllerAnimated:YES];
//                                                  }];
        
        [self.navigationController popViewControllerAnimated:YES];
    }
    else{
        [self.navigationController popViewControllerAnimated:YES];
    }
}
-(void)touchedBackButton:(id)sender{
    if (hasModifty) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示"
                                                       message:@"确定使用此操作？"
                                                      delegate:self
                                             cancelButtonTitle:@"取消"
                                             otherButtonTitles:@"确定", nil];
        [alert show];
    }
    else{
        [self.navigationController popViewControllerAnimated:YES];
    }
}
-(void)switchAction:(id)sender{
    swtch = (ZJSwitch *)sender;
    Scene *tmpScene = aryIOScene[swtch.tag];
    tmpScene.status = swtch.on?@"on":@"off";
    hasModifty = YES;
}
@end
