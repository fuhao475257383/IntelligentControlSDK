//
//  IOInputEditVC.h
//  BWRemoter
//
//  Created by JianBo He on 15/3/3.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "HE_BaseViewController.h"
#import "HE_DropDownProtocol.h"
#import "HE_DropDownListView.h"

@interface IOInputEditVC : HE_BaseViewController<HE_DDDataSource,HE_DDDelegate,UITableViewDataSource,UITableViewDelegate>
{
    UIView *backView;
    NSMutableArray *aryMode;
    NSMutableArray *aryRoomName;
    NSMutableArray *aryDeviceName;
    NSMutableArray *aryOperation;
    NSMutableArray *aryValue;
    
    //DropDownList
    HE_DropDownListView *ddRoom;
    HE_DropDownListView *ddDevice;
    HE_DropDownListView *ddMode;
    UITableView *table;
    UITextField *txtInerval;
    NSString *opertion;
    NSString *opValue;
}
@property (nonatomic, retain)Scene *IODevice;
@end
