//
//  EditDoorVC.m
//  BWRemoter
//
//  Created by tc on 15/11/12.
//  Copyright © 2015年 ReSun. All rights reserved.
//

#import "EditDoorVC.h"
#import "CustomSwitch.h"
#import "HE_DropDownProtocol.h"
#import "HE_DropDownListView.h"

@interface EditDoorVC () <HE_DDDataSource,HE_DDDelegate>

//模式、防区列表
@property (nonatomic,strong) NSMutableArray *zoneArray;
//场景列表
@property (nonatomic,strong) NSMutableArray *sceneArray;
//门锁设置实例
@property (nonatomic,strong) Doorlock *doorlock;
//提醒语
@property (nonatomic,strong) NSMutableArray *detailArray;
//是否要显示提示框
@property (nonatomic) BOOL isNeedShowAlertView;
//下拉框数组
@property (nonatomic,strong) NSMutableArray *dropArray;
//switch数组
@property (nonatomic,strong) NSMutableArray *switchArray;

@end

@implementation EditDoorVC
//进入界面时，显示是否设置了场景安防
- (NSMutableArray *)detailArray {
    if (_detailArray == nil) {
        _detailArray = [[NSMutableArray alloc]init];
    }
    return _detailArray;
}
- (NSMutableArray *)dropArray {
    if (_dropArray == nil) {
        _dropArray = [[NSMutableArray alloc]init];
    }
    return _dropArray;
}
- (NSMutableArray *)switchArray {
    if (_switchArray == nil) {
        _switchArray = [[NSMutableArray alloc]init];
    }
    return _switchArray;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self getZoneAndSensorInfo];
    self.isNeedShowAlertView = NO;
    self.title = self.doorName;
    [self addViewInfo];
}
#pragma mark -获得数据
- (void)getZoneAndSensorInfo {
    //所有防区
    self.zoneArray = [CYM_Engine getAllZoneInfo];
    //所有场景
    self.sceneArray = [CYM_Engine getAllSoftHardScene];
}
#pragma mark -界面设置
- (void)addViewInfo {
    self.doorlock = [CYM_Engine getDoorlockSetWithName:self.doorName];
    [self setRowInfoWithScene:@"入门场景：" andState:NO withRectY:104 withDropTag:0];
    [self setRowInfoWithScene:@"离家场景：" andState:NO withRectY:154 withDropTag:1];
    [self setRowInfoWithScene:@"入户安防：" andState:NO withRectY:234 withDropTag:2];
    [self setRowInfoWithScene:@"离家安防：" andState:NO withRectY:284 withDropTag:3];
    UIButton *sureButton = [[UIButton alloc]initWithFrame:CGRectMake(curScreenSize.width*2/5, curScreenSize.height - 60, curScreenSize.width/5, 30)];
    [sureButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [sureButton setTitle:@"应用" forState:UIControlStateNormal];
    [sureButton setBackgroundColor:[UIColor colorWithRed:230/255.0 green:230/255.0 blue:230/255.0 alpha:1]];
    sureButton.layer.cornerRadius   = 5;
    sureButton.layer.masksToBounds  = YES;
    sureButton.layer.borderColor    = [UIColor blackColor].CGColor;
    sureButton.layer.borderWidth    = 1;
    [self.view addSubview:sureButton];
}
//按照行添加
- (void)setRowInfoWithScene:(NSString *)sceneName andState:(BOOL)isChoice withRectY:(CGFloat)rectY withDropTag:(NSInteger)tag{
    //名字
    CGRect labelRect = CGRectMake(0, rectY, curScreenSize.width/3, 30);
    UILabel *label = [[UILabel alloc]initWithFrame:labelRect];
    label.text = sceneName;
    label.font = [UIFont systemFontOfSize:15];
    label.textAlignment = NSTextAlignmentCenter;
    label.textColor = [UIColor blackColor];
    [self.view addSubview:label];
    //选择框
    CGRect dropRect = CGRectMake(curScreenSize.width*3/10, rectY, curScreenSize.width*2/5, 30);
    HE_DropDownListView *dropView = [[HE_DropDownListView alloc]initWithFrame:dropRect dataSource:self delegate:self ddTag:tag];
    dropView.mSuperView = self.view;
    [self.view addSubview:dropView];
    dropView.tag = tag;
    //switch按钮
    CGRect switchRect = CGRectMake(curScreenSize.width*3/4, rectY, 60, 30);
    CustomSwitch *customSwitch = [[CustomSwitch alloc]initWithFrame:switchRect andState:isChoice];
    [self.view addSubview:customSwitch];
    customSwitch.tag = tag;
    [self.dropArray addObject:dropView];
    [self.switchArray addObject:customSwitch];
}
#pragma mark -dropdownList数据源和代理
//几个分区
- (NSInteger)numberOfSections:(HE_DropDownListView *)dropDown {
    return 1;
}
//分区有几行
- (NSInteger)dropDownList:(HE_DropDownListView *)dropDown numberOfRowsInSection:(NSInteger)section {
    if (dropDown.tag%2) {
        if (!self.sceneArray.count) {
            return 1;
        }
        return self.sceneArray.count;
    }
    else {
        if (!self.zoneArray.count) {
            return 1;
        }
        return self.zoneArray.count;
    }
}
//每行title
- (NSString *)dropDownList:(HE_DropDownListView *)dropDown titleInSection:(NSInteger)section index:(NSInteger)index {
    if (dropDown.tag%4 <= 1) {
        if (!self.sceneArray.count) {
            return @"无场景数据";
        }
        //场景tag12sensor
        return ((Scene *)self.sceneArray[index]).name;
    }else {
        if (!self.zoneArray.count) {
            return @"无安防数据";
        }
        //模式tag34zone
        return ((SecurityContent_zone *)self.zoneArray[index]).name;
    }
}
//默认显示的数据
- (NSInteger)dropDownList:(HE_DropDownListView *)dropDown defaultShowSection:(NSInteger)section {
    if (dropDown.tag == 0) {
        if (self.doorlock.enterScene == nil) {
            self.isNeedShowAlertView = YES;
            return 0;
        }
        for (Scene *scene in self.sceneArray) {
            if ([scene.name isEqualToString:self.doorlock.enterScene]) {
                return [self.sceneArray indexOfObject:scene];
            }
        }
        self.isNeedShowAlertView = YES;
    }else if (dropDown.tag == 1) {
        if (self.doorlock.leaveScene == nil) {
            self.isNeedShowAlertView = YES;
            return 0;
        }
        for (Scene *scene in self.sceneArray) {
            if ([scene.name isEqualToString:self.doorlock.leaveScene]) {
                return [self.sceneArray indexOfObject:scene];
            }
        }
        self.isNeedShowAlertView = YES;
    }else if (dropDown.tag == 2) {
        if (self.doorlock.enterSecutityZone == nil) {
            self.isNeedShowAlertView = YES;
            return 0;
        }
        for (SecurityContent_zone *zone in self.zoneArray) {
            if ([zone.name isEqualToString:self.doorlock.enterSecutityZone]) {
                return [self.zoneArray indexOfObject:zone];
            }
        }
        self.isNeedShowAlertView = YES;
    }else if (dropDown.tag == 3){
        if (self.doorlock.leaveSecutityZone == nil) {
            self.isNeedShowAlertView = YES;
            return 0;
        }
        for (SecurityContent_zone *zone in self.zoneArray) {
            if ([zone.name isEqualToString:self.doorlock.leaveSecutityZone]) {
                return [self.zoneArray indexOfObject:zone];
            }
        }
        self.isNeedShowAlertView = YES;
    }
    return 0;
}
//界面将要显示时
- (void)viewWillAppear:(BOOL)animated {
    [self.detailArray addObject:@"入户场景"];
    [self.detailArray addObject:@"离家场景"];
    [self.detailArray addObject:@"入户安防"];
    [self.detailArray addObject:@"离家安防"];
    if (self.isNeedShowAlertView) {
        //查找数组，如果入户场景是存在的，就移除
        for (Scene *scene in self.sceneArray) {
            if ([scene.name isEqualToString:self.doorlock.enterScene]) {
                [self.detailArray removeObject:@"入户场景"];
                break;
            }
        }
        if (!self.sceneArray.count) {
            [self prohibitClickWithTag:0];
        }
        
        for (Scene *scene in self.sceneArray) {
            if ([scene.name isEqualToString:self.doorlock.leaveScene]) {
                [self.detailArray removeObject:@"离家场景"];
                break;
            }
        }
        if (!self.sceneArray.count) {
            [self prohibitClickWithTag:1];
        }
        
        for (SecurityContent_zone *zone in self.zoneArray) {
            if ([zone.name isEqualToString:self.doorlock.enterSecutityZone]) {
                [self.detailArray removeObject:@"入户安防"];
                break;
            }
        }
        if (!self.zoneArray.count) {
            [self prohibitClickWithTag:2];
        }
        
        for (SecurityContent_zone *zone in self.zoneArray) {
            if ([zone.name isEqualToString:self.doorlock.leaveSecutityZone]) {
                [self.detailArray removeObject:@"离家安防"];
                break;
            }
        }
        if (!self.zoneArray.count) {
            [self prohibitClickWithTag:3];
        }
        
    }
    if (self.detailArray.count != 0 && self.isNeedShowAlertView == YES) {
        [self showAlertViewWithDetail];
    }
}
//假如没有主句，则后面的switch是不允许点击的。
- (void)prohibitClickWithTag:(NSInteger)tag {
    for (HE_DropDownListView *dropView in self.dropArray) {
        if (dropView.tag == tag) {
            UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, dropView.frame.origin.y, curScreenSize.width, 30)];
            view.alpha = 0.3;
            [self.view addSubview:view];
            //添加个手势
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(showRemind)];
            [view addGestureRecognizer:tap];
        }
    }
}
- (void)showRemind {
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"没有场景或安防数据，\n请先到工程设置中添加。" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
    [alert show];
}
- (void)showAlertViewWithDetail {
    NSMutableString *detail = [NSMutableString new];
    if (self.doorlock == nil) {
        detail = @"您还没有设置场景、防区，请设置！";
    }
    else {
        if (self.detailArray) {
            for (NSString *str in self.detailArray) {
                [detail appendFormat:@"'%@'",str];
            }
        }
        [detail appendString:@"不存在，请重新设置！"];
    }
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:detail delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil];
    [alert show];
}
//点击事件
- (void)dropDownList:(HE_DropDownListView *)dropDown chooseAtSection:(NSInteger)section index:(NSInteger)index {
    NSLog(@"点击了%ld,section %ld,index %ld",(long)dropDown.tag,(long)section,(long)index);
}

@end
