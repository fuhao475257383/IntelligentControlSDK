//
//  EditDoorVC.h
//  BWRemoter
//
//  Created by tc on 15/11/12.
//  Copyright © 2015年 ReSun. All rights reserved.
//

#import "HE_BaseViewController.h"
#import "Doorlock.h"

@interface EditDoorVC : HE_BaseViewController

@property (nonatomic,strong) NSString *doorName;

@end
