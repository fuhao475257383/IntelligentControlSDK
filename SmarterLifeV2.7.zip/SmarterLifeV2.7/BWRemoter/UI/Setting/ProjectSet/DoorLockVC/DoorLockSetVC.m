//
//  DoorLockSetVC.m
//  BWRemoter
//
//  Created by tc on 15/11/12.
//  Copyright © 2015年 ReSun. All rights reserved.
//

#import "DoorLockSetVC.h"
#import "EditDoorVC.h"
#import "CYM_Engine.h"

@interface DoorLockSetVC () <UITableViewDataSource,UITableViewDelegate>

//门锁数组
@property (nonatomic,strong) NSArray *doorArray;
//tableView
@property (nonatomic,strong) UITableView *tableV;

@end

@implementation DoorLockSetVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"门锁设置";
    [self addViewInfo];
    [self addTableView];
}
#pragma mark -获取数据
- (NSArray *)doorArray {
    if (!_doorArray) {
        _doorArray = [CYM_Engine getAllDoorlockName];
    }
    return _doorArray;
}
#pragma mark -界面设置
//界面信息
- (void)addViewInfo {
    CGFloat buttonWidth = curScreenSize.width / 5;
    //确定按钮
    UIButton *sureButton = [[UIButton alloc]initWithFrame:CGRectMake(buttonWidth, curScreenSize.height - 60, buttonWidth, 30)];
    [sureButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [sureButton setTitle:@"确定" forState:UIControlStateNormal];
    [sureButton setBackgroundColor:[UIColor colorWithRed:230/255.0 green:230/255.0 blue:230/255.0 alpha:1]];
    sureButton.layer.cornerRadius   = 5;
    sureButton.layer.masksToBounds  = YES;
    sureButton.layer.borderColor    = [UIColor blackColor].CGColor;
    sureButton.layer.borderWidth    = 1;
    [self.view addSubview:sureButton];
    
    //取消按钮
    UIButton *cancelButton = [[UIButton alloc]initWithFrame:CGRectMake(buttonWidth * 3, curScreenSize.height - 60, buttonWidth, 30)];
    [cancelButton setTitle:@"取消" forState:UIControlStateNormal];
    [cancelButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [cancelButton setBackgroundColor:[UIColor colorWithRed:230/255.0 green:230/255.0 blue:230/255.0 alpha:1]];
    cancelButton.layer.cornerRadius     = 5;
    cancelButton.layer.masksToBounds    = YES;
    cancelButton.layer.borderColor      = [UIColor blackColor].CGColor;
    cancelButton.layer.borderWidth      = 1;
    [self.view addSubview:cancelButton];
}
//添加tableView
- (void)addTableView {
    UIView *backView        = [[UIView alloc]initWithFrame:CGRectMake(0, 64, curScreenSize.width, curScreenSize.height - 64 - 90)];
    self.tableV             = [[UITableView alloc]initWithFrame:backView.bounds style:UITableViewStylePlain];
    self.tableV.delegate    = self;
    self.tableV.dataSource  = self;
    self.tableV.separatorInset  = UIEdgeInsetsMake(0, 40, 0, 40);
    self.tableV.separatorColor  = [UIColor blackColor];
    self.tableV.allowsSelection = NO;
    [backView addSubview:self.tableV];
    [self.view addSubview:backView];
}
#pragma mark -tableView相关的
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.doorArray.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    //由于门锁不会有很多，不需要重用
    UITableViewCell *cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    UIView *cellView      = [[UIView alloc]initWithFrame:CGRectMake(0, 0, curScreenSize.width, 80)];
    //门锁名字
    UILabel *nameLabel    = [[UILabel alloc]initWithFrame:CGRectMake(40, 0, curScreenSize.width/2 - 40, 90)];
    nameLabel.text        = self.doorArray[indexPath.row];;
    nameLabel.textColor   = [UIColor blackColor];
    nameLabel.font        = [UIFont systemFontOfSize:17];
    [cellView addSubview:nameLabel];
    //编辑按钮
    UIButton *editButton            = [[UIButton alloc]initWithFrame:CGRectMake(curScreenSize.width - 40 - curScreenSize.width/5, 30, curScreenSize.width/5, 30)];
    editButton.layer.cornerRadius   = 5;
    editButton.layer.masksToBounds  = YES;
    editButton.layer.borderColor    = [UIColor blackColor].CGColor;
    editButton.layer.borderWidth    = 1;
    editButton.titleLabel.font      = [UIFont systemFontOfSize:15];
    editButton.tag = indexPath.row;
    [editButton setTitle:@"编辑" forState:UIControlStateNormal];
    [editButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [editButton addTarget:self action:@selector(editButtonBeginTouch:) forControlEvents:UIControlEventTouchUpInside];
    [cellView addSubview:editButton];
    [cell addSubview:cellView];
    
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 90;
}
//按钮点击
- (void)editButtonBeginTouch:(UIButton *)sender {
    EditDoorVC *editVC = [[EditDoorVC alloc]init];
    //获取到点击行的数据
    editVC.doorName          = self.doorArray[sender.tag];
    [self.navigationController pushViewController:editVC animated:YES];
}
@end
