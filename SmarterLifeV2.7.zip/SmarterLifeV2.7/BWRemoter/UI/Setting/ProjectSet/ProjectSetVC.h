//
//  ProjectSetVC.h
//  BWRemoter
//
//  Created by wangbin on 14/12/6.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "HE_BaseViewController.h"

@interface ProjectSetVC : HE_BaseViewController<UITableViewDelegate,UITableViewDataSource>

@property(nonatomic,retain) IBOutlet UITableView *table;

@end
