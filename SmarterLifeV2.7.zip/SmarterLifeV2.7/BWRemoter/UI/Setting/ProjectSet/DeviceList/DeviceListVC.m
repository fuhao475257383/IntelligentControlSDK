//
//  DeviceListVC.m
//  BWRemoter
//
//  Created by wangbin on 14/12/6.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "DeviceListVC.h"
#import "FXW_CenterConditionVC.h"
#import "FXW_LightVC.h"
#import "HE_UIDevice.h"
#import "FXW_CurtainVC.h"
#import "FXW_PowerVC.H"
#import "FXW_ScenoModeVC.h"
#import "FXW_BackmusicVC.h"
#import "FXW_ConditionVC.h"
#import "HE_TVControlVC.h"
#import "HE_CustomeInfraredVC.h"
#import "DoorLockVC.h"

#import "HE_CustemExtend.h"

@interface DeviceListVC ()
{
    NSMutableArray *aryAllDeviceName;
    NSMutableArray *aryDevices;
    NSMutableArray *tmpLight;
    NSMutableArray *tmpDLight;
    NSMutableArray *tmpCurtain; //开合窗帘
    NSMutableArray *tmpDCurtain;//升降窗帘
    NSMutableArray *tmpScene;
    NSMutableArray *tmpSocket;//智能插座
    //添加了门锁
    NSMutableArray *tmpDoorlock;
    RoomDevice *tmpDevices;//用这个感觉比较好
  //  NSArray *aryimgsensor;
}
@end

@implementation DeviceListVC

@synthesize table;
- (void)viewDidLoad {
    [super viewDidLoad];
    aryAllDeviceName = [CYM_Engine getAlldeviceContentName];
    if(!aryDevices){
        aryDevices = [[NSMutableArray alloc]init];
        tmpLight = [[NSMutableArray alloc]init];
        tmpDLight = [[NSMutableArray alloc]init];
        tmpCurtain = [[NSMutableArray alloc]init];
        tmpDCurtain = [[NSMutableArray alloc]init];
        tmpScene = [[NSMutableArray alloc]init];
        tmpSocket = [[NSMutableArray alloc]init];
        tmpDoorlock = [[NSMutableArray alloc]init];
    }
    // Do any additional setup after loading the view from its nib.
    [self setTitle:@"设备列表"];
    [self processAry];
    table = [[UITableView alloc]initWithFrame:CGRectMake(0.0f, 10.0f, curScreenSize.width, curScreenSize.height) style:UITableViewStylePlain];
    table.separatorInset = UIEdgeInsetsMake(0, 3, 0, 17);
    
    [table setBackgroundColor:[UIColor clearColor]];
    [table setDelegate:self];
    [table setDataSource:self];
    [self.view addSubview:table];
}
-(void)processAry{
    for(int i =0 ; i<aryAllDeviceName.count;i++){
        ControlDeviceContentValue * tmpDeviceValue = [CYM_Engine getDeviceDetailsWithDeviceName:aryAllDeviceName[i]];
        RoomDevice *tmpDevice = [[RoomDevice alloc]init];
        [tmpDevice init:tmpDevice];
        
        ////////////////不能控制的设备 -》 不予显示
        if ([tmpDeviceValue.property isEqualToString:@"I/O输入"] ||
            [tmpDeviceValue.category isEqualToString:@"传感器"]  ||
            [tmpDeviceValue.category isEqualToString:@"报警设备"]){
            continue;
        }
        
        if([tmpDeviceValue.property isEqualToString:@"可调灯"]){
            [tmpDLight addObject:tmpDeviceValue];
        }
        else if([tmpDeviceValue.property isEqualToString:@"非可调灯"]){
            [tmpLight addObject:tmpDeviceValue];
        }
        else if([tmpDeviceValue.property isEqualToString:@"开合窗帘"]){
            [tmpCurtain addObject:tmpDeviceValue];
        }
        else if([tmpDeviceValue.property isEqualToString:@"升降窗帘"]){
            [tmpDCurtain addObject:tmpDeviceValue];
        }
        else if ([tmpDeviceValue.property isEqualToString:@"场景控制器"]){
            [tmpScene addObject:[CYM_Engine getSenceWithSenceName:tmpDeviceValue.name]];
        }
        else if([tmpDeviceValue.property isEqualToString:@"智能插座"] || [tmpDeviceValue.property isEqualToString:@"电源控制"]){
            [tmpSocket addObject:tmpDeviceValue];
        }
        else if ([tmpDeviceValue.property isEqualToString:@"智能门锁"]){
            [tmpDoorlock addObject:tmpDeviceValue];
        }
        else{
//            tmpDevice.property = @"other";
            tmpDevice.property  = tmpDeviceValue.property;
            [tmpDevice.contentArr addObject:tmpDeviceValue];
            [aryDevices addObject:tmpDevice];
        }
        
    }
    RoomDevice *tmp = [[RoomDevice alloc]init];
    [tmp init:tmp];
    tmp.property = @"场景控制器";
    for(int i =0;i<[CYM_Engine getAllSoftSence].count;i++){
        [tmpScene addObject:[CYM_Engine getAllSoftSence][i]];
    }
    [tmp.contentArr addObject:tmpScene];
    if  (tmpScene.count > 0 ){
        [aryDevices insertObject:tmp atIndex:0];
    }
    
    if(tmpSocket.count>0){
        RoomDevice *tmp = [[RoomDevice alloc]init];
        [tmp init:tmp];
        tmp.property = @"智能插座";
        [tmp.contentArr addObject:tmpSocket];
        [aryDevices insertObject:tmp atIndex:0];
    }
    if(tmpCurtain.count>0||tmpDCurtain.count>0){
        RoomDevice *tmp = [[RoomDevice alloc]init];
        [tmp init:tmp];
        tmp.property = @"窗帘";
        [tmp.contentArr addObject:tmpCurtain];
        [tmp.contentArr addObject:tmpDCurtain];
        [aryDevices insertObject:tmp atIndex:0];
    }
    if(tmpDLight.count>0||tmpLight.count>0){
        RoomDevice *tmp = [[RoomDevice alloc]init];
        [tmp init:tmp];
        tmp.property = @"灯光";
        [tmp.contentArr addObject:tmpLight];
        [tmp.contentArr addObject:tmpDLight];
        [aryDevices insertObject:tmp atIndex:0];
    }
    if (tmpDoorlock.count > 0) {
        RoomDevice *tmp = [[RoomDevice alloc]init];
        [tmp init:tmp];
        tmp.property = @"智能门锁";
        [tmp.contentArr addObject:tmpDoorlock];
        [aryDevices insertObject:tmp atIndex:0];
    }
}
- (BOOL)matchStringFormat:(NSString *)matchedStr withRegex:(NSString *)regex
{
    NSRange range=[matchedStr rangeOfString:regex];
    if(range.location!=NSNotFound)
        return true;
    else
        return false;
}
#pragma mark -- UITableViewDelegate And DataSourse
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return aryDevices.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *cell= [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    
    if (cell==nil) {
        cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"qe"];
    }
    UIView *backView = [[UIView alloc] initWithFrame: CGRectMake(0.0f, 0.0f, curScreenSize.width, 80.0f)];
    UILabel *ListName = [[UILabel alloc]initWithFrame:CGRectMake(curScreenSize.width*0.3, 25.0f, cell.frameW-curScreenSize.width*0.2, 30.0f)];
    ListName.adjustsFontSizeToFitWidth=YES;
    UIImageView *logo = [[UIImageView alloc]initWithFrame:CGRectMake(curScreenSize.width*0.1, 17.0f, 40.0f, 40.0f)];
    UIImageView *rightgogo = [[UIImageView alloc] initWithFrame: CGRectMake(curScreenSize.width*0.8,30.0f, 20.0f, 20.0f)];
    [rightgogo setImage:[UIImage imageNamed:@"arrowicon.png"]];
    [backView addSubview:rightgogo];
    
    RoomDevice *roomDevice = aryDevices[indexPath.row];
    if([roomDevice.property isEqualToString:@"灯光"]){
        [ListName setText:@"灯光"];
        [logo setImage:[UIImage imageNamed:@"lighticon.png"]];
    }
    else if([roomDevice.property isEqualToString:@"窗帘"]){
        [ListName setText:@"窗帘"];
        [logo setImage:[UIImage imageNamed:@"win1icon.png"]];
    }
    else if([roomDevice.property isEqualToString:@"场景控制器"]){
        [ListName setText:@"场景控制器"];
        [logo setImage:[UIImage imageNamed:@"senceicon.png"]];
    }
    else if([roomDevice.property isEqualToString:@"智能插座"]){
        [ListName setText:@"电源"];
        [logo setImage:[UIImage imageNamed:@"icSmartSocket"]];
    }
    else if([roomDevice.property isEqualToString:@"智能门锁"]){
        [ListName setText:@"智能门锁"];
        [logo setImage:[UIImage imageNamed:@"hc_doorlock.png"]];
    }
    else {
        ControlDeviceContentValue *tmp = ((RoomDevice *)aryDevices[indexPath.row]).contentArr[0];
        [ListName setText:tmp.name];
        if([roomDevice.property isEqualToString:@"背景音乐"]){
            [logo setImage:[UIImage imageNamed:@"musicicon.png"]];
        }
        else if([self matchStringFormat:roomDevice.property withRegex:@"空调"]){
            [logo setImage:[UIImage imageNamed:@"conicon.png"]];
        }
//        else if([roomDevice.property isEqualToString:@"煤气"]){
//            [logo setImage:[UIImage imageNamed:@"safe_gas_icon.png"]];
//        }
//        else if([self matchStringFormat:roomDevice.property withRegex:@"门磁"]){
//            [logo setImage:[UIImage imageNamed:@"safe_door_icon.png"]];
//        }
//        else if([self matchStringFormat:roomDevice.property withRegex:@"紧急按钮"]){
//            [logo setImage:[UIImage imageNamed:@"safe_urgent_icon.png"]];
//        }
//        else if([self matchStringFormat:roomDevice.property withRegex:@"红外探测器"]){
//            [logo setImage:[UIImage imageNamed:@"safe_red_icon.png"]];
//        }
//        else if([self matchStringFormat:roomDevice.property withRegex:@"烟雾"]){
//            [logo setImage:[UIImage imageNamed:@"safe_smoke_icon.png"]];
//        }
        else if([self matchStringFormat:roomDevice.property withRegex:@"电视/播放器/DVD"]){
            [logo setImage:[UIImage imageNamed:@"tvicon.png"]];
        }
        else{
            [logo setImage:[UIImage imageNamed:@"otherDeviceicon.png"]];
        }
    }
    [backView addSubview:ListName];
    [backView addSubview:logo];
    [cell addSubview:backView];
    [cell setBackgroundColor:[UIColor clearColor]];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}
/*  点击事件 */
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
     [tableView deselectRowAtIndexPath:indexPath animated:YES];
    /* 跳转页面 */
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    RoomDevice *roomDevices = (RoomDevice *)aryDevices[indexPath.row];
    if([roomDevices.property isEqualToString:@"灯光"]){
        FXW_LightVC *Light = [[FXW_LightVC alloc]init];
        UINavigationItem *title = [Light navigationItem];
        [title setTitle:@"灯光"];
        [Light setAryLight:tmpLight];
        [Light setAryLight2:tmpDLight];
        [self.navigationController pushViewController:Light animated:YES];
    }
    else if([roomDevices.property isEqualToString:@"窗帘"]){
        FXW_CurtainVC *Curtain = [[FXW_CurtainVC alloc]init];
        UINavigationItem *title = [Curtain navigationItem];
        [title setTitle:@"窗帘"];
        [Curtain setAryCurtain1:tmpDCurtain];
        [Curtain setAryCurtain2:tmpCurtain];
        [Curtain setFrameType:1];
        [self.navigationController pushViewController:Curtain animated:YES];
    }
    else if([roomDevices.property isEqualToString:@"智能插座"] || [roomDevices.property myContainsString:@"电源"]){
        FXW_PowerVC *power = [[FXW_PowerVC alloc]init];
        UINavigationItem *title = [power navigationItem];
        [title setTitle:@"智能插座"];
        [power setAryPower:tmpSocket];
        [self.navigationController pushViewController:power animated:YES];
    }
    else if([roomDevices.property isEqualToString:@"场景控制器"]){
        FXW_ScenoModeVC *scene = [[FXW_ScenoModeVC alloc]init];
        UINavigationItem *title = [scene navigationItem];
        [title setTitle:@"场景控制器"];
        [scene setSceneList:tmpScene];
        [self.navigationController pushViewController:scene animated:YES];
    }
    else if ([roomDevices.property isEqualToString:@"智能门锁"]) {
        DoorLockVC *gateVC = [[DoorLockVC alloc]init];
        gateVC.allDoorArray = tmpDoorlock;
        [self.navigationController pushViewController:gateVC animated:YES];
    }
    else{
        ControlDeviceContentValue *tmpDevice = roomDevices.contentArr[0];
        if([tmpDevice.property isEqualToString:@"背景音乐"]){
            FXW_BackmusicVC *backmisicVC = [[FXW_BackmusicVC alloc]init];
            [backmisicVC setAryMuiscDev:@[tmpDevice]];
            
            [self.navigationController pushViewController:backmisicVC animated:YES];
        }
        else if([tmpDevice.property isEqualToString:@"中央空调"]){
            FXW_CenterConditionVC *vc = [[FXW_CenterConditionVC alloc] init];
            [vc setConditionValue:tmpDevice];
            [vc setIsStudyMode:YES];
            [self.navigationController pushViewController:vc animated:YES];
        }
        else if([tmpDevice.property isEqualToString:@"单体空调"]){
            FXW_ConditionVC *singleConditonVC = [[FXW_ConditionVC alloc]init];
            [singleConditonVC setIsStudyMode:YES];
            [singleConditonVC setSingleAircondition:tmpDevice];
            [self.navigationController pushViewController:singleConditonVC animated:YES];
        
        }
        else if([tmpDevice.property isEqualToString:@"电视/播放器/DVD"]){
            HE_TVControlVC *vc = [[HE_TVControlVC alloc] init];
            [vc setIsStudyMode:YES];
            [vc setDeviceTV:tmpDevice];
            [self.navigationController pushViewController:vc animated:YES];
        }
        else if ([tmpDevice.property isEqualToString:@"电源控制"]){
            FXW_PowerVC *power = [[FXW_PowerVC alloc]init];
            UINavigationItem *title = [power navigationItem];
            [title setTitle:@"电源控制"];
            [power setAryPower:@[tmpDevice]];
            [self.navigationController pushViewController:power animated:YES];
        }
        else if([tmpDevice.property myContainsString:@"自定义"]){
                HE_CustomeInfraredVC *vc = [[HE_CustomeInfraredVC alloc] init];
                [vc setIsStudyMode:YES];
                [vc setDeviceValue:tmpDevice];
                [self.navigationController pushViewController:vc animated:YES];
        }
    }
    
}
@end
