//
//  SensorVC.m
//  BWRemoter
//
//  Created by baiwei－mac on 16/1/14.
//  Copyright © 2016年 ReSun. All rights reserved.
//

#import "SensorVC.h"
#import "ReplaceDevice.h"

@interface SensorVC () <UITableViewDataSource,UITableViewDelegate,UIAlertViewDelegate>

@property (nonatomic,strong) UITextField *nameField;//名字
@property (nonatomic,strong) UITapGestureRecognizer *tap;
@property (nonatomic,strong) UIButton *property;//属性
@property (nonatomic,strong) UIButton *trigger;//触发方式
@property (nonatomic,strong) UIButton *alarm;//报警器
@property (nonatomic,strong) UIView *topView;
@property (nonatomic,strong) NSMutableArray *allTrigger;//所有的房间
@property (nonatomic,strong) NSArray *propertyArray;//所有属性
@property (nonatomic,strong) NSMutableArray *allAlarm;//所有报警器
@property (nonatomic,strong) NSString *modiProperty;//选择的属性
@property (nonatomic,strong) NSString *moditype;//选择的触发方式
@property (nonatomic,strong) NSString *modiName;//修改的名字
@property (nonatomic,strong) NSString *modiAlarm;//修改的名字
@property (nonatomic,strong) UIButton *h24;//24小时按钮
@property (nonatomic,strong) UIButton *safe;//布放
@property (nonatomic,strong) UIButton *power;//电量
@property (nonatomic, copy) NSString *oldName;

@end

@implementation SensorVC
- (NSMutableArray *)allDevice {
    if (!_allDevice) {
        _allDevice = [NSMutableArray new];
    }
    return _allDevice;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"设备编辑";
    if ([self.device.type isEqualToString:@"传感器"]) {
        self.propertyArray = @[@"煤气",@"烟雾",@"CO探测器",@"红外探测器",@"门磁探测器",@"紧急按钮",@"窗磁探测器"];
//        [self addReplaceButton];
    }
    
    DeviceSettingModel *model = [CYM_DatabaseTable getSensorModelWithName:self.device.name];
    
    self.device.trigger = model.trigger;
    self.device.BD = model.BD;
    self.device.sensor24h = model.sensor24h;
    self.device.isAlarm = model.isAlarm;
    self.device.powerMSG = model.powerMSG;
    self.allTrigger = @[@"常闭",@"常开"];
    self.allAlarm = [CYM_Engine getAllAlarm];
    [self.allAlarm addObject:@"不绑定报警器"];
    
    [self addLabelWithText:@"设备类型：" rect:CGRectMake(20, 80, 70, 20) isAdjustsFontSizeToFit:NO];
    [self addLabelWithText:@"设备名称：" rect:CGRectMake(20, 120, 70, 20) isAdjustsFontSizeToFit:NO];
    [self addLabelWithText:@"设备属性：" rect:CGRectMake(20, 160, 70, 20) isAdjustsFontSizeToFit:NO];
    [self addLabelWithText:@"触发方式：" rect:CGRectMake(20, 200, 70, 20) isAdjustsFontSizeToFit:NO];
    [self addLabelWithText:@"绑定报警器：" rect:CGRectMake(20, 240, 100, 20) isAdjustsFontSizeToFit:NO];
    [self addLabelWithText:@"24小时设备" rect:CGRectMake(50,280,curScreenSize.width/2-50,20) isAdjustsFontSizeToFit:NO];
    [self addLabelWithText:@"布防" rect:CGRectMake(curScreenSize.width/2+30, 280,curScreenSize.width/2-50,20) isAdjustsFontSizeToFit:NO];
    [self addLabelWithText:@"电量不足报警" rect:CGRectMake(50,320,curScreenSize.width/2-50,20) isAdjustsFontSizeToFit:NO];
    
    [self addLabelWithText:@"ID:" rect:CGRectMake(curScreenSize.width/2, 80, 20, 20) isAdjustsFontSizeToFit:NO];
    [self addLabelWithText:self.device.type rect:CGRectMake(90, 80, curScreenSize.width/2-100, 20) isAdjustsFontSizeToFit:YES];
    [self addLabelWithText:[cmdP getDeviceNumberWithCMD:self.device.ID] rect:CGRectMake(curScreenSize.width/2+20, 80, curScreenSize.width/2-20, 20) isAdjustsFontSizeToFit:YES];
    
    self.nameField = [[UITextField alloc]initWithFrame:CGRectMake(90, 115, curScreenSize.width-120, 30)];
    self.nameField.borderStyle = UITextBorderStyleRoundedRect;
    self.nameField.text = self.device.name;
    self.nameField.font = [UIFont systemFontOfSize:14];
    self.nameField.delegate = self;
    [self.view addSubview:self.nameField];
    if ([self.device.property isEqualToString:@""] || self.device.property == nil) {
        self.device.property = @"未设置";
    }
    if (self.device.trigger == nil || [self.device.trigger isEqualToString:@""]) {
        self.device.trigger = @"常开";
    }
    self.property = [self addButtonWithText:self.device.property rect:CGRectMake(90,160,curScreenSize.width-130,20)];

    self.trigger = [self addButtonWithText:self.device.trigger rect:CGRectMake(90,200,curScreenSize.width-130,20)];
    
    if (self.device.BD == nil || [self.device.BD isEqualToString:@""]) {
        self.device.BD = @"未设置";
    }
    self.alarm = [self addButtonWithText:self.device.BD rect:CGRectMake(120, 240, curScreenSize.width-160, 20)];
    self.h24 = [self addButtonWithText:nil rect:CGRectMake(20, 275, 30, 30)];
    self.safe = [self addButtonWithText:nil rect:CGRectMake(curScreenSize.width/2, 275,30,30)];
    self.power = [self addButtonWithText:nil rect:CGRectMake(20, 315, 30, 30)];
    [self.property addTarget:self action:@selector(choseProperty) forControlEvents:UIControlEventTouchUpInside];
    [self.trigger addTarget:self action:@selector(choseRoom) forControlEvents:UIControlEventTouchUpInside];
    [self.alarm addTarget:self action:@selector(choseAlarm) forControlEvents:UIControlEventTouchUpInside];
    [self.h24 addTarget:self action:@selector(choseH24) forControlEvents:UIControlEventTouchUpInside];
    [self.safe addTarget:self action:@selector(choseSafe) forControlEvents:UIControlEventTouchUpInside];
    [self.power addTarget:self action:@selector(chosePower) forControlEvents:UIControlEventTouchUpInside];
    
    
    
    UIButton *deleteButton = [[UIButton alloc]initWithFrame:CGRectMake(20, curScreenSize.height - 60, curScreenSize.width/2-30, 30)];
    deleteButton.layer.cornerRadius = 5;
    [deleteButton setBackgroundColor:[UIColor grayColor]];
    [deleteButton setTitle:@"删除设备" forState:UIControlStateNormal];
    [deleteButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [deleteButton addTarget:self action:@selector(deleteR) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:deleteButton];
    
    UIButton *aplayButton = [[UIButton alloc]initWithFrame:CGRectMake(curScreenSize.width/2+10, curScreenSize.height - 60, curScreenSize.width/2 - 30, 30)];
    aplayButton.layer.cornerRadius = 5;
    [aplayButton setBackgroundColor:[UIColor grayColor]];
    [aplayButton setTitle:@"保存设置" forState:UIControlStateNormal];
    [aplayButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [aplayButton addTarget:self action:@selector(aplayR) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:aplayButton];
    
    self.device.sensor24h?(self.h24.selected=YES):(self.h24.selected=NO);
    self.device.isAlarm?(self.safe.selected=YES):(self.safe.selected=NO);
    self.device.powerMSG?(self.power.selected=YES):(self.power.selected=NO);
    
    self.modiName = self.device.name;
    self.modiProperty = self.device.property;
    self.moditype = self.device.trigger;
    self.modiAlarm = self.device.BD;
    self.oldName = self.device.name;
    
}
- (void)addReplaceButton {
    //右侧按钮
    //添加右侧按钮
    if (self.device.isNewDevice) {
        UIButton *applyButton = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 40, 30)];
        applyButton.backgroundColor = [UIColor whiteColor];
        [applyButton setTitle:@"替换" forState:UIControlStateNormal];
        [applyButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        applyButton.titleLabel.font = [UIFont systemFontOfSize:14];
        applyButton.layer.borderWidth = 1;
        applyButton.layer.cornerRadius = 5;
        applyButton.layer.borderColor = [UIColor blackColor].CGColor;
        [applyButton addTarget:self action:@selector(replaceDevice) forControlEvents:UIControlEventTouchUpInside];
        UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithCustomView:applyButton];
        self.navigationItem.rightBarButtonItem =item;
    }
}
- (void)replaceDevice {
    ReplaceDevice *VC = [ReplaceDevice new];
    VC.device = self.device;
    VC.allDevice = self.allDevice;
    [self.navigationController pushViewController:VC animated:YES];
}
- (void)deleteR {
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:@"该操作会删除该设备，是否删除？" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    [alert show];
}
- (void)aplayR {
    if ([self.nameField.text isEqualToString:@""] || self.nameField.text == nil) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示:" message:@"名称不能为空" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
        [alert show];
        return;
    }
    NSLog(@"%@",self.nameField.text);
    for (DeviceSettingModel *model in self.allDevice) {
        if ([model.name isEqualToString:self.nameField.text] && ![self.nameField.text isEqualToString:self.modiName]) {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示:" message:@"名称已存在，请重新设置！" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
            [alert show];
            return;
        }
    }
    if ([self.modiProperty isEqualToString:@"未设置"]) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示:" message:@"请设置设备属性！" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
        [alert show];
        return;
    }
    if (self.h24.selected == YES && self.safe.selected == NO) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示：" message:@"如果设置成24小时设备，那么不能设置成撤防!\n请重新设置！" delegate:nil cancelButtonTitle:@"我知道了" otherButtonTitles: nil];
        [alert show];
        return;
    }
    if (self.device.isNewDevice == YES) {
        //清空数据，由于是新的设备，不会有重复名字的情况，大胆删除
        self.device.name = self.nameField.text;
        self.device.property = self.modiProperty;
        self.device.trigger = self.moditype;
        self.device.BD = self.modiAlarm;
        self.device.sensor24h = self.h24.selected;
        self.device.isAlarm = self.safe.selected;
        self.device.powerMSG = self.power.selected;
//        self.device.roomName = self.modiRoom;
        [CYM_DatabaseTable deleteDeviceFromDevice:self.device withOldName:self.oldName];
        //插入数据
        [CYM_DatabaseTable insertDevice:self.device];
        [self.navigationController popViewControllerAnimated:YES];
        return;
    }
    
//    if (![self.nameField.text isEqualToString:self.device.name]) {
        [CYM_DatabaseTable modiOldName:self.device.name toNewName:self.nameField.text];//修改名字
//    }
    self.device.name = self.nameField.text;
//    if (![self.modiProperty isEqualToString:self.device.property]) {
        [CYM_DatabaseTable modiProperty:self.modiProperty withDevice:self.device withRoomName:self.device.roomName];//修改属性
//    }
    self.device.property = self.modiProperty;
    
    //修改触发方式
//    if (![self.moditype isEqualToString:self.device.trigger]) {
        [CYM_DatabaseTable modiTrigger:[self.moditype isEqualToString:@"常闭"]?@"0":@"1" withDevice:self.device];
//    }
    self.device.trigger = self.moditype;
    //修改绑定
//    if (![self.modiAlarm isEqualToString:self.device.BD]) {
        [CYM_DatabaseTable modiAlarm:self.modiAlarm withDevice:self.device];
//    }
    self.device.BD = self.modiAlarm;
    
    
    self.device.sensor24h = self.h24.selected;
    self.device.isAlarm = self.safe.selected;
    self.device.powerMSG = self.power.selected;
    [CYM_DatabaseTable modiStateWithModel:self.device];
    
    [self.navigationController popViewControllerAnimated:YES];
    
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 1) {
        
        [CYM_DatabaseTable deleteDeviceFromDevice:self.device withOldName:self.device.name];
        
        //如果是新设备，需要从新设备数组中移除
        if (self.device.isNewDevice == YES) {
            [self.allDevice removeObject:self.device];
            [appManager.deviceNewArray removeObject:self.device];
        }
        
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    self.tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(closeKeyboard)];
    [self.view addGestureRecognizer:self.tap];
}
- (void)closeKeyboard {
    [self.view removeGestureRecognizer:self.tap];
    [self.nameField resignFirstResponder];
    self.tap = nil;
}

- (void)addLabelWithText:(NSString *)text rect:(CGRect)rect isAdjustsFontSizeToFit:(BOOL)adjust{
    UILabel *label = [[UILabel alloc]initWithFrame:rect];
    label.text = text;
    label.font = [UIFont systemFontOfSize:14];
    label.textColor = [UIColor blackColor];
    label.textAlignment = NSTextAlignmentLeft;
    label.adjustsFontSizeToFitWidth = adjust;
    [self.view addSubview:label];
}

- (UIButton *)addButtonWithText:(NSString *)text rect:(CGRect)rect{
    UIButton *button = [[UIButton alloc]initWithFrame:rect];
    [button setTitle:text forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:14];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    if (text != nil) {
        UIImageView *image = [[UIImageView alloc]initWithFrame:CGRectMake(rect.size.width - rect.size.height, 0, rect.size.height, rect.size.height)];
        image.image = [UIImage imageNamed:@"arrowicon.png"];
        [button addSubview:image];
    }
    else {
        [button setImage:[UIImage imageNamed:@"no.png"] forState:UIControlStateNormal];
        [button setImage:[UIImage imageNamed:@"yes.png"] forState:UIControlStateSelected];
    }
    [self.view addSubview:button];
    return button;
}
- (void)choseProperty {
    self.topView = [self addTopViewWithType:@"property"];
}
- (void)choseRoom {
    self.topView = [self addTopViewWithType:@"room"];
}
- (void)choseAlarm {
    self.topView = [self addTopViewWithType:@"alarm"];
}
- (void)choseH24 {
    self.h24.selected = !self.h24.selected;
}
- (void)choseSafe {
    self.safe.selected = !self.safe.selected;
}
- (void)chosePower {
    self.power.selected = !self.power.selected;
}
- (UIView *)addTopViewWithType:(NSString *)type {
    
    [self closeKeyboard];
    
    UIView *view = [[UIView alloc]initWithFrame:self.view.frame];
    view.backgroundColor = [UIColor colorWithRed:10/255.0 green:10/255.0 blue:10/255.0 alpha:0.5];
    self.tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(back:)];
    UIView *tapView = [[UIView alloc]initWithFrame:view.bounds];
    tapView.backgroundColor = [UIColor clearColor];
    [view addSubview:tapView];
    [tapView addGestureRecognizer:self.tap];
    [self.view addSubview:view];
    
    UITableView *tableView = [[UITableView alloc]initWithFrame:CGRectMake(curScreenSize.width/4, curScreenSize.height/4, curScreenSize.width/2, curScreenSize.height/2) style:UITableViewStylePlain];
    if ([type isEqualToString:@"property"]) {
        tableView.tag = 1;
    }
    if ([type isEqualToString:@"room"]) {
        tableView.tag = 2;
    }
    if ([type isEqualToString:@"alarm"]) {
        tableView.tag = 3;
    }
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    [view addSubview:tableView];
    
    return view;
}
- (void)back:(UITapGestureRecognizer *)tap {
    self.tap = nil;
    [self.topView removeFromSuperview];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (tableView.tag == 1) {
        return self.propertyArray.count;
    }
    else if (tableView.tag == 2) {
        return self.allTrigger.count;
    }
    else if (tableView.tag == 3) {
        return self.allAlarm.count;
    }
    else
        return 0;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    if (tableView.tag == 1) {
        cell.textLabel.text = self.propertyArray[indexPath.row];
        cell.textLabel.textColor = [UIColor blackColor];
    }
    else if (tableView.tag == 2) {
        cell.textLabel.text = self.allTrigger[indexPath.row];
        cell.textLabel.textColor = [UIColor blackColor];
    }
    else if (tableView.tag == 3) {
        cell.textLabel.text = self.allAlarm[indexPath.row];
        cell.textLabel.textColor = [UIColor blackColor];
    }
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (tableView.tag == 1 && indexPath.row<self.propertyArray.count) {
        self.modiProperty = self.propertyArray[indexPath.row];
        [self.property setTitle:self.modiProperty forState:UIControlStateNormal];
        [self back:nil];
    }
    else if (tableView.tag == 2 && indexPath.row < self.allTrigger.count) {
    
        self.moditype = self.allTrigger[indexPath.row];
        [self.trigger setTitle:self.moditype forState:UIControlStateNormal];
        [self back:nil];

    }
    else if (tableView.tag == 3 && indexPath.row < self.allAlarm.count) {
        self.modiAlarm = self.allAlarm[indexPath.row];
        [self.alarm setTitle:self.modiAlarm forState:UIControlStateNormal];
        [self back:nil];
    }
}
@end
