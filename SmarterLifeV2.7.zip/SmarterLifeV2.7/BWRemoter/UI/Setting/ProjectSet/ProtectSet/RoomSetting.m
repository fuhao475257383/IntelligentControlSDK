//
//  RoomSetting.m
//  BWRemoter
//
//  Created by baiwei－mac on 16/1/11.
//  Copyright © 2016年 ReSun. All rights reserved.
//

#import "RoomSetting.h"
#import "CYM_Engine.h"
#import "NormalVC.h"

@interface RoomSetting () <UITableViewDataSource,UITableViewDelegate,UIAlertViewDelegate>

//房间table
@property (nonatomic,strong) UITableView *table;
//所有房间
@property (nonatomic,strong) NSMutableArray *allRoom;

@end

@implementation RoomSetting

- (void)viewWillAppear:(BOOL)animated {
    self.allRoom = [CYM_DatabaseTable getRoom];
    
    [self.table reloadData];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.allRoom = [NSMutableArray new];
    
    self.allRoom = [CYM_DatabaseTable getRoom];
    
    self.title = @"所有房间";
    
    self.table = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, curScreenSize.width, curScreenSize.height - 80) style:UITableViewStylePlain];
    self.table.delegate = self;
    self.table.dataSource = self;
    self.table.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    
    [self.view addSubview:self.table];
    
    UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(curScreenSize.width*1/5, curScreenSize.height - 60, curScreenSize.width*3/5, 40)];
    button.layer.cornerRadius = 5;
    [button setTitle:@"添加房间" forState:UIControlStateNormal];
    [button setBackgroundColor:[UIColor grayColor]];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [button addTarget:self action:@selector(addRoom) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.allRoom.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 60;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
        static NSString *identifier = @"roomSetting";
        
        Room *room = self.allRoom[indexPath.row];
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (!cell) {
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        
        cell.textLabel.text = room.name;
        
        return cell;
}
- (void)addRoom {
    UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:nil message:@"请输入房间名称：" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确认", nil];
    alertView.alertViewStyle = UIAlertViewStylePlainTextInput;
    UITextField *nameField = [alertView textFieldAtIndex:0];
    nameField.placeholder = @"请输入名称:";
    [alertView show];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 1) {
        UITextField *nameField = [alertView textFieldAtIndex:0];
        if ([nameField.text isEqualToString:@""] || nameField.text == nil) {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示:" message:@"名称不能为空" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
            [alert show];
            return;
        }
        NSLog(@"%@",nameField.text);
        for (Room *room in self.allRoom) {
            if ([room.name isEqualToString:nameField.text]) {
                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示:" message:@"名称已存在，请重新添加！" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
                [alert show];
                return;
            }
        }
        [nameField resignFirstResponder];
        Room *room = [Room new];
        room.name = nameField.text;
        room.prio = @"FFFFFFFFFFFFF";
        room.ID = [CYM_DatabaseTable GenerateGUID];
        [Room insertRomm:room];
        [self.allRoom addObject:room];
        [self.table reloadData];
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示:" message:[NSString stringWithFormat:@"房间：%@  添加成功！",nameField.text] delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
        
        [self updateRoomJSON];
        
        [alert show];
    }
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
        Room *room = self.allRoom[indexPath.row];
        NormalVC *normalVC = [NormalVC new];
        normalVC.name = room.name;
        normalVC.allRoom = self.allRoom;
        [self.navigationController pushViewController:normalVC animated:YES];
}
- (void)updateRoomJSON {
    //上传room.json文件
    NSData *roomOld = [CYM_Engine generateJSONFileWithName:@"room.json"];
    [appManager uploadFileWithName:@"room.json" andData:roomOld isShowHUD:NO];
}
@end
