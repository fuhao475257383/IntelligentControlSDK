//
//  ProtectSetVC.m
//  BWRemoter
//
//  Created by wangbin on 14/12/6.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "ProtectSetVC.h"
#import "SecurityContent_zone.h"
#import "FXW_alertView.h"
#import "FXW_SecurityEditVCViewController.h"
@interface ProtectSetVC ()

@end

@implementation ProtectSetVC

@synthesize table;
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    aryZone = [[NSMutableArray alloc]init];
    aryZone = [CYM_Engine getZoneContentInfo];
    [table reloadData];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self setTitle:@"防区设定"];
    aryimgzone =@[@"key.png",@"house.png",@"out.png",@"diyzoneicon"];

    table = [[UITableView alloc]initWithFrame:CGRectMake(0.0f, 0.0f, curScreenSize.width, curScreenSize.height-100) style:UITableViewStylePlain];
    [table setBackgroundColor:[UIColor clearColor]];
    table.separatorInset = UIEdgeInsetsMake(0, 3, 0, 17);
    table.tableFooterView = [[UIView alloc] init];
    [table setScrollEnabled:YES];
    [table setDelegate:self];
    [table setDataSource:self];
    [self.view addSubview:table];
    
    UIButton *AddViewModel = [[UIButton alloc]initWithFrame:CGRectMake(curScreenSize.width*0.1,table.frameSumY_H+20, 80.0f, 35.0f)];
    [AddViewModel setBackgroundImage:[UIImage imageNamed:@"add_icon.png"] forState:UIControlStateNormal];
    [AddViewModel addTarget:self action:@selector(AddModelClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:AddViewModel];
    
}

#pragma mark - UITableViewDelegate And DataSourse
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return aryZone.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *cell= [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    
    if (cell==nil) {
        cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"qe"];
    }
    UIView *backView = [[UIView alloc] initWithFrame: CGRectMake(0.0f, 0.0f, curScreenSize.width, 90.0f)];
    
    UILabel *ListName = [[UILabel alloc]initWithFrame:CGRectMake(curScreenSize.width*0.3, 25.0f, 100.0f, 30.0f)];
    [ListName setText:((SecurityContent_zone *)aryZone[indexPath.row]).name];
    [backView addSubview:ListName];
    
    
    UIImageView *logo = [[UIImageView alloc]initWithFrame:CGRectMake(curScreenSize.width*0.1, 17.0f, 40.0f, 40.0f)];
    [logo setImage:[UIImage imageNamed:aryimgzone[[((SecurityContent_zone *)aryZone[indexPath.row]).type integerValue]]]];
    [backView addSubview:logo];
    
    UIButton *editBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [editBtn setFrame:CGRectMake(curScreenSize.width*0.7, 25.0f, 70.0f, 30.0f)];
    [editBtn setTitle:@"编辑" forState:UIControlStateNormal];
    [editBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [editBtn.layer setBorderWidth:1.0];   //边框宽度
    editBtn.tag = 1000+indexPath.row;
    [editBtn addTarget:self action:@selector(btnEditClick:) forControlEvents:UIControlEventTouchUpInside];
    editBtn.layer.borderColor = [[UIColor colorWithRed:120/255.0f green:120/255.0f blue:120/255.0f alpha:1] CGColor];
    [editBtn.layer setMasksToBounds:YES];
    [editBtn.layer setCornerRadius:5.0f];
    [backView addSubview:editBtn];
    
    [cell addSubview:backView];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    [cell setAccessoryType:UITableViewCellAccessoryNone];
    [cell setBackgroundColor:[UIColor clearColor]];
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 70;
}
#pragma mark 编辑新增
-(void)btnEditClick:(id)sender{
   // NSLog(@"%ld",(long)((UIButton *)sender).tag);
    FXW_SecurityEditVCViewController *securityeditvc = [[FXW_SecurityEditVCViewController alloc]init];
    
//    [securityeditvc setZone:(SecurityContent_zone *)aryZone[((UIButton *)sender).tag-1000]];
    [securityeditvc setIndex:((UIButton *)sender).tag-1000];
    [self.navigationController pushViewController:securityeditvc animated:YES];
}
-(void)AddModelClick:(id)sender{
    FXW_alertView *addAlert = [[FXW_alertView alloc]initWithFrame:self.view.frame Delegate:self Datasourse:self];
    [addAlert setContent:addArea andTitle:@"添加防区"];
    [self.view addSubview:addAlert];
}
-(BOOL)saveBtnAddArea:(NSString *)text{
    
    if (text == nil || [text isEqualToString:@""]) {
        [appManager hudShowMsg:@"名称不能为空！" andInterval:1];
        return NO;
    }
    for (SecurityContent_zone *zon in aryZone) {
        if ([zon.name isEqualToString:text]) {
            [appManager hudShowMsg:@"名称不能重复！" andInterval:1];
            return NO;
        }
    }
    
    zone = [[SecurityContent_zone alloc]init];
    zone.name = text;
    zone.type = @"3";//自定义防区类型
    zone.state = @"0";//默认撤防
    zone.delay = @"0";//默认延时0
    zone.handled = @"1";
    if([CYM_Engine updateZoneSet:zone]){
        [aryZone addObject:zone];
        [table reloadData];
    }
    [self generateJSONFileAndUpload];
    return true;
}

- (void)generateJSONFileAndUpload{
    //1.根据数据库生成JSON文件
    //2.上传JSON文件
    //3.上传成功->更新本地信息、 否则下载服务器文件更新本地数据库
    NSData *cronData = [CYM_Engine generateJSONFileWithName:@"security.json"];
    [[HE_APPManager sharedManager] uploadFileWithName:@"security.json" andData:cronData isShowHUD:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
