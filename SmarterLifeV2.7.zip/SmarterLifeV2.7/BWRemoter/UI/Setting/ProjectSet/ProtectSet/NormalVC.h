//
//  NormalVC.h
//  BWRemoter
//
//  Created by baiwei－mac on 16/1/11.
//  Copyright © 2016年 ReSun. All rights reserved.
//

#import "HE_BaseViewController.h"

@interface NormalVC : HE_BaseViewController

@property (nonatomic,strong) NSString *name;
@property (nonatomic,strong) NSMutableArray *allRoom;

@end
