//
//  ReplaceDevice.m
//  BWRemoter
//
//  Created by baiwei－mac on 16/1/19.
//  Copyright © 2016年 ReSun. All rights reserved.
//

#import "ReplaceDevice.h"
#import "ZigBeeNetCell.h"
#import "DeviceSettingModel.h"
#import "ZigBeeNetworking.h"

@interface ReplaceDevice () <UITableViewDataSource,UITableViewDelegate>

@property (nonatomic,strong) UITableView *leftT;
@property (nonatomic,strong) UITableView *rightT;
//所有当前同类型设备
@property (nonatomic,strong) NSMutableArray *curentAllTypeDevice;//右边选择的老设备列表
//所有新的当前同类型设备
@property (nonatomic,strong) NSMutableArray *curentAllTypeNewDevice;//左边
//选择的老设备数组
@property (nonatomic, strong) NSMutableArray *deviceOldArray;//右边选择后的列表
@property (nonatomic, strong) NSString *old;
@property (nonatomic,strong) UITapGestureRecognizer *tap;
@property (nonatomic,strong) UIView *topView;
@property (nonatomic, strong) UITableView *topTableView;

@end
/**
 *  替换流程
 1.左边是当前新入网设备
 2.右边最开始是空的，最下方有一个添加替换设备按钮
 3.点击后，显示所有可替换设备
 4.点击列表内任何一个，返回，右边出现刚才点击的数据
 5.点击替换功能，开始替换
 */
@implementation ReplaceDevice

- (DeviceSettingModel *)device {
    if (!_device) {
        _device = [DeviceSettingModel new];
    }
    return _device;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.deviceOldArray = [NSMutableArray new];
    self.curentAllTypeNewDevice = [NSMutableArray new];
    for (DeviceSettingModel *model in appManager.deviceNewArray) {
        /**
         *  获取点击的替换设备对应的所有类型设备
         1.获得当前设备对应的所有新设备数组
         2.与当前点击的进行比较，如果ID前4为相同，则假如数组
         3.记录数组有多少个元素，就知道是几路灯光
         */
        if ([[self getHeaderWihtCMD:model.ID] isEqualToString:[self getHeaderWihtCMD:self.device.ID]]) {
            [self.curentAllTypeNewDevice addObject:model];
        }
    }
    
    self.curentAllTypeDevice = [NSMutableArray new];
    [self getCurrentNewArrayWithNumber:self.curentAllTypeNewDevice.count];
    
    [self addLabelWithText:@"新入网设备：" rect:CGRectMake(0,74,curScreenSize.width/2,30) isAdjustsFontSizeToFit:NO];
    
    UIButton *choiceOldDevice = [[UIButton alloc]initWithFrame:CGRectMake(curScreenSize.width/2,74,curScreenSize.width/2,30)];
    choiceOldDevice.layer.cornerRadius = 5;
    [choiceOldDevice setBackgroundColor:[UIColor grayColor]];
    [choiceOldDevice setTitle:@"可替换设备" forState:UIControlStateNormal];
    [choiceOldDevice setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [choiceOldDevice addTarget:self action:@selector(choiceOldDevice) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:choiceOldDevice];
    //左边
    UIView *left = [[UIView alloc]initWithFrame:CGRectMake(0, 104, curScreenSize.width/2, curScreenSize.height - 184)];
    self.leftT = [[UITableView alloc]initWithFrame:left.bounds style:UITableViewStylePlain];
    [left addSubview:self.leftT];
    self.leftT.allowsSelection = NO;
    //右边
    UIView *right = [[UIView alloc]initWithFrame:CGRectMake(curScreenSize.width/2, 104, curScreenSize.width/2, curScreenSize.height - 184)];
    self.rightT = [[UITableView alloc]initWithFrame:right.bounds style:UITableViewStylePlain];
    [right addSubview:self.rightT];
    self.rightT.allowsSelection = NO;
    
    self.leftT.dataSource = self;
    self.leftT.delegate = self;
    self.leftT.tag = 1;
    [self.view addSubview:left];

    self.rightT.dataSource = self;
    self.rightT.delegate = self;
    self.rightT.tag = 2;
    [self.view addSubview:right];

    [self.leftT registerClass:[ZigBeeNetCell class] forCellReuseIdentifier:@"left"];
    [self.rightT registerClass:[ZigBeeNetCell class] forCellReuseIdentifier:@"right"];
    
    //确认替换
    UIButton *relace = [[UIButton alloc]initWithFrame:CGRectMake(curScreenSize.width/3, curScreenSize.height - 60, curScreenSize.width/3, 30)];
    relace.layer.cornerRadius = 5;
    [relace setBackgroundColor:[UIColor grayColor]];
    [relace setTitle:@"确认替换" forState:UIControlStateNormal];
    [relace setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [relace addTarget:self action:@selector(relace) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:relace];
}
- (void)choiceOldDevice {
    self.topView = [self addTopViewWithType:@"choice"];
}
- (void)back:(UITapGestureRecognizer *)tap {
    self.tap = nil;
    self.topTableView = nil;
    [self.topView removeFromSuperview];
}
- (UIView *)addTopViewWithType:(NSString *)type {
    
    UIView *view = [[UIView alloc]initWithFrame:self.view.frame];
    view.backgroundColor = [UIColor colorWithRed:10/255.0 green:10/255.0 blue:10/255.0 alpha:0.5];
    self.tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(back:)];
    UIView *tapView = [[UIView alloc]initWithFrame:view.bounds];
    tapView.backgroundColor = [UIColor clearColor];
    [view addSubview:tapView];
    [tapView addGestureRecognizer:self.tap];
    [self.view addSubview:view];
    
    UITableView *tableView = [[UITableView alloc]initWithFrame:CGRectMake(curScreenSize.width/4, curScreenSize.height/4, curScreenSize.width/2, curScreenSize.height/2) style:UITableViewStylePlain];
    tableView.tag = 1000;
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    [view addSubview:tableView];
    
    return view;
}
- (void)getCurrentNewArrayWithNumber:(NSInteger)number {
    NSMutableArray *arrayType = [NSMutableArray new];//当前类型设备
    NSMutableArray *allNeedArray = [NSMutableArray new];
    for (DeviceSettingModel *model in self.allDevice) {
        if ([model.type isEqualToString:self.device.type]) {
            [arrayType addObject:model];
        }
    }
    for (DeviceSettingModel *model in arrayType) {
        NSString *header = [self getHeaderWihtCMD:model.ID];
        NSInteger number1 = 0;
        for (DeviceSettingModel *model in arrayType) {
            if ([[self getHeaderWihtCMD:model.ID] isEqualToString:header]) {
                number1++;
            }
        }
        if (number1 == number && ![self.old isEqualToString:header]) {
            self.old = header;
            [allNeedArray addObject:header];
        }
    }
    for (NSString *header in allNeedArray) {
        for (DeviceSettingModel *model in arrayType) {
            if ([[self getHeaderWihtCMD:model.ID] isEqualToString:header] && ![[self getHeaderWihtCMD:model.ID] isEqualToString:[self getHeaderWihtCMD:self.device.ID]]) {
                [self.curentAllTypeDevice addObject:model];
            }
        }
    }
    
}
- (NSString *)getHeaderWihtCMD:(NSString *)cmd {
    return [[cmdP getDeviceNumberWithCMD:cmd] substringWithRange:NSMakeRange(0, 4)];
}
- (NSString *)getNumberWithCMD:(NSString *)cmd {
    return [[cmdP getDeviceNumberWithCMD:cmd] substringWithRange:NSMakeRange(4, 2)];
}
- (void)relace {
    
    for (int x = 0; x < self.curentAllTypeNewDevice.count; x++) {
        [CYM_DatabaseTable relaceDeviceFrom:self.curentAllTypeNewDevice[x] to:self.deviceOldArray[x]];
    }
    for (id subVC in self.navigationController.childViewControllers) {
        if ([subVC isKindOfClass:[ZigBeeNetworking class]]) {
            [self.navigationController popToViewController:subVC animated:YES];
            break;
        }
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (tableView.tag == 1000) {
        return self.curentAllTypeDevice.count;
    }
    if (tableView.tag == 1) {
        return self.curentAllTypeNewDevice.count;
    }
    else {
        return self.deviceOldArray.count;
    }
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (tableView.tag == 1000) {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
        if (cell == nil) {
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
        }
        DeviceSettingModel *model = self.curentAllTypeDevice[indexPath.row];
        cell.textLabel.text = model.name;
        cell.detailTextLabel.text = [cmdP getDeviceNumberWithCMD:model.ID];
        cell.detailTextLabel.textColor = [UIColor blackColor];
        cell.textLabel.textColor = [UIColor blackColor];
        return cell;
    }
    if (tableView.tag == 1) {
        DeviceSettingModel *model = self.curentAllTypeNewDevice[indexPath.row];
        ZigBeeNetCell *cell = [tableView dequeueReusableCellWithIdentifier:@"left"];
        cell.number.text = [NSString stringWithFormat:@"%ld",indexPath.row+1];
        cell.type.text = [NSString stringWithFormat:@"设备名称：%@",model.name];
        cell.ID.text = [NSString stringWithFormat:@"ID:%@",[cmdP getDeviceNumberWithCMD:model.ID]];
        cell.number.textColor = [UIColor redColor];
        cell.type.textColor = [UIColor redColor];
        cell.ID.textColor = [UIColor redColor];
        [cell.name removeFromSuperview];
        [cell.room removeFromSuperview];
        cell.accessoryType = UITableViewCellAccessoryNone;
        return cell;
    }
    else {
        DeviceSettingModel *model = self.deviceOldArray[indexPath.row];
        ZigBeeNetCell *cell = [tableView dequeueReusableCellWithIdentifier:@"right"];
        cell.number.text = [NSString stringWithFormat:@"%ld",indexPath.row+1];
        cell.type.text = [NSString stringWithFormat:@"设备名称：%@",model.name];
        cell.ID.text = [NSString stringWithFormat:@"ID:%@",[cmdP getDeviceNumberWithCMD:model.ID]];
        [cell.name removeFromSuperview];
        [cell.room removeFromSuperview];
        cell.accessoryType = UITableViewCellAccessoryNone;
        return cell;
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 60;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (tableView.tag == 1000) {
        DeviceSettingModel *mod = self.curentAllTypeDevice[indexPath.row];
        for (DeviceSettingModel *model in self.curentAllTypeDevice) {
            if ([[self getHeaderWihtCMD:model.ID] isEqualToString:[self getHeaderWihtCMD:mod.ID]]) {
                [self.deviceOldArray removeAllObjects];
                break;
            }
        }
        for (DeviceSettingModel *model in self.curentAllTypeDevice) {
            /**
             *  获取点击的替换设备对应的所有类型设备
             1.获得当前设备对应的所有新设备数组
             2.与当前点击的进行比较，如果ID前4为相同，则假如数组
             3.记录数组有多少个元素，就知道是几路灯光
             */
            if ([[self getHeaderWihtCMD:model.ID] isEqualToString:[self getHeaderWihtCMD:mod.ID]]) {
                [self.deviceOldArray addObject:model];
            }
        }
        [self back:nil];
        [self.rightT reloadData];
    }
}
- (void)addLabelWithText:(NSString *)text rect:(CGRect)rect isAdjustsFontSizeToFit:(BOOL)adjust{
    UILabel *label = [[UILabel alloc]initWithFrame:rect];
    label.text = text;
    label.font = [UIFont systemFontOfSize:14];
    label.textColor = [UIColor blackColor];
    label.textAlignment = NSTextAlignmentLeft;
    label.adjustsFontSizeToFitWidth = adjust;
    [self.view addSubview:label];
}
@end
