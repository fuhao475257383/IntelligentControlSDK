//
//  ZigBeeNetworking.m
//  BWRemoter
//
//  Created by baiwei－mac on 16/1/8.
//  Copyright © 2016年 ReSun. All rights reserved.
//

#import "ZigBeeNetworking.h"
#import "ZigBeeNetCell.h"
#import "DeviceSettingModel.h"
#import "CommonSetVC.h"
#import "MoreController.h"
#import "ZigbeeAlarmVC.h"
#import "SensorVC.h"
#import "OSPFVC.h"
#import "MBProgressHUD.h"
#import "CYM_Engine.h"
#import "Scenes.h"


@interface ZigBeeNetworking () <UITableViewDelegate,UITableViewDataSource,UIAlertViewDelegate>

@property (nonatomic,strong) UITableView *tableView;
//所有设备
@property (nonatomic,strong) NSMutableArray *allDevice;
//com口数目
@property (nonatomic,strong) NSMutableArray *comArray;
//com按钮
@property (nonatomic,strong) UIButton *comButton;
//选中的com口
@property (nonatomic,strong) NSString *comS;
@property (nonatomic,strong) UITapGestureRecognizer *tap;
//顶层视图
@property (nonatomic,strong) UIView *topView;
//定时器
@property (nonatomic,strong) NSTimer *timer;
//入网按钮
@property (nonatomic,strong) UIButton *rightButton;
//倒计时时间
@property (nonatomic) NSInteger timeNmuber;
//设备类型
@property (nonatomic,strong) NSArray *deviceState;
//新设备
@property (nonatomic,strong) NSMutableArray *newDevice;
//当前点击行
@property (nonatomic) NSInteger currentCell;

//HUD
@property (nonatomic,strong) MBProgressHUD *HUD;
@property (nonatomic) NSInteger fileNum;
//是否修改
@property (nonatomic) BOOL isModified;

@property (nonatomic,strong) NSMutableArray *discardCMD;

//是否是入网状态
@property (nonatomic) BOOL isNetWorking;

//上一次收到的命令
@property (nonatomic, strong) NSString *lastCMD;

@end

@implementation ZigBeeNetworking
- (NSMutableArray *)discardCMD {
    if (!_discardCMD) {
        _discardCMD = [NSMutableArray new];
    }
    return _discardCMD;
}
- (NSMutableArray *)newDevice {
    if (!_newDevice) {
        _newDevice = [NSMutableArray new];
    }
    return _newDevice;
}
- (NSArray *)deviceState {
    if (!_deviceState) {
        _deviceState = @[@"灯光",@"窗帘",@"空调控制器",@"智能插座",@"场景控制器",@"多功能控制器",@"zigbee转TTL",@"数据透传模块",@"传感器",@"报警设备",@"智能门锁"];
    }
    return _deviceState;
}
- (void)viewWillAppear:(BOOL)animated {
    //获得全部设备
    self.allDevice = [CYM_Engine getAllDevice];
    //遍历
    for (DeviceSettingModel *model in self.allDevice) {
        model.roomName = [CYM_Engine getRoomNameWithRoomDeviceName:model.name];
        if (!model.roomName) {
            model.roomName = @" ";
        }
    }
    NSMutableArray *needDeleteDevice = [NSMutableArray new];
    for (DeviceSettingModel *newModel in self.newDevice) {//遍历所有新设备
        for (DeviceSettingModel *model in self.allDevice) {//遍历所有设备
            if ([model.ID isEqualToString:newModel.ID] && [model.name isEqualToString:newModel.name]) {//新设备的ID和旧设备ID相等,并且名字一样，说明重复了
                [needDeleteDevice addObject:model];
            }
        }
    }
    for (DeviceSettingModel *model in needDeleteDevice) {
        [self.allDevice removeObject:model];
    }
    //添加新入网设备
    for (DeviceSettingModel *model in self.newDevice) {
        [self.allDevice addObject:model];
    }
    self.comArray = [CYM_DatabaseTable getAllControl];
   
    [self.tableView reloadData];

}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.isNetWorking = NO;
    self.comS = @"0";
    /********************/
    //为了保证数据的正确性，做了如下流程的判断
    /*
     1.就在系统中存储一个字段，用来记录用户进入了设置
     2.一旦用户进入该设置，该字段记录为YES
     3.如果用户正常保存或者退出，该字段为NO
     4.如果用户异常退出，那么该字段不变
     5.登录的时候提取该字段，如果为YES，就下载配置文件
     6.如果为NO，正常登录
    */
    /********************/
    //复制数据库副本
    
    [[NSUserDefaults standardUserDefaults] setObject:@"YES" forKey:@"NETWORKING"];
    self.isModified = NO;
    
    NSFileManager *fileManager =[NSFileManager defaultManager];
    
    NSString *documentsStr   = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    
    NSString *databasePath     =[NSString stringWithFormat:@"%@/BWDatabase_V2.sqlite",documentsStr];
    NSString *databaseCopy =[NSString stringWithFormat:@"%@/BWDatabase_Copy.sqlite",documentsStr];
    
    if (![fileManager fileExistsAtPath:databaseCopy])
    {
        [fileManager copyItemAtPath:databasePath toPath:databaseCopy error:nil];
    }
    else
    {
        [fileManager removeItemAtPath:databaseCopy error:nil];
        [fileManager copyItemAtPath:databasePath toPath:databaseCopy error:nil];
    }
    
    self.fileNum = 0;
    self.timeNmuber = 0;
    self.currentCell = 0;
    self.title = @"ZigBee组网";
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(goOnInNet) name:@"InNet" object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(newDeviceIn:) name:@"InNetMSG" object:nil];
    self.comArray = [CYM_DatabaseTable getAllControl];
    self.allDevice = [NSMutableArray new];
//    self.allDevice = [CYM_Engine getAllDevice];
//    for (DeviceSettingModel *model in self.allDevice) {
//        model.roomName = [CYM_Engine getRoomNameWithRoomDeviceName:model.name];
//        if (!model.roomName) {
//            model.roomName = @"未设置";
//        }
//    }
    
    //添加右侧按钮
    UIButton *applyButton = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 40, 30)];
    applyButton.backgroundColor = [UIColor whiteColor];
    [applyButton setTitle:@"应用" forState:UIControlStateNormal];
    [applyButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    applyButton.titleLabel.font = [UIFont systemFontOfSize:14];
    applyButton.layer.borderWidth = 1;
    applyButton.layer.cornerRadius = 5;
    applyButton.layer.borderColor = [UIColor blackColor].CGColor;
    [applyButton addTarget:self action:@selector(applySet) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithCustomView:applyButton];
    self.navigationItem.rightBarButtonItem =item;
    
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, curScreenSize.width, curScreenSize.height - 70) style:UITableViewStylePlain];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    [self.tableView registerClass:[ZigBeeNetCell class] forCellReuseIdentifier:@"ZigBeeCell"];
    [self.view addSubview:self.tableView];
    
    //com口选择
    self.comButton = [[UIButton alloc]initWithFrame:CGRectMake(10, curScreenSize.height - 50, curScreenSize.width / 2 - 20, 30)];
    if (self.comArray.count != 0) {
        [self.comButton setTitle:((Control*)self.comArray[0]).com forState:UIControlStateNormal];
    }
    else {
        [self.comButton setTitle:@"未知" forState:UIControlStateNormal];
    }
    [self.comButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.comButton addTarget:self action:@selector(addTopView) forControlEvents:UIControlEventTouchUpInside];
    self.comButton.titleLabel.adjustsFontSizeToFitWidth = YES;
    self.comButton.backgroundColor = [UIColor grayColor];
    self.comButton.layer.cornerRadius = 5;
    [self.view addSubview:self.comButton];
    
    //按钮
    self.rightButton = [[UIButton alloc]initWithFrame:CGRectMake(curScreenSize.width / 2 + 10, curScreenSize.height - 50, curScreenSize.width / 2 - 20, 30)];
    self.rightButton.backgroundColor = [UIColor grayColor];
    self.rightButton.layer.cornerRadius = 5;
    [self.rightButton setTitle:@"允许入网" forState:UIControlStateNormal];
    [self.rightButton addTarget:self action:@selector(beginInNet) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.rightButton];
    
}
- (void)addTopView{
    
    UIView *view = [[UIView alloc]initWithFrame:self.view.frame];
    view.backgroundColor = [UIColor colorWithRed:10/255.0 green:10/255.0 blue:10/255.0 alpha:0.5];
    self.tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(back:)];
    UIView *tapView = [[UIView alloc]initWithFrame:view.bounds];
    tapView.backgroundColor = [UIColor clearColor];
    [view addSubview:tapView];
    [tapView addGestureRecognizer:self.tap];
    [self.view addSubview:view];
    
    UITableView *tableView = [[UITableView alloc]initWithFrame:CGRectMake(curScreenSize.width/4, curScreenSize.height/4, curScreenSize.width/2, curScreenSize.height/2) style:UITableViewStylePlain];
    tableView.tag = 1;
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    [view addSubview:tableView];
    self.topView = view;
    
}
- (void)back:(UITapGestureRecognizer *)tap {
    self.tap = nil;
    [self.topView removeFromSuperview];
}
//tableview
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (tableView.tag == 1) {
        return self.comArray.count;
    }
    return self.allDevice.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (tableView.tag == 1) {
        return 44;
    }
    return 60;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    

    ZigBeeNetCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ZigBeeCell" ];

    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    if (tableView.tag == 1) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
        cell.textLabel.text = ((Control*)self.comArray[indexPath.row]).com;
        return cell;
    }
    
    DeviceSettingModel *model = self.allDevice[indexPath.row];
    
    cell.tag = indexPath.row;
    cell.number.text = [NSString stringWithFormat:@"%ld",indexPath.row+1];
    cell.type.text = [NSString stringWithFormat:@"%@/%@",model.type,model.property];
    cell.name.text = [NSString stringWithFormat:@"名称:%@",model.name];
    cell.ID.text = [NSString stringWithFormat:@"ID:%@",[cmdP getDeviceNumberWithCMD:model.ID]];
    cell.room.text = [NSString stringWithFormat:@"%@",model.roomName];
    cell.number.textColor = [UIColor blackColor];
    cell.type.textColor = [UIColor blackColor];
    cell.name.textColor = [UIColor blackColor];
    cell.ID.textColor = [UIColor blackColor];
    cell.room.textColor = [UIColor blackColor];
    
    if (model.isNewDevice == YES) {
        cell.number.textColor = [UIColor redColor];
        cell.type.textColor = [UIColor redColor];
        cell.name.textColor = [UIColor redColor];
        cell.ID.textColor = [UIColor redColor];
        cell.room.textColor = [UIColor redColor];
    }
    
    UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(againInNet:)];
    longPress.minimumPressDuration = 1;
    
    [cell addGestureRecognizer:longPress];
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (tableView.tag == 1) {
        Control *control = self.comArray[indexPath.row];
        self.comS = control.comNumber;
        [self.comButton setTitle:control.com forState:UIControlStateNormal];
        [self back:nil];
        return;
    }
    //点击设备cell
    [self sendIdentifyWithCellIndex:indexPath.row];
    
}
- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath {
    DeviceSettingModel *model = self.allDevice[indexPath.row];
    if ([model.type isEqualToString:@"灯光"] || [model.type isEqualToString:@"窗帘"] || [model.type isEqualToString:@"智能插座"] || [model.type isEqualToString:@"场景控制器"] || [model.type isEqualToString:@"智能门锁"]) {
        CommonSetVC *VC = [CommonSetVC new];
        VC.device = self.allDevice[indexPath.row];
        VC.allDevice = self.allDevice;
        [self.navigationController pushViewController:VC animated:YES];
    }
    if ([model.type isEqualToString:@"多功能控制器"] || [model.type isEqualToString:@"空调控制器"]) {
        MoreController *VC = [MoreController new];
        VC.device = self.allDevice[indexPath.row];
        VC.allDevice = self.allDevice;
        [self.navigationController pushViewController:VC animated:YES];
    }
    if ([model.type isEqualToString:@"zigbee转TTL"] || [model.type isEqualToString:@"报警设备"]) {
        ZigbeeAlarmVC *VC = [ZigbeeAlarmVC new];
        VC.device = self.allDevice[indexPath.row];
        VC.allDevice = self.allDevice;
        [self.navigationController pushViewController:VC animated:YES];
    }
    if ([model.type isEqualToString:@"传感器"]) {
        SensorVC *VC = [SensorVC new];
        VC.device = self.allDevice[indexPath.row];
        VC.allDevice = self.allDevice;
        [self.navigationController pushViewController:VC animated:YES];
    }
    if ([model.type isEqualToString:@"数据透传模块"]) {
        OSPFVC *VC = [OSPFVC new];
        VC.device = self.allDevice[indexPath.row];
        VC.allDevice = self.allDevice;
        [self.navigationController pushViewController:VC animated:YES];
    }
    self.isModified = YES;
}
- (void)touchedBackButton:(id)sender{
    self.isNetWorking = NO;
    self.timeNmuber = 0;
    [self.timer invalidate];
    if (self.isModified == NO) {
        [self.navigationController popViewControllerAnimated:YES];
        return;
    }
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示：" message:@"是否保存当前设置？" delegate:self cancelButtonTitle:@"不保存" otherButtonTitles:@"保存", nil];
    alert.tag = 1000000;
    [alert show];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    
    
    
    if (buttonIndex == 0 && alertView.tag == 1000000) {
            //删除掉修改过的数据库，将副本改为原数据库名字
        
        NSFileManager *fileManager =[NSFileManager defaultManager];
        
        NSString *documentsStr   = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
        
        NSString *databasePath     =[NSString stringWithFormat:@"%@/BWDatabase_V2.sqlite",documentsStr];
        NSString *databaseCopy =[NSString stringWithFormat:@"%@/BWDatabase_Copy.sqlite",documentsStr];
        
        if (![fileManager fileExistsAtPath:databasePath])
        {
            [fileManager copyItemAtPath:databaseCopy toPath:databasePath error:nil];
        }
        else
        {
            [fileManager removeItemAtPath:databasePath error:nil];
            [fileManager copyItemAtPath:databaseCopy toPath:databasePath error:nil];
        }
        
        [[NSUserDefaults standardUserDefaults] setObject:@"NO" forKey:@"NETWORKING"];
        [self.navigationController popViewControllerAnimated:YES];
        return;
    }
    if (buttonIndex == 1 && alertView.tag == 1000000){
        [self applySet];
        return;
    }
    
    if (buttonIndex == 0) {
        return;
    }else {
        [self copyDeviceNumber:alertView.tag];
    }
    
}
//应用
- (void)applySet {
    self.isNetWorking = NO;
    [self back:nil];
    self.HUD = [[MBProgressHUD alloc] initWithView:[UIApplication sharedApplication].keyWindow];
    [[UIApplication sharedApplication].keyWindow addSubview:self.HUD];
    
    self.HUD.labelText                 = @"请稍候";
    self.HUD.labelFont                 = [UIFont systemFontOfSize:15];
    self.HUD.detailsLabelText          = @"正在努力保存到网关...";
    self.HUD.detailsLabelFont          = [UIFont systemFontOfSize:13];
    self.HUD.square                    = YES;
    self.HUD.removeFromSuperViewOnHide = YES;
    
    /*HUD的显示不会阻塞主线程*/
    [self.HUD show:YES];
    
    NSData *roomOld = [CYM_Engine generateJSONFileWithName:@"room.json"];
    NSData *sceneOld = [CYM_Engine generateJSONFileWithName:@"scene.json"];
    NSData *controlOld = [CYM_Engine generateJSONFileWithName:@"control.json"];
    NSData *crontabOld = [CYM_Engine generateJSONFileWithName:@"crontab.json"];
    NSData *securityOld = [CYM_Engine generateJSONFileWithName:@"security.json"];
    
    
    
    [appManager uploadFileWithName:@"room.json" andData:roomOld isShowHUD:NO handler:^(NSString *fileName, NSError *error) {
        self.fileNum++;
        if (self.fileNum == 5) {
            self.fileNum = 0;
            [self.HUD hide:YES];
            [[NSUserDefaults standardUserDefaults] setObject:@"NO" forKey:@"NETWORKING"];
            [self.navigationController popViewControllerAnimated:YES];
        }
    }];
    [appManager uploadFileWithName:@"scene.json" andData:sceneOld isShowHUD:NO handler:^(NSString *fileName, NSError *error) {
        self.fileNum++;
        if (self.fileNum == 5) {
            self.fileNum = 0;
            [self.HUD hide:YES];
            [[NSUserDefaults standardUserDefaults] setObject:@"NO" forKey:@"NETWORKING"];
            [self.navigationController popViewControllerAnimated:YES];
        }
    }];
    [appManager uploadFileWithName:@"control.json" andData:controlOld isShowHUD:NO handler:^(NSString *fileName, NSError *error) {
        self.fileNum++;
        if (self.fileNum == 5) {
            self.fileNum = 0;
            [self.HUD hide:YES];
            [[NSUserDefaults standardUserDefaults] setObject:@"NO" forKey:@"NETWORKING"];
            [self.navigationController popViewControllerAnimated:YES];
        }
    }];
    [appManager uploadFileWithName:@"crontab.json" andData:crontabOld isShowHUD:NO handler:^(NSString *fileName, NSError *error) {
        self.fileNum++;
        if (self.fileNum == 5) {
            self.fileNum = 0;
            [self.HUD hide:YES];
            [[NSUserDefaults standardUserDefaults] setObject:@"NO" forKey:@"NETWORKING"];
            [self.navigationController popViewControllerAnimated:YES];
        }
    }];
    [appManager uploadFileWithName:@"security.json" andData:securityOld isShowHUD:NO handler:^(NSString *fileName, NSError *error) {
        self.fileNum++;
        if (self.fileNum == 5) {
            self.fileNum = 0;
            [self.HUD hide:YES];
            [[NSUserDefaults standardUserDefaults] setObject:@"NO" forKey:@"NETWORKING"];
            [self.navigationController popViewControllerAnimated:YES];
        }
    }];
    
}
//允许入网
- (void)beginInNet {
    //允许入网命令  a55a 06 09 fa 00
    NSMutableString *cmd = [NSMutableString stringWithString:@"A55A0609FA"];
    NSString *tmp = [NSString stringFromHexString:cmd];
    uint sum = 0;
    for (int i=0; i<tmp.length; i++) {
        unsigned int c = [tmp characterAtIndex:i];
        sum += c;
    }
    [cmd appendString:[self getChecksum:cmd]];
    NSString *msg = [msgB getMessageWithType:[self.comS longLongValue] action:ACTION_TRANSMIT commond:cmd];
    [[HE_APPManager sharedManager] SendMsg:msg withNameSpace:@"control" isShowLoading:NO];
    self.isNetWorking = YES;
}
- (NSString *)getChecksum:(NSString *)str{
    int len = (int)[str length] / 2 + 1;
    unsigned char *myBuffer = (unsigned char *)malloc(len);
    bzero(myBuffer, [str length] / 2 + 1);
    for (int i = 0; i < [str length] - 1; i += 2) {
        unsigned int anInt;
        NSString * hexCharStr = [str substringWithRange:NSMakeRange(i, 2)];
        NSScanner * scanner = [[NSScanner alloc] initWithString:hexCharStr];
        [scanner scanHexInt:&anInt];
        myBuffer[i / 2] = (unsigned char)anInt;
    }
    myBuffer[len - 1] = 0;
    unsigned int sum = 0;
    for (int i=0; i<len; i++){
        sum += myBuffer[i];
    }
    NSString *ans = [NSString stringWithFormat:@"%X", sum];
    return [ans substringWithRange:NSMakeRange(ans.length-2, 2)];
}
- (void)goOnInNet {
    self.timeNmuber = 0;
    [self.timer invalidate];
    self.timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(changeButtonTitle) userInfo:nil repeats:YES];
}
- (void)changeButtonTitle {
    self.timeNmuber++;
    [self.rightButton setTitle:[NSString stringWithFormat:@"%ld",250-self.timeNmuber] forState:UIControlStateNormal];

    if (self.timeNmuber == 249) {
        self.timeNmuber = 0;
        [self.rightButton setTitle:@"允许入网" forState:UIControlStateNormal];
        [self.timer invalidate];
    }
}
- (void)timerOver {
    self.isNetWorking = NO;
    self.timeNmuber = 0;
    [self.timer invalidate];
}
- (void)newDeviceIn:(NSNotification *)dic {
    
    if (self.isNetWorking == NO) {
        return;
    }
    NSLog(@"%@",dic);
    NSDictionary *dict = dic.userInfo;
    NSString *cmd = dict[@"msg"];
    if ([self.lastCMD isEqualToString:cmd]) {
        return;
    }
    self.lastCMD = cmd;
    
    if ([[cmd substringWithRange:NSMakeRange(0, 10)] isEqualToString:@"A55A0D040A"]) {
        for (DeviceSettingModel *model in self.allDevice) {
            if (model.isSensor == YES && [[cmd substringWithRange:NSMakeRange(10, 4)] isEqualToString:[model.ID substringWithRange:NSMakeRange(12, 4)]]) {
                NSString *type = [cmd substringWithRange:NSMakeRange(16, 2)];
                NSArray *typeArray = @[@"煤气",@"烟雾",@"CO探测器",@"红外探测器",@"门磁探测器",@"紧急按钮",@"窗磁探测器"];
                model.property = typeArray[type.intValue];
                model.name = [NSString stringWithFormat:@"%@传感器",model.property];
                [self.tableView reloadData];
            }
        }
        return;
    }
    
    NSString *devicNumber = [cmd substringWithRange:NSMakeRange(8, 2)];
//    NSString *stateNumber = [cmd substringWithRange:NSMakeRange(10, 2)];
    DeviceSettingModel *new = [DeviceSettingModel new];
    //isNewDevice
    new.isNewDevice = YES;
    //type
    
    for (NSString *str in self.discardCMD) {
        if ([str isEqualToString:[cmdP getDeviceNumberWithCMD:cmd]]) {
            return;
        }
    }
    
    if ([devicNumber isEqualToString:@"01"]) {
        new.type = self.deviceState[0];
    }
    else if ([devicNumber isEqualToString:@"02"]) {
        new.type = self.deviceState[1];
    }
    else if ([devicNumber isEqualToString:@"03"]) {
        new.type = self.deviceState[2];
    }
    else if ([devicNumber isEqualToString:@"04"]) {
        new.type = self.deviceState[3];
    }
    else if ([devicNumber isEqualToString:@"05"]) {
        new.type = self.deviceState[4];
    }
    else if ([devicNumber isEqualToString:@"06"]) {
        new.type = self.deviceState[5];
    }
    else if ([devicNumber isEqualToString:@"08"]) {
        [self.discardCMD addObject:[NSString stringWithFormat:@"%@16",[[cmdP getDeviceNumberWithCMD:cmd] substringWithRange:NSMakeRange(0, 4)]]];
        new.type = self.deviceState[6];
    }
    else if ([devicNumber isEqualToString:@"09"]) {
        new.type = self.deviceState[7];
    }
    else if ([devicNumber isEqualToString:@"0A"] || [devicNumber isEqualToString:@"0a"]) {
        new.type = self.deviceState[8];
    }
    else if ([devicNumber isEqualToString:@"0B"] || [devicNumber isEqualToString:@"0b"]) {
        new.type = self.deviceState[9];
    }
    else if ([devicNumber isEqualToString:@"0C"] || [devicNumber isEqualToString:@"0c"]) {
        new.type = self.deviceState[10];
    }
    //com
    NSString *number = dict[@"com"];
    if ( [[number substringWithRange:NSMakeRange(0, 1)]isEqualToString:@"0"]) {
        new.com = [number substringWithRange:NSMakeRange(1, 1)];
    }else {
        new.com = number;
    }
    //ID
    new.ID = cmd;
    new.roomName = @" ";
    new.property = @"未设置";
    new.isSensor = YES;
    [self.newDevice addObject:new];
    [self.allDevice addObject:new];
    appManager.deviceNewArray = self.newDevice;
    
    
    [self.tableView reloadData];
    //滚动到最新的设备那一行
    NSIndexPath *scrollIndexPath = [NSIndexPath indexPathForRow:(self.allDevice.count-1) inSection:0];
    [[self tableView] scrollToRowAtIndexPath:scrollIndexPath atScrollPosition:UITableViewScrollPositionTop animated:YES];

}
//发送identify命令
- (void)sendIdentifyWithCellIndex:(NSInteger)row {
    //发送identify命令
    DeviceSettingModel *model = self.allDevice[row];
    
    A4_DeviceTypeCode typeA4 = A4_DEVICE_UNKNOW;
    if ([model.type isEqualToString:@"灯光"]) {
        typeA4 = A4_DEVICE_LIGHT;
    }
    else if ([model.type isEqualToString:@"窗帘"]) {
        typeA4 = A4_DEVICE_CURTAIN;
    }
    else if ([model.type isEqualToString:@"空调控制器"]) {
        typeA4 = A4_DEVICE_AIR_CONDITION;
    }
    else if ([model.type isEqualToString:@"智能插座"]) {
        typeA4 = A4_DEVICE_SOCKET;
    }
    else if ([model.type isEqualToString:@"场景控制器"]) {
        typeA4 = A4_DEVICE_SENCE;
    }
    else if ([model.type isEqualToString:@"多功能控制器"]) {//1
        typeA4 = A4_DEVICE_MUTIL;
    }
    else if ([model.type isEqualToString:@"zigbee转TTL"]) {//1 15
        typeA4 = A4_DEVICE_IO;
    }
    else if ([model.type isEqualToString:@"数据透传模块"]) {//1
        typeA4 = A4_DEVICE_UART;
    }
    else if ([model.type isEqualToString:@"智能门锁"]) {
        typeA4 = A4_DEVICE_DOORLOCK;
    }
    else if ([model.type isEqualToString:@"传感器"]) {
        typeA4 = A4_DEVICE_SENSAR;
    }
    else if ([model.type isEqualToString:@"报警设备"]) {
        typeA4 = A4_DEVICE_ALARM;
    }
    
    
    NSString *strData = [NSString stringWithFormat:@"%@05",[model.ID substringWithRange:NSMakeRange(12, 6)]];
    //NSString *strData = [NSString stringWithFormat:@"%@", @"FFFFFF"];
    NSString *cmd = [cmdB getCMDWithAction:A4_ACTION_DEVICE_INSTRUCTIO DeviceType:typeA4 Data:strData];
    NSString *msg = [msgB getMessageWithType:[model.com longLongValue] action:ACTION_TRANSMIT commond:cmd];
    [[HE_APPManager sharedManager] SendMsg:msg withNameSpace:@"control" isShowLoading:NO];
}
//再次组网,复制设备
- (void)againInNet:(UILongPressGestureRecognizer *)longPress {
    if (longPress.state == UIGestureRecognizerStateBegan) {
        ZigBeeNetCell *cell = longPress.view;
        DeviceSettingModel *model = self.allDevice[cell.tag];
        
        if ([model.type isEqualToString:@"空调控制器"] || [model.type isEqualToString:@"多功能控制器"] || ([[[cmdP getDeviceNumberWithCMD:model.ID] substringWithRange:NSMakeRange(4, 2)] isEqualToString:@"15"]&&[model.type isEqualToString:@"zigbee转TTL"]) || [model.type isEqualToString:@"数据透传模块"]) {
            [self showAlertViewWithDetail:@"是否复制该设备？" withRow:cell.tag];
        }
        else {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示：" message:@"该设备不能复制！" delegate:nil cancelButtonTitle:@"我知道了" otherButtonTitles: nil];
            [alert show];
        }
    }
}
- (void)copyDeviceNumber:(NSInteger)number {
    DeviceSettingModel *model = self.allDevice[number];
    DeviceSettingModel *new = [DeviceSettingModel new];
    new.isNewDevice = YES;
    new.type = model.type;
    new.com = model.com;
    new.ID = model.ID;
    new.property = model.property;
    new.roomName = model.roomName;
    new.trigger = model.trigger;
    new.BD = model.BD;
    new.sensor24h = model.sensor24h;
    new.isAlarm = model.isAlarm;
    new.powerMSG = model.powerMSG;
    
    [self.newDevice addObject:new];
    [self.allDevice addObject:new];
    appManager.deviceNewArray = self.newDevice;
    [self.tableView reloadData];
    //滚动到最新的设备那一行
    NSIndexPath *scrollIndexPath = [NSIndexPath indexPathForRow:(self.allDevice.count-1) inSection:0];
    [[self tableView] scrollToRowAtIndexPath:scrollIndexPath atScrollPosition:UITableViewScrollPositionTop animated:YES];
}
- (void)showAlertViewWithDetail:(NSString *)detail withRow:(NSInteger)row {
    
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示：" message:detail delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    alert.tag = row;
    [alert show];
}

@end
