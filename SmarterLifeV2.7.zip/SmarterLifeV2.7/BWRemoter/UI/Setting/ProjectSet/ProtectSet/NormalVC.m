//
//  NormalVC.m
//  BWRemoter
//
//  Created by baiwei－mac on 16/1/11.
//  Copyright © 2016年 ReSun. All rights reserved.
//

#import "NormalVC.h"
#import "Room.h"

@interface NormalVC () <UIAlertViewDelegate,UITableViewDataSource,UITableViewDelegate>

@property (nonatomic,strong) UITextField *nameField;
@property (nonatomic,strong) UITapGestureRecognizer *tap;
@property (nonatomic,strong) Room *currentRoom;
//房间列表
@property (nonatomic,strong) UITableView *table;
//所有设备
@property (nonatomic,strong) NSMutableArray *allDevice;

@end

@implementation NormalVC

- (NSMutableArray *)allRoom {
    if (!_allRoom) {
        _allRoom = [NSMutableArray new];
    }
    return _allRoom;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"房间设备列表";
    
    self.allDevice = [CYM_DatabaseTable getAllDeviceWithRoomName:self.name];
    
    UILabel *name = [[UILabel alloc]initWithFrame:CGRectMake(20, 94, curScreenSize.width/5, 20)];
    name.text = @"名称：";
    name.font = [UIFont systemFontOfSize:14];
    name.textColor = [UIColor blackColor];
    [self.view addSubview:name];
    
    self.nameField = [[UITextField alloc]initWithFrame:CGRectMake(20+curScreenSize.width/5, 84, curScreenSize.width*3/5, 30)];
    self.nameField.borderStyle = UITextBorderStyleRoundedRect;
    self.nameField.text = self.name;
    self.nameField.delegate = self;
    [self.view addSubview:self.nameField];
    
    UIButton *deleteButton = [[UIButton alloc]initWithFrame:CGRectMake(20, curScreenSize.height - 60, curScreenSize.width/2-30, 30)];
    deleteButton.layer.cornerRadius = 5;
    [deleteButton setBackgroundColor:[UIColor grayColor]];
    [deleteButton setTitle:@"删除房间" forState:UIControlStateNormal];
    [deleteButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [deleteButton addTarget:self action:@selector(deleteR) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:deleteButton];
    
    UIButton *aplayButton = [[UIButton alloc]initWithFrame:CGRectMake(curScreenSize.width/2+10, curScreenSize.height - 60, curScreenSize.width/2 - 30, 30)];
    aplayButton.layer.cornerRadius = 5;
    [aplayButton setBackgroundColor:[UIColor grayColor]];
    [aplayButton setTitle:@"应用" forState:UIControlStateNormal];
    [aplayButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [aplayButton addTarget:self action:@selector(aplayR) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:aplayButton];
    
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(20, 134, curScreenSize.width-40, curScreenSize.height-134-80)];
    self.table = [[UITableView alloc]initWithFrame:view.bounds style:UITableViewStylePlain];
    self.table.dataSource = self;
    self.table.delegate = self;
    [view addSubview:self.table];
    [self.view addSubview:view];
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.allDevice.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"roomCell"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"roomCell"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    cell.textLabel.text = self.allDevice[indexPath.row];
    return cell;
}

- (void)deleteR {
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:@"该操作会删除房间，是否删除？" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    [alert show];
}
- (void)aplayR {
    if ([self.nameField.text isEqualToString:@""] || self.nameField.text == nil) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示:" message:@"名称不能为空" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
        [alert show];
        return;
    }
    NSLog(@"%@",self.nameField.text);
    for (Room *room in self.allRoom) {
        if ([room.name isEqualToString:self.name]) {
            self.currentRoom = room;
        }
        if ([room.name isEqualToString:self.nameField.text]) {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示:" message:@"名称已存在，请重新设置！" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
            [alert show];
            return;
        }
    }
    NSString *oldName = self.currentRoom.name;
    self.currentRoom.name = self.nameField.text;
    [Room updataRoomWithNewRoom:self.currentRoom withOldName:oldName];
    
    //上传文件
    [self updateRoomJSON];
    
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)textFieldDidBeginEditing:(UITextField *)textField {
    self.tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(closeKeyboard)];
    [self.view addGestureRecognizer:self.tap];
}
- (void)closeKeyboard {
    [self.view removeGestureRecognizer:self.tap];
    [self.nameField resignFirstResponder];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 1) {
        [Room deleteRoom:self.nameField.text];
        
        //上传文件room.json和scene.json
        [self updateRoomJSON];
        
        [self.navigationController popViewControllerAnimated:YES];
    }
    
}
- (void)updateRoomJSON {
    //上传room.json文件
    NSData *sceneOld = [CYM_Engine generateJSONFileWithName:@"scene.json"];
    [appManager uploadFileWithName:@"scene.json" andData:sceneOld isShowHUD:NO];
    
    NSData *roomOld = [CYM_Engine generateJSONFileWithName:@"room.json"];
    [appManager uploadFileWithName:@"room.json" andData:roomOld isShowHUD:NO];
}
@end
