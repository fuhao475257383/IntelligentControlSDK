//
//  OSPFVC.m
//  BWRemoter
//
//  Created by baiwei－mac on 16/1/15.
//  Copyright © 2016年 ReSun. All rights reserved.
//

#import "OSPFVC.h"
#import "AddOrderVC.h"

@interface OSPFVC () <UITableViewDataSource,UITableViewDelegate,UIAlertViewDelegate>

@property (nonatomic,strong) UITextField *nameField;//名字
@property (nonatomic,strong) UITapGestureRecognizer *tap;
@property (nonatomic,strong) UIButton *property;//属性
@property (nonatomic,strong) UIButton *room;//房间
@property (nonatomic,strong) UIView *topView;
@property (nonatomic,strong) NSMutableArray *allRoom;//所有的房间
@property (nonatomic,strong) NSArray *propertyArray;//所有属性
@property (nonatomic,strong) NSString *modiProperty;//选择的属性
@property (nonatomic,strong) NSString *modiRoom;//选择的房间
@property (nonatomic,strong) NSString *modiName;//修改的名字
//新增
@property (nonatomic,strong) UITableView *CMDView;
@property (nonatomic,strong) UIButton *baudRate;
@property (nonatomic,strong) NSArray *baudRateArray;
//模板数组
@property (nonatomic,strong) NSMutableArray *modelArray;
//存储波特率
@property (nonatomic,strong) NSString *baudRateStr;
//指令
@property (nonatomic,strong) UIButton *add;
@property (nonatomic,strong) UIButton *model;
@property (nonatomic,strong) UIButton *clear;

@property (nonatomic, strong) UITableView *topTableView;
@property (nonatomic, copy) NSString *oldName;

@end

@implementation OSPFVC
- (NSMutableArray *)allDevice {
    if (!_allDevice) {
        _allDevice = [NSMutableArray new];
    }
    return _allDevice;
}
- (NSMutableArray *)modelArray {
    if (!_modelArray) {
        _modelArray = [NSMutableArray new];
        //模板1
        NSMutableArray *arr1 = [NSMutableArray new];
        NSString *sourcePath     =[[NSBundle mainBundle]pathForResource:@"背景音乐终极版"  ofType: @"txt"];
        NSString *str = [NSString stringWithContentsOfFile:sourcePath encoding:NSUTF8StringEncoding error:nil];
        
        NSArray*arr =[str componentsSeparatedByString:@";\r\n"];
        for (NSString *s in arr) {
            
            NSArray *ar = [s componentsSeparatedByString:@","];
            ControlDeviceContentValueKey *key = [ControlDeviceContentValueKey new];
            key.name = ar[0];
            key.value = ar[1];
            key.query = ar[2];
            key.backkey = ar[3];
            key.time = ar[4];
            [arr1 addObject:key];
        }
        [_modelArray addObject:arr1];
        //模板2
        NSMutableArray *arr2 = [NSMutableArray new];
        NSString *path     =[[NSBundle mainBundle]pathForResource:@"大金中央空调终极版1-00"  ofType: @"txt"];
        NSString *stri = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
        
        NSArray*arra =[stri componentsSeparatedByString:@";\r\n"];
        for (NSString *s in arra) {
            
            NSArray *ar = [s componentsSeparatedByString:@","];
            ControlDeviceContentValueKey *key = [ControlDeviceContentValueKey new];
            key.name = ar[0];
            key.value = ar[1];
            key.query = ar[2];
            key.backkey = ar[3];
            key.time = ar[4];
            [arr2 addObject:key];
        }
        [_modelArray addObject:arr2];
    }
    return _modelArray;
}
- (void)viewWillAppear:(BOOL)animated {
    //发送查询命令
    NSString *strData = [NSString stringWithFormat:@"%@",[self.device.ID substringWithRange:NSMakeRange(12, 6)]];
    NSString *cmd = [cmdB getCMDWithAction:a4_ACTION_CONFIG DeviceType:A4_DEVICE_UART Data:strData];
    NSString *msg = [msgB getMessageWithType:[self.device.com longLongValue] action:ACTION_TRANSMIT commond:cmd];
    [[HE_APPManager sharedManager] SendMsg:msg withNameSpace:@"control" isShowLoading:NO];
    [self.CMDView reloadData];
}
- (void)reciveMsg:(NSNotification *)notification{
    NSString *strMsg = notification.userInfo[@"msg"];
    if ([[strMsg substringWithRange:NSMakeRange(6, 4)] isEqualToString:@"7F09"]||[[strMsg substringWithRange:NSMakeRange(6, 4)] isEqualToString:@"7f09"]) {
        //解析数据，刷新数据
        NSString *state = [strMsg substringWithRange:NSMakeRange(20, 2)];
        if ([state isEqualToString:@"00"]) {
            [self.baudRate setTitle:self.baudRateArray[0] forState:UIControlStateNormal];
        }
        else if ([state isEqualToString:@"01"]) {
            [self.baudRate setTitle:self.baudRateArray[1] forState:UIControlStateNormal];
        }
        else if ([state isEqualToString:@"02"]) {
            [self.baudRate setTitle:self.baudRateArray[2] forState:UIControlStateNormal];
        }
        else if ([state isEqualToString:@"03"]) {
            [self.baudRate setTitle:self.baudRateArray[3] forState:UIControlStateNormal];
        }
        else if ([state isEqualToString:@"04"]) {
            [self.baudRate setTitle:self.baudRateArray[4] forState:UIControlStateNormal];
        }
        else if ([state isEqualToString:@"05"]) {
            [self.baudRate setTitle:self.baudRateArray[5] forState:UIControlStateNormal];
        }
        else if ([state isEqualToString:@"06"]) {
            [self.baudRate setTitle:self.baudRateArray[6] forState:UIControlStateNormal];
        }
        else if ([state isEqualToString:@"07"]) {
            [self.baudRate setTitle:self.baudRateArray[7] forState:UIControlStateNormal];
        }
        else if ([state isEqualToString:@"08"]) {
            [self.baudRate setTitle:self.baudRateArray[8] forState:UIControlStateNormal];
        }
        else if ([state isEqualToString:@"09"]) {
            [self.baudRate setTitle:self.baudRateArray[9] forState:UIControlStateNormal];
        }
        else if ([state isEqualToString:@"0A"]||[state isEqualToString:@"0a"]) {
            [self.baudRate setTitle:self.baudRateArray[10] forState:UIControlStateNormal];
        }
        else if ([state isEqualToString:@"0B"]||[state isEqualToString:@"0b"]) {
            [self.baudRate setTitle:self.baudRateArray[11] forState:UIControlStateNormal];
        }
        else if ([state isEqualToString:@"0C"]||[state isEqualToString:@"0c"]) {
            [self.baudRate setTitle:self.baudRateArray[12] forState:UIControlStateNormal];
        }
        else if ([state isEqualToString:@"0D"]||[state isEqualToString:@"0d"]) {
            [self.baudRate setTitle:self.baudRateArray[13] forState:UIControlStateNormal];
        }
        else if ([state isEqualToString:@"0E"]||[state isEqualToString:@"0e"]) {
            [self.baudRate setTitle:self.baudRateArray[14] forState:UIControlStateNormal];
        }
        else if ([state isEqualToString:@"0F"]||[state isEqualToString:@"0f"]) {
            [self.baudRate setTitle:self.baudRateArray[15] forState:UIControlStateNormal];
        }
    }
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"设备编辑";
    if ([self.device.type isEqualToString:@"数据透传模块"]) {
        self.propertyArray = @[@"电视/播放器/DVD",@"中央空调",@"背景音乐",@"自定义设备"];
    }
    self.baudRateArray = @[@"300",@"600",@"900",@"1200",@"2400",@"4800",@"9600",@"14400",@"19200",@"28800",@"38400",@"50000",@"57600",@"76800",@"100000",@"115200"];
    
    self.allRoom = [CYM_DatabaseTable getRoom];
    self.device.cmdArray = [NSMutableArray new];
    ControlDeviceContentValue *value = [CYM_DatabaseTable getDeviceDetailsWithDeviceName:self.device.name];
    self.device.cmdArray = value.keyArr;
    
    [self addLabelWithText:@"设备类型：" rect:CGRectMake(20, 80, 70, 20) isAdjustsFontSizeToFit:NO];
    [self addLabelWithText:@"设备名称：" rect:CGRectMake(20, 120, 70, 20) isAdjustsFontSizeToFit:NO];
    [self addLabelWithText:@"设备属性：" rect:CGRectMake(20, 160, 70, 20) isAdjustsFontSizeToFit:NO];
    [self addLabelWithText:@"房间选择：" rect:CGRectMake(20, 200, 70, 20) isAdjustsFontSizeToFit:NO];
    [self addLabelWithText:@"波特率选择：" rect:CGRectMake(20, 240, 100, 20) isAdjustsFontSizeToFit:NO];
    
    [self addLabelWithText:@"ID:" rect:CGRectMake(curScreenSize.width/2, 80, 20, 20) isAdjustsFontSizeToFit:NO];
    [self addLabelWithText:self.device.type rect:CGRectMake(90, 80, curScreenSize.width/2-100, 20) isAdjustsFontSizeToFit:YES];
    [self addLabelWithText:[cmdP getDeviceNumberWithCMD:self.device.ID] rect:CGRectMake(curScreenSize.width/2+20, 80, curScreenSize.width/2-20, 20) isAdjustsFontSizeToFit:YES];
    
    self.nameField = [[UITextField alloc]initWithFrame:CGRectMake(90, 115, curScreenSize.width-120, 30)];
    self.nameField.borderStyle = UITextBorderStyleRoundedRect;
    self.nameField.text = self.device.name;
    self.nameField.font = [UIFont systemFontOfSize:14];
    self.nameField.delegate = self;
    [self.view addSubview:self.nameField];
    
    self.property = [self addButtonWithText:self.device.property rect:CGRectMake(90,160,curScreenSize.width-130,20)];
    self.room = [self addButtonWithText:self.device.roomName rect:CGRectMake(90,200,curScreenSize.width-130,20)];
    self.baudRate = [self addButtonWithText:@"未知" rect:CGRectMake(120, 240, curScreenSize.width-160, 20)];
    [self.property addTarget:self action:@selector(choseProperty) forControlEvents:UIControlEventTouchUpInside];
    [self.room addTarget:self action:@selector(choseRoom) forControlEvents:UIControlEventTouchUpInside];
    [self.baudRate addTarget:self action:@selector(choseBaudRate) forControlEvents:UIControlEventTouchUpInside];
    
    
    UIButton *deleteButton = [[UIButton alloc]initWithFrame:CGRectMake(20, curScreenSize.height - 60, curScreenSize.width/2-30, 30)];
    deleteButton.layer.cornerRadius = 5;
    [deleteButton setBackgroundColor:[UIColor grayColor]];
    [deleteButton setTitle:@"删除设备" forState:UIControlStateNormal];
    [deleteButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [deleteButton addTarget:self action:@selector(deleteR) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:deleteButton];
    
    UIButton *aplayButton = [[UIButton alloc]initWithFrame:CGRectMake(curScreenSize.width/2+10, curScreenSize.height - 60, curScreenSize.width/2 - 30, 30)];
    aplayButton.layer.cornerRadius = 5;
    [aplayButton setBackgroundColor:[UIColor grayColor]];
    [aplayButton setTitle:@"保存设置" forState:UIControlStateNormal];
    [aplayButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [aplayButton addTarget:self action:@selector(aplayR) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:aplayButton];
    
    self.modiName = self.device.name;
    self.modiProperty = self.device.property;
    self.modiRoom = self.device.roomName;
    self.oldName = self.device.name;
    
    //新增
    [self addLabelWithText:@"指令" rect:CGRectMake(20, 280, 40, 20) isAdjustsFontSizeToFit:NO];
    self.CMDView = [[UITableView alloc]initWithFrame:CGRectMake(20, 300, curScreenSize.width - 40, curScreenSize.height - 240 - 120) style:UITableViewStylePlain];
    self.CMDView.tag = 1000;
    self.CMDView.delegate = self;
    self.CMDView.dataSource = self;
    self.CMDView.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    
    self.add = [self addButtonNoImageWithText:@"添加" rect:CGRectMake(20 + 40 + 20, 280, (curScreenSize.width - 60 - 80)/3, 20)];
    self.model = [self addButtonNoImageWithText:@"模板" rect:CGRectMake((curScreenSize.width - 60 - 80)/3 + 100, 280, (curScreenSize.width - 60 - 80)/3, 20)];
    self.clear = [self addButtonNoImageWithText:@"清空" rect:CGRectMake((curScreenSize.width - 60 - 80)*2/3 + 120, 280, (curScreenSize.width - 60 - 80)/3, 20)];
    
    [self.add addTarget:self action:@selector(addOrder) forControlEvents:UIControlEventTouchUpInside];
    [self.model addTarget:self action:@selector(modelOrder) forControlEvents:UIControlEventTouchUpInside];
    [self.clear addTarget:self action:@selector(clearOrder) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:self.CMDView];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reciveMsg:) name:@"baudRate" object:nil];
    
}
- (void)deleteR {
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:@"该操作会删除该设备，是否删除？" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    [alert show];
}
- (void)aplayR {
    if ([self.nameField.text isEqualToString:@""] || self.nameField.text == nil) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示:" message:@"名称不能为空" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
        [alert show];
        return;
    }
    NSLog(@"%@",self.nameField.text);
    for (DeviceSettingModel *model in self.allDevice) {
        if ([model.name isEqualToString:self.nameField.text] && ![self.nameField.text isEqualToString:self.modiName]) {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示:" message:@"名称已存在，请重新设置！" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
            [alert show];
            return;
        }
    }
    if ([self.modiProperty isEqualToString:@"未设置"]) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示:" message:@"请设置设备属性！" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
        [alert show];
        return;
    }
    if (self.device.isNewDevice == YES) {
        //清空数据，由于是新的设备，不会有重复名字的情况，大胆删除
        self.device.name = self.nameField.text;
        self.device.property = self.modiProperty;
        self.device.roomName = self.modiRoom;
        [CYM_DatabaseTable deleteDeviceFromDevice:self.device withOldName:self.oldName];
        //插入数据
        [CYM_DatabaseTable insertDevice:self.device];
        [self sendMsgFrom:self.baudRateStr];
        [self.navigationController popViewControllerAnimated:YES];
        return;
    }
    
    //    if (![self.nameField.text isEqualToString:self.device.name]) {
    [CYM_DatabaseTable modiOldName:self.device.name toNewName:self.nameField.text];//修改名字
    //    }
    self.device.name = self.nameField.text;
    //    if (![self.modiProperty isEqualToString:self.device.property]) {
    [CYM_DatabaseTable modiProperty:self.modiProperty withDevice:self.device withRoomName:self.modiRoom];//修改属性
    //    }
    self.device.property = self.modiProperty;
    //    if (![self.modiRoom isEqualToString:self.device.roomName]) {
    [CYM_DatabaseTable modiRoomName:self.modiRoom withDevice:self.device];//修改房间
    //    }
    
    //清空指令
    [CYM_DatabaseTable clearOrderWithDeviceValue:self.device];
    //修改指令
    [CYM_DatabaseTable saveKeys:self.device.cmdArray ToDevice:self.device];
    
    //发送波特率消息
    [self sendMsgFrom:self.baudRateStr];
    [self.navigationController popViewControllerAnimated:YES];
    
}
- (void)sendMsgFrom:(NSString *)baudRate {
    //发送波特率
    NSString *baud = self.baudRate.currentTitle;
    NSString *baudNumber = @"00";
    if ([baud isEqualToString:@"300"]) {
        baudNumber = @"00";
    }
    else if ([baud isEqualToString:@"600"]) {
        baudNumber = @"01";
    }
    else if ([baud isEqualToString:@"900"]) {
        baudNumber = @"02";
    }
    else if ([baud isEqualToString:@"1200"]) {
        baudNumber = @"03";
    }
    else if ([baud isEqualToString:@"2400"]) {
        baudNumber = @"04";
    }
    else if ([baud isEqualToString:@"4800"]) {
        baudNumber = @"05";
    }
    else if ([baud isEqualToString:@"9600"]) {
        baudNumber = @"06";
    }
    else if ([baud isEqualToString:@"14400"]) {
        baudNumber = @"07";
    }
    else if ([baud isEqualToString:@"19200"]) {
        baudNumber = @"08";
    }
    else if ([baud isEqualToString:@"28800"]) {
        baudNumber = @"09";
    }
    else if ([baud isEqualToString:@"38400"]) {
        baudNumber = @"0A";
    }
    else if ([baud isEqualToString:@"50000"]) {
        baudNumber = @"0B";
    }
    else if ([baud isEqualToString:@"57600"]) {
        baudNumber = @"0C";
    }
    else if ([baud isEqualToString:@"76800"]) {
        baudNumber = @"0D";
    }
    else if ([baud isEqualToString:@"100000"]) {
        baudNumber = @"0E";
    }
    else if ([baud isEqualToString:@"115200"]) {
        baudNumber = @"0F";
    }
    NSString *strData = [NSString stringWithFormat:@"%@00%@0000",[self.device.ID substringWithRange:NSMakeRange(12, 6)],baudNumber];
    NSString *cmd = [cmdB getCMDWithAction:A4_ACTION_CONFIG_CONFIG DeviceType:A4_DEVICE_UART Data:strData];
    NSString *msg = [msgB getMessageWithType:[self.device.com longLongValue] action:ACTION_TRANSMIT commond:cmd];
    [[HE_APPManager sharedManager] SendMsg:msg withNameSpace:@"control" isShowLoading:NO];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (alertView.tag == 100 && buttonIndex == 1) {
        [CYM_DatabaseTable clearOrderWithDeviceValue:self.device];
        [self.device.cmdArray removeAllObjects];
        [self.CMDView reloadData];
        return;
    }
    if (buttonIndex == 1) {
        
        if (self.topTableView) {
            UITextField *nameField = [alertView textFieldAtIndex:0];
            if ([nameField.text isEqualToString:@""] || nameField.text == nil) {
                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示:" message:@"名称不能为空" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
                [alert show];
                return;
            }
            NSLog(@"%@",nameField.text);
            for (Room *room in self.allRoom) {
                if ([room.name isEqualToString:nameField.text]) {
                    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示:" message:@"名称已存在，请重新添加！" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
                    [alert show];
                    return;
                }
            }
            [nameField resignFirstResponder];
            Room *room = [Room new];
            room.name = nameField.text;
            room.prio = @"FFFFFFFFFFFFF";
            room.ID = [CYM_DatabaseTable GenerateGUID];
            [Room insertRomm:room];
            [self.allRoom addObject:room];
            [self.topTableView reloadData];
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示:" message:[NSString stringWithFormat:@"房间：%@  添加成功！",nameField.text] delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
            
            [self updateRoomJSON];
            
            [alert show];
            return;
        }
        
        [CYM_DatabaseTable deleteDeviceFromDevice:self.device withOldName:self.oldName];
        
        //如果是新设备，需要从新设备数组中移除
        if (self.device.isNewDevice == YES) {
            [self.allDevice removeObject:self.device];
            [appManager.deviceNewArray removeObject:self.device];
        }
        
        [self.navigationController popViewControllerAnimated:YES];
    }else {
        UITextField *nameField = [alertView textFieldAtIndex:0];
        [nameField resignFirstResponder];
    }
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    self.tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(closeKeyboard)];
    [self.view addGestureRecognizer:self.tap];
}
- (void)closeKeyboard {
    [self.view removeGestureRecognizer:self.tap];
    [self.nameField resignFirstResponder];
    self.tap = nil;
}

- (void)addLabelWithText:(NSString *)text rect:(CGRect)rect isAdjustsFontSizeToFit:(BOOL)adjust{
    UILabel *label = [[UILabel alloc]initWithFrame:rect];
    label.text = text;
    label.font = [UIFont systemFontOfSize:14];
    label.textColor = [UIColor blackColor];
    label.textAlignment = NSTextAlignmentLeft;
    label.adjustsFontSizeToFitWidth = adjust;
    [self.view addSubview:label];
}
- (UIButton *)addButtonNoImageWithText:(NSString *)text rect:(CGRect)rect {
    UIButton *button = [[UIButton alloc]initWithFrame:rect];
    [button setTitle:text forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:14];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    button.layer.cornerRadius = 5;
    button.layer.borderWidth = 1;
    button.layer.borderColor = [UIColor blackColor].CGColor;
    [self.view addSubview:button];
    return button;
}
- (UIButton *)addButtonWithText:(NSString *)text rect:(CGRect)rect{
    UIButton *button = [[UIButton alloc]initWithFrame:rect];
    [button setTitle:text forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:14];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    UIImageView *image = [[UIImageView alloc]initWithFrame:CGRectMake(rect.size.width - rect.size.height, 0, rect.size.height, rect.size.height)];
    image.image = [UIImage imageNamed:@"arrowicon.png"];
    [button addSubview:image];
    [self.view addSubview:button];
    return button;
}
- (void)choseProperty {
    self.topView = [self addTopViewWithType:@"property"];
}
- (void)choseRoom {
    self.topView = [self addTopViewWithType:@"room"];
}
- (void)choseBaudRate {
    self.topView = [self addTopViewWithType:@"baudRate"];
}
- (UIView *)addTopViewWithType:(NSString *)type {
    
    [self closeKeyboard];
    
    UIView *view = [[UIView alloc]initWithFrame:self.view.frame];
    view.backgroundColor = [UIColor colorWithRed:10/255.0 green:10/255.0 blue:10/255.0 alpha:0.5];
    self.tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(back:)];
    UIView *tapView = [[UIView alloc]initWithFrame:view.bounds];
    tapView.backgroundColor = [UIColor clearColor];
    [view addSubview:tapView];
    [tapView addGestureRecognizer:self.tap];
    [self.view addSubview:view];
    
    UITableView *tableView = [[UITableView alloc]initWithFrame:CGRectMake(curScreenSize.width/4, curScreenSize.height/4, curScreenSize.width/2, curScreenSize.height/2) style:UITableViewStylePlain];
    if ([type isEqualToString:@"property"]) {
        tableView.tag = 1;
    }
    if ([type isEqualToString:@"room"]) {
        tableView.tag = 2;
        UIButton *addRoom = [[UIButton alloc]initWithFrame:CGRectMake(curScreenSize.width/4, curScreenSize.height/4+curScreenSize.height/2, curScreenSize.width/2, 40)];
        [addRoom setTitle:@"添加房间" forState:UIControlStateNormal];
        [addRoom setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        addRoom.backgroundColor = [UIColor whiteColor];
        [addRoom addTarget:self action:@selector(addRoom) forControlEvents:UIControlEventTouchUpInside];
        self.topTableView = tableView;
        [view addSubview:addRoom];
    }
    if ([type isEqualToString:@"baudRate"]) {
        tableView.tag = 3;
    }
    if ([type isEqualToString:@"addModel"]) {
        tableView.tag = 4;
    }
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    [view addSubview:tableView];
    
    return view;
}
- (void)addRoom {
    UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:nil message:@"请输入房间名称：" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确认", nil];
    alertView.alertViewStyle = UIAlertViewStylePlainTextInput;
    UITextField *nameField = [alertView textFieldAtIndex:0];
    nameField.placeholder = @"请输入名称:";
    [alertView show];
}

- (void)updateRoomJSON {
    //上传room.json文件
    NSData *roomOld = [CYM_Engine generateJSONFileWithName:@"room.json"];
    [appManager uploadFileWithName:@"room.json" andData:roomOld isShowHUD:NO];
}
- (void)back:(UITapGestureRecognizer *)tap {
    self.tap = nil;
    self.topTableView = nil;
    [self.topView removeFromSuperview];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (tableView.tag == 1) {
        return self.propertyArray.count;
    }
    else if (tableView.tag == 2) {
        return self.allRoom.count;
    }
    //新增
    else if (tableView.tag == 3) {
        return self.baudRateArray.count;
    }
    else if (tableView.tag == 4) {
        return self.modelArray.count;
    }
    else if (tableView.tag == 1000) {
        return self.device.cmdArray.count;
    }
    else
        return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    if (tableView.tag == 1) {
        cell.textLabel.text = self.propertyArray[indexPath.row];
        cell.textLabel.textColor = [UIColor blackColor];
    }
    else if (tableView.tag == 2) {
        cell.textLabel.text = ((Room*)self.allRoom[indexPath.row]).name;
        cell.textLabel.textColor = [UIColor blackColor];
    }
    else if (tableView.tag == 3) {
        cell.textLabel.text = self.baudRateArray[indexPath.row];
        cell.textLabel.textColor = [UIColor blackColor];
    }
    else if (tableView.tag == 4) {
        if (indexPath.row == 0) {
            cell.textLabel.text = @"背景音乐";
        }
        if (indexPath.row == 1) {
            cell.textLabel.text = @"大金中央空调";
        }
        
        cell.textLabel.textColor = [UIColor blackColor];
    }
    else if (tableView.tag == 1000) {
        ControlDeviceContentValueKey *key = self.device.cmdArray[indexPath.row];
        
        cell.textLabel.text = [NSString stringWithFormat:@"%@,%@,%@,%@,%@",key.name,key.value,key.query,key.backkey,key.time];
        cell.textLabel.adjustsFontSizeToFitWidth = YES;
    }
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (tableView.tag == 1000) {
        return 30;
    }
    return 44;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (tableView.tag == 1 && indexPath.row<self.propertyArray.count) {
        self.modiProperty = self.propertyArray[indexPath.row];
        [self.property setTitle:self.modiProperty forState:UIControlStateNormal];
        [self back:nil];
    }
    else if (tableView.tag == 2 && indexPath.row < self.allRoom.count) {
        //        if (indexPath.row == self.allRoom.count) {
        //            //特殊处理
        //            self.modiRoom = @"不设置";
        //            [self.room setTitle:@"未设置" forState:UIControlStateNormal];
        //            [self back:nil];
        //        }
        //        else {
        self.modiRoom = ((Room*)self.allRoom[indexPath.row]).name;
        [self.room setTitle:((Room*)self.allRoom[indexPath.row]).name forState:UIControlStateNormal];
        [self back:nil];
        //        }
    }
    else if (tableView.tag == 3 && indexPath.row < self.baudRateArray.count) {
        self.baudRateStr = self.baudRateArray[indexPath.row];
        [self.baudRate setTitle:self.baudRateStr forState:UIControlStateNormal];
        [self back:nil];
    }
    else if (tableView.tag == 4 && indexPath.row < self.modelArray.count) {
        //刷新指令列表
        self.device.cmdArray = self.modelArray[indexPath.row];
        [self.CMDView reloadData];
        [self back:nil];
    }
    else if (tableView.tag == 1000 && indexPath.row < self.device.cmdArray.count) {
        AddOrderVC *vc = [AddOrderVC new];
        vc.cmdArray = self.device.cmdArray;
        vc.currentKey = self.device.cmdArray[indexPath.row];
        [self.navigationController pushViewController:vc animated:YES];
    }
}
- (void)addOrder {
    AddOrderVC *vc = [AddOrderVC new];
    vc.cmdArray = self.device.cmdArray;
    [self.navigationController pushViewController:vc animated:YES];
}
- (void)modelOrder {
    self.topView = [self addTopViewWithType:@"addModel"];
}
- (void)clearOrder {
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示：" message:@"该操作会清空指令，是否清空？" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确认", nil];
    alert.tag = 100;
    [alert show];
    
}
@end
