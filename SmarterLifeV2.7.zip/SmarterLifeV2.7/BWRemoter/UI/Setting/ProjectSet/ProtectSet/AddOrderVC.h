//
//  AddOrderVC.h
//  BWRemoter
//
//  Created by baiwei－mac on 16/1/18.
//  Copyright © 2016年 ReSun. All rights reserved.
//

#import "HE_BaseViewController.h"
#import "DeviceSettingModel.h"

@interface AddOrderVC : HE_BaseViewController

@property (nonatomic,strong) NSMutableArray *cmdArray;
@property (nonatomic,strong) ControlDeviceContentValueKey *currentKey;

@end
