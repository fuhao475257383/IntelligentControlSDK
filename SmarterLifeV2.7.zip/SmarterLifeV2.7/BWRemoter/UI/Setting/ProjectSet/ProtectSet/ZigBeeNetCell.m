//
//  ZigBeeNetCell.m
//  BWRemoter
//
//  Created by baiwei－mac on 16/1/8.
//  Copyright © 2016年 ReSun. All rights reserved.
//

#import "ZigBeeNetCell.h"

@implementation ZigBeeNetCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.accessoryType = UITableViewCellAccessoryDetailButton;
        
        self.number = [[UILabel alloc]initWithFrame:CGRectMake(20, 20, 30, 20)];
        self.type = [[UILabel alloc]initWithFrame:CGRectMake(50, 10, self.frame.size.width/2-50, 20)];
        self.name = [[UILabel alloc]initWithFrame:CGRectMake(self.frame.size.width/2, 10, self.frame.size.width/2-60, 20)];
        self.ID = [[UILabel alloc]initWithFrame:CGRectMake(50, 30, (self.frame.size.width * 4 / 5 - 30)/2, 20)];
        self.room = [[UILabel alloc]initWithFrame:CGRectMake(50 + (self.frame.size.width * 4 / 5 - 60)/2, 30, (self.frame.size.width * 4 / 5 - 30)/2, 20)];
        self.number.text = @"空";
        self.number.font = [UIFont systemFontOfSize:15];
        self.number.textAlignment = NSTextAlignmentCenter;
        self.number.adjustsFontSizeToFitWidth = YES;
        self.type.text = @"空";
        self.type.font = [UIFont systemFontOfSize:14];
        self.type.textAlignment = NSTextAlignmentLeft;
        self.type.adjustsFontSizeToFitWidth = YES;
        self.name.text = @"空";
        self.name.font = [UIFont systemFontOfSize:14];
        self.name.textAlignment = NSTextAlignmentLeft;
        self.name.adjustsFontSizeToFitWidth = YES;
        self.ID.text = @"空";
        self.ID.font = [UIFont systemFontOfSize:13];
        self.ID.textAlignment = NSTextAlignmentLeft;
        self.ID.adjustsFontSizeToFitWidth = YES;
        self.room.text = @"空";
        self.room.font = [UIFont systemFontOfSize:13];
        self.room.textAlignment = NSTextAlignmentLeft;
        self.room.adjustsFontSizeToFitWidth = YES;
        
        [self addSubview:self.number];
        [self addSubview:self.type];
        [self addSubview:self.name];
        [self addSubview:self.ID];
        [self addSubview:self.room];
    }
    return self;
}
@end
