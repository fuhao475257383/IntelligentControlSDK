//
//  AddOrderVC.m
//  BWRemoter
//
//  Created by baiwei－mac on 16/1/18.
//  Copyright © 2016年 ReSun. All rights reserved.
//

#import "AddOrderVC.h"

@interface AddOrderVC ()

//名称
@property (nonatomic,strong) UITextField *name;
//控制
@property (nonatomic,strong) UITextField *control;
//查询
@property (nonatomic,strong) UITextField *find;
//反馈
@property (nonatomic,strong) UITextField *back;
//延时
@property (nonatomic,strong) UITextField *delay;
//手势
@property (nonatomic,strong) UITapGestureRecognizer *tap;

@end

@implementation AddOrderVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self addLabelWithText:@"指令名称：" rect:CGRectMake(20,84,70,20) isAdjustsFontSizeToFit:YES];
    [self addLabelWithText:@"控制命令：" rect:CGRectMake(20,124,70,20) isAdjustsFontSizeToFit:YES];
    [self addLabelWithText:@"查询命令：" rect:CGRectMake(20,164,70,20) isAdjustsFontSizeToFit:YES];
    [self addLabelWithText:@"反馈命令：" rect:CGRectMake(20,204,70,20) isAdjustsFontSizeToFit:YES];
    [self addLabelWithText:@"延时时间：" rect:CGRectMake(20,244,70,20) isAdjustsFontSizeToFit:YES];
    
    self.name = [self addTextFieldWithText:self.currentKey.name rect:CGRectMake(90,79,curScreenSize.width-110,30)];
    self.control = [self addTextFieldWithText:self.currentKey.value rect:CGRectMake(90,119,curScreenSize.width-110,30)];
    self.find = [self addTextFieldWithText:self.currentKey.query rect:CGRectMake(90,159,curScreenSize.width-110,30)];
    self.back = [self addTextFieldWithText:self.currentKey.backkey rect:CGRectMake(90,199,curScreenSize.width-110,30)];
    self.delay = [self addTextFieldWithText:self.currentKey.time rect:CGRectMake(90,239,curScreenSize.width-110,30)];
    
    
    UIButton *deleteButton = [[UIButton alloc]initWithFrame:CGRectMake(20, curScreenSize.height - 60, curScreenSize.width/2-30, 30)];
    deleteButton.layer.cornerRadius = 5;
    [deleteButton setBackgroundColor:[UIColor grayColor]];
    [deleteButton setTitle:@"删除指令" forState:UIControlStateNormal];
    [deleteButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [deleteButton addTarget:self action:@selector(deleteR) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:deleteButton];
    
    UIButton *aplayButton = [[UIButton alloc]initWithFrame:CGRectMake(curScreenSize.width/2+10, curScreenSize.height - 60, curScreenSize.width/2 - 30, 30)];
    aplayButton.layer.cornerRadius = 5;
    [aplayButton setBackgroundColor:[UIColor grayColor]];
    [aplayButton setTitle:@"保存指令" forState:UIControlStateNormal];
    [aplayButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [aplayButton addTarget:self action:@selector(aplayR) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:aplayButton];
    
}
- (void)deleteR {
    [self.cmdArray removeObject:self.currentKey];
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)aplayR {
    
    ControlDeviceContentValueKey *key = [ControlDeviceContentValueKey new];
    key.name = self.name.text?self.name.text:@"null";
    key.value = self.control.text?self.control.text:@"null";
    key.query = self.find.text?self.find.text:@"null";
    key.backkey = self.back.text?self.back.text:@"null";
    key.time = self.delay.text?self.delay.text:@"null";
    
    if (self.currentKey == nil) {
        [self.cmdArray addObject:key];
    }
    else {
        self.currentKey.name = self.name.text;
        self.currentKey.value = self.control.text;
        self.currentKey.query = self.find.text;
        self.currentKey.backkey = self.back.text;
        self.currentKey.time = self.delay.text;
    }
    [self.navigationController popViewControllerAnimated:YES];
    
}
- (void)addLabelWithText:(NSString *)text rect:(CGRect)rect isAdjustsFontSizeToFit:(BOOL)adjust{
    UILabel *label = [[UILabel alloc]initWithFrame:rect];
    label.text = text;
    label.font = [UIFont systemFontOfSize:14];
    label.textColor = [UIColor blackColor];
    label.textAlignment = NSTextAlignmentLeft;
    label.adjustsFontSizeToFitWidth = adjust;
    [self.view addSubview:label];
}
- (void)textFieldDidBeginEditing:(UITextField *)textField {
    self.tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(closeKeyBoard)];
    [self.view addGestureRecognizer:self.tap];
}
- (void)closeKeyBoard {
    self.tap = nil;
    [self.view endEditing:YES];
}
- (UITextField *)addTextFieldWithText:(NSString *)text rect:(CGRect)rect {
    UITextField *field = [[UITextField alloc]initWithFrame:rect];
    field.text = text;
    field.delegate = self;
    field.borderStyle = UITextBorderStyleRoundedRect;
    field.placeholder = @"请输入您要设定的值：";
    field.font = [UIFont systemFontOfSize:14];
    [self.view addSubview:field];
    return field;
}
@end
