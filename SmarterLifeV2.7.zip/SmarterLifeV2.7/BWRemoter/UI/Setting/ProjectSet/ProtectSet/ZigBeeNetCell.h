//
//  ZigBeeNetCell.h
//  BWRemoter
//
//  Created by baiwei－mac on 16/1/8.
//  Copyright © 2016年 ReSun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZigBeeNetCell : UITableViewCell

//编号
@property (nonatomic,strong) UILabel *number;
//设备类型
@property (nonatomic,strong) UILabel *type;
//设备名称
@property (nonatomic,strong) UILabel *name;
//设备ID
@property (nonatomic,strong) UILabel *ID;
//room
@property (nonatomic,strong) UILabel *room;


@end
