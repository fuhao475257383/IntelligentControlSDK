//
//  Project2.m
//  BWRemoter
//
//  Created by baiwei－mac on 16/1/8.
//  Copyright © 2016年 ReSun. All rights reserved.
//

#import "Project2.h"
#import "ZigBeeNetworking.h"
#import "RoomSetting.h"

@interface Project2 () <UITableViewDelegate,UITableViewDataSource>

@end

@implementation Project2

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"自组网设置";
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, curScreenSize.width, curScreenSize.height)];
    [self.view addSubview:view];
    UITableView *tableView = [[UITableView alloc]initWithFrame:view.bounds style:UITableViewStylePlain];
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    [view addSubview:tableView];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 2;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 80;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    if (indexPath.row == 0) {
        cell.textLabel.text = @"ZigBee组网";
    }
    if (indexPath.row == 1) {
        cell.textLabel.text = @"房间设置";
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (indexPath.row == 0) {
        ZigBeeNetworking *zigBee = [[ZigBeeNetworking alloc]init];
        [self.navigationController pushViewController:zigBee animated:YES];
    }
    if (indexPath.row == 1) {
        RoomSetting *roomSetting = [[RoomSetting alloc]init];
        [self.navigationController pushViewController:roomSetting animated:YES];
    }
}
- (void)dealloc {
    [[HE_APPManager sharedManager] reloadRoom];
    [[NSNotificationCenter defaultCenter]postNotificationName:@"ROOM_UPDATE" object:self];
}
@end
