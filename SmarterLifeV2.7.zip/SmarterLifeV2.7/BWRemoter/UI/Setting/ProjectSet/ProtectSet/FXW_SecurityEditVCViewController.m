//
//  FXW_SecurityEditVCViewController.m
//  BWRemoter
//
//  Created by 6602_Loop on 15-2-9.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "FXW_SecurityEditVCViewController.h"
//#define TABLE_HEIGHT zone.sensorArr.count*50>curScreenSize.height*0.5?curScreenSize.height*0.5:zone.sensorArr.count*50+70
#define TABLE_HEIGHT 200
@interface FXW_SecurityEditVCViewController (){
    
    UIScrollView *mainView;
    
    UIButton *btnAddSensor;
    UILabel *labTime;
    UILabel *labSec;
    UIButton *btnCancel;
    UIButton *btnSave;
    UIButton *btnDelete;
}
@end

@implementation FXW_SecurityEditVCViewController
@synthesize zone;
@synthesize table;
@synthesize index;
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    zone = [CYM_Engine getZoneContentInfo][index];
    [self setTitle:zone.name];
    [txtTime setText:zone.delay];
    [table reloadData];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    mainView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, curScreenSize.width, curScreenSize.height)];
    
    if(!zone){
        zone = [CYM_Engine getZoneContentInfo][index];
    }
    table = [[UITableView alloc]initWithFrame:CGRectMake(curScreenSize.width*0.1,20, curScreenSize.width*0.8,TABLE_HEIGHT)];
    table.separatorStyle=NO;
    table.delegate = self;
    table.dataSource = self;
    
    
    btnAddSensor = [UIButton buttonWithType:UIButtonTypeSystem];
    [btnAddSensor setFrame:CGRectMake(table.frameX, table.frameSumY_H+10, table.frameW, 35)];
    btnAddSensor.layer.borderWidth = 1.0f;
    btnAddSensor.layer.borderColor = [[UIColor colorWithRed:170/255.0f green:170/255.0f blue:170/255.0f alpha:1]CGColor];
    [btnAddSensor setTitle:@"+" forState:UIControlStateNormal];
    [btnAddSensor setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    btnAddSensor.layer.cornerRadius = 5.0f;
    [btnAddSensor.titleLabel setTextAlignment:NSTextAlignmentCenter];
    [btnAddSensor.titleLabel setFont:[UIFont boldSystemFontOfSize:30]];
    btnAddSensor.tag = 100;
    [btnAddSensor addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    
    
    labTime= [[UILabel alloc]initWithFrame:CGRectMake(table.frameX, btnAddSensor.frameSumY_H+10, curScreenSize.height*0.4, 30)];
    [labTime setText:@"延时生效时间:"];
    [labTime setTextAlignment:NSTextAlignmentLeft];
    [labTime setFont:[UIFont boldSystemFontOfSize:18]];
    
    
    txtTime= [[UITextField alloc] initWithFrame:CGRectMake(curScreenSize.width*0.5,btnAddSensor.frameSumY_H+10,80, 30)];
    [txtTime setReturnKeyType:UIReturnKeyDone];
    txtTime.delegate = self;
    [txtTime setKeyboardType:UIKeyboardTypeNumbersAndPunctuation];
    txtTime.borderStyle=UITextBorderStyleLine;
    txtTime.clearButtonMode=UITextFieldViewModeWhileEditing;
    
    
    labSec = [[UILabel alloc] initWithFrame:CGRectMake(txtTime.frameSumX_W+10, txtTime.frameY, 30, 30)];
    [labSec setText:@"秒"];
    [labSec setFont:[UIFont boldSystemFontOfSize:18]];
    
    
    btnCancel = [UIButton buttonWithType:UIButtonTypeSystem];
    [btnCancel setFrame:CGRectMake(curScreenSize.width*0.2, labTime.frameSumY_H+50, 70, 30)];
    [btnCancel setBackgroundColor:[UIColor colorWithRed:150/255.0f green:150/255.0f blue:150/255.0f alpha:1]];
    [btnCancel setTitle:@"取消" forState:UIControlStateNormal];
    [btnCancel setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    btnCancel.tag = 200;
    [btnCancel addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    btnCancel.layer.cornerRadius = 5.0f;
    
    
    btnSave = [UIButton buttonWithType:UIButtonTypeSystem];
    [btnSave setFrame:CGRectMake(curScreenSize.width*0.65, labTime.frameSumY_H+50, 70, 30)];
    [btnSave setBackgroundColor:[UIColor colorWithRed:150/255.0f green:150/255.0f blue:150/255.0f alpha:1]];
    [btnSave setTitle:@"保存" forState:UIControlStateNormal];
    [btnSave setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    btnSave.tag = 300;
    [btnSave addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    btnSave.layer.cornerRadius = 5.0f;
    
    
    btnDelete = [UIButton buttonWithType:UIButtonTypeSystem];
    [btnDelete setFrame:CGRectMake(curScreenSize.width*0.2, btnCancel.frameSumY_H+30, curScreenSize.width*0.6, 30)];
    btnDelete.layer.borderWidth = 1;
    btnDelete.layer.borderColor = [[UIColor colorWithRed:150/255.0f green:150/255.0f blue:150/255.0f alpha:1] CGColor];
    [btnDelete setTitle:@"删除防区" forState:UIControlStateNormal];
    [btnDelete.titleLabel setFont:[UIFont boldSystemFontOfSize:18]];
    [btnDelete setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    btnDelete.tag = 400;
    btnDelete.layer.cornerRadius = 5.0f;
    [btnDelete addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    
    [mainView addSubview:table];
    [mainView addSubview:btnAddSensor];
    [mainView addSubview:labTime];
    [mainView addSubview:txtTime];
    [mainView addSubview:labSec];
    [mainView addSubview:btnCancel];
    [mainView addSubview:btnSave];
    [mainView addSubview:btnDelete];
    mainView.contentSize = CGSizeMake(mainView.frameW, btnDelete.frameSumY_H);
    [self.view addSubview:mainView];
}
#pragma mark tableDatasourse
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell= [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    if (cell==nil) {
        cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"qe"];
    }
    UILabel *labName=[[UILabel alloc]initWithFrame:CGRectMake(0, 10,100, 30)];
    [cell addSubview:labName];
    [labName setTextAlignment:NSTextAlignmentCenter];
    [labName setText:((SecurityContent_zone_sensor *)zone.sensorArr[indexPath.row]).name];
    labName.layer.borderWidth= 1.0f;
    labName.layer.cornerRadius = 5.0f;
    [labName setFont:[UIFont boldSystemFontOfSize:18]];
    labName.layer.borderColor = [[UIColor colorWithRed:170/255.0f green:170/255.0f blue:170/255.0f alpha:1]CGColor];
    UIButton *btnSwitch = [[UIButton alloc]initWithFrame:CGRectMake(cell.frameW*0.55, 5, 80, 40)];
    btnSwitch.tag = 1000+indexPath.row;
    [btnSwitch addTarget:self action:@selector(btnSwitch:) forControlEvents:UIControlEventTouchUpInside];
    if([((SecurityContent_zone_sensor *)zone.sensorArr[indexPath.row]).state isEqualToString:@"0"]){
        [btnSwitch setImage:[UIImage imageNamed:@"safe_off_icon.png"] forState:UIControlStateNormal];
    }
    else{
        [btnSwitch setImage:[UIImage imageNamed:@"safe_on_icon.png"] forState:UIControlStateNormal];
    }
    [cell addSubview:btnSwitch];
    cell.selectionStyle= UITableViewCellSelectionStyleNone;
    return cell;
}
-(void)btnSwitch:(id)sender{
    UIButton *btntmp = (UIButton *)sender;
    if([((SecurityContent_zone_sensor *)zone.sensorArr[btntmp.tag-1000]).state isEqualToString:@"0"]){
        [btntmp setImage:[UIImage imageNamed:@"safe_on_icon.png"] forState:UIControlStateNormal];
        ((SecurityContent_zone_sensor *)zone.sensorArr[btntmp.tag-1000]).state = @"1";
    }
    else{
        [btntmp setImage:[UIImage imageNamed:@"safe_off_icon.png"] forState:UIControlStateNormal];
        ((SecurityContent_zone_sensor *)zone.sensorArr[btntmp.tag-1000]).state = @"0";
    }
}


-(void)btnClick:(id)sender{
    switch (((UIButton *)sender).tag) {
        case 100:{//＋号按钮
            FXW_alertView *alert = [[FXW_alertView alloc]initWithFrame:self.view.frame Delegate:self Datasourse:self];
            [alert setZone:zone];
            [self.view addSubview:alert];
            //绑定数据
            [alert setContent:defineArea andTitle:self.title];
        }
            break;
        case 200:{//取消按钮
            [self.navigationController popViewControllerAnimated:YES];
        }
            break;
        case 300:{//保存按钮
            if(![txtTime.text isEqualToString:@""]){
                zone.delay = txtTime.text;
                //先删掉原来的防区
//                [CYM_Engine deleteZoneIndfoByzoneId:zone.ID];
                //再把写新的防区进去
                [CYM_Engine updateZoneSet:zone];
                [self generateJSONFileAndUpload];
                [self.navigationController popViewControllerAnimated:YES];
            }
            else{
                [appManager hudShowMsg:@"延时时间不能为空" andInterval:1.5];
            }

        }
            break;
        case 400:{//删除防区
            UIAlertView *alert=  [[UIAlertView alloc]initWithTitle:@"提示" message:[NSString stringWithFormat:@"%@",zone.name] delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
            [alert show];

        }
            break;
        default:
            break;
    }
}


-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(buttonIndex==1){
        if([CYM_Engine deleteZoneIndfoByzoneId:zone.ID]){
            [self generateJSONFileAndUpload];
            [self.navigationController popViewControllerAnimated:YES];
        }
    }
}
#pragma mark alert 保存
-(BOOL)saveDefineArea{
    if(table){
        [UIView animateWithDuration:0.5 animations:^(void){
//            [table setFrame:CGRectMake(curScreenSize.width*0.1,20, curScreenSize.width*0.8,TABLE_HEIGHT)];
//            [btnAddSensor setFrame:CGRectMake(table.frameX, table.frameSumY_H+10, table.frameW, 35)];
//            [labTime setFrame:CGRectMake(table.frameX, btnAddSensor.frameSumY_H+10, curScreenSize.height*0.4, 30)];
//            [txtTime setFrame:CGRectMake(curScreenSize.width*0.5,btnAddSensor.frameSumY_H+10,80, 30)];
//            [labSec setFrame:CGRectMake(txtTime.frameSumX_W+10, txtTime.frameY, 30, 30)];
//            [btnCancel setFrame:CGRectMake(curScreenSize.width*0.2, labTime.frameSumY_H+50, 70, 30)];
//            [btnSave setFrame:CGRectMake(curScreenSize.width*0.65, labTime.frameSumY_H+50, 70, 30)];
//            [btnDelete setFrame:CGRectMake(curScreenSize.width*0.2, btnCancel.frameSumY_H+30, curScreenSize.width*0.6, 30)];
        }];
      //  NSLog(@"%f",TABLE_HEIGHT);
    }
    [table reloadData];
    return YES;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSLog(@"%lu",(unsigned long)zone.sensorArr.count);
    return zone.sensorArr.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 50;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)generateJSONFileAndUpload{
    //1.根据数据库生成JSON文件
    //2.上传JSON文件
    //3.上传成功->更新本地信息、 否则下载服务器文件更新本地数据库
    NSData *cronData = [CYM_Engine generateJSONFileWithName:@"security.json"];
    [[HE_APPManager sharedManager] uploadFileWithName:@"security.json" andData:cronData isShowHUD:YES];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
