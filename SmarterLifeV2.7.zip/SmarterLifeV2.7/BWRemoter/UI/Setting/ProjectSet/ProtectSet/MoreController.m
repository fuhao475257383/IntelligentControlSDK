//
//  MoreController.m
//  BWRemoter
//
//  Created by baiwei－mac on 16/1/14.
//  Copyright © 2016年 ReSun. All rights reserved.
//

#import "MoreController.h"
#import "AddOrderVC.h"

@interface MoreController () <UITableViewDataSource,UITableViewDelegate,UIAlertViewDelegate>

@property (nonatomic,strong) UITextField *nameField;//名字
@property (nonatomic,strong) UITapGestureRecognizer *tap;
@property (nonatomic,strong) UIButton *property;//属性
@property (nonatomic,strong) UIButton *room;//房间
@property (nonatomic,strong) UIView *topView;
@property (nonatomic,strong) NSMutableArray *allRoom;//所有的房间
@property (nonatomic,strong) NSArray *propertyArray;//所有属性
@property (nonatomic,strong) NSString *modiProperty;//选择的属性
@property (nonatomic,strong) NSString *modiRoom;//选择的房间
@property (nonatomic,strong) NSString *modiName;//修改的名字
//新增
@property (nonatomic,strong) UITableView *CMDView;
@property (nonatomic, strong) UITableView *topTableView;
@property (nonatomic, copy) NSString *oldName;

@end

@implementation MoreController
- (NSMutableArray *)allDevice {
    if (!_allDevice) {
        _allDevice = [NSMutableArray new];
    }
    return _allDevice;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"设备编辑";
    if ([self.device.type isEqualToString:@"多功能控制器"]) {
        self.propertyArray = @[@"电源控制",@"单体空调",@"中央空调",@"电视/播放器/DVD",@"自定义设备"];
    }
    if ([self.device.type isEqualToString:@"空调控制器"]) {
        self.propertyArray = @[@"单体空调",@"中央空调",@"自定义设备"];
    }
    
    
    self.allRoom = [CYM_DatabaseTable getRoom];
    ControlDeviceContentValue *value = [CYM_DatabaseTable getDeviceDetailsWithDeviceName:self.device.name];
    self.device.cmdArray = value.keyArr;
    
    [self addLabelWithText:@"设备类型：" rect:CGRectMake(20, 80, 70, 20) isAdjustsFontSizeToFit:NO];
    [self addLabelWithText:@"设备名称：" rect:CGRectMake(20, 120, 70, 20) isAdjustsFontSizeToFit:NO];
    [self addLabelWithText:@"设备属性：" rect:CGRectMake(20, 160, 70, 20) isAdjustsFontSizeToFit:NO];
    [self addLabelWithText:@"房间选择：" rect:CGRectMake(20, 200, 70, 20) isAdjustsFontSizeToFit:NO];
    [self addLabelWithText:@"ID:" rect:CGRectMake(curScreenSize.width/2, 80, 20, 20) isAdjustsFontSizeToFit:NO];
    [self addLabelWithText:self.device.type rect:CGRectMake(90, 80, curScreenSize.width/2-100, 20) isAdjustsFontSizeToFit:YES];
    [self addLabelWithText:[cmdP getDeviceNumberWithCMD:self.device.ID] rect:CGRectMake(curScreenSize.width/2+20, 80, curScreenSize.width/2-20, 20) isAdjustsFontSizeToFit:YES];
    
    self.nameField = [[UITextField alloc]initWithFrame:CGRectMake(90, 115, curScreenSize.width-120, 30)];
    self.nameField.borderStyle = UITextBorderStyleRoundedRect;
    self.nameField.text = self.device.name;
    self.nameField.font = [UIFont systemFontOfSize:14];
    self.nameField.delegate = self;
    [self.view addSubview:self.nameField];
    
    self.property = [self addButtonWithText:self.device.property rect:CGRectMake(90,160,curScreenSize.width-130,20)];
    self.room = [self addButtonWithText:self.device.roomName rect:CGRectMake(90,200,curScreenSize.width-130,20)];
    [self.property addTarget:self action:@selector(choseProperty) forControlEvents:UIControlEventTouchUpInside];
    [self.room addTarget:self action:@selector(choseRoom) forControlEvents:UIControlEventTouchUpInside];
    
    
    UIButton *deleteButton = [[UIButton alloc]initWithFrame:CGRectMake(20, curScreenSize.height - 60, curScreenSize.width/2-30, 30)];
    deleteButton.layer.cornerRadius = 5;
    [deleteButton setBackgroundColor:[UIColor grayColor]];
    [deleteButton setTitle:@"删除设备" forState:UIControlStateNormal];
    [deleteButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [deleteButton addTarget:self action:@selector(deleteR) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:deleteButton];
    
    UIButton *aplayButton = [[UIButton alloc]initWithFrame:CGRectMake(curScreenSize.width/2+10, curScreenSize.height - 60, curScreenSize.width/2 - 30, 30)];
    aplayButton.layer.cornerRadius = 5;
    [aplayButton setBackgroundColor:[UIColor grayColor]];
    [aplayButton setTitle:@"保存设置" forState:UIControlStateNormal];
    [aplayButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [aplayButton addTarget:self action:@selector(aplayR) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:aplayButton];
    
    self.modiName = self.device.name;
    self.modiProperty = self.device.property;
    self.modiRoom = self.device.roomName;
    self.oldName = self.device.name;
    
    //新增
    [self addLabelWithText:@"指令" rect:CGRectMake(20, 240, 70, 20) isAdjustsFontSizeToFit:NO];
    self.CMDView = [[UITableView alloc]initWithFrame:CGRectMake(20, 260, curScreenSize.width - 40, curScreenSize.height - 240 - 80) style:UITableViewStylePlain];
    self.CMDView.tag = 1000;
    self.CMDView.delegate = self;
    self.CMDView.dataSource = self;
    self.CMDView.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    [self.view addSubview:self.CMDView];
    
}

- (void)deleteR {
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:@"该操作会删除该设备，是否删除？" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    [alert show];
}
- (void)aplayR {
    if ([self.nameField.text isEqualToString:@""] || self.nameField.text == nil) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示:" message:@"名称不能为空" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
        [alert show];
        return;
    }
    NSLog(@"%@",self.nameField.text);
    for (DeviceSettingModel *model in self.allDevice) {
        if ([model.name isEqualToString:self.nameField.text] && ![self.nameField.text isEqualToString:self.modiName]) {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示:" message:@"名称已存在，请重新设置！" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
            [alert show];
            return;
        }
    }
    if ([self.modiProperty isEqualToString:@"未设置"]) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示:" message:@"请设置设备属性！" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
        [alert show];
        return;
    }
    if (self.device.isNewDevice == YES) {
        //清空数据，由于是新的设备，不会有重复名字的情况，大胆删除
        self.device.name = self.nameField.text;
        self.device.property = self.modiProperty;
        self.device.roomName = self.modiRoom;
        [CYM_DatabaseTable deleteDeviceFromDevice:self.device withOldName:self.oldName];
        //插入数据
        [CYM_DatabaseTable insertDevice:self.device];
        [self.navigationController popViewControllerAnimated:YES];
        return;
    }
    
//    if (![self.nameField.text isEqualToString:self.device.name]) {
        [CYM_DatabaseTable modiOldName:self.device.name toNewName:self.nameField.text];//修改名字
//    }
    self.device.name = self.nameField.text;
//    if (![self.modiProperty isEqualToString:self.device.property]) {
        [CYM_DatabaseTable modiProperty:self.modiProperty withDevice:self.device withRoomName:self.modiRoom];//修改属性
//    }
    self.device.property = self.modiProperty;
//    if (![self.modiRoom isEqualToString:self.device.roomName]) {
        [CYM_DatabaseTable modiRoomName:self.modiRoom withDevice:self.device];//修改房间
//    }
    [self.navigationController popViewControllerAnimated:YES];
    
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 1) {
        
        if (self.topTableView) {
            UITextField *nameField = [alertView textFieldAtIndex:0];
            if ([nameField.text isEqualToString:@""] || nameField.text == nil) {
                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示:" message:@"名称不能为空" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
                [alert show];
                return;
            }
            NSLog(@"%@",nameField.text);
            for (Room *room in self.allRoom) {
                if ([room.name isEqualToString:nameField.text]) {
                    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示:" message:@"名称已存在，请重新添加！" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
                    [alert show];
                    return;
                }
            }
            [nameField resignFirstResponder];
            Room *room = [Room new];
            room.name = nameField.text;
            room.prio = @"FFFFFFFFFFFFF";
            room.ID = [CYM_DatabaseTable GenerateGUID];
            [Room insertRomm:room];
            [self.allRoom addObject:room];
            [self.topTableView reloadData];
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示:" message:[NSString stringWithFormat:@"房间：%@  添加成功！",nameField.text] delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
            
            [self updateRoomJSON];
            
            [alert show];
            return;
        }
        
        [CYM_DatabaseTable deleteDeviceFromDevice:self.device withOldName:self.device.name];
        
        //如果是新设备，需要从新设备数组中移除
        if (self.device.isNewDevice == YES) {
            [self.allDevice removeObject:self.device];
            [appManager.deviceNewArray removeObject:self.device];
        }
        
        [self.navigationController popViewControllerAnimated:YES];
    }else {
        UITextField *nameField = [alertView textFieldAtIndex:0];
        [nameField resignFirstResponder];
    }
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    self.tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(closeKeyboard)];
    [self.view addGestureRecognizer:self.tap];
}
- (void)closeKeyboard {
    [self.view removeGestureRecognizer:self.tap];
    [self.nameField resignFirstResponder];
    self.tap = nil;
}

- (void)addLabelWithText:(NSString *)text rect:(CGRect)rect isAdjustsFontSizeToFit:(BOOL)adjust{
    UILabel *label = [[UILabel alloc]initWithFrame:rect];
    label.text = text;
    label.font = [UIFont systemFontOfSize:14];
    label.textColor = [UIColor blackColor];
    label.textAlignment = NSTextAlignmentLeft;
    label.adjustsFontSizeToFitWidth = adjust;
    [self.view addSubview:label];
}

- (UIButton *)addButtonWithText:(NSString *)text rect:(CGRect)rect{
    UIButton *button = [[UIButton alloc]initWithFrame:rect];
    [button setTitle:text forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:14];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    UIImageView *image = [[UIImageView alloc]initWithFrame:CGRectMake(rect.size.width - rect.size.height, 0, rect.size.height, rect.size.height)];
    image.image = [UIImage imageNamed:@"arrowicon.png"];
    [button addSubview:image];
    [self.view addSubview:button];
    return button;
}
- (void)choseProperty {
    self.topView = [self addTopViewWithType:@"property"];
}
- (void)choseRoom {
    self.topView = [self addTopViewWithType:@"room"];
}
- (UIView *)addTopViewWithType:(NSString *)type {
    
    [self closeKeyboard];
    
    UIView *view = [[UIView alloc]initWithFrame:self.view.frame];
    view.backgroundColor = [UIColor colorWithRed:10/255.0 green:10/255.0 blue:10/255.0 alpha:0.5];
    self.tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(back:)];
    UIView *tapView = [[UIView alloc]initWithFrame:view.bounds];
    tapView.backgroundColor = [UIColor clearColor];
    [view addSubview:tapView];
    [tapView addGestureRecognizer:self.tap];
    [self.view addSubview:view];
    
    UITableView *tableView = [[UITableView alloc]initWithFrame:CGRectMake(curScreenSize.width/4, curScreenSize.height/4, curScreenSize.width/2, curScreenSize.height/2) style:UITableViewStylePlain];
    if ([type isEqualToString:@"property"]) {
        tableView.tag = 1;
    }
    if ([type isEqualToString:@"room"]) {
        tableView.tag = 2;
        UIButton *addRoom = [[UIButton alloc]initWithFrame:CGRectMake(curScreenSize.width/4, curScreenSize.height/4+curScreenSize.height/2, curScreenSize.width/2, 40)];
        [addRoom setTitle:@"添加房间" forState:UIControlStateNormal];
        [addRoom setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        addRoom.backgroundColor = [UIColor whiteColor];
        [addRoom addTarget:self action:@selector(addRoom) forControlEvents:UIControlEventTouchUpInside];
        self.topTableView = tableView;
        [view addSubview:addRoom];
    }
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    [view addSubview:tableView];
    
    return view;
}
- (void)addRoom {
    UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:nil message:@"请输入房间名称：" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确认", nil];
    alertView.alertViewStyle = UIAlertViewStylePlainTextInput;
    UITextField *nameField = [alertView textFieldAtIndex:0];
    nameField.placeholder = @"请输入名称:";
    [alertView show];
}

- (void)updateRoomJSON {
    //上传room.json文件
    NSData *roomOld = [CYM_Engine generateJSONFileWithName:@"room.json"];
    [appManager uploadFileWithName:@"room.json" andData:roomOld isShowHUD:NO];
}
- (void)back:(UITapGestureRecognizer *)tap {
    self.tap = nil;
    self.topTableView = nil;
    [self.topView removeFromSuperview];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (tableView.tag == 1) {
        return self.propertyArray.count;
    }
    else if (tableView.tag == 2) {
        return self.allRoom.count;
    }
    //新增
    else if (tableView.tag == 1000) {
        return self.device.cmdArray.count;
    }
    else
        return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    if (tableView.tag == 1) {
        cell.textLabel.text = self.propertyArray[indexPath.row];
        cell.textLabel.textColor = [UIColor blackColor];
    }
    else if (tableView.tag == 2) {
        //        if (indexPath.row == self.allRoom.count) {
        //            cell.textLabel.text = @"不设置";
        //            cell.textLabel.textColor = [UIColor redColor];
        //            return cell;
        //        }
        cell.textLabel.text = ((Room*)self.allRoom[indexPath.row]).name;
        cell.textLabel.textColor = [UIColor blackColor];
    }
    else if (tableView.tag == 1000) {
        ControlDeviceContentValueKey *key = self.device.cmdArray[indexPath.row];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.textLabel.text = [NSString stringWithFormat:@"%@,%@,%@,%@,%@",key.name,key.value,key.query,key.backkey,key.time];
        cell.textLabel.adjustsFontSizeToFitWidth = YES;
    }
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (tableView.tag == 1000) {
        return 30;
    }
    return 44;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (tableView.tag == 1 && indexPath.row<self.propertyArray.count) {
        self.modiProperty = self.propertyArray[indexPath.row];
        [self.property setTitle:self.modiProperty forState:UIControlStateNormal];
        [self back:nil];
    }
    else if (tableView.tag == 2 && indexPath.row < self.allRoom.count) {
        //        if (indexPath.row == self.allRoom.count) {
        //            //特殊处理
        //            self.modiRoom = @"不设置";
        //            [self.room setTitle:@"未设置" forState:UIControlStateNormal];
        //            [self back:nil];
        //        }
        //        else {
        self.modiRoom = ((Room*)self.allRoom[indexPath.row]).name;
        [self.room setTitle:((Room*)self.allRoom[indexPath.row]).name forState:UIControlStateNormal];
        [self back:nil];
        //        }
    }
    else if (tableView.tag == 1000 && indexPath.row < self.device.cmdArray.count) {
        AddOrderVC *vc = [AddOrderVC new];
        vc.cmdArray = self.device.cmdArray;
        vc.currentKey = self.device.cmdArray[indexPath.row];
        [self.navigationController pushViewController:vc animated:YES];
    }
}
@end

