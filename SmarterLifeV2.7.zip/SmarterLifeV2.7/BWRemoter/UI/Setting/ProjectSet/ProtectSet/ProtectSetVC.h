//
//  ProtectSetVC.h
//  BWRemoter
//
//  Created by wangbin on 14/12/6.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "HE_BaseViewController.h"
#import "FXW_alertView.h"
@interface ProtectSetVC : HE_BaseViewController<UITableViewDelegate,UITableViewDataSource,FXW_alertDelegate>
{
    NSArray *aryimgzone;
    NSMutableArray *aryZone;
    SecurityContent_zone *zone;
}
@property(nonatomic,retain) IBOutlet UITableView *table;

@end
