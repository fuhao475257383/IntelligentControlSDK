//
//  FXW_SecurityEditVCViewController.h
//  BWRemoter
//
//  Created by 6602_Loop on 15-2-9.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "HE_BaseViewController.h"
#import "FXW_AlertView.h"
@interface FXW_SecurityEditVCViewController: HE_BaseViewController<UITableViewDelegate,UITableViewDataSource,FXW_alertDelegate,UIAlertViewDelegate>
{
    UITextField *txtTime;
}
@property SecurityContent_zone *zone;
@property NSInteger index;
@property UITableView *table;
@end
