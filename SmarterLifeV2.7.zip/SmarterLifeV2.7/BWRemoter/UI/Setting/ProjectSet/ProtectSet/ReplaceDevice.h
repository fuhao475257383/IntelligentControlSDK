//
//  ReplaceDevice.h
//  BWRemoter
//
//  Created by baiwei－mac on 16/1/19.
//  Copyright © 2016年 ReSun. All rights reserved.
//

#import "HE_BaseViewController.h"

@interface ReplaceDevice : HE_BaseViewController

@property (nonatomic,strong) DeviceSettingModel *device;
@property (nonatomic,strong) NSMutableArray *allDevice;

@end
