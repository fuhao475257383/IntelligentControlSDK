//
//  ZigbeeAlarmVC.h
//  BWRemoter
//
//  Created by baiwei－mac on 16/1/14.
//  Copyright © 2016年 ReSun. All rights reserved.
//

#import "HE_BaseViewController.h"

@interface ZigbeeAlarmVC : HE_BaseViewController

@property (nonatomic,strong) DeviceSettingModel *device;//当前设备
@property (nonatomic,strong) NSMutableArray *allDevice;//所有设备，比较用

@end
