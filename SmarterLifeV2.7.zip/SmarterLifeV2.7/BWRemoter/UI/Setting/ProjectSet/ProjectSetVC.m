//
//  ProjectSetVC.m
//  BWRemoter
//
//  Created by wangbin on 14/12/6.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "ProjectSetVC.h"
#import "DeviceListVC.h"
#import "IOInputDeviceVC.h"
#import "ProtectSetVC.h"
#import "ViewSetVC.h"
#import "DoorLockSetVC.h"
#import "Project2.h"

@interface ProjectSetVC ()

@end

@implementation ProjectSetVC

@synthesize table;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    
    /********************当前页标题设置**********************/
    UINavigationItem *n = [self navigationItem];
    [n setTitle:@"工程设置"];
    //字体大小、颜色
    NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:
                                [UIColor blackColor],
                                NSForegroundColorAttributeName, nil];
    [self.navigationController.navigationBar setTitleTextAttributes:attributes];
    /******************************************************/

    
    
    table = [[UITableView alloc]initWithFrame:CGRectMake(0.0f, 10.0f, curScreenSize.width, curScreenSize.height-80.0f) style:UITableViewStylePlain];
    [table setBackgroundColor:[UIColor clearColor]];
    
//    //创建UINib对象、 该对象代表包含了ItemCell的Nib文件
//    UINib *nib = [UINib nibWithNibName:@"Cell" bundle:nil];
//    
//    //通过UINib 对象、注册相应的Nib文件
//    [[self table] registerNib:nib forCellReuseIdentifier:@"wb_Cell"];
    table.separatorInset = UIEdgeInsetsMake(0, 3, 0, 17);
    [table setDelegate:self];
    [table setDataSource:self];
    table.tableFooterView = [[UIView alloc] init];
    [self.view addSubview:table];
    
    //    UIButton *SetTime = [[UIButton alloc]initWithFrame:CGRectMake(curScreenSize.width*0.8, 70.0f, 30.0f, 30.0f)];
    //    [SetTime setBackgroundImage:[UIImage imageNamed:@"定时icon.png"] forState:UIControlStateNormal];
    //    [SetTime addTarget:self action:@selector(settimeclick:) forControlEvents:UIControlEventTouchUpInside];
    //    [self.view addSubview:SetTime];
}



#pragma mark - UITableViewDelegate And DataSourse
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if ([appManager getAppNetState] == NET_XMPP) {
        return 4;
    }
    return 5;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *cell= [tableView dequeueReusableCellWithIdentifier:@"wb_Cell"];
    
    if (cell==nil) {
        cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"qe"];
        //cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    }
    UIView *backView = [[UIView alloc] initWithFrame: CGRectMake(0.0f, 0.0f, curScreenSize.width, 90.0f)];
    //[backView setBackgroundColor:[UIColor colorWithRed:113.0f/255.0f green:191.0f/255.0f blue:89.0f/255.0 alpha:1]];
    //    [backView.layer setMasksToBounds:YES];
    //    [backView.layer setCornerRadius:5.0f];
    
    UILabel *ListName = [[UILabel alloc]initWithFrame:CGRectMake(curScreenSize.width*0.3, 25.0f, 100.0f, 30.0f)];
    if(indexPath.row == 0){
        [ListName setText:@"场景设置"];
    }else if(indexPath.row == 1){
        [ListName setText:@"防区设置"];
    }else if(indexPath.row == 2){
        [ListName setText:@"设备列表"];
    }else if(indexPath.row == 3){
        [ListName setText:@"I/O输入设备"];
    }
    if ([appManager getAppNetState] == NET_WAN_SOCKET && indexPath.row == 4) {
        [ListName setText:@"自组网设置"];
    }
    else{}
    [backView addSubview:ListName];
    
    
    UIImageView *logo = [[UIImageView alloc]initWithFrame:CGRectMake(curScreenSize.width*0.1, 17.0f, 40.0f, 40.0f)];
    if(indexPath.row == 0){
        [logo setImage:[UIImage imageNamed:@"scenomode.png"]];
    }else if(indexPath.row == 1){
        [logo setImage:[UIImage imageNamed:@"areaicon.png"]];
    }else if(indexPath.row == 2){
        [logo setImage:[UIImage imageNamed:@"devicesicon.png"]];
    }else if(indexPath.row == 3){
        [logo setImage:[UIImage imageNamed:@"io_icon.png"]];
    }
    if ([appManager getAppNetState] == NET_WAN_SOCKET && indexPath.row == 4) {
        [logo setImage:[UIImage imageNamed:@"projecticon.png"]];
    }
    
    else{}
    [backView addSubview:logo];
    
    
    UIImageView *rightgogo = [[UIImageView alloc] initWithFrame: CGRectMake(curScreenSize.width*0.8,30.0f, 20.0f, 20.0f)];
    [rightgogo setImage:[UIImage imageNamed:@"arrowicon.png"]];
    [backView addSubview:rightgogo];
    
    [cell addSubview:backView];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    [cell setAccessoryType:UITableViewCellAccessoryNone];
    //cell.backgroundColor = [UIColor colorWithRed:230/255.0 green:230/255.0 blue:230/255.0 alpha:1];
    [cell setBackgroundColor:[UIColor clearColor]];
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}
/*  点击事件 */
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    /* 跳转页面 */
    if(indexPath.row == 0){
        ViewSetVC *viewsetvc = [[ViewSetVC alloc] init];
        [self.navigationController pushViewController:viewsetvc animated:YES];
    }else if(indexPath.row == 1){
        ProtectSetVC *protectvc = [[ProtectSetVC alloc]init];
        [self.navigationController pushViewController:protectvc animated:YES];
    }else if(indexPath.row == 2){
        DeviceListVC *devicelistvc = [[DeviceListVC alloc]init];
        [self.navigationController pushViewController:devicelistvc animated:YES];
    }else if(indexPath.row == 3){
        IOInputDeviceVC *ioinputdevicevc = [[IOInputDeviceVC alloc]init];
        [self.navigationController pushViewController:ioinputdevicevc animated:YES];
    }
    if ([appManager getAppNetState] == NET_WAN_SOCKET && indexPath.row == 4) {
        Project2 *doorLockVC = [[Project2 alloc]init];
        [self.navigationController pushViewController:doorLockVC animated:YES];
    }
    else{
    }
}

-(void)btnBack:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
