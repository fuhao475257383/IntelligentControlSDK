//
//  HouseSetVC.m
//  BWRemoter
//
//  Created by wangbin on 14/12/7.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "HouseSetVC.h"
#import "HE_DLight.h"
#import "FXW_DChangeLight.h"
#import "FXW_Curtain.h"
#import "ImagesScrollView.h"
#import "WB_UIAlertView.h"
#import "FXW_Power.h"
#import "FXW_CommonDevice.h"
#import "DoorView.h"

@interface HouseSetVC ()
{
    UILabel *labHousename;
    NSMutableArray *imageArray;
    NSMutableArray *PicNameArray;
    ImagesScrollView *imageScrollView;

    UIScrollView *mainScrollView;
    UIScrollView *scrollDevice;//底部

    float x_view;///每个设备距左
    
    NSMutableArray *smallArray;//底部数组
    WB_UIAlertView *addAlert;
    UIAlertView *Alert;
    //下拉菜单
    UIActionSheet *myActionSheet;
    //图片2进制路径
    NSString *filePath;
    NSData *data;//图片2进制
    
    NSInteger curPageIndex;//房间号的索引
    NSInteger curTag;
    
    NSMutableArray *aryhouseDevice;
}

@end

@implementation HouseSetVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setTitle:@"房型设置"];
    //对房间照片数组的初始化
    imageArray = [NSMutableArray array];
    //对房间名称数组的初始化
    PicNameArray = [NSMutableArray array];
    //对底部房间的数据进行初始化
    smallArray = [NSMutableArray array];
    
    aryhouseDevice = [NSMutableArray array];

    aryDevice = [appManager aryRoom];
    deviceTag = 1;
    /////////////////////向左切换房间
    UIButton *btnHouseleft= [UIButton buttonWithType:UIButtonTypeCustom];
    [btnHouseleft setFrame:CGRectMake(curScreenSize.width*0.1-20, 10, 40, 40)];
    [btnHouseleft setImage:[UIImage imageNamed:@"house_left.png"] forState:UIControlStateNormal];
    [btnHouseleft addTarget:self action:@selector(TurnLeftClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btnHouseleft];

    /////////////////////向右切换房间
    UIButton *btnHouseright= [UIButton buttonWithType:UIButtonTypeCustom];
    [btnHouseright setFrame:CGRectMake(curScreenSize.width*0.9-20, 10, 40, 40)];
    [btnHouseright setImage:[UIImage imageNamed:@"house_right.png"] forState:UIControlStateNormal];
    [btnHouseright addTarget:self action:@selector(TurnRightClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btnHouseright];
    ///////////////////////房间名
    labHousename = [[UILabel alloc]initWithFrame:CGRectMake(btnHouseleft.frameSumX_W, 20,
                                                            btnHouseright.frameX-btnHouseleft.frameSumX_W, 20)];
    [labHousename setText:@"暂无任何房间"];
    [labHousename setTextAlignment:NSTextAlignmentCenter];
    [labHousename setFont:[UIFont boldSystemFontOfSize:16]];
    [self.view addSubview:labHousename];
    //////////////////////添加房间
    UIButton *btnAddhouse = [UIButton buttonWithType:UIButtonTypeSystem];
    [btnAddhouse setFrame:CGRectMake(curScreenSize.width*0.1, btnHouseleft.frameSumY_H+20, 80, 30)];
    [btnAddhouse setTitle:@"添加房间" forState:UIControlStateNormal];
    [btnAddhouse setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    btnAddhouse.layer.cornerRadius = 5.0f;
    btnAddhouse.layer.borderWidth = 1;
    btnAddhouse.layer.borderColor = [[UIColor colorWithRed:171/255.0f green:171/255.0f blue:171/255.0f alpha:1]CGColor];
    [btnAddhouse addTarget:self action:@selector(AddHouseClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btnAddhouse];
    //////////////////////删除房间
    UIButton *btnDeletehouse = [UIButton buttonWithType:UIButtonTypeSystem];
    [btnDeletehouse setFrame:CGRectMake(curScreenSize.width*0.9-80, btnHouseleft.frameSumY_H+20, 80, 30)];
    [btnDeletehouse setTitle:@"删除房间" forState:UIControlStateNormal];
    [btnDeletehouse setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    btnDeletehouse.layer.cornerRadius = 5.0f;
    btnDeletehouse.layer.borderWidth = 1;
    btnDeletehouse.layer.borderColor = [[UIColor colorWithRed:171/255.0f green:171/255.0f blue:171/255.0f alpha:1]CGColor];
    [btnDeletehouse addTarget:self action:@selector(DeleteHouseClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btnDeletehouse];
    
    
    mainScrollView= [[UIScrollView alloc] initWithFrame: CGRectMake(0.0f, btnAddhouse.frameSumY_H+20, curScreenSize.width, curScreenSize.width)];
    [mainScrollView setBackgroundColor:[UIColor grayColor]];
    [mainScrollView setShowsVerticalScrollIndicator: NO];
    [self.view addSubview: mainScrollView];
    //对房间大scrollview的定义与属性加载
    
    imageScrollView = [[ImagesScrollView alloc] initWith: CGRectMake(0.0f, 0.0f, curScreenSize.width, curScreenSize.width)
                                             ImagesArray: imageArray TitleArray: nil isURL: NO curPoint:0];
    [imageScrollView setTag:999999];
    [imageScrollView setDelegate:self];
    [mainScrollView addSubview:imageScrollView];
    
    
    ///底部向左按钮
    UIButton *btnDeviceleft= [UIButton buttonWithType:UIButtonTypeCustom];
    [btnDeviceleft setFrame:CGRectMake(curScreenSize.width*0.05,mainScrollView.frameSumY_H+20, 40, 40)];
    btnDeviceleft.layer.cornerRadius = 20;
    btnDeviceleft.layer.borderWidth = 1;
    btnDeviceleft.layer.borderColor = [[UIColor grayColor]CGColor];
    [btnDeviceleft setBackgroundColor:[UIColor colorWithRed:240/255.0f green:240/255.0f blue:240/255.0f alpha:1]];
    [btnDeviceleft setImage:[UIImage imageNamed:@"house_left.png"] forState:UIControlStateNormal];
    btnDeviceleft.tag = 10000;
    [btnDeviceleft addTarget:self action:@selector(scrollDeviceturn:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btnDeviceleft];
    
    ///底部向右按钮
    UIButton *btnDeviceright= [UIButton buttonWithType:UIButtonTypeCustom];
    [btnDeviceright setFrame:CGRectMake(curScreenSize.width*0.95-40, mainScrollView.frameSumY_H+20, 40, 40)];
    btnDeviceright.layer.cornerRadius = 20;
    btnDeviceright.layer.borderWidth = 1;
    btnDeviceright.layer.borderColor = [[UIColor grayColor]CGColor];
    [btnDeviceright setBackgroundColor:[UIColor colorWithRed:240/255.0f green:240/255.0f blue:240/255.0f alpha:1]];
    [btnDeviceright setImage:[UIImage imageNamed:@"house_right.png"] forState:UIControlStateNormal];
    btnDeviceright.tag = 20000;
    [btnDeviceright addTarget:self action:@selector(scrollDeviceturn:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btnDeviceright];
    ///////Device scrollView
    scrollDevice = [[UIScrollView alloc]initWithFrame:CGRectMake(btnDeviceleft.frameSumX_W+5, btnDeviceleft.frameY, curScreenSize.width*0.9-90, 40)];
    [self.view addSubview:scrollDevice];
    
    x_view = 0;
    /////////////////底部
    [self drawDevice];
    /////////////////趁还没有add上去，赶紧从smarllary里面copy下引用
    aryAllDevices = [NSArray arrayWithArray:smallArray];
    for(int i = 0;i<aryAllDevices.count;i++){
        HE_UIDevice *tmp = aryAllDevices[i];
        tmp.tag = 10000+i;
    }
    [scrollDevice setContentSize:CGSizeMake(x_view, 0)];
    [self dataBind];
    
    [((UIScrollView *)self.view) setContentSize:CGSizeMake(curScreenSize.width, scrollDevice.frameSumY_H + 10)];
}
/////编辑使用，查询所有房间的url并绑定数据
-(void)dataBind{
    NSMutableArray *aryhouse = [[NSMutableArray alloc]init];
    aryhouse = [CYM_Engine getALLHouseUrl];
    for(int i = 0;i<aryhouse.count;i++){
        House *tmphouse = (House *)aryhouse[i];
        NSString * doc = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
        data = [[NSData alloc]initWithContentsOfFile:[NSString stringWithFormat:@"%@%@",doc,tmphouse.houseImgUrl]];
        [PicNameArray addObject:tmphouse.houseName];
        [imageArray addObject:data];
        [imageScrollView AddImageView:imageArray];
        [labHousename setText:PicNameArray[curPageIndex]];
        data = nil;
        //////////////取得该房间内所有设备位置信息
        NSMutableArray *aryD = [[NSMutableArray alloc]init];
        aryD = [CYM_Engine getAllDevicelocationByhouseName:tmphouse.houseName];
        /////////////画到对应的房间当中
        ////1、取到在scrollDevice中的设备对象通过设备名字
        NSArray *tmparyD = [scrollDevice subviews];
        for(int j = 0;j<tmparyD.count;j++){
        //    HE_UIDevice *tmp = (HE_UIDevice *)tmparyD[j];
            for(int k = 0;k<aryD.count;k++){
                if([((HouseDevice *)aryD[k]).deviceName isEqualToString: ((HE_UIDevice *)tmparyD[j]).name]){
                    CGPoint point = CGPointMake(0, 0);
                    point.x = [((HouseDevice *)aryD[k]).pointX floatValue];
                    point.y = [((HouseDevice *)aryD[k]).pointY floatValue];
                    [self AddToBig:(HE_UIDevice *)tmparyD[j] andPoint:point];
                }
            }
        }
    }
}
-(void)drawDevice{
    for(int i = 0;i<aryDevice.count;i++){
        Room *tmproom = (Room *)aryDevice[i];
        for(int j = 0 ;j<tmproom.deviceArr.count;j++){
            RoomDevice *tmpRoomdevice = (RoomDevice *)tmproom.deviceArr[j];
            if([tmpRoomdevice.property isEqualToString:@"场景控制器"]){
                for(int k =0;k<tmpRoomdevice.contentArr.count;k++){
                    ControlDeviceContentValue *tmpUidevice = (ControlDeviceContentValue *)tmpRoomdevice.contentArr[k];
                    
                    /////////////////创建场景
                    FXW_CommonDevice *sceneMode = [[FXW_CommonDevice alloc]initWithFrame:CGRectMake(x_view, 2, 36, 36)];
                    x_view+=40;
                    sceneMode.name            = tmpUidevice.name;
                    sceneMode.prio            = tmpUidevice.prio;
                    sceneMode.property        = @"场景控制器";
                    sceneMode.category        = @"场景控制器";
                    sceneMode.isNeedQuery     = NO;
                    sceneMode.delegate        = self.navigationController;
                    sceneMode.backgroundColor = [UIColor clearColor];
                    sceneMode.aryScene        = @[tmpUidevice];
                    [sceneMode setBackimgName:@"senceicon.png" andTitle:tmpUidevice.name IsTapLink: true];
                    
                    [scrollDevice addSubview:sceneMode];
                    [smallArray addObject:sceneMode];
                    
                    UITapGestureRecognizer *tapDoubleClick = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(touchedSeletedView:)];
                    tapDoubleClick.numberOfTapsRequired = 2;
                    [sceneMode addGestureRecognizer:tapDoubleClick];
                    /////////////////
                }
            }
            else{
                for(int k =0;k<tmpRoomdevice.contentArr.count;k++){
                    ControlDeviceContentValue *tmpUidevice = (ControlDeviceContentValue *)tmpRoomdevice.contentArr[k];
                    if([tmpUidevice.property isEqualToString:@"非可调灯"]){
                        /////////////////创建非可调灯
                        HE_DLight *tmplight = [[HE_DLight alloc]initWithFrame:CGRectMake(x_view, 2, 36, 36)];
                        tmplight.isNeedQuery = NO;
                        x_view +=40;
                        [tmplight setAttrWithCtrlValue:tmpUidevice];
                        [appManager.aryActiveDevice addObject:tmplight];
                        tmplight.backgroundColor = [UIColor clearColor];
                        [scrollDevice addSubview:tmplight];
                        [smallArray addObject:tmplight];
                        ///add 手势
                        UITapGestureRecognizer *tapDoubleClick = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(touchedSeletedView:)];
                        tapDoubleClick.numberOfTapsRequired = 2;
                        [tmplight addGestureRecognizer:tapDoubleClick];
                        for (UIGestureRecognizer *g in tmplight.gestureRecognizers) {
                            [g requireGestureRecognizerToFail:tapDoubleClick];
                        }
                    }
                    else if([tmpUidevice.property isEqualToString:@"可调灯"]){
                        /////////////////创建可调灯
                        FXW_DChangeLight *tmpDlight = [[FXW_DChangeLight alloc]initWithFrame:CGRectMake(x_view, 2, 80, 36)];
                        x_view+=84;
                        [tmpDlight setName:tmpUidevice.name];
                        [appManager.aryActiveDevice addObject:tmpDlight];
                        [tmpDlight setIsNeedQuery:NO];
                        [tmpDlight setAttrWithCtrlValue:tmpUidevice];
                        tmpDlight.backgroundColor = [UIColor clearColor];
                        [scrollDevice addSubview:tmpDlight];
                        [smallArray addObject:tmpDlight];
                        ///add 手势
                        UITapGestureRecognizer *tapDoubleClick = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(touchedSeletedView:)];
                        tapDoubleClick.numberOfTapsRequired = 2;
                        [tmpDlight addGestureRecognizer:tapDoubleClick];
                        for (UIGestureRecognizer *g in ((UIView *)tmpDlight.subviews[0]).gestureRecognizers) {
                            [g requireGestureRecognizerToFail:tapDoubleClick];
                        }
                        for (UIGestureRecognizer *g in ((UIView *)tmpDlight.subviews[1]).gestureRecognizers) {
                            [g requireGestureRecognizerToFail:tapDoubleClick];
                        }
                    }
                    
                    //门锁
                    else if ([tmpUidevice.property isEqualToString:@"智能门锁"]) {
                        DoorView *tmpDoor = [[DoorView alloc]initWithFrame:CGRectMake(x_view, 2, 36, 36)];
                        tmpDoor.isNeedQuery = NO;
                        x_view +=40;
                        [tmpDoor setAttrWithCtrlValue:tmpUidevice];
                        [appManager.aryActiveDevice addObject:tmpDoor];
                        tmpDoor.backgroundColor = [UIColor clearColor];
                        [scrollDevice addSubview:tmpDoor];
                        [smallArray addObject:tmpDoor];
                        ///add 手势
                        UITapGestureRecognizer *tapDoubleClick = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(touchedSeletedView:)];
                        tapDoubleClick.numberOfTapsRequired = 2;
                        [tmpDoor addGestureRecognizer:tapDoubleClick];
                        for (UIGestureRecognizer *g in tmpDoor.gestureRecognizers) {
                            [g requireGestureRecognizerToFail:tapDoubleClick];
                        }
                    }
                    
                    else if([tmpUidevice.property isEqualToString:@"升降窗帘"]){
                        /////////////////创建升降窗帘
                        FXW_Curtain *curtain = [[FXW_Curtain alloc]initWithFrame:CGRectMake(x_view,2,80, 36)];
                        x_view+=84;

                        [curtain setAttrWithCtrlValue:tmpUidevice];
                        curtain.isNeedQuery = NO;
                        [curtain setCategoryType:CurtainCategoryTypefUp_Down andFrameType:2];
                        [[[HE_APPManager sharedManager] aryActiveDevice] addObject:curtain];
                        curtain.backgroundColor = [UIColor clearColor];
                        [scrollDevice addSubview:curtain];
                        [smallArray addObject:curtain];
                        ///add 手势
                        UITapGestureRecognizer *tapDoubleClick = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(touchedSeletedView:)];
                        tapDoubleClick.numberOfTapsRequired = 2;
                        [curtain addGestureRecognizer:tapDoubleClick];
                        for (UIGestureRecognizer *g in curtain.gestureRecognizers) {
                            [g requireGestureRecognizerToFail:tapDoubleClick];
                        }
                        
                    }
                    else if([tmpUidevice.property isEqualToString:@"开合窗帘"]){
                        /////////////////创建开合窗帘
                        FXW_Curtain *curtain = [[FXW_Curtain alloc]initWithFrame:CGRectMake(x_view,2,80, 36)];
                        x_view+=84;

                        [curtain setAttrWithCtrlValue:tmpUidevice];
                        curtain.isNeedQuery = NO;
                        [curtain setCategoryType:CurtainCategoryTypeOpenClose andFrameType:2];
                        [[[HE_APPManager sharedManager] aryActiveDevice] addObject:curtain];
                        curtain.backgroundColor = [UIColor clearColor];
                        [scrollDevice addSubview:curtain];
                        [smallArray addObject:curtain];
                        UITapGestureRecognizer *tapDoubleClick = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(touchedSeletedView:)];
                        [curtain addGestureRecognizer:tapDoubleClick];
                        tapDoubleClick.numberOfTapsRequired = 2;
                        for (UIGestureRecognizer *g in curtain.gestureRecognizers) {
                            [g requireGestureRecognizerToFail:tapDoubleClick];
                        }
                        /////////////////
                        
                    }
                    else if([tmpUidevice.property isEqualToString:@"单体空调"]){
                        /////////////////创建单体空调
                        FXW_CommonDevice *singleCodition = [[FXW_CommonDevice alloc]initWithFrame:CGRectMake(x_view, 2, 36, 36)];
                        x_view+=40;
                        
                        singleCodition.isNeedQuery     = NO;
                        singleCodition.delegate        = self.navigationController;
                        singleCodition.backgroundColor = [UIColor clearColor];
                        singleCodition.contentValue    = tmpUidevice;
                        
                        [singleCodition setAttrWithCtrlValue:tmpUidevice];
                        [singleCodition setBackimgName:@"conicon.png" andTitle:tmpUidevice.name IsTapLink: true];
                        
                        [scrollDevice addSubview:singleCodition];
                        [smallArray addObject:singleCodition];
                        [[[HE_APPManager sharedManager]aryActiveDevice] addObject:singleCodition];
                        
                        UITapGestureRecognizer *tapDoubleClick = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(touchedSeletedView:)];
                        tapDoubleClick.numberOfTapsRequired = 2;
                        [singleCodition addGestureRecognizer:tapDoubleClick];
                        /////////////////
                    }
                    else if([tmpUidevice.property isEqualToString:@"电源控制"]){
                        /////////////////创建电源控制
                        FXW_Power *tmpPower = [[FXW_Power alloc]initWithFrame:CGRectMake(x_view, 2, 36, 36)];
                        x_view+=40;
                        [tmpPower setName:tmpUidevice.name];
                        [appManager.aryActiveDevice addObject:tmpPower];
                        [tmpPower setIsNeedQuery:NO];
                        [tmpPower setAttrWithCtrlValue:tmpUidevice];
                        tmpPower.backgroundColor = [UIColor clearColor];
                        [scrollDevice addSubview:tmpPower];
                        [smallArray addObject:tmpPower];
                        ///add 手势
                        UITapGestureRecognizer *tapDoubleClick = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(touchedSeletedView:)];
                        tapDoubleClick.numberOfTapsRequired = 2;
                        [tmpPower addGestureRecognizer:tapDoubleClick];
                        for (UIGestureRecognizer *g in tmpPower.gestureRecognizers){
                            [g requireGestureRecognizerToFail:tapDoubleClick];
                        }
                    }
                    else if([tmpUidevice.property isEqualToString:@"中央空调"]){
                        /////////////////创建中央空调
                        FXW_CommonDevice *CenterCodition = [[FXW_CommonDevice alloc]initWithFrame:CGRectMake(x_view, 2, 36, 36)];
                        x_view+=40;

                        CenterCodition.isNeedQuery = NO;
                        CenterCodition.delegate = self.navigationController;
                        CenterCodition.backgroundColor = [UIColor clearColor];
                        
                        [CenterCodition setAttrWithCtrlValue:tmpUidevice];
                        [CenterCodition setContentValue:tmpUidevice];
                        [CenterCodition setBackimgName:@"conicon.png" andTitle:tmpUidevice.name IsTapLink: true];

                        
                        [scrollDevice addSubview:CenterCodition];
                        [smallArray addObject:CenterCodition];
                        [[[HE_APPManager sharedManager] aryActiveDevice] addObject:CenterCodition];
                        
                        UITapGestureRecognizer *tapDoubleClick = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(touchedSeletedView:)];
                        tapDoubleClick.numberOfTapsRequired = 2;
                        [CenterCodition addGestureRecognizer:tapDoubleClick];
                        /////////////////
                        
                    }
                    else if([tmpUidevice.property isEqualToString:@"背景音乐"]){
                        /////////////////创建背景音乐
                        FXW_CommonDevice *backmusic = [[FXW_CommonDevice alloc]initWithFrame:CGRectMake(x_view, 2, 36, 36)];
                        x_view+=40;

                        backmusic.delegate    = self.navigationController;
                        backmusic.aryMusic    = @[tmpUidevice];
                        backmusic.isNeedQuery = NO;
                        backmusic.backgroundColor = [UIColor clearColor];
                        
                        [backmusic setAttrWithCtrlValue:tmpUidevice];
                        [backmusic setBackimgName:@"musicicon.png" andTitle:tmpUidevice.name IsTapLink: true];
                        
                        
                        [scrollDevice addSubview:backmusic];
                        [smallArray addObject:backmusic];
                        [[[HE_APPManager sharedManager]aryActiveDevice] addObject:backmusic];
                        
                        UITapGestureRecognizer *tapDoubleClick = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(touchedSeletedView:)];
                        tapDoubleClick.numberOfTapsRequired = 2;
                        [backmusic addGestureRecognizer:tapDoubleClick];
                        /////////////////                        
                    }
                    else if([tmpUidevice.property isEqualToString:@"电视/播放器/DVD"]){
                        /////////////////创建电视
                        FXW_CommonDevice *tv = [[FXW_CommonDevice alloc]initWithFrame:CGRectMake(x_view, 2, 36, 36)];
                        x_view+=40;

                        tv.isNeedQuery = NO;
                        tv.delegate = self.navigationController;
                        tv.backgroundColor = [UIColor clearColor];
                        [tv setAttrWithCtrlValue:tmpUidevice];
                        [tv setContentValue:tmpUidevice];
                        [tv setBackimgName:@"tvicon.png" andTitle:tmpUidevice.name IsTapLink: true];
                        
                        [scrollDevice addSubview:tv];
                        [smallArray addObject:tv];
                        [[[HE_APPManager sharedManager]aryActiveDevice] addObject:tv];
                        UITapGestureRecognizer *tapDoubleClick = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(touchedSeletedView:)];
                        tapDoubleClick.numberOfTapsRequired = 2;
                        [tv addGestureRecognizer:tapDoubleClick];
                        /////////////////
                        
                    }
                    else if([tmpUidevice.property isEqualToString:@"自定义设备"]){
                        /////////////////创建自定义设备
                        FXW_CommonDevice *device = [[FXW_CommonDevice alloc]initWithFrame:CGRectMake(x_view, 2, 36, 36)];
                        x_view+=40;
                        
                        device.backgroundColor = [UIColor clearColor];
                        device.isNeedQuery = NO;
                        device.delegate = self.navigationController;
                        
                        [device setAttrWithCtrlValue:tmpUidevice];
                        [device setContentValue:tmpUidevice];
                        [device setBackimgName:@"otherDeviceicon.png" andTitle:tmpUidevice.name IsTapLink: true];
                        
                        
                        [scrollDevice addSubview:device];
                        [smallArray addObject:device];
                        UITapGestureRecognizer *tapDoubleClick = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(touchedSeletedView:)];
                        tapDoubleClick.numberOfTapsRequired = 2;
                        [device addGestureRecognizer:tapDoubleClick];
                        /////////////////
                        [[[HE_APPManager sharedManager] aryActiveDevice] addObject:device];
                    }
                }
            }
            /////////
            deviceTag ++;
            /////////
        }
    }
}

//为房间添加图片按钮方法实现（alert上的（“+”）号对应的方法）
-(void)AddHouseClick
{
    addAlert = [[WB_UIAlertView alloc]initWithFrame:self.view.frame Delegate:self Datasourse:self];
    
    [addAlert setContent:AddHouse andBaseInfo:@"请完成信息" andActionType:10011];
    
    [self.view addSubview:addAlert];
}
-(void)DeleteHouseClick{
    UIAlertView *alertDele = [[UIAlertView alloc]initWithTitle:@"提示" message:[NSString stringWithFormat:@"确定删除%@吗?",labHousename.text] delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    [alertDele show];
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(buttonIndex == 1){
        [self DeleteHouse];
    }
}
///删除房间按钮的方法实现
-(void)DeleteHouse
{
    UIScrollView *curScrollView = (UIScrollView *)[imageScrollView viewWithTag:999];
    NSArray *curViewArray = [curScrollView subviews];
    if(curViewArray.count>1)
    {
        /////////删除沙盒中的图片
        NSFileManager* fileManager=[NSFileManager defaultManager];
        NSString *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES)[0];
        //获取文件名
        House *tmp = [CYM_Engine getHouseByHouseName:PicNameArray[curPageIndex]];
        NSString *uniquePath=[path stringByAppendingPathComponent:tmp.houseImgUrl];
        ////////////删除
        if([[NSFileManager defaultManager] fileExistsAtPath:uniquePath]){
            if ([fileManager removeItemAtPath:uniquePath error:nil]) {
                /////////再删除数据库的信息
                [CYM_Engine deleteHouseInfoByHouseName:PicNameArray[curPageIndex]];
                [CYM_Engine deleteHouse:PicNameArray[curPageIndex]];
                for(int i=0;i<curViewArray.count;i++)
                {
                    if(((HE_UIDevice *)curViewArray[i]).tag == curTag)
                    {
                        [PicNameArray removeObjectAtIndex:curPageIndex];
                        for(UIImageView *img in [[curViewArray objectAtIndex:i] subviews]){
                            for(HE_UIDevice *tmpView in img.subviews){
                                [self AddToSmall:tmpView];
                            }
                        }
                        [[curViewArray objectAtIndex:i] removeFromSuperview];
                        
                        [imageArray removeObjectAtIndex:curPageIndex];
                        [imageScrollView DeleteImageView:imageArray];
                        if(PicNameArray.count == 0)
                        {[labHousename setText:@"暂无任何房间"];}
                        else{[labHousename setText:[NSString stringWithFormat:@"%@",[PicNameArray objectAtIndex:curPageIndex]]];}
                        
                        break;
                    }
                }
            }else {
                [appManager hudShowMsgTitle:@"警告" details:@"删除出现错误" andInterval:2];
            }
        }
        else{
            return;
        }

    }
    else
    {
        [appManager hudShowMsgTitle:@"没有房间" details:@"已经没有房间可以继续删除" andInterval:1.5];
    }
}
//向左切换房间的方法定义
-(void)TurnLeftClick
{
    if(imageArray.count == 0)
    {
        [appManager hudShowMsgTitle:@"抱歉" details:@"当前无任何房间，请先添加房间" andInterval:1.5];
    }
    else
    {
        NSInteger action = [imageScrollView TurnLeft];
        if(PicNameArray.count == 0)
        {[labHousename setText:@"无房间"];}
        else{[labHousename setText:[NSString stringWithFormat:@"%@",[PicNameArray objectAtIndex:curPageIndex]]];}
        if(action == 1)
        {
            [appManager hudShowMsgTitle:@"提示" details:@"已经到最左边了" andInterval:2];
        }
    }
}

//向右切换房间的方法定义
-(void)TurnRightClick
{
    if(imageArray.count == 0)
    {
        [appManager hudShowMsgTitle:@"抱歉" details:@"当前无任何房间，请先添加房间" andInterval:2];
    }
    else
    {
        NSInteger action = [imageScrollView TurnRight];
        if(PicNameArray.count == 0)
        {[labHousename setText:@"无房间"];}
        else{[labHousename setText:[NSString stringWithFormat:@"%@",[PicNameArray objectAtIndex:curPageIndex]]];}
        if(action == 1)
        {
            [appManager hudShowMsgTitle:@"提示" details:@"已经到最右边了" andInterval:2];
        }
    }
}
////底部切换按钮
-(void)scrollDeviceturn:(id)sender{
    CGPoint point = scrollDevice.contentOffset;
    if(((UIButton *)sender).tag ==10000){
       // if(point.x<x_view){
          //  point.x +=x_view-point.x>80?80:x_view-point.x;
        point.x+=80;
            [scrollDevice setContentOffset:point animated:YES];
     //   }
    }
    else{
        point.x -=80;
        [scrollDevice setContentOffset:point animated:YES];
    }
    
}
//alert上的取消方法
-(void)CancelAlert
{
    data = nil;//这里必须把图像二进制数据置空，因为data是全局的，不置空的话，如果下次没选图片，就会把上次的图片加载进来
}
//为房间添加图片的方法
-(void)AddHousePicture
{
    //这里呼出菜单，选择“从相册获取”和“现拍现照”
    [self openMenu];
}
//呼出菜单选择控件
-(void)openMenu
{
    //在这里呼出下方菜单按钮项
    myActionSheet = [[UIActionSheet alloc]
                     initWithTitle:@"照片来自"
                     delegate:self
                     cancelButtonTitle:@"取消"
                     destructiveButtonTitle:nil
                     otherButtonTitles: @"拍照获取", @"相册获取",nil];
    
    [myActionSheet showInView:self.view];
    
}
///照片菜单点击事件
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    //呼出的菜单按钮点击后的响应
    if (buttonIndex == myActionSheet.cancelButtonIndex)
    {
        //进入到这里，说明用户按了取消而未做任何操作
    }
    switch (buttonIndex)
    {
        case 0:  //打开照相机拍照
            [self takePickturesButtonClick];
            break;
            
        case 1:  //打开本地相册
            [self selectForAlbumButtonClick];
            break;
    }
}
//从相册中选择
- (void)selectForAlbumButtonClick
{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    picker.delegate = self;
    //设置选择后的图片可被编辑，也就是可对其放大，缩小
    picker.allowsEditing = YES;
    [self presentViewController:picker animated:YES completion:nil];
}

//拍照获取
- (void)takePickturesButtonClick
{
    UIImagePickerControllerSourceType sourceType = UIImagePickerControllerSourceTypeCamera;
    if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera])
    {
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.delegate = self;
        //设置拍照后的图片可被编辑
        picker.allowsEditing = YES;
        picker.sourceType = sourceType;
        
        [self presentViewController:picker animated:YES completion:nil];
    }
    else
    {
    //    NSLog(@"模拟其中无法打开照相机,请在真机中使用");
    }
}
//当选择一张图片后进入这里（无论是现拍的，还是相册获取的，确定了照片，都进入这里）
-(void)imagePickerController:(UIImagePickerController*)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    NSString *type = [info objectForKey:UIImagePickerControllerMediaType];
    //当选择的类型是图片
    if ([type isEqualToString:@"public.image"])
    {
        //先把图片转成NSData
        UIImage* image = [info objectForKey:@"UIImagePickerControllerEditedImage"];//获取用户编辑截取后的图像，改变了图片尺寸大小
        
        //这里的data就是选好的图片的二进制流
        if (UIImagePNGRepresentation(image) == nil)
        {
            data = UIImageJPEGRepresentation(image, 1.0);
        }
        else
        {
            data = UIImagePNGRepresentation(image);
        }
        
        //图片保存的路径
        //这里将图片放在沙盒的documents文件夹中
        NSString * DocumentsPath = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
        
        //文件管理器
        NSFileManager *fileManager = [NSFileManager defaultManager];
        
        //////1970至今的毫秒数
        NSTimeInterval time=[[NSDate date] timeIntervalSince1970]*1000;
        NSString *fileName = [NSString stringWithFormat:@"/%f.png",time];
        
        //把刚刚图片转换的data对象拷贝至沙盒中 并保存
        [fileManager createDirectoryAtPath:DocumentsPath withIntermediateDirectories:YES attributes:nil error:nil];
        [fileManager createFileAtPath:[DocumentsPath stringByAppendingString:fileName] contents:data attributes:nil];
        
        //得到选择后沙盒中图片的路径
        filePath = [[NSString alloc]initWithFormat:@"%@",fileName];
        
        //关闭相册界面
        [picker dismissViewControllerAnimated:YES completion:nil];
    }
    
    //用选好的照片，替换alert上面的添加（“+”）按钮
    UIButton *AddPicBtn = (UIButton *)[addAlert viewWithTag:10012];
    UIImageView *curImage = [[UIImageView alloc]init];
    [curImage setFrame:CGRectMake(AddPicBtn.frame.origin.x, AddPicBtn.frame.origin.y, AddPicBtn.frame.size.width/2, AddPicBtn.frame.size.height+15)];
    [curImage setImage:[UIImage imageWithData:data]];
    [AddPicBtn.superview addSubview:curImage];
    [AddPicBtn removeFromSuperview];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    //用户取消了照片选择，进入这里
    [picker dismissViewControllerAnimated:YES completion:nil];
}

//获取当前图片滚动到第curPageIndex张了，但当前图片的tag标记为curtag，这两个标记要区分开，是不同的。
-(void)GetTag:(NSInteger)curtag curPageIndex:(NSInteger)curpageindex
{
    curTag = curtag;
    curPageIndex = curpageindex;
    [labHousename setText:PicNameArray[curPageIndex]];
}
/*****************************************************************/
//（点击alert上的保存按钮）隐藏自定义alert ，当返回false则不隐藏，true则隐藏
-(BOOL)saveBtnAddHouse:(NSString *)picname actionType:(NSInteger)actionType
{
    if(actionType == 10011)
    {
        if([picname isEqualToString:@""] || picname == nil)
        {
            [appManager hudShowMsgTitle:@"添加失败" details:@"请填写房间名称" andInterval:2];
            return false;
        }
        if(data.length == 0 || data == nil)
        {
            [appManager hudShowMsgTitle:@"添加失败" details:@"请为房间添加一张照片" andInterval:2];
            return false;
        }
        if([PicNameArray containsObject:picname]){
            [appManager hudShowMsgTitle:@"添加失败" details:[NSString stringWithFormat:@"已存在房间:%@,请更换房间名称",picname] andInterval:2];
            return false;
        }
        [PicNameArray addObject:picname];
        [imageArray addObject:data];
        [imageScrollView AddImageView:imageArray];
        
        if(PicNameArray.count == 0)
        {[labHousename setText:@"无房间"];}
        else{[labHousename setText:[NSString stringWithFormat:@"%@",[PicNameArray objectAtIndex:curPageIndex]]];}
        
        data = nil;//这里必须把上一次添加的图片data清空
        House *house = [[House alloc]init];
        house.houseName = PicNameArray[curPageIndex];
        house.houseImgUrl = filePath;
        [CYM_Engine insertHouse:house];
        return true;
    }
    else
    {
        return true;
    }
}
- (BOOL)matchStringFormat:(NSString *)matchedStr withRegex:(NSString *)regex
{
    NSRange range=[matchedStr rangeOfString:regex];
    if(range.location!=NSNotFound)
    {
        return true;
    }
    else
    {
        return false;
    }
}
//时刻动画调整小里的图标位置
-(void)switchSmallScroll:(id)sender
{
    for(int j=0;j<smallArray.count;j++)
    {
        CGRect rect = ((HE_UIDevice *)sender).frame;
        [UIView beginAnimations:nil context:NULL];//此处添加动画，使之变化平滑一点
        [UIView setAnimationDuration:0.3];//设置动画时间 秒为单位
        ((HE_UIDevice *)sender).frame = CGRectMake(j*rect.size.width+10, 5, rect.size.width,rect.size.height);//整体屏幕位置的y坐标移动到offY
        [UIView commitAnimations];//开始动画效果
    }
}
- (void)touchedSeletedView:(UITapGestureRecognizer *)tap{
    HE_UIDevice *tmp =  (HE_UIDevice*)tap.view;
    if(imageArray.count>0)
    {
        //////////////如果是从下点击到上，保存原来的位置以便再次点击回来
        if([tmp.superview isEqual:scrollDevice]){
            ///////点击到大视图中
            [self AddToBig:tmp andPoint:CGPointMake(0, 0)];
        }
        /////////////如果是从上点击到下，恢复原来的位置
        else{

            [self AddToSmall:tmp];
        }
    }
    else
    {
        [appManager hudShowMsgTitle:@"没有房间" details:@"请先至少添加一个房间" andInterval:1.5];
    }
    
}
-(void)AddToBig:(HE_UIDevice *)tmp andPoint:(CGPoint)tmpPoint{
NSLog(@"add big:%f",tmp.frameH);
    //////底部changeframe
    [self changeFrameToAdd:tmp];
NSLog(@"add big2:%f",tmp.frameH);
    HouseDevice *tmpdevice = [[HouseDevice alloc]init];
    tmpdevice.houseName = PicNameArray[curPageIndex];
    tmpdevice.deviceName = tmp.name;
    tmpdevice.pointX = [NSString stringWithFormat:@"%f",tmp.center.x];
    tmpdevice.pointY = [NSString stringWithFormat:@"%f",tmp.center.y];
    [aryhouseDevice addObject:tmpdevice];
    if([tmp.property isEqualToString:@"非可调灯"]||[tmp.property isEqualToString:@"电源控制"]){
        tmpdevice.width = 36;
    }
    else if([tmp.property isEqualToString:@"可调灯"]||[self matchStringFormat:tmp.category withRegex:@"窗帘"]){
        tmpdevice.width = 80;
    }
    else{
        tmpdevice.width = 36;
    }
    ///拖动手势
    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(panGesture:)];
    panGesture.delegate = self;
    [tmp addGestureRecognizer:panGesture];
    [smallArray removeObject:tmp];
    [self switchSmallScroll:tmp];//底部动画

    if(tmpPoint.x !=0)///先这样
    {
        tmp.center = tmpPoint;
    }
    CGFloat imgH = 0.0f;
    CGFloat imgW = 0.0f;
    UIScrollView *curScrollView = (UIScrollView *)[imageScrollView viewWithTag:999];
    NSArray *curViewArray = [curScrollView subviews];
    for(int i=0;i<curViewArray.count;i++)
    {
        if(((HE_UIDevice *)[curViewArray objectAtIndex:i]).tag == curTag)
        {
            @try {
                [((HE_UIDevice *)[curViewArray objectAtIndex:i]).subviews[0] addSubview:tmp];
                imgH = ((UIImageView *)((HE_UIDevice *)curViewArray[i]).subviews[0]).image.size.height;
                imgW = ((UIImageView *)((HE_UIDevice *)curViewArray[i]).subviews[0]).image.size.width;
                
            }
            @catch (NSException *exception) {
                
            }
            @finally {
                
            }
        }
    }
    //////随机位置
    if(tmpPoint.y==0&&tmpPoint.x==0){
        imgH = imgH/imgW *curScreenSize.width;
        [tmp setCenter:CGPointMake([self getRandomNumber:20 to:curScreenSize.width/2-20],[self getRandomNumber:(curScreenSize.width-imgH)/2 to:(curScreenSize.width-imgH)/2 +imgH-20])];
    }
    //    [tmp setFrame:CGRectMake(10, 10, tmp.frameW,tmp.frameH)];
    //////
    /////刚点到上面去也要保存信息

    ///建立临时变量
     HouseDevice *tmpd = [[HouseDevice alloc]init];
    tmpd.houseName = tmpdevice.houseName;
    tmpd.deviceName = tmpdevice.deviceName;
    tmpd.pointX = [NSString stringWithFormat:@"%f",tmp.center.x];
    tmpd.pointY = [NSString stringWithFormat:@"%f",tmp.center.y];
    [CYM_Engine insertHouseInfo:tmpd];

    
}
-(void)AddToSmall:(HE_UIDevice *)tmp{
    NSLog(@"add small:%f",tmp.frameH);
    ///////
    [self changeFrameToReduce:tmp];
    /////////////删除滑动手势
    for (UIGestureRecognizer *g in tmp.gestureRecognizers){
        if([g isKindOfClass:[UIPanGestureRecognizer class]]){
            [tmp removeGestureRecognizer:g];
        }
    }
  //  [smallArray addObject:tmp];
    
    
//    CGPoint point=CGPointMake(0, 0);
//    float width = 0;
//    for(int i = 0 ;i<aryhouseDevice.count;i++){
//        if([((HouseDevice *)aryhouseDevice[i]).deviceName isEqualToString:tmp.name]){
//            point.x = [((HouseDevice *)aryhouseDevice[i]).pointX floatValue];
//            point.y = [((HouseDevice *)aryhouseDevice[i]).pointY floatValue];
//            width   = ((HouseDevice *)aryhouseDevice[i]).width;
//            [aryhouseDevice removeObjectAtIndex:i];
//        }
//    }
//    [tmp setFrame:CGRectMake(0, 0,width, 36)];
//    tmp.center=point;
    [scrollDevice addSubview:tmp];
    //////////////这儿需要删除
    [CYM_Engine deleteHouseInfoByDeviceName:tmp.name];
  //  [self AddToSmall:tmp];
   // [self changeFrameToReduce:tmp];
}
/////滑动手势结束
-(void)panGesture:(UIPanGestureRecognizer *)pan{
    CGPoint point = [pan locationInView:imageScrollView];
    if (pan.state == UIGestureRecognizerStateEnded){
        
        
      
        
        HouseDevice *tmphouseD = [[HouseDevice alloc]init];
        tmphouseD.houseName = PicNameArray[curPageIndex];
        tmphouseD.deviceName = ((HE_UIDevice *)pan.view).name;
        tmphouseD.pointX =  [NSString stringWithFormat:@"%f",pan.view.center.x];
        tmphouseD.pointY = [NSString stringWithFormat:@"%f",pan.view.center.y];
        //////////////////////////保存位置
        /////////////////////////
       [CYM_Engine insertHouseInfo:tmphouseD];
    }
    else{
        CGFloat imgH = 0.0f;
        CGFloat imgW = 0.0f;
        

        UIScrollView *curScrollView = (UIScrollView *)[imageScrollView viewWithTag:999];
        NSArray *curViewArray = [curScrollView subviews];
        for(int i=0;i<curViewArray.count;i++)
        {
            if(((HE_UIDevice *)[curViewArray objectAtIndex:i]).tag == curTag)
            {
                @try {
                    imgH = ((UIImageView *)((HE_UIDevice *)curViewArray[i]).subviews[0]).image.size.height;
                    imgW = ((UIImageView *)((HE_UIDevice *)curViewArray[i]).subviews[0]).image.size.width;
                }
                @catch (NSException *exception) {
                    
                }
                @finally {
                    
                }
            }
        }
        if(imgH != 0){
            imgH = imgH/imgW *curScreenSize.width;
            point.y = point.y > (curScreenSize.width - imgH)/2+pan.view.frameH/2?point.y: (curScreenSize.width - imgH)/2+pan.view.frameH/2;
            point.y = point.y <= ((curScreenSize.width-imgH)/2 + imgH)-pan.view.frameH/2?point.y:((curScreenSize.width-imgH)/2 + imgH)-pan.view.frameH/2;
        }
        else{
            point.y = point.y>imageScrollView.frameY+pan.view.frameH/2?point.y:imageScrollView.frameY+pan.view.frameH/2;
            point.y = point.y<imageScrollView.frameSumY_H-pan.view.frameH/2?point.y:imageScrollView.frameSumY_H-pan.view.frameH/2;
        }
        pan.view.center = point;
    }
}
-(void)changeFrameToAdd:(HE_UIDevice *)tmp{
    NSInteger index = [smallArray indexOfObject:tmp];
    for(int i = index+1;i<smallArray.count;i++){
        HE_UIDevice *tmpDevice = smallArray[i];
        [UIView animateWithDuration:0.5 animations:^{
            [tmpDevice setFrameX:tmpDevice.frameX-tmp.frameW - 4];
        }];
    }
}
-(void)changeFrameToReduce:(HE_UIDevice *)tmp{
    NSInteger index = 0;
    //短路特性，前面是真，后面不会执行，整个判断语句就都为真
    if(smallArray.count == 0 || tmp.tag<((HE_UIDevice *)smallArray[0]).tag ){
        ///第一个
        index = 0;
    }
    else if(tmp.tag>((HE_UIDevice *)smallArray[smallArray.count-1]).tag){
        ///最后一个
        index = smallArray.count - 1;
    }
    else{///在中间
        for(int i =0;i<smallArray.count;i++){
            HE_UIDevice *proDevice = smallArray[i];
            HE_UIDevice *nextDevice = smallArray[i+1];
            if(tmp.tag<nextDevice.tag&&tmp.tag>proDevice.tag){
                index = i+1;
//                proIndex = i - 1;
                break;
            }
        }
    }
    //特殊情况，当设备全部被使用时会出现BUG，修改了该BUG
    if (smallArray.count == 0) {
        [UIView animateWithDuration:0.5 animations:^{
            [tmp setFrameX:0];
            [tmp setFrameY:2];
        }];
    }
    for(int j = index;j<smallArray.count;j++){
        HE_UIDevice *tmpDevice = smallArray[j];
        [UIView animateWithDuration:0.5 animations:^{
            if(index == 0){
                [tmp setFrameX:0];
                [tmpDevice setFrameX:tmpDevice.frameX+tmp.frameW+4];
            }
            else if(index == smallArray.count - 2){
                [tmp setFrameX:((HE_UIDevice *)smallArray[smallArray.count-1]).frameSumX_W+4];
            }
            else{
                [tmp setFrameX:((HE_UIDevice *)smallArray[index-1]).frameSumX_W+4];
                [tmpDevice setFrameX:tmpDevice.frameX+tmp.frameW+4];
            }
            [tmp setFrameY:2];
        }];
    }
    [smallArray insertObject:tmp atIndex:index];
    NSLog(@"----------%ld",(long)index);


//    @try {
//        [smallArray insertObject:tmp atIndex:[smallArray indexOfObject:proDevice]+1];
//    }
//    @catch (NSException *exception) {
//        [smallArray insertObject:tmp atIndex:[smallArray indexOfObject:nextDevice]-1];
//    }
//    @finally {
//        
//    }
}
-(int)getRandomNumber:(int)from to:(int)to
{
    return (CGFloat)(from + (arc4random() % (to - from + 1))); //+1,result is [from to]; else is [from, to)!!!!!!!
}
@end
