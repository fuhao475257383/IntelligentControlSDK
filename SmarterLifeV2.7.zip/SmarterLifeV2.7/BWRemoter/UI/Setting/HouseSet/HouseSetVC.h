//
//  HouseSetVC.h
//  BWRemoter
//
//  Created by wangbin on 14/12/7.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "HE_BaseViewController.h"
#import "ImagesScrollView.h"
@interface HouseSetVC : HE_BaseViewController<XZJ_ImagesScrollViewDelegate,UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIGestureRecognizerDelegate,UIAlertViewDelegate>
{
    NSArray *aryDevice;
    NSInteger deviceTag;///给每个device加上tag
    NSArray *aryAllDevices;//保存所有的device类
}
@end
