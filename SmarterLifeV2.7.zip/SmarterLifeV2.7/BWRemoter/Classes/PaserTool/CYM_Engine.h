//
//  CYM_Engine.h
//  BWRemoter
//
//  Created by cym on 14-12-30.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CYM_DatabaseTable.h"
@interface CYM_Engine : NSObject

+(void)configSemaphore;
////////////////  JSON 文件接口
///获得json格式文件
+(NSData *)generateJSONFileWithName:(NSString *)name;
///根据JSON文件生成数据库
+(void)paserFileWithPath:(NSString *)path fileName:(NSString *)name;


///////////////// 获取数据接口 Room
///获取所有房间的设备
+(NSArray *)getRoomAllDevice;
///获取设备所在的房间名称
+(NSString *)getRoomNameWithRoomDeviceName:(NSString *)deviceName;
///移除房间中名称为XXX的设备/场景
+(BOOL)deleteRoomDeviceContentWithName:(NSString *)name;
///添加名称为XXX的设备/场景到房间中
+(BOOL)addRoomDeviceContentWithName:(NSString *)devName room:(NSString *) roomName;
//所有设备
+ (NSMutableArray *)getAllDevice;
//插入房间到db_room
+ (BOOL)insertRoom:(Room*)room;
//移除房间
+ (void)deleteRoomWithName:(NSString *)name;

///////////////// 获取数据接口 Control
///根据设备名称获取设备详情
+(ControlDeviceContentValue *)getDeviceDetailsWithDeviceName:(NSString *)deviceName;
///获取空调控制器的所有的已学习Key
+(NSMutableArray *)getCategoryAllKeyWithValue:(ControlDeviceContentValue *)value;
//根据设备ID获取所有KEY
+(NSMutableArray *)getContrlKeyWithValueID:(NSString *)valueID;
//根据设备名称获取所有KEY
+(NSMutableArray *)getContrlKeyWithValueName:(NSString *)valueName;
//获取所有设备名称
+(NSMutableArray *)getAlldeviceContentName;
///获取所有的报警器
+(NSMutableArray *)getAlarmDevice;
///获取property=property的 controlValue，获取某属性的设备
+(NSMutableArray *)getContrlValueWithProperty:(NSString *) property;
// 是一条查询命令
+(BOOL)isQueryValue:(NSString *)value;
//2.7增加,获得所有报警设备名字
+ (NSMutableArray *)getAllAlarm;
//通过传感器名字获得传感器信息
+ (SecurityContent_sensor *)getSensorFromName:(NSString *)name;


////重新设置某个CtrlValue的 所有Key
+(BOOL)updateContrlValueKeys:(NSArray *)aryKey ValueName:(NSString *)valName;
////更新设备的权限
+(BOOL)updateDevicePriowith:(NSMutableArray *)arydeviceValue;
///////////////// 获取数据接口 Config
///获取某文件的版本号
+(NSInteger)getVersionWithFileName:(NSString *)fileName;

///////////////// 获取数据接口 IPC
+(NSMutableArray *)getAllIPCInfo;


///////////////// 获取数据接口 Scene
//获取所有场景+防区模式
+(NSMutableArray *)getAllScene;
///通过名字获取场景信息
+(Scene *)getSenceWithSenceName:(NSString *)senceName;
///获取所有软场景 
+(NSMutableArray *)getAllSoftSence;
///获取所有的软场景数组
+(NSMutableArray *)getAllSoftHardScene;
///获取Type=2的场景数组
+(NSMutableArray *)getAllOtherScene;
///获取某房间的所有设备
+(NSArray *)getRoomDeviceValueWithName:(NSString *)name;
///删除场景
+(BOOL)deleteSceneWithSceneName:(NSString *)name;
///更新OR新增场景
+(BOOL)updateSceneWithName:(Scene *)scene;
///获取定时信息
+(NSMutableArray *)getAllTimeInfo;
///新增or编辑定时信息
+(BOOL)addOrEditCrontabbycrontab:(Crontab *)crontab;
///更新所有定时信息
+(BOOL)UpdeteAllCrontab:(NSMutableArray *)aryCrontab;
///删除定时
+(BOOL)deleteCrontabInfoByCrontabId:(NSString *)crontab_Id;
///获取防区
+(NSMutableArray *)getAllZoneInfo;
//获取所有的传感器
+(NSMutableArray *)getAllSensorInfo;
//获取防区内容
+(NSMutableArray *)getZoneContentInfo;
//更新某个防区,安防界面
+(BOOL)updateZoneInfo:(SecurityContent_zone *)zone;
//设置界面更新某个防区或者添加防区
+ (BOOL)updateZoneSet:(SecurityContent_zone *)zone;
//删除防区
+(BOOL)deleteZoneIndfoByzoneId:(NSString*)zoneId;
//更新传感器
+(BOOL)updeteSensorInfo:(SecurityContent_sensor *)sensor;
//获取前500安防消息
+(NSMutableArray *)getTop500SecurityNoteInfo;
//获取最新的报警时间
+(NSString *)getNewNoteDate;
//获取最新的报警消息
+(NSMutableArray *)getNewSecurtyNote:(NSString *)lastDate;
//获取某个防区所有的报警器名称
+(NSMutableArray *)getAlarmNameWithZoneID:(NSString *)strZoneID;
//根据MAC获取报警器
+(NSMutableArray *)getAlarmNameWithSensorMAC:(NSString *)strSensorMAC;
//获取非24小事的报警器
+(NSMutableArray *)getAlarmNameWithNot24H;
//取消非24H得报警器
+(void)cancelSecrityNot24H;
/////获取传感器或者报警器的权限
+(NSString *)getSensorOrAlarmPriowithName:(NSString *)name;
/////////////房型专用
//获取房型URL
+(NSMutableArray *)getALLHouseUrl;
//新增一个房型
+(void)insertHouse:(House *)house;
//根据房型名称获取其所有设备的坐标
+(NSMutableArray *)getAllDevicelocationByhouseName:(NSString *)houseName;
//根据名称获取房型实例
+(House *)getHouseByHouseName:(NSString *)housename;
//删除房型
+(void)deleteHouse:(NSString *)housename;
//新增一个房型
+(void)insertHouseInfo:(HouseDevice *)houseDevice;
//删除一个房型中的设备
+(BOOL)deleteHouseInfoByDeviceName:(NSString *)deviceName;
//删除所有房型中的设备
+(BOOL)deleteHouseInfoByHouseName:(NSString *)houseName;

//获得所有门锁名字
+ (NSMutableArray *)getAllDoorlockName;
//获取所有门锁设置
+ (NSMutableArray *)getAllDoorlockSet;
//获取所有门锁报警
+ (NSMutableArray *)getNewDoorlockNote:(NSString *)lastDate;
//获取门锁最新的报警信息时间
+ (NSString *)getNewDoorlockNoteDate;
//获取最近500条信息
+ (NSMutableArray *)getTop500DoorlockNoteInfo;
//通过设备value，找到设备名字
+ (NSString *)getDevNameWithDevValue:(NSString *)devValue;
//通过门锁名字找到门锁的设置相关项
+ (Doorlock *)getDoorlockSetWithName:(NSString *)name;

//用户操作
//通过id找到user
+ (DoorlockUser *)getNameWithUserID:(NSString *)userID;
//通过用户登陆名找到user信息
+ (DoorlockUser *)getUserWithUserLoadName:(NSString *)loadName;
//保存用户到数据库
+ (BOOL)saveUserToDataBase:(DoorlockUser *)user;
//删除用户
+ (BOOL)deleteUserWithLoadName:(NSString *)loadName;
//获取所有门锁用户
+ (NSMutableArray *)getAllDoorlockUser;

//根据防区和传感器生成json数据
+ (NSData *)generateSecuritySensorArr:(NSArray *)sceneA zoneArr:(NSArray *)zoneA;

@end
