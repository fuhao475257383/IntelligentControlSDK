//
//  CYM_Engine.m
//  BWRemoter
//
//  Created by cym on 14-12-30.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "CYM_Engine.h"

#import "Room.h"
#import "Control.h"
#import "Scenes.h"
#import "Ipc.h"
#import "Config.h"
#import "Crontab.h"
#import "SecurityNote.h"
#import "Security.h"
//门锁
#import "Door.h"
#import "DoorlockNote.h"

#import "HE_UIDevice.h"
#import "HE_CustemExtend.h"


static dispatch_semaphore_t semConfig;
static dispatch_semaphore_t semRoom;
static dispatch_semaphore_t semScene;
static dispatch_semaphore_t semControl;
static dispatch_semaphore_t semIPC;
static dispatch_semaphore_t semCrontab;
static dispatch_semaphore_t semSecurity;
static dispatch_semaphore_t semSecurityNote;

@implementation CYM_Engine
+(void)configSemaphore{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        semConfig = dispatch_semaphore_create(1);
        semRoom = dispatch_semaphore_create(1);
        semScene = dispatch_semaphore_create(1);
        semControl = dispatch_semaphore_create(1);
        semIPC = dispatch_semaphore_create(1);
        semCrontab = dispatch_semaphore_create(1);
        semSecurity = dispatch_semaphore_create(1);
        semSecurityNote = dispatch_semaphore_create(1);
    });
}
///根据JSON文件生成数据库
+(void)paserFileWithPath:(NSString *)path fileName:(NSString *)name{
    NSLog(@"Parse %@",name);
    [CYM_Engine configSemaphore];
    
    //打印下载下来的数据
    NSData *data = [NSData dataWithContentsOfFile:path];
    NSString *uploadString = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
    NSLog(@"%@",uploadString);
    
    if ([name isEqualToString:@"room.json"]) {
        [self paserRoomWithPath:path];
    }
    else if ([name isEqualToString:@"scene.json"]){
        [self paserSceneWithPath:path];
    }
    else if ([name isEqualToString:@"control.json"]){
        [self paserControlWithPath:path];
    }
    else if ([name isEqualToString:@"ipc.json"]){
        [self paserIpcWithPath:path];
    }
    else if ([name isEqualToString:@"1.json"]){//config.json
        [self paserConfigWithPath:path];
    }
    else if ([name isEqualToString:@"crontab.json"]){
        [self paserCrontabWithPath:path];
    }
    else if ([name isEqualToString:@"securitynote.json"]){
        [self paserSecuritynoteWithPath:path];
    }
    else if ([name isEqualToString:@"security.json"]){
        [self paserSecurityWithPath:path];
    }else if ([name isEqualToString:@"doorlock.json"]){
        [self paserDoorlockWithPath:path];
    }
    else if ([name isEqualToString:@"doorlocknote.json"]){
        [self paserDoorlockNoteWithPath:path];
    }
}

+(NSData *)generateJSONFileWithName:(NSString *)name{
    NSLog(@"Generate %@",name);
    NSData *resultData = nil;
    if ([name isEqualToString:@"room.json"]) {
        resultData = [self generateRoomJSON];
    }
    else if ([name isEqualToString:@"scene.json"]){
        resultData = [self generateSceneSON];
    }
    else if ([name isEqualToString:@"control.json"]){
        resultData = [self generateControlJSON];
    }
    else if ([name isEqualToString:@"ipc.json"]){
        resultData = [self generateIPCJSON];
    }
    else if ([name isEqualToString:@"1.json"]){//config.json
        resultData = [self generateConfigJSON];
    }
    else if ([name isEqualToString:@"crontab.json"]){
        resultData = [self generateCrontabJSON];
    }
    else if ([name isEqualToString:@"securitynote.json"]){
        resultData = [self generateSecuritynoteJSPN];
    }
    else if ([name isEqualToString:@"security.json"]){
        resultData = [self generateSecurityJSON];
    }
    else if ([name isEqualToString:@"doorlock.json"]){
        resultData = [self generateDoorlockJSON];
    }
    return resultData;
}


#pragma mark -
#pragma mark  获取数据的接口
#pragma mark Room
+(NSArray *)getRoomAllDevice{
    //得到所有房间
    NSMutableArray *aryRoom = [CYM_DatabaseTable getRoom];
    for (Room *r in aryRoom) {
        //获取该房间的所有设备类别Property
        r.deviceArr = [CYM_DatabaseTable getRoomDeviceWithRoomID:r.ID];
        for (int i=0; i<r.deviceArr.count; i++) {
            RoomDevice *d = r.deviceArr[i];
            ////1.获取该property的Value详情(查询Control的设备 和 场景)
            NSMutableArray *aryValue =  [CYM_DatabaseTable getDeviceDetailsWithDeviceID:d.ID];
            ////1.1  若为ControlDeviceContentValue类型获取其KeyArry
            for (ControlDeviceContentValue *val in aryValue) {
                if ([val isKindOfClass:[ControlDeviceContentValue class]]) {
                    val.keyArr = [CYM_DatabaseTable getContrlKeyWithValueID:val.ID];
                }
            }
            
            /////房间里有多个中央空调时.
            if (aryValue.count > 1 &&
                ([d.property isEqualToString:@"中央空调"] || [d.property isEqualToString:@"单体空调"] ||
                 [d.property isEqualToString:@"背景音乐"] || [d.property isEqualToString:@"电视/播放器/DVD"])) {
                for (id xxx in aryValue) {
                    RoomDevice *rdTmp = [[RoomDevice alloc] init];
                    rdTmp.property = d.property;
                    rdTmp.contentArr = [[NSMutableArray alloc] initWithObjects:xxx, nil];
                    [r.deviceArr insertObject:rdTmp atIndex:i+1];
                }
                i += aryValue.count - 1;
                [r.deviceArr removeObject:d];
            }
            
            //若为场景类设备数组 则再去 取所有的 软场景放入aryDevice
            if ([d.property myContainsString:@"场景"]) {
////////////场景方式一 ： 只读取Room.json
//                if (aryValue.count > 0) {
//                    for (Scene *sence in aryValue) {
//                        sence.deviceArr = [CYM_DatabaseTable getSenceDeviceWithSenceID:sence.ID];
//                    }
//                }
//                else{
//                    [r.deviceArr removeObject: d];
//                }
////////////场景方式二：  读取Scene.json
           //接下：修订
            }
            ////////////得到Key
            d.contentArr = aryValue;
        }
    }
    /////////////////////////////修订 aryRoom 让数据源适应控制页面的UI
    /////1.合并 可调灯 非可调灯、开合窗帘 升降窗帘
    for (int i=0; i<aryRoom.count; i++) {
        Room *r = aryRoom[i];
        NSMutableArray *aryLight   = [NSMutableArray array];
        NSMutableArray *aryCurtain = [NSMutableArray array];

        for (int j=0; j<r.deviceArr.count;) {
            RoomDevice *rd = r.deviceArr[j];
            if ([rd.property myContainsString:@"灯"]){
                for (ControlDeviceContentValue *v in rd.contentArr) {
                    [aryLight addObject:v];
                }
                [r.deviceArr removeObject:rd];
            }
            else if ([rd.property myContainsString:@"窗帘"]){
                for (ControlDeviceContentValue *v in rd.contentArr) {
                    [aryCurtain addObject:v];
                }
                [r.deviceArr removeObject:rd];
            }else{
                j++;
            }
        }
        if (aryLight.count > 0) {
            RoomDevice *rdNew = [[RoomDevice alloc] init];
            rdNew.property    = @"非可调灯";
            rdNew.contentArr  = aryLight;
            [r.deviceArr insertObject:rdNew atIndex:0];
        }
        if (aryCurtain.count > 0) {
            RoomDevice *rdNew = [[RoomDevice alloc] init];
            rdNew.property    = @"升降窗帘";
            rdNew.contentArr  = aryCurtain;
            if (r.deviceArr.count >= 1) {
                [r.deviceArr insertObject:rdNew atIndex:1];
            }
            else{
                [r.deviceArr addObject:rdNew];
            }
        }
    }
    
    /////////////////////////////修订 aryRoom 让数据源适应控制页面的UI
    ////1.展开自定义设备
    for (int i=0; i<aryRoom.count; i++) {
        Room *r = aryRoom[i];
        for (int j=0; j<r.deviceArr.count; j++) {
            RoomDevice *rd = r.deviceArr[j];
            if ([rd.property isEqualToString:@"自定义设备"]) {
                NSMutableArray *aryNewRD = [NSMutableArray array];
                for (ControlDeviceContentValue *v in rd.contentArr) {
                    RoomDevice *newRD = [[RoomDevice alloc] init];
                    newRD.property    = rd.property;
                    newRD.contentArr  = [NSMutableArray arrayWithObject:v];
                    
                    [aryNewRD addObject:newRD];
                }
                [r.deviceArr removeObject:rd];
                [r.deviceArr insertObjects:aryNewRD atIndexes:[NSIndexSet indexSetWithIndexesInRange:NSMakeRange(j, aryNewRD.count)]];
            }
        }
    }
    
    /////////////////////////////错误的修订 aryRoom 让数据源适应Andorid的场景添加的BUG
    ///1.
    for (int i=0; i<aryRoom.count; i++) {
        Room *r = aryRoom[i];
        BOOL hasScene = NO;
        for (int j=0; j<r.deviceArr.count; j++) {
            RoomDevice *rd = r.deviceArr[j];
            if ([rd.property isEqualToString:@"场景控制器"]) {
                hasScene      = YES;
                rd.contentArr = [CYM_DatabaseTable getSenceWithRoomName:r.name];
                for (Scene *sence in rd.contentArr) {
                    sence.deviceArr = [CYM_DatabaseTable getSenceDeviceWithSenceID:sence.ID];
                }
            }
        }
        if (!hasScene) {
            RoomDevice *rdScene = [[RoomDevice alloc] init];
            rdScene.property    = @"场景控制器";
            rdScene.contentArr  = [CYM_DatabaseTable getSenceWithRoomName:r.name];
            for (Scene *sence in rdScene.contentArr) {
                sence.deviceArr = [CYM_DatabaseTable getSenceDeviceWithSenceID:sence.ID];
            }
            if(rdScene.contentArr.count > 0) {
                if (r.deviceArr.count == 0 || r.deviceArr == nil) {
                    r.deviceArr = [NSMutableArray new];
                    [r.deviceArr addObject:rdScene];
                }else {
                    [r.deviceArr insertObject:rdScene atIndex:r.deviceArr.count -1];
                }
            }
        }
    }
    ///////////////END
    
    return aryRoom;
}

+(NSArray *)getRoomTreeToContentName{
    //得到所有房间
    NSMutableArray *aryRoom = [CYM_DatabaseTable getRoom];
    for (Room *r in aryRoom) {
        //获取该房间的所有设备类别Property
        r.deviceArr = [CYM_DatabaseTable getRoomDeviceWithRoomID:r.ID];
        for (int i=0; i<r.deviceArr.count; i++) {
            RoomDevice *d = r.deviceArr[i];
            d.contentArr  = [CYM_DatabaseTable getContentNameWithRoomDeivceID:d.ID];
        }
    }
    return aryRoom;
}
///获取某房间的所有设备
+(NSArray *)getRoomDeviceValueWithName:(NSString *)name{
    NSMutableArray *aryDeviceValue = [[NSMutableArray alloc] init];
    aryDeviceValue = [CYM_DatabaseTable getDeviceValueWithRoomName:name];
    for (ControlDeviceContentValue *dv in aryDeviceValue) {
        dv.keyArr = [CYM_DatabaseTable getContrlKeyWithValueID:dv.ID];
    }
    return aryDeviceValue;
}
///获取设备所在的房间名称
+(NSString *)getRoomNameWithRoomDeviceName:(NSString *)deviceName{
    return [CYM_DatabaseTable getRoomNameWithRoomDeviceName:deviceName];
}

///移除房间中名称为XXX的设备
+(BOOL)deleteRoomDeviceContentWithName:(NSString *)name{
    return [CYM_DatabaseTable deleteRoomDeviceContentWithName:name];
}
+(BOOL)addRoomDeviceContentWithName:(NSString *)devName room:(NSString *) roomName{
    return [CYM_DatabaseTable addRoomDeviceContentWithName:devName room:roomName];
}
+ (NSMutableArray *)getAllDevice {
    return [CYM_DatabaseTable getAllDevice];
}
+ (BOOL)insertRoom:(Room *)room {
    return [CYM_DatabaseTable insertRoom:room];
}
+ (void)deleteRoomWithName:(NSString *)name {
    [CYM_DatabaseTable deleteRoomWithName:name];
}


#pragma mark Control

+(NSMutableArray *)getAlldeviceContentName{
    return [CYM_DatabaseTable getAlldeviceContent];
}

//////获取Controll
+(NSMutableArray *)getAllContrls{
    NSMutableArray *aryContrls = [CYM_DatabaseTable getAllContrls];
    for (Control *c in aryContrls) {
        c.deviceArr = [CYM_DatabaseTable getCtrlDeviceWithCtrlID:c.ID];
        for (ControlDevice *cd in c.deviceArr) {
            cd.contentArr = [CYM_DatabaseTable getContentWithDeviceID:cd.ID];
            for (ControlDeviceContent *cdc in cd.contentArr) {
                cdc.valueArr = [CYM_DatabaseTable getValuesWithContentID:cdc.ID];
                for (ControlDeviceContentValue *value in cdc.valueArr) {
                    value.keyArr = [CYM_DatabaseTable getContrlKeyWithValueID:value.ID];
                }
            }
        }
    }
    return aryContrls;
}
+(NSMutableArray *)getAlarmDevice{
    NSMutableArray *result = [NSMutableArray array];
    NSMutableArray *aryTMP = [CYM_DatabaseTable getAlarmDevice];
    for (ControlDeviceContentValue *v in aryTMP) {
        ControlDeviceContentValue *device = [self getDeviceDetailsWithDeviceName:v.name];
        [result addObject:device];
    }
    return result;
}
+(ControlDeviceContentValue *)getDeviceDetailsWithDeviceName:(NSString *)deviceName{
    return [CYM_DatabaseTable getDeviceDetailsWithDeviceName:deviceName];
}
///获取空调控制器的所有的已学习Key
+(NSMutableArray *)getCategoryAllKeyWithValue:(ControlDeviceContentValue *)value{
    ///////////1.通过valName获取多功能控制器的下的所有Value
    NSMutableArray *aryKey   = [NSMutableArray array];
    ///////////2.获取所有的多功能控制器的 设备
    NSMutableArray *aryValue = [CYM_DatabaseTable getTogetherCategoryValues:value.name];
    ///////////3.筛选出该多功能控制器 --  并找到所有 Key
    HE_CMDParser *cmdP = [[HE_CMDParser alloc] init];
    NSString *deviceNum = [cmdP getDeviceNumWithBindCMD:value.value];
    for (ControlDeviceContentValue *v in aryValue) {
        NSString *tmpNum = [cmdP getDeviceNumWithBindCMD:v.value];
        if ([deviceNum isEqualToString:tmpNum]) {
            NSMutableArray *aryTmp = [self getContrlKeyWithValueID:v.ID];
            for (ControlDeviceContentValueKey *k in aryTmp) {
                [aryKey addObject:k];
            }
        }
    }
    return aryKey;
}

+(NSMutableArray *)getContrlKeyWithValueID:(NSString *)valueID{
    return [CYM_DatabaseTable getContrlKeyWithValueID:valueID];
}
+(NSMutableArray *)getContrlKeyWithValueName:(NSString *)valueName{
    return [self getDeviceDetailsWithDeviceName:valueName].keyArr;
}
+(BOOL)updateContrlValueKeys:(NSArray *)aryKey ValueName:(NSString *)valName{
    return [CYM_DatabaseTable updateContrlValueKeys:aryKey ValueName:valName];
}
+(BOOL)updateDevicePriowith:(NSMutableArray *)arydeviceValue{
    return [CYM_DatabaseTable  updateDevicePriowith:arydeviceValue];
}
+(NSMutableArray *)getContrlValueWithProperty:(NSString *) property{
    return [CYM_DatabaseTable getContrlValueWithProperty:property];
}

+(BOOL)isQueryValue:(NSString *)value {
    
    return [CYM_DatabaseTable isQueryValue:value];
}
+ (NSMutableArray *)getAllAlarm {
    return [CYM_DatabaseTable getAllAlarm];
}
+ (SecurityContent_sensor *)getSensorFromName:(NSString *)name {
    return [CYM_DatabaseTable getsensorFromName:name];
}

#pragma mark Config
///获取某文件的版本号
+(NSInteger)getVersionWithFileName:(NSString *)fileName;{
    Config *config = [CYM_DatabaseTable getConfigWithName:fileName];
    return [config.version integerValue];

}

#pragma mark Scene
+(Scene *)getSenceWithSenceName:(NSString *)senceName{
    return [CYM_DatabaseTable getSenceWithSenceName:senceName];
}
+(NSMutableArray *)getAllSoftSence{
    return [CYM_DatabaseTable getAllSoftSence];
}
///获取所有的软硬场景数组
+(NSMutableArray *)getAllSoftHardScene{
    NSMutableArray *aryScene = [[NSMutableArray alloc] init];
    aryScene = [CYM_DatabaseTable getAllSoftHardScene];
    for (Scene *s in aryScene) {
        s.deviceArr = [CYM_DatabaseTable getSenceDeviceWithSenceID:s.ID];
    }
    return aryScene;
}
///获取Type=2的场景数组 ---Scene
+(NSMutableArray *)getAllOtherScene{
    NSMutableArray *aryScene = [[NSMutableArray alloc] init];
    aryScene = [CYM_DatabaseTable getAllOtherScene];
    for (Scene *s in aryScene) {
        s.deviceArr = [CYM_DatabaseTable getSenceDeviceWithSenceID:s.ID];
    }
    return aryScene;
}
//获取所有场景+防区模式
+(NSMutableArray *)getAllScene{
    NSMutableArray *aryHardSoft = [self getAllSoftHardScene];
    NSMutableArray *aryOther = [self getAllOtherScene];
    for (id obj in aryOther) {
        [aryHardSoft addObject:obj];
    }
    return aryHardSoft;
}

///删除场景
+(BOOL)deleteSceneWithSceneName:(NSString *)name{
    return [CYM_DatabaseTable deleteSceneWithSceneName:name];
}
///更新OR新增场景
+(BOOL)updateSceneWithName:(Scene *)scene{
    return [CYM_DatabaseTable updateSceneWithName:scene];
}
#pragma mark 定时
///获取定时信息
+(NSMutableArray *)getAllTimeInfo{
    NSMutableArray * fixTimeary = [[NSMutableArray alloc]init];
    fixTimeary = [CYM_DatabaseTable getAllFixTime];
    for(Crontab *r in fixTimeary){
        r.instructionsArr = [CYM_DatabaseTable getCrontabInstructionbycrontabId:r.crontabId];
    }
    return fixTimeary;
}
+(BOOL)deleteCrontabInfoByCrontabId:(NSString *)crontab_Id{
    return [CYM_DatabaseTable deleteCrontabByCrontabId:crontab_Id];
}
///新增or编辑定时
+(BOOL)addOrEditCrontabbycrontab:(Crontab *)crontab{
    return [CYM_DatabaseTable addOrEditCrontabwithcrontab:crontab];
}
///更新所有定时信息
+(BOOL)UpdeteAllCrontab:(NSMutableArray *)aryCrontab{
    return [CYM_DatabaseTable EditAllCrontab:aryCrontab];
}

#pragma IPC
+(NSMutableArray *)getAllIPCInfo{
    return [CYM_DatabaseTable getAllIPCInfo];
}

#pragma mark 防区
///获取所有传感器
+(NSMutableArray *)getAllSensorInfo{
    return [CYM_DatabaseTable GetAllsensor];
}
+(NSMutableArray *)getAllZoneInfo{
    return [CYM_DatabaseTable GetAllZone];
}
///获取防区传感器信息
+(NSMutableArray *)getZoneContentInfo{
    NSMutableArray * arySensorContent = [[NSMutableArray alloc]init];
    arySensorContent = [CYM_DatabaseTable GetAllZone];
    for(SecurityContent_zone *r in arySensorContent){
        r.sensorArr = [CYM_DatabaseTable getSensorFormZonewithcontentId:r.ID];
    }
    return arySensorContent;
}
///更新防区信息（状态）
+(BOOL)updateZoneInfo:(SecurityContent_zone *)zone{
    return [CYM_DatabaseTable updateZonewith:zone];
}
//设置界面更新防区
+ (BOOL)updateZoneSet:(SecurityContent_zone *)zone {
    return [CYM_DatabaseTable updateZoneSet:zone];
}
+(BOOL)deleteZoneIndfoByzoneId:(NSString*)zoneId{
    return  [CYM_DatabaseTable deleteZoneByzoneId:zoneId];
}
///更新传感器状态
+(BOOL)updeteSensorInfo:(SecurityContent_sensor *)sensor{
    return [CYM_DatabaseTable updateSensor:sensor];
}
///查询前500条报警信息
+(NSMutableArray *)getTop500SecurityNoteInfo{
    return [CYM_DatabaseTable GetAllSecurityNote];
}
///获取当前报警信息 最新日期
+(NSString *)getNewNoteDate{
    return [CYM_DatabaseTable getNewNoteDate];
}
///获取最新报警信息的个数
+(NSMutableArray *)getNewSecurtyNote:(NSString *)lastDate{
    return [CYM_DatabaseTable getNewSecurtyNote:lastDate];
}
+(NSMutableArray *)getAlarmNameWithZoneID:(NSString *)strZoneID{
    return [CYM_DatabaseTable getAlarmNameWithZoneID:strZoneID];
}
+(NSMutableArray *)getAlarmNameWithSensorMAC:(NSString *)strSensorMAC{
    return [CYM_DatabaseTable getAlarmNameWithSensorMAC:strSensorMAC];
}
+(NSMutableArray *)getAlarmNameWithNot24H{
    return [CYM_DatabaseTable getAlarmNameWithNot24H];
}
+(void)cancelSecrityNot24H{
    [CYM_DatabaseTable cancelSecrityNot24H];
}
+(NSString *)getSensorOrAlarmPriowithName:(NSString *)name{
    return [CYM_DatabaseTable getSensorOrAlarmPriowithName:name];
}
#pragma mark - 
#pragma mark Private Method

#pragma mark Parse JSON File
+(void)paserRoomWithPath:(NSString *)path{
    NSData * data = [[NSData alloc] initWithContentsOfFile:path];
    NSMutableArray * array = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
    [CYM_DatabaseTable deleteDataFromRoom];
    for (NSDictionary * dict in array){
        Room * room = [Room paserRoomWithDict:dict];
        [CYM_DatabaseTable insertToRoom:room];
    }
}

+(void)paserSceneWithPath:(NSString *)path{
    NSData * data = [[NSData alloc]initWithContentsOfFile:path];
    NSDictionary * dictionary = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
    [CYM_DatabaseTable deleteDataFromScene];
    [Scenes paserScenesWithDict:dictionary];
}

+(void)paserControlWithPath:(NSString *)path{
    NSData * data = [[NSData alloc]initWithContentsOfFile:path];
    NSMutableArray * mutableArr = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
    [CYM_DatabaseTable deleteDataFromControl];
    for (NSDictionary * dict in mutableArr){
        Control * control = [Control paserControlWithDict:dict];
        [CYM_DatabaseTable insertToControl:control];
    }
}

+(void)paserIpcWithPath:(NSString *)path{
    NSData * data = [[NSData alloc]initWithContentsOfFile:path];
    NSMutableArray * mutableArr = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments  error:nil];
    [CYM_DatabaseTable deleteDataFromIPC];
    for (NSDictionary * dict in mutableArr) {
        Ipc * ipc = [Ipc paserIpcWithDict:dict];
        [CYM_DatabaseTable insertToIpc:ipc];
    }
}

+(void)paserConfigWithPath:(NSString *)path{
    NSData * data = [[NSData alloc]initWithContentsOfFile:path];
    NSMutableArray * mutableArr = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments  error:nil];
    [CYM_DatabaseTable deleteDataFromConfig];
//    NSLog(@"%@", mutableArr);
    for (NSDictionary * dict in mutableArr) {
        Config * config = [Config paserConfigWithDict:dict];
        [CYM_DatabaseTable insertToConfig:config];
    }
}

+(void)paserCrontabWithPath:(NSString *)path{
    NSData * data = [[NSData alloc]initWithContentsOfFile:path];
    NSMutableArray * mutableArr = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
    [CYM_DatabaseTable deleteDataFromCrontab];
//    NSLog(@"%@", mutableArr);
    for (NSDictionary * dict in mutableArr) {
        Crontab * crontab = [Crontab paserCrontabWithDict:dict];
        [CYM_DatabaseTable insertToCrontab:crontab];
    }
}


+(void)paserSecuritynoteWithPath:(NSString *)path{
    NSData * data = [[NSData alloc]initWithContentsOfFile:path];
    NSMutableArray * mutableArr = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
    [CYM_DatabaseTable deleteDataFromSecurityNote];
    for (NSDictionary * dict in mutableArr) {
        SecurityNote * securityNote = [SecurityNote paserSecurityNoteWithDict:dict];
        if (!([CYM_DatabaseTable getDeviceNameById:securityNote.devMac] == nil || [[CYM_DatabaseTable getDeviceNameById:securityNote.devMac] isEqualToString:@""])) {
            [CYM_DatabaseTable insertToSecurityNote:securityNote];
        }
    }
}

+(void)paserSecurityWithPath:(NSString *)path{
    NSData * data = [[NSData alloc]initWithContentsOfFile:path];
    NSMutableArray * mutableArr = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
    [CYM_DatabaseTable deleteDataFromSecurity];
//    NSLog(@"%@", mutableArr);
    for (NSDictionary * dict in mutableArr) {
        Security * security = [Security paserSecurityWithDict:dict];
        [CYM_DatabaseTable insertToSecurity:security];
    }
}
//解析门锁
+ (void)paserDoorlockWithPath:(NSString *)path {
    NSData * data = [[NSData alloc]initWithContentsOfFile:path];
    NSMutableDictionary * mutableDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
    [CYM_DatabaseTable deleteDataFromDoorlock];
    NSLog(@"doorlock:%@", mutableDic);
    
    Door *door = [Door paserDoorWithDict:mutableDic];
    [CYM_DatabaseTable insertToDoorlock:door];

}
//解析门锁警告
+ (void)paserDoorlockNoteWithPath:(NSString *)path {
    NSData * data = [[NSData alloc]initWithContentsOfFile:path];
    NSMutableArray * mutableArr = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
    [CYM_DatabaseTable deleteDataFromDoorlockNote];
    NSLog(@"doorlockNote:%@", mutableArr);
    
    for (NSDictionary * dict in mutableArr) {
        DoorlockNote *note = [DoorlockNote paserSecurityWithDict:dict];
        
        NSString *devValue = [[HE_CMDBuilder new] getCMDWithAction:A4_ACTION_BIND_RE DeviceType:A4_DEVICE_DOORLOCK Data:[NSString stringWithFormat:@"00%@",note.devID]];
        NSString *doorName = [CYM_Engine getDevNameWithDevValue:devValue];
        
        if (!(doorName == nil || [doorName isEqualToString:@""])) {
            [CYM_DatabaseTable insertToDoorlockNote:note];
        }
    }

}
#pragma mark Generate JSON File
+(NSData *)generateRoomJSON{
    NSData *resultData;
//    NSArray *aryRoom = [self getRoomAllDevice];
    NSArray *aryRoom = [self getRoomTreeToContentName];
    //Room 数组
    NSMutableArray *tmpAryRoom = [[NSMutableArray alloc] init];
    for (Room *r in aryRoom) {
        NSLog(@"ROOM:%@", r.name);
        NSMutableDictionary *tmpDicRoom = [[NSMutableDictionary alloc] init];
        [tmpDicRoom setMayNilObject:r.name forKey:@"name"];
        [tmpDicRoom setMayNilObject:r.prio forKey:@"prio"];

        //Room内的Device 数组
        NSMutableArray *tmpAryRoomDevice = [[NSMutableArray alloc] init];
        for (RoomDevice *rm in r.deviceArr) {
            NSLog(@"RDevice:%@", rm.property);
            NSMutableDictionary *tmpDicRoomDevice = [[NSMutableDictionary alloc] init];
            [tmpDicRoomDevice setMayNilObject:rm.property forKey:@"property"];
            
            //Device内的 Content数组
            NSMutableArray *tmpAryDeviceContent = [[NSMutableArray alloc] init];
            for (id dev in rm.contentArr) {
                NSMutableDictionary *tmpDicDeviceContent = [[NSMutableDictionary alloc] init];
//                NSString *DevName = @"";
//                if ([dev respondsToSelector:@selector(name)]) {
//                    DevName = [dev performSelector:@selector(name)];
//                }
                [tmpDicDeviceContent setMayNilObject:dev forKey:@"name"];
                [tmpAryDeviceContent addObject:tmpDicDeviceContent];
            }
            [tmpDicRoomDevice setObject:tmpAryDeviceContent forKey:@"content"];
            [tmpAryRoomDevice addObject:tmpDicRoomDevice];
        }
        [tmpDicRoom setObject:tmpAryRoomDevice forKey:@"device"];
        [tmpAryRoom addObject:tmpDicRoom];
    }
    //解析为JSON文件
    NSMutableString *strJSON = [[NSMutableString alloc] init];
    [strJSON appendString:@"["];
    for (NSDictionary *dic in tmpAryRoom) {
        [strJSON appendString:[self parseDictionary:dic]];
        [strJSON appendString:@","];
    }
    //去掉 最后多余的 ',' 号
    char last = [strJSON characterAtIndex:strJSON.length - 1];
    if (last == ',') {
        strJSON = [[NSMutableString alloc] initWithString:[strJSON substringToIndex:strJSON.length - 1]];
    }
    [strJSON appendString:@"]"];
//    NSLog(@"Generate Room: %@", strJSON);
    resultData = [strJSON dataUsingEncoding:NSUTF8StringEncoding];
    return resultData;
}


+(NSData *)generateSceneSON{
    NSData *resultData;
    NSArray *aryScene = [self getAllScene];
    
    //Scene数组
    NSMutableArray *tmpAryScene = [[NSMutableArray alloc] init];
    for (Scene *s in aryScene) {
        NSMutableDictionary *tmpDicScene = [[NSMutableDictionary alloc] init];
        [tmpDicScene setMayNilObject:s.sceneId forKey:@"id"];
        [tmpDicScene setMayNilObject:s.name forKey:@"name"];
        [tmpDicScene setMayNilObject:s.isedit forKey:@"isedit"];
        [tmpDicScene setMayNilObject:s.status forKey:@"status"];
        [tmpDicScene setMayNilObject:s.delay forKey:@"delay"];
        [tmpDicScene setMayNilObject:s.scene forKey:@"scene"];
        [tmpDicScene setMayNilObject:s.prio forKey:@"prio"];
        [tmpDicScene setMayNilObject:s.type forKey:@"type"];
        [tmpDicScene setMayNilObject:s.room forKey:@"room"];
        
        //SceneDevice数组
        NSMutableArray *tmpArySceneDevice = [[NSMutableArray alloc] init];
        for (SceneDevice *sd in s.deviceArr) {
            NSMutableDictionary *tmpDicSceneDevice = [[NSMutableDictionary alloc] init];
            [tmpDicSceneDevice setMayNilObject:sd.interval forKey:@"interval"];
            [tmpDicSceneDevice setMayNilObject:sd.value forKey:@"value"];
            [tmpDicSceneDevice setMayNilObject:sd.operation forKey:@"operation"];
            [tmpDicSceneDevice setMayNilObject:sd.name forKey:@"name"];
            
            [tmpArySceneDevice addObject:tmpDicSceneDevice];
        }
        [tmpDicScene setObject:tmpArySceneDevice forKey:@"device"];
        [tmpAryScene addObject:tmpDicScene];
    }
    NSMutableDictionary *dicScene = [[NSMutableDictionary alloc] init];
    [dicScene setObject:tmpAryScene forKey:@"scenes"];
    //2.解析为JSON文件
    NSString *strJSON = [self parseDictionary:dicScene];
//    NSLog(@"Generate Scene: %@", strJSON);
    resultData = [strJSON dataUsingEncoding:NSUTF8StringEncoding];
    return resultData;
}

+(NSData *)generateControlJSON{
    NSData *resultData;
    //1.Contrl 数组 -> Device对象->Content对象->
    NSMutableArray *aryContrls = [self getAllContrls];
    NSMutableArray *aryResult  = [NSMutableArray array];
    for (Control *c in aryContrls) {
        NSMutableDictionary *dicCtrls = [NSMutableDictionary dictionary];
        [dicCtrls setMayNilObject:c.com forKey:@"com"];
        
        NSMutableArray *aryDeviceTmp  = [NSMutableArray array];
        for (ControlDevice *cd in c.deviceArr) {
            NSMutableDictionary *dicDevic = [NSMutableDictionary dictionary];
            [dicDevic setMayNilObject:cd.type forKey:@"type"];
            [dicDevic setMayNilObject:cd.method forKey:@"method"];
            [dicDevic setMayNilObject:cd.category forKey:@"category"];
            
            NSMutableArray *aryContentTmp = [NSMutableArray array];
            for (ControlDeviceContent *content in cd.contentArr) {
                NSMutableDictionary *dicContent = [NSMutableDictionary dictionary];
                [dicContent setMayNilObject:content.property forKey:@"property"];
                
                NSMutableArray *aryValueTmp = [NSMutableArray array];
                for (ControlDeviceContentValue *value in content.valueArr) {
                    NSMutableDictionary *dicValue = [NSMutableDictionary dictionary];
                    [dicValue setMayNilObject:value.prio forKey:@"prio"];
                    [dicValue setMayNilObject:value.value forKey:@"value"];
                    [dicValue setMayNilObject:value.name forKey:@"name"];
                    
                    NSMutableArray *aryKeyTmp = [NSMutableArray array];
                    for (ControlDeviceContentValueKey *key in value.keyArr) {
                        NSMutableDictionary *dicKey = [NSMutableDictionary dictionary];
                        [dicKey setMayNilObject:key.value forKey:@"value"];
                        if ([content.property isEqualToString:@"背景音乐"] || [cd.category isEqualToString:@"数据透传模块"] || [cd.category isEqualToString:@"默认设备"]) {
                            [dicKey setMayNilObject:key.time forKey:@"time"];
                        }
                        [dicKey setMayNilObject:key.backkey forKey:@"backkey"];
                        [dicKey setMayNilObject:key.query forKey:@"query"];
                        [dicKey setMayNilObject:key.name forKey:@"name"];
                        
                        [aryKeyTmp addObject:dicKey];
                    }
                    [dicValue setMayNilObject:aryKeyTmp forKey:@"key"];
                    [aryValueTmp addObject:dicValue];
                }
                [dicContent setMayNilObject:aryValueTmp forKey:@"value"];
                [aryContentTmp addObject:dicContent];
            }
            [dicDevic setMayNilObject:aryContentTmp forKey:@"content"];
            
            [aryDeviceTmp addObject:dicDevic];
        }
        [dicCtrls setMayNilObject:aryDeviceTmp forKey:@"device"];
        [aryResult addObject:dicCtrls];
    }
    if (aryContrls.count == 1) {
        NSMutableDictionary *dicCtrls = [NSMutableDictionary dictionary];
        [dicCtrls setMayNilObject:@"1" forKey:@"com"];//com
        NSMutableArray *aryDeviceTmp = [NSMutableArray new];//device
        NSMutableDictionary *dicDevic = [NSMutableDictionary dictionary];
        [dicDevic setMayNilObject:@"baiwei" forKey:@"type"];
        [dicDevic setMayNilObject:@"02" forKey:@"method"];
        [dicDevic setMayNilObject:@"默认设备" forKey:@"category"];
            
        NSMutableArray *aryContentTmp = [NSMutableArray array];
        NSArray *property = @[@"单体空调",@"中央空调",@"电视/播放器/DVD",@"背景音乐",@"自定义设备"];
        for (NSString *pro in property) {
            NSMutableDictionary *dicContent = [NSMutableDictionary dictionary];
            [dicContent setMayNilObject:pro forKey:@"property"];
            
            NSMutableArray *aryValueTmp = [NSMutableArray array];
            [dicContent setMayNilObject:aryValueTmp forKey:@"value"];
            [aryContentTmp addObject:dicContent];
        }
        [dicDevic setMayNilObject:aryContentTmp forKey:@"content"];
        [aryDeviceTmp addObject:dicDevic];
        [dicCtrls setMayNilObject:aryDeviceTmp forKey:@"device"];
        [aryResult addObject:dicCtrls];//添加
    }
    //解析为JSON文件
    NSMutableString *strJSON = [[NSMutableString alloc] init];
    [strJSON appendString:@"["];
    for (NSDictionary *dic in aryResult) {
        [strJSON appendString:[self parseDictionary:dic]];
        [strJSON appendString:@","];
    }
    //去掉 最后多余的 ',' 号
    char last = [strJSON characterAtIndex:strJSON.length - 1];
    if (last == ',') {
        strJSON = [[NSMutableString alloc] initWithString:[strJSON substringToIndex:strJSON.length - 1]];
    }
    [strJSON appendString:@"]"];
 //   NSLog(@"Generate Control: %@", strJSON);
    resultData = [strJSON dataUsingEncoding:NSUTF8StringEncoding];
    return resultData;
}

+(NSData *)generateIPCJSON{
    NSData *resultData;
    
    return resultData;
}

+(NSData *)generateConfigJSON{
    NSData *resultData;
    
    return resultData;
}

+(NSData *)generateCrontabJSON{
    NSData *resultData;
    NSArray *aryCrontab = [self getAllTimeInfo];
    //Crontab数组
    NSMutableArray *tmparyCrontab = [[NSMutableArray alloc] init];
    for (Crontab *s in aryCrontab) {
        NSMutableDictionary *tmpDicCrontab = [[NSMutableDictionary alloc] init];
        [tmpDicCrontab setMayNilObject:s.ID forKey:@"id"];
        [tmpDicCrontab setMayNilObject:s.date forKey:@"date"];
        [tmpDicCrontab setMayNilObject:s.time forKey:@"time"];
        [tmpDicCrontab setMayNilObject:s.status forKey:@"status"];
        [tmpDicCrontab setMayNilObject:s.scene forKey:@"scene"];
        [tmpDicCrontab setMayNilObject:s.repeat forKey:@"repeat"];
        [tmpDicCrontab setMayNilObject:s.name forKey:@"name"];
        //instruction数组
        NSMutableArray *tmpAryInstruction = [[NSMutableArray alloc] init];
        for (CrontabInstruction *sd in s.instructionsArr) {
            NSMutableDictionary *tmpDicInstruction = [[NSMutableDictionary alloc]init];
            [tmpDicInstruction setMayNilObject:sd.cmd forKey:@"cmd"];
            [tmpDicInstruction setMayNilObject:sd.delay forKey:@"delay"];
            
            [tmpAryInstruction addObject:tmpDicInstruction];
        }
        [tmpDicCrontab setObject:tmpAryInstruction forKey:@"instructions"];
        [tmparyCrontab addObject:tmpDicCrontab];
    }
    //解析为JSON文件
    NSMutableString *strJSON = [[NSMutableString alloc] init];
    [strJSON appendString:@"["];
    for (NSDictionary *dic in tmparyCrontab) {
        [strJSON appendString:[self parseDictionary:dic]];
        [strJSON appendString:@","];
    }
    //去掉 最后多余的 ',' 号
    char last = [strJSON characterAtIndex:strJSON.length - 1];
    if (last == ',') {
        strJSON = [[NSMutableString alloc] initWithString:[strJSON substringToIndex:strJSON.length - 1]];
    }
    [strJSON appendString:@"]"];
//    NSLog(@"Generate crontab: %@", strJSON);
    resultData = [strJSON dataUsingEncoding:NSUTF8StringEncoding];
    return resultData;
}

+(NSData *)generateSecuritynoteJSPN{
    NSData *resultData;
    
    return resultData;
}
+ (NSData *)generateSecuritySensorArr:(NSArray *)sceneA zoneArr:(NSArray *)zoneA {
    NSData *resultData;
    NSArray *aryZone = zoneA;
    NSArray *arySensor = sceneA;
    NSMutableArray *tmparySecurity = [[NSMutableArray alloc] init];
    //Zone数组
    NSMutableArray *tmparyZone = [[NSMutableArray alloc] init];
    for (SecurityContent_zone *z in aryZone) {
        NSMutableDictionary *tmpDicZone = [[NSMutableDictionary alloc] init];
        [tmpDicZone setMayNilObject:z.name forKey:@"name"];
        [tmpDicZone setMayNilObject:z.state forKey:@"state"];
        [tmpDicZone setMayNilObject:z.delay forKey:@"delay"];
        [tmpDicZone setMayNilObject:z.type forKey:@"type"];
        [tmpDicZone setMayNilObject:z.handled forKey:@"handled"];
        
        //sensor数组
        NSMutableArray *tmpArysensor = [[NSMutableArray alloc] init];
        for (SecurityContent_zone_sensor *sz in z.sensorArr) {
            NSMutableDictionary *tmpDiczon_sen = [[NSMutableDictionary alloc]init];
            [tmpDiczon_sen setMayNilObject:sz.state forKey:@"state"];
            [tmpDiczon_sen setMayNilObject:sz.type forKey:@"type"];
            [tmpDiczon_sen setMayNilObject:sz.mac forKey:@"mac"];
            [tmpDiczon_sen setMayNilObject:sz.name forKey:@"name"];
            
            [tmpArysensor addObject:tmpDiczon_sen];
        }
        [tmpDicZone setMayNilObject:tmpArysensor forKey:@"sensor"];
        [tmparyZone addObject:tmpDicZone];
    }
    NSMutableDictionary * temDicZone = [[NSMutableDictionary alloc]init];
    [temDicZone setObject:tmparyZone forKey:@"content"];
    [temDicZone setObject:@"zone" forKey:@"type"];
    
    
    ///传感器
    NSMutableArray *tmparySensor = [[NSMutableArray alloc] init];
    for(SecurityContent_sensor *ss in arySensor){
        NSMutableDictionary *tmpDicss = [[NSMutableDictionary alloc]init];
        [tmpDicss setMayNilObject:ss.sensorOldName forKey:@"sensorOldName"];
        [tmpDicss setMayNilObject:ss.minValue forKey:@"minValue"];
        [tmpDicss setMayNilObject:ss.alarmName forKey:@"alarmName"];
        [tmpDicss setMayNilObject:ss.sensorSignal forKey:@"sensorSignal"];
        [tmpDicss setMayNilObject:ss.sensorMac forKey:@"sensorMac"];
        [tmpDicss setMayNilObject:ss.powerMsg forKey:@"powerMsg"];
        [tmpDicss setMayNilObject:ss.alarmTime forKey:@"alarmTime"];
        [tmpDicss setMayNilObject:ss.isAlarm forKey:@"isAlarm"];
        [tmpDicss setMayNilObject:ss.alarmOldName forKey:@"alarmOldName"];
        [tmpDicss setMayNilObject:ss.alarmMsg forKey:@"alarmMsg"];
        [tmpDicss setMayNilObject:ss.sensorType forKey:@"sensorType"];
        [tmpDicss setMayNilObject:ss.alarmMac forKey:@"alarmMac"];
        [tmpDicss setMayNilObject:ss.alarmType forKey:@"alarmType"];
        [tmpDicss setMayNilObject:ss.sensorName forKey:@"sensorName"];
        [tmpDicss setMayNilObject:ss.isElectromic forKey:@"isElectronic"];
        [tmpDicss setMayNilObject:ss.maxValue forKey:@"maxValue"];
        [tmpDicss setMayNilObject:ss.ctrlValue forKey:@"ctrlValue"];
        [tmpDicss setMayNilObject:ss.sensor24h forKey:@"sensor24h"];
        [tmparySensor addObject:tmpDicss];
    }
    NSMutableDictionary * temDicSensor = [[NSMutableDictionary alloc]init];
    [temDicSensor setObject:tmparySensor forKey:@"content"];
    [temDicSensor setObject:@"sensor" forKey:@"type"];
    [tmparySecurity addObject:temDicSensor];
    [tmparySecurity addObject:temDicZone];
    
    //2.解析为JSON文件
    NSMutableString *strJSON = [[NSMutableString alloc] init];
    [strJSON appendString:@"["];
    for (NSDictionary *dic in tmparySecurity) {
        [strJSON appendString:[self parseDictionary:dic]];
        [strJSON appendString:@","];
    }
    //去掉 最后多余的 ',' 号
    char last = [strJSON characterAtIndex:strJSON.length - 1];
    if (last == ',') {
        strJSON = [[NSMutableString alloc] initWithString:[strJSON substringToIndex:strJSON.length - 1]];
    }
    [strJSON appendString:@"]"];
    //    NSLog(@"Generate Scene: %@", strJSON);
    resultData = [strJSON dataUsingEncoding:NSUTF8StringEncoding];
    return resultData;
}
+(NSData *)generateSecurityJSON{
    NSData *resultData;
    NSArray *aryZone = [self getZoneContentInfo];
    NSArray *arySensor = [self getAllSensorInfo];
    NSMutableArray *tmparySecurity = [[NSMutableArray alloc] init];
    //Zone数组
    NSMutableArray *tmparyZone = [[NSMutableArray alloc] init];
    for (SecurityContent_zone *z in aryZone) {
        NSMutableDictionary *tmpDicZone = [[NSMutableDictionary alloc] init];
        [tmpDicZone setMayNilObject:z.name forKey:@"name"];
        [tmpDicZone setMayNilObject:z.state forKey:@"state"];
        [tmpDicZone setMayNilObject:z.delay forKey:@"delay"];
        [tmpDicZone setMayNilObject:z.type forKey:@"type"];
        [tmpDicZone setMayNilObject:z.handled forKey:@"handled"];
        
        //sensor数组
        NSMutableArray *tmpArysensor = [[NSMutableArray alloc] init];
        for (SecurityContent_zone_sensor *sz in z.sensorArr) {
            NSMutableDictionary *tmpDiczon_sen = [[NSMutableDictionary alloc]init];
            [tmpDiczon_sen setMayNilObject:sz.state forKey:@"state"];
            [tmpDiczon_sen setMayNilObject:sz.type forKey:@"type"];
            [tmpDiczon_sen setMayNilObject:sz.mac forKey:@"mac"];
            [tmpDiczon_sen setMayNilObject:sz.name forKey:@"name"];
            
            [tmpArysensor addObject:tmpDiczon_sen];
        }
        [tmpDicZone setMayNilObject:tmpArysensor forKey:@"sensor"];
        [tmparyZone addObject:tmpDicZone];
    }
    NSMutableDictionary * temDicZone = [[NSMutableDictionary alloc]init];
    [temDicZone setObject:tmparyZone forKey:@"content"];
    [temDicZone setObject:@"zone" forKey:@"type"];


    ///传感器
    NSMutableArray *tmparySensor = [[NSMutableArray alloc] init];
    for(SecurityContent_sensor *ss in arySensor){
        NSMutableDictionary *tmpDicss = [[NSMutableDictionary alloc]init];
        [tmpDicss setMayNilObject:ss.sensorOldName forKey:@"sensorOldName"];
        [tmpDicss setMayNilObject:ss.minValue forKey:@"minValue"];
        [tmpDicss setMayNilObject:ss.alarmName forKey:@"alarmName"];
        [tmpDicss setMayNilObject:ss.sensorSignal forKey:@"sensorSignal"];
        [tmpDicss setMayNilObject:ss.sensorMac forKey:@"sensorMac"];
        [tmpDicss setMayNilObject:ss.powerMsg forKey:@"powerMsg"];
        [tmpDicss setMayNilObject:ss.alarmTime forKey:@"alarmTime"];
        [tmpDicss setMayNilObject:ss.isAlarm forKey:@"isAlarm"];
        [tmpDicss setMayNilObject:ss.alarmOldName forKey:@"alarmOldName"];
        [tmpDicss setMayNilObject:ss.alarmMsg forKey:@"alarmMsg"];
        [tmpDicss setMayNilObject:ss.sensorType forKey:@"sensorType"];
        [tmpDicss setMayNilObject:ss.alarmMac forKey:@"alarmMac"];
        [tmpDicss setMayNilObject:ss.alarmType forKey:@"alarmType"];
        [tmpDicss setMayNilObject:ss.sensorName forKey:@"sensorName"];
        [tmpDicss setMayNilObject:ss.isElectromic forKey:@"isElectronic"];
        [tmpDicss setMayNilObject:ss.maxValue forKey:@"maxValue"];
        [tmpDicss setMayNilObject:ss.ctrlValue forKey:@"ctrlValue"];
        [tmpDicss setMayNilObject:ss.sensor24h forKey:@"sensor24h"];
        [tmparySensor addObject:tmpDicss];
    }
    NSMutableDictionary * temDicSensor = [[NSMutableDictionary alloc]init];
    [temDicSensor setObject:tmparySensor forKey:@"content"];
    [temDicSensor setObject:@"sensor" forKey:@"type"];
    [tmparySecurity addObject:temDicSensor];
    [tmparySecurity addObject:temDicZone];

    //2.解析为JSON文件
    NSMutableString *strJSON = [[NSMutableString alloc] init];
    [strJSON appendString:@"["];
    for (NSDictionary *dic in tmparySecurity) {
        [strJSON appendString:[self parseDictionary:dic]];
        [strJSON appendString:@","];
    }
    //去掉 最后多余的 ',' 号
    char last = [strJSON characterAtIndex:strJSON.length - 1];
    if (last == ',') {
        strJSON = [[NSMutableString alloc] initWithString:[strJSON substringToIndex:strJSON.length - 1]];
    }
    [strJSON appendString:@"]"];
//    NSLog(@"Generate Scene: %@", strJSON);
    resultData = [strJSON dataUsingEncoding:NSUTF8StringEncoding];
    return resultData;
}
+ (NSData *)generateDoorlockJSON {
    NSData *resultData;
    NSMutableArray *allUser = [NSMutableArray new];
    //遍历数组，获得内部的单个字典
    for (DoorlockUser *user in [CYM_Engine getAllDoorlockUser]) {
        NSMutableDictionary *dic = [NSMutableDictionary new];
        [dic setMayNilObject:user.userID forKey:@"id"];
        [dic setMayNilObject:user.userAnotherName forKey:@"member_role"];
        [dic setMayNilObject:user.userLandingName forKey:@"user_name"];
        [allUser addObject:dic];
    }
    
    NSMutableDictionary *dic = [NSMutableDictionary new];
    [dic setMayNilObject:allUser forKey:@"doorlock_users"];
    
    //解析为JSON文件
    NSMutableString *strJSON = [[NSMutableString alloc] init];
//    [strJSON appendString:@"["];
//    for (NSDictionary *dic in allUser) {
        [strJSON appendString:[self parseDoorlockDictionary:dic]];
        [strJSON appendString:@","];
//    }
    //去掉 最后多余的 ',' 号
    char last = [strJSON characterAtIndex:strJSON.length - 1];
    if (last == ',') {
        strJSON = [[NSMutableString alloc] initWithString:[strJSON substringToIndex:strJSON.length - 1]];
    }
//    [strJSON appendString:@"]"];
    NSLog(@"门锁用户: %@", strJSON);
    resultData = [strJSON dataUsingEncoding:NSUTF8StringEncoding];
    return resultData;
}

#pragma mark 字典保存为JSON文件
//由于解析的时候，id需要为整形，为了避免出现问题，重新为doorlock写了一个解析方法
+ (NSString *)parseDoorlockDictionary:(NSDictionary *)dic{
    NSMutableString *resultStr  = [[NSMutableString alloc] init];
    ///解析Dictionary
    NSArray* key1 = [dic allKeys];
    [resultStr appendString:@"{"];
    for (NSString *k1 in key1) {
        id obj = [dic objectForKey:k1];
        //判断是否为数组
        [resultStr appendFormat:@"\"%@\":", k1];
        if ([obj isKindOfClass:[NSArray class]]) {
            [resultStr appendString:@"["];
            for (NSDictionary *d in obj) {
                [resultStr appendString:[self parseDoorlockDictionary:d]];
                [resultStr appendString:@","];
            }
            //去掉 最后多余的 ',' 号
            char last = [resultStr characterAtIndex:resultStr.length - 1];
            if (last == ',') {
                resultStr = [[NSMutableString alloc] initWithString:[resultStr substringToIndex:resultStr.length - 1]];
            }
            [resultStr appendString:@"],"];
        }
        else{
            if ([k1 isEqualToString:@"id"]) {
                [resultStr appendFormat:@"%@,",obj];
            }
            else {
                [resultStr appendFormat:@"\"%@\",", obj];
            }
        }
    }
    //去掉 最后多余的 ',' 号
    char last = [resultStr characterAtIndex:resultStr.length - 1];
    if (last == ',') {
        resultStr = [[NSMutableString alloc] initWithString:[resultStr substringToIndex:resultStr.length - 1]];
    }
    [resultStr appendString:@"}"];
    return resultStr;
}

+ (NSString *)parseDictionary:(NSDictionary *)dic{
    NSMutableString *resultStr  = [[NSMutableString alloc] init];
    ///解析Dictionary
    NSArray* key1 = [dic allKeys];
    [resultStr appendString:@"{"];
    for (NSString *k1 in key1) {
        id obj = [dic objectForKey:k1];
        //判断是否为数组
        [resultStr appendFormat:@"\"%@\":", k1];
        if ([obj isKindOfClass:[NSArray class]]) {
            [resultStr appendString:@"["];
            for (NSDictionary *d in obj) {
                [resultStr appendString:[self parseDictionary:d]];
                [resultStr appendString:@","];
            }
            //去掉 最后多余的 ',' 号
            char last = [resultStr characterAtIndex:resultStr.length - 1];
            if (last == ',') {
                resultStr = [[NSMutableString alloc] initWithString:[resultStr substringToIndex:resultStr.length - 1]];
            }
            [resultStr appendString:@"],"];
        }
        else{
            [resultStr appendFormat:@"\"%@\",", obj];
        }
    }
    //去掉 最后多余的 ',' 号
    char last = [resultStr characterAtIndex:resultStr.length - 1];
    if (last == ',') {
        resultStr = [[NSMutableString alloc] initWithString:[resultStr substringToIndex:resultStr.length - 1]];
    }
    [resultStr appendString:@"}"];
    return resultStr;
}
//////////////房型专用
+(NSMutableArray *)getALLHouseUrl{
    return [CYM_DatabaseTable getALLHouseUrl];
}
+(void)insertHouse:(House *)house{
    [CYM_DatabaseTable insertHouse:house];
}
+(NSMutableArray *)getAllDevicelocationByhouseName:(NSString *)houseName{

    return [CYM_DatabaseTable getAllDevicelocationByhouseName:houseName];
}
+(House *)getHouseByHouseName:(NSString *)housename{
    return [CYM_DatabaseTable getHouseByHouseName:housename];
}
+(void)deleteHouse:(NSString *)housename{
    [CYM_DatabaseTable deleteHouse:housename];
}
+(void)insertHouseInfo:(HouseDevice *)houseDevice{
    [CYM_DatabaseTable insertHouseInfo:houseDevice];
}
+(BOOL)deleteHouseInfoByDeviceName:(NSString *)deviceName{
    return [CYM_DatabaseTable deleteHouseInfoByDeviceName:deviceName];
}
+(BOOL)deleteHouseInfoByHouseName:(NSString *)houseName{
    return [CYM_DatabaseTable deleteHouseInfoByHouseName:houseName];
}
#pragma mark -门锁
//获取所有门锁
+ (NSMutableArray *)getAllDoorlockName {
    return [CYM_DatabaseTable getAllDoorlockName];
}
+ (NSMutableArray *)getAllDoorlockSet {
    return [CYM_DatabaseTable getAllDoorlockSet];
}
+ (NSMutableArray *)getNewDoorlockNote:(NSString *)lastDate {
    return [CYM_DatabaseTable getNewDoorlockNote:lastDate];
}
+ (NSString *)getNewDoorlockNoteDate {
    return [CYM_DatabaseTable getNewDoorlockNoteDate];
}
+ (NSMutableArray *)getTop500DoorlockNoteInfo {
    return [CYM_DatabaseTable getLatest500DoorlockNote];
}
+ (DoorlockUser *)getNameWithUserID:(NSString *)userID {
    return [CYM_DatabaseTable getNameWithUserID:userID];
}
+ (NSString *)getDevNameWithDevValue:(NSString *)devValue {
    return [CYM_DatabaseTable getDevNameWithDevValue:devValue];
}
+ (Doorlock *)getDoorlockSetWithName:(NSString *)name {
    NSString *value = [CYM_DatabaseTable getDoorlockValueWithDoorName:name];
    if (value.length < 18) {
        return nil;
    }
    NSRange range;
    range.location = 12;
    range.length =  6;
    NSString *devID = [value substringWithRange:range];
//    Doorlock *d = [Doorlock new];
//    d.enterScene = @"测试";
//    d.leaveScene = @"测试";
//    d.enterSecutityZone = @"离家模式";
//    d.leaveSecutityZone = @"离家模式";
//    return d;
    return [CYM_DatabaseTable getDoorlockWithDoorDevID:devID];
}
+ (DoorlockUser *)getUserWithUserLoadName:(NSString *)loadName {
    return [CYM_DatabaseTable getUserWithLoadName:loadName];
}
+ (BOOL)saveUserToDataBase:(DoorlockUser *)user {
    return [CYM_DatabaseTable saveUserToDataBase:user];
}
+ (BOOL)deleteUserWithLoadName:(NSString *)loadName {
    return [CYM_DatabaseTable deleteUserWithLoadName:loadName];
}
+ (NSMutableArray *)getAllDoorlockUser {
    return [CYM_DatabaseTable getAllDoorlockUser];
}
@end
