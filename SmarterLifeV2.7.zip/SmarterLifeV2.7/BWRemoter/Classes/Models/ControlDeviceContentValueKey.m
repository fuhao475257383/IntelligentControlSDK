//
//  ControlDeviceContentValueKey.m
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "ControlDeviceContentValueKey.h"
#import "CYM_DatabaseTable.h"

@implementation ControlDeviceContentValueKey

+(ControlDeviceContentValueKey *)paserControlDeviceContentValueKeyWithDict:(NSDictionary *)dict
                                                               withValueID:(NSString *)valueID
                                                             withContentID:(NSString *)contentID
                                                              withDeviceID:(NSString *)deviceID
                                                             withControlID:(NSString *)controlId
{
    ControlDeviceContentValueKey * controlDeviceContentValueKey = [[ControlDeviceContentValueKey alloc]init];
    controlDeviceContentValueKey.ID = [CYM_DatabaseTable GenerateGUID];
    controlDeviceContentValueKey.value = dict [@"value"];
    controlDeviceContentValueKey.backkey = dict[@"backkey"];
    controlDeviceContentValueKey.query= dict[@"query"];
    controlDeviceContentValueKey.name = dict[@"name"];
    controlDeviceContentValueKey.time = dict[@"time"];
    
    return controlDeviceContentValueKey;
}


-(NSString *)description{
    return [NSString stringWithFormat:@"name:%@ value:%@",self.name, self.value];
}
@end
