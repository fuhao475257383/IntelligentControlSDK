//
//  ControlDeviceContent.h
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ControlDeviceContent : NSObject
@property(nonatomic,copy)NSString *ID;
@property(nonatomic,copy)NSString * property;
@property(nonatomic,retain)NSMutableArray * valueArr;


+(ControlDeviceContent *)paserControlDeviceContentWithDict:(NSDictionary *)dict andDeviceID:(NSString *)deviceID andControlID:(NSString *)controlID;

@end
