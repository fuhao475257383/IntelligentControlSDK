//
//  DoorlockNote.h
//  BWRemoter
//
//  Created by tc on 15/11/16.
//  Copyright © 2015年 ReSun. All rights reserved.
//

//该类用于记录门锁通知

#import <Foundation/Foundation.h>

@interface DoorlockNote : NSObject

//时间
@property (nonatomic,strong) NSString *alarmTime;
//门锁编号
@property (nonatomic,strong) NSString *devID;
//门锁操作
@property (nonatomic,strong) NSString *operateNum;
//门锁角色
@property (nonatomic,strong) NSString *partNum;
//低压报警
@property (nonatomic,strong) NSString *powerMsg;
//门锁动作报警
@property (nonatomic,strong) NSString *alarmMsg;

+ (DoorlockNote *)paserSecurityWithDict:(NSDictionary *)dict;

@end
