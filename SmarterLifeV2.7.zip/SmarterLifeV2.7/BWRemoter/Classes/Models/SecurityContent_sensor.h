//
//  SecurityContent_sensor.h
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SecurityContent_sensor : NSObject
@property(nonatomic,copy)NSString * ID;
@property(nonatomic,copy)NSString * sensorName;
@property(nonatomic,copy)NSString * sensorOldName;
@property(nonatomic,copy)NSString * sensorMac;
@property(nonatomic,copy)NSString * sensorType;
@property(nonatomic,copy)NSString * sensorSignal;
@property(nonatomic,copy)NSString * sensor24h;
@property(nonatomic,copy)NSString * minValue;
@property(nonatomic,copy)NSString * maxValue;
@property(nonatomic,copy)NSString * ctrlValue;
@property(nonatomic,copy)NSString * alarmName;
@property(nonatomic,copy)NSString * alarmOldName;
@property(nonatomic,copy)NSString * alarmMac;
@property(nonatomic,copy)NSString * alarmType;
@property(nonatomic,copy)NSString * alarmTime;
@property(nonatomic,copy)NSString * isElectromic;
@property(nonatomic,copy)NSString * isAlarm;
@property(nonatomic,copy)NSString * alarmMsg;
@property(nonatomic,copy)NSString * powerMsg;

+(SecurityContent_sensor *)paserSecurityContent_sensorWithDict:(NSDictionary *)dict withSecurityID:(NSString *)securityID;

@end
