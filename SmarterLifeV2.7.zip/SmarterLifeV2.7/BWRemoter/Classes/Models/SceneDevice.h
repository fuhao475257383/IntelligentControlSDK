//
//  SceneDevice.h
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SceneDevice : NSObject
@property(nonatomic,copy)NSString * ID;
@property(nonatomic,copy)NSString * interval;
@property(nonatomic,copy)NSString * value;
@property(nonatomic,copy)NSString * operation;
@property(nonatomic,copy)NSString * name;


+(SceneDevice *)paserSceneDeviceWithDict:(NSDictionary *)dict;

@end
