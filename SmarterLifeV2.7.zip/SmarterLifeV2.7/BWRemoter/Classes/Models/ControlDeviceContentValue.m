//
//  ControlDeviceContentValue.m
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "ControlDeviceContentValue.h"
#import "ControlDeviceContentValueKey.h"
#import "CYM_DatabaseTable.h"

@implementation ControlDeviceContentValue

+(ControlDeviceContentValue *)paserControlDeviceContentValueWithDict:(NSDictionary *)dict
                                                       withContentID:(NSString *)contentID
                                                        withDeviceID:(NSString *)deviceID
                                                       withControlID:(NSString *)controlID
{
    ControlDeviceContentValue * controlDeviceContentValue = [[ControlDeviceContentValue alloc]init];
    controlDeviceContentValue.keyArr = [[NSMutableArray alloc]init];
    controlDeviceContentValue.ID = [CYM_DatabaseTable GenerateGUID];
    controlDeviceContentValue.prio = dict[@"prio"];
    controlDeviceContentValue.value = dict[@"value"];
    controlDeviceContentValue.name = dict[@"name"];
    NSMutableArray * mutableArr = dict[@"key"];

    for (NSDictionary * dict in mutableArr) {

        ControlDeviceContentValueKey *controlDeviceContentValueKey =
            [ControlDeviceContentValueKey paserControlDeviceContentValueKeyWithDict:dict
                                                                        withValueID:controlDeviceContentValue.ID
                                                                      withContentID:contentID
                                                                       withDeviceID:deviceID
                                                                      withControlID:controlID];
        
        [CYM_DatabaseTable insertToControlDeviceContentValueKey:controlDeviceContentValueKey
                                                     andValueID:controlDeviceContentValue.ID
                                                   andContentID:contentID
                                                    andDeviceID:deviceID
                                                   andControlID:controlID];
        [controlDeviceContentValue.keyArr addObject:controlDeviceContentValueKey];
    }

    return controlDeviceContentValue;
}

@end
