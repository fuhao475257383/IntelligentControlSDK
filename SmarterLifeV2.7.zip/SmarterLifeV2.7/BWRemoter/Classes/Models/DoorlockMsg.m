//
//  DoorlockMsg.m
//  BWRemoter
//
//  Created by tc on 15/11/19.
//  Copyright © 2015年 ReSun. All rights reserved.
//

#import "DoorlockMsg.h"

@interface DoorlockMsg ()
//状态数组
@property (nonatomic,strong) NSDictionary *DSD;
//角色数组
@property (nonatomic,strong) NSDictionary *OPD;
//电压数组
@property (nonatomic,strong) NSDictionary *PND;
//报警数组
@property (nonatomic,strong) NSDictionary *AND;
@end

@implementation DoorlockMsg

- (NSArray *)DSD {
    if (_DSD == nil) {
        _DSD = @{@"00":@"钥匙开门",@"01":@"密码开门",@"02":@"指纹开门",@"03":@"家庭网关开门",@"04":@"卡开门",@"80":@"关门",@"81":@"门未关好",@"82":@"离家"};
    }
    return _DSD;
}
- (NSDictionary *)OPD {
    if (_OPD == nil) {
        _OPD = @{@"00":@"男主人",@"01":@"女主人",@"02":@"小孩",@"03":@"保姆",@"04":@"朋友",@"05":@"亲戚",@"06":@"老人",@"07":@"其它"};
    }
    return _OPD;
}
- (NSDictionary *)PND {
    if (_PND == nil) {
        _PND = @{@"00":@"正常",@"11":@"低压警告",@"22":@"低压严重警告"};
    }
    return _PND;
}
- (NSDictionary *)AND {
    if (_AND == nil) {
        _AND = @{@"00":@"正常",@"01":@"挟持报警",@"02":@"防撬报警",@"03":@"密码输入错误报警",@"04":@"其它报警"};
    }
    return _AND;
}
- (void)getDoorlockMsgWithCMD:(NSString *)CMD {
    if (CMD.length < 8) {
        return;
    }
    //这是门状态的字典key数组，number:所有key，validNumber：有效的，和开门角色相关
    NSArray *number = @[@"00",@"01",@"02",@"03",@"04",@"80",@"81",@"82"];
    NSArray *validNumber = @[@"00",@"01",@"02",@"03",@"04"];
    NSRange range;
    range.location = 0;
    range.length =  2;
    for (NSString *num in number) {
        if ([num isEqualToString:[CMD substringWithRange:range]]) {
            self.doorState = [self.DSD objectForKey:[CMD substringWithRange:range]];
        }
    }
    if (self.doorState == nil) {
        self.doorState = @"其它";
    }
    for (NSString *num in validNumber) {
        if ([num isEqualToString:[CMD substringWithRange:range]]) {
            range.location = 2;
            self.openRole = [self.OPD objectForKey:[CMD substringWithRange:range]];
            self.isDoorOpen = YES;
        }
    }
    if (self.openRole == nil) {
        self.openRole = @"无效字节";
    }
    range.location = 4;
    self.powerNote = [self.PND objectForKey:[CMD substringWithRange:range]];
    range.location = 6;
    self.alarmNote = [self.AND objectForKey:[CMD substringWithRange:range]];
}
+ (NSString *)getAlarmNoteWithNmuber:(NSString *)number {
    NSString *newNumber;
    if (number.length == 1) {
        newNumber = [NSString stringWithFormat:@"0%@",number];
    }
    else {
        newNumber = number;
    }
    NSDictionary *dic = @{@"00":@"正常",@"01":@"挟持报警",@"02":@"防撬报警",@"03":@"密码输入错误报警",@"04":@"其它报警"};
    return [dic objectForKey:newNumber];
}
+ (NSString *)getOperateRoleWithNumber:(NSString *)number {
    NSString *newNumber;
    if (number.length == 1) {
        newNumber = [NSString stringWithFormat:@"0%@",number];
    }
    else {
        newNumber = number;
    }
    NSDictionary *dic = @{@"00":@"男主人",@"01":@"女主人",@"02":@"小孩",@"03":@"保姆",@"04":@"朋友",@"05":@"亲戚",@"06":@"老人",@"07":@"其它",@"ff":@"未知角色"};
    return [dic objectForKey:newNumber];
}
+ (NSString *)getOpenroleWithNumber:(NSString *)number {
        NSString *newNumber;
        if (number.length == 1) {
            newNumber = [NSString stringWithFormat:@"0%@",number];
        }
        else {
            newNumber = number;
        }
    NSDictionary *dic = @{@"00":@"钥匙开门",@"01":@"密码开门",@"02":@"指纹开门",@"03":@"家庭网关开门",@"04":@"卡开门",@"80":@"关门",@"81":@"门未关好",@"82":@"离家"};
    return [dic objectForKey:newNumber];
}
+ (NSString *)getPowerNoteWithNmuber:(NSString *)number {
        NSString *newNumber;
        if (number.length == 1) {
            newNumber = [NSString stringWithFormat:@"0%@",number];
        }
        else {
            newNumber = number;
        }
    NSDictionary *dic = @{@"00":@"正常",@"11":@"低压警告",@"22":@"低压严重警告"};
    return [dic objectForKey:newNumber];
}
@end
