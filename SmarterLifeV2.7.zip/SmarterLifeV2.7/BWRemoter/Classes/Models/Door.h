//
//  Door.h
//  BWRemoter
//
//  Created by tc on 15/11/16.
//  Copyright © 2015年 ReSun. All rights reserved.
//

//该类用于解析json后，暂时存储数据用的

#import <Foundation/Foundation.h>
#import "Doorlock.h"
#import "DoorlockUser.h"

@interface Door : NSObject

@property (nonatomic,strong) NSMutableArray *doorlockArr;
@property (nonatomic,strong) NSMutableArray *doorlockUserArr;

//解析
+(Door *)paserDoorWithDict:(NSDictionary *)dict;

@end
