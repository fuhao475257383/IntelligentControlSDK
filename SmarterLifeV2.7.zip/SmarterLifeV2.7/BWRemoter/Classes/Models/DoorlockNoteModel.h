//
//  DoorlockNoteModel.h
//  BWRemoter
//
//  Created by tc on 15/11/23.
//  Copyright © 2015年 ReSun. All rights reserved.
//

//该类是记录中，每一行的数据MODEL

//该数据模型用于记录中，每一行的数据
#import <Foundation/Foundation.h>
#import "DoorlockNote.h"
#import "DoorlockMsg.h"
#import "HE_CMDBuilder.h"
#import "CYM_Engine.h"

@interface DoorlockNoteModel : NSObject

@property (nonatomic,strong) NSString *time;
@property (nonatomic,strong) NSString *role;
@property (nonatomic,strong) NSString *doorlock;
@property (nonatomic,strong) NSString *event;
//是否需要显示红色字体
@property (nonatomic) BOOL isNeedShowRedWord;

+ (NSMutableArray *)paserDoorlockNoteModelWithNote:(NSMutableArray *)note;

@end
