//
//  DoorlockMsg.h
//  BWRemoter
//
//  Created by tc on 15/11/19.
//  Copyright © 2015年 ReSun. All rights reserved.
//

//该类用于解析命令所用

#import <Foundation/Foundation.h>

@interface DoorlockMsg : NSObject
//门状态
@property (nonatomic,strong) NSString *doorState;
//开门角色
@property (nonatomic,strong) NSString *openRole;
//电压指示
@property (nonatomic,strong) NSString *powerNote;
//报警指示
@property (nonatomic,strong) NSString *alarmNote;
//UI界面门的显示
@property (nonatomic) BOOL isDoorOpen;
//获得门锁所有指示
- (void)getDoorlockMsgWithCMD:(NSString *)CMD;
//获得操作
+ (NSString *)getOpenroleWithNumber:(NSString *)number;
//获得操作角色
+ (NSString *)getOperateRoleWithNumber:(NSString *)number;
//获得电压指示
+ (NSString *)getPowerNoteWithNmuber:(NSString *)number;
//获得报警指示
+ (NSString *)getAlarmNoteWithNmuber:(NSString *)number;

@end
