//
//  SecurityNote.m
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "SecurityNote.h"
#import "CYM_DatabaseTable.h"
@implementation SecurityNote

+(SecurityNote *)paserSecurityNoteWithDict:(NSDictionary *)dict
{
    SecurityNote * securityNote = [[SecurityNote alloc]init];
    securityNote.ID = [CYM_DatabaseTable GenerateGUID];
    securityNote.alarmTime = dict[@"alarmTime"];
    securityNote.alarmType = dict[@"alarmType"];
    securityNote.devMac = dict[@"devMac"];
    return securityNote;
}

@end
