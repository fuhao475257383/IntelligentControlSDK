//
//  DoorlockUser.m
//  BWRemoter
//
//  Created by tc on 15/11/16.
//  Copyright © 2015年 ReSun. All rights reserved.
//

#import "DoorlockUser.h"

@implementation DoorlockUser

+ (DoorlockUser *)paserDoorlockUserWithDict:(NSDictionary *)dict {
    DoorlockUser *user = [DoorlockUser new];
    user.userLandingName = dict[@"user_name"];
    user.userID = dict[@"id"];
    user.userAnotherName = dict[@"member_role"];
    return user;
}

@end
