//
//  Config.h
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Config : NSObject

@property(nonatomic,copy)NSString * ID;
@property(nonatomic,copy)NSString * name;
@property(nonatomic,copy)NSString * version;


+(Config *)paserConfigWithDict:(NSDictionary * )dict;

@end
