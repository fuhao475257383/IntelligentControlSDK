//
//  DoorlockUser.h
//  BWRemoter
//
//  Created by tc on 15/11/16.
//  Copyright © 2015年 ReSun. All rights reserved.
//

//该类是为用户添加别名的MODEL

#import <Foundation/Foundation.h>

@interface DoorlockUser : NSObject

//用户名
@property (nonatomic,strong) NSString *userLandingName;
//用户id
@property (nonatomic,strong) NSString *userID;
//用户别名
@property (nonatomic,strong) NSString *userAnotherName;

//@property(nonatomic,copy)NSString * ID;//用于 查询

//解析
+(DoorlockUser *)paserDoorlockUserWithDict:(NSDictionary *)dict;

@end
