//
//  SecurityNote.h
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SecurityNote : NSObject
@property(nonatomic,copy)NSString * ID;
@property(nonatomic,copy)NSString * alarmTime;
@property(nonatomic,copy)NSString * alarmType;
@property(nonatomic,copy)NSString * devMac;


+(SecurityNote *)paserSecurityNoteWithDict:(NSDictionary *)dict;


@end
