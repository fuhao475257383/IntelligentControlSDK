//
//  ControlDevice.h
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ControlDevice : NSObject
@property(nonatomic,copy)NSString *ID;
@property(nonatomic,copy)NSString *type;
@property(nonatomic,copy)NSString * method;
@property(nonatomic,copy)NSString * category;
@property(nonatomic,retain)NSMutableArray * contentArr;

+(ControlDevice *)paserControlDeviceWithDict:(NSDictionary *)dict withControlID:(NSString *)controlID;

@end
