//
//  SecurityContent_zone_sensor.m
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "SecurityContent_zone_sensor.h"
#import "CYM_DatabaseTable.h"

@implementation SecurityContent_zone_sensor

+(SecurityContent_zone_sensor *)paserSecurityContent_zone_sensorWithDict:(NSDictionary *)dict withContentID:(NSString *)contentID withSecurityID:(NSString *)securityID
{
    SecurityContent_zone_sensor * securityContent_zone_sensor = [[SecurityContent_zone_sensor alloc]init];
    securityContent_zone_sensor.ID = [CYM_DatabaseTable GenerateGUID];
    securityContent_zone_sensor.name = dict[@"name"];
    securityContent_zone_sensor.mac = dict[@"mac"];
    securityContent_zone_sensor.type = dict[@"type"];
    securityContent_zone_sensor.state= dict[@"state"];
    securityContent_zone_sensor.contentId = contentID;
    
    return securityContent_zone_sensor;
}
-(id)copyWithZone:(NSZone*)zone{
    SecurityContent_zone_sensor *copy = [[[self class] allocWithZone:zone] init];
    copy.ID = self.ID;
    copy.name = self.name;
    copy.state = self.state;
    copy.mac = self.mac;
    copy.type = self.type;
    copy.contentId = self.contentId;
    return copy;
}
@end
