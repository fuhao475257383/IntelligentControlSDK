//
//  CrontabInstruction.h
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CrontabInstruction : NSObject

@property(nonatomic,copy)NSString * ID;
@property(nonatomic,copy)NSString * cmd;
@property(nonatomic,copy)NSString * delay;

+(CrontabInstruction *)paserCrontabInstructionWithDict:(NSDictionary *)dict;
@end
