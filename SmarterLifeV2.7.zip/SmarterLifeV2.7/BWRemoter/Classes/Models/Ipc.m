//
//  Ipc.m
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "Ipc.h"
#import "CYM_DatabaseTable.h"

@implementation Ipc

+(Ipc *)paserIpcWithDict:(NSDictionary *)dict
{
    Ipc * ipc   = [[Ipc alloc]init];
    ipc.ID      = [CYM_DatabaseTable GenerateGUID];
    ipc.name    = dict[@"name"];
    ipc.android = dict[@"android"];
    ipc.IOS     = dict[@"IOS"];
    ipc.package = dict[@"package"];
    
    
    ipc.androidActivity = dict[@"androidActivity"];
    ipc.IOS2     = dict[@"IOS2"];
    ipc.addState = dict[@"addState"];
    ipc.IOSto    = dict[@"IOSto"];
    
    return ipc;
}

@end
