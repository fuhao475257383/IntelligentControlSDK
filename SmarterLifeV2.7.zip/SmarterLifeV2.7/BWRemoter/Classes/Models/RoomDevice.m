//
//  RoomDevice.m
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "RoomDevice.h"
#import "CYM_DatabaseTable.h"

@implementation RoomDevice


+(RoomDevice *)paserRoomDeviceWithDict:(NSDictionary *)dict withRoomID:(NSString *)roomID;{
    RoomDevice * roomDevice = [[RoomDevice alloc]init];
    
    roomDevice.ID = [CYM_DatabaseTable GenerateGUID];
    roomDevice.contentArr = [[NSMutableArray alloc]init];
    roomDevice.property = dict[@"property"];
    
    NSMutableArray * mutableArr = dict[@"content"];
    for (NSDictionary * dict in mutableArr) {
        NSString * name = dict[@"name"];
        [CYM_DatabaseTable insertToRoomDeviceContent:name andDeviceID:roomDevice.ID andRoomID:roomID];
        [roomDevice.contentArr addObject:name];
    }
    return roomDevice;
}
//add by fxw 用于设备列表
-(void)init:(RoomDevice *)roomDevice{
  //  RoomDevice * roomDevice = [[RoomDevice alloc]init];
    roomDevice.contentArr = [[NSMutableArray alloc]init];
}
@end
