//
//  DoorlockNoteModel.m
//  BWRemoter
//
//  Created by tc on 15/11/23.
//  Copyright © 2015年 ReSun. All rights reserved.
//

#import "DoorlockNoteModel.h"

@implementation DoorlockNoteModel

+ (NSMutableArray *)paserDoorlockNoteModelWithNote:(NSMutableArray *)noteArray {
    NSMutableArray *result = [NSMutableArray new];
    for (int x = 0; x < 500; x++) {
        if (x == noteArray.count) {
            return result;
        }
        DoorlockNote *note = noteArray[x];
        //角色
        NSString *role = [DoorlockMsg getOperateRoleWithNumber:note.partNum];
        //门锁
        NSString *devValue = [[HE_CMDBuilder new] getCMDWithAction:A4_ACTION_BIND_RE DeviceType:A4_DEVICE_DOORLOCK Data:[NSString stringWithFormat:@"00%@",note.devID]];
        NSString *doorName = [CYM_Engine getDevNameWithDevValue:devValue];
        if (note.operateNum && ![note.operateNum isEqualToString:@"ff"]) {
            DoorlockNoteModel *msg = [DoorlockNoteModel new];
            msg.time = note.alarmTime;
            msg.role = role;
            msg.doorlock = doorName;
            msg.event = [DoorlockMsg getOpenroleWithNumber:note.operateNum];
            [result addObject:msg];
        }
        if (![note.alarmMsg isEqualToString:@"0"] && ![note.alarmMsg isEqualToString:@"00"]) {
            DoorlockNoteModel *msg = [DoorlockNoteModel new];
            msg.time = note.alarmTime;
            //            msg.role = role;
            msg.doorlock = doorName;
            msg.event = [DoorlockMsg getAlarmNoteWithNmuber:note.alarmMsg];
            msg.isNeedShowRedWord = YES;
            [result addObject:msg];
        }
        if (![note.powerMsg isEqualToString:@"0"] && ![note.powerMsg isEqualToString:@"00"]) {
            DoorlockNoteModel *msg = [DoorlockNoteModel new];
            msg.time = note.alarmTime;
            //            msg.role = role;
            msg.doorlock = doorName;
            msg.event = [DoorlockMsg getPowerNoteWithNmuber:note.powerMsg];
            msg.isNeedShowRedWord = YES;
            [result addObject:msg];
        }
    }
    return result;
}

@end
