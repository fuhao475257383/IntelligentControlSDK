//
//  Control.m
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "Control.h"
#import "ControlDevice.h"
#import "CYM_DatabaseTable.h"

@implementation Control

+(Control *)paserControlWithDict:(NSDictionary *)dict
{
    Control * control = [[Control alloc]init];
    control.ID = [CYM_DatabaseTable GenerateGUID];
    control.deviceArr = [[NSMutableArray alloc]init];
    control.com = dict[@"com"];
    NSMutableArray * mutableArr = dict[@"device"];
    
    for (NSDictionary * dict in mutableArr) {
        ControlDevice * controlDevice = [ControlDevice paserControlDeviceWithDict:dict withControlID:control.ID];
        [CYM_DatabaseTable insertToControlDevice:controlDevice andControlID:control.ID];
        [control.deviceArr addObject:controlDevice];
    }
    return control;
}

@end
