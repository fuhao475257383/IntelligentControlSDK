//
//  Doorlock.h
//  BWRemoter
//
//  Created by tc on 15/11/16.
//  Copyright © 2015年 ReSun. All rights reserved.
//

//该类是门锁设置界面数据MODEL

#import <Foundation/Foundation.h>

@interface Doorlock : NSObject

//设备名称
@property (nonatomic,strong) NSString *deviceName;
//设备编号
@property (nonatomic,strong) NSString *deviceNumber;
//入门场景
@property (nonatomic,strong) NSString *enterScene;
//离家场景
@property (nonatomic,strong) NSString *leaveScene;
//入户防区
@property (nonatomic,strong) NSString *enterSecutityZone;
//离家防区
@property (nonatomic,strong) NSString *leaveSecutityZone;
//enter_scene_enable
@property (nonatomic) BOOL enter_scene_enable;
//leave_scene_enable
@property (nonatomic) BOOL leave_scene_enable;
//enter_secutity_enable
@property (nonatomic) BOOL enter_secutity_enable;
//leave_secutity_enable
@property (nonatomic) BOOL leave_secutity_enable;

@property(nonatomic,copy)NSString * ID;//用于 查询

//解析
+(Doorlock *)paserDoorlockWithDict:(NSDictionary *)dict;

@end
