//
//  Room.m
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "Room.h"
#import "CYM_DatabaseTable.h"
#import "CYM_Engine.h"

@implementation Room

+(Room *)paserRoomWithDict:(NSDictionary *)dict
{
    Room * room = [[Room alloc]init];
    room.deviceArr = [[NSMutableArray alloc]init];
    
    room.ID = [CYM_DatabaseTable GenerateGUID];
    room.name = dict[@"name"];
    room.prio = dict[@"prio"];
    NSMutableArray * mutableArr = dict[@"device"];
    for (NSDictionary * dict in mutableArr) {
        RoomDevice * roomDevice = [RoomDevice paserRoomDeviceWithDict:dict withRoomID:room.ID];
        [CYM_DatabaseTable insertToRoomDevice:roomDevice andID:room.ID];
        
        [room.deviceArr addObject:roomDevice];
    }
    return room;
}
-(id)copyWithZone:(NSZone*)zone{
    Room *copy = [[[self class] allocWithZone:zone] init];
    copy.name = self.name;
    copy.prio = self.prio;
    copy.name = self.name;
    for (RoomDevice *d in self.deviceArr) {
        [copy.deviceArr addObject:[d copy]];
    }
    return copy;
}
+ (void)insertRomm:(Room *)room {
    [CYM_Engine insertRoom:room];
}
+ (void)updataRomm:(Room *)room {
    [self deleteRoom:room.name];
    for (RoomDevice *device in room.deviceArr) {
        device.ID = [CYM_DatabaseTable GenerateGUID];
        [CYM_DatabaseTable insertToRoomDevice:device andID:room.ID];
        for (NSString *name in device.contentArr) {
            [CYM_DatabaseTable insertToRoomDeviceContent:name andDeviceID:device.ID andRoomID:room.ID];
        }
    }
}
+ (void)deleteRoom:(NSString *)name {
    [CYM_Engine deleteRoomWithName:name];
}
+ (Room *)getRoomFromName:(NSString *)name {
    return [CYM_DatabaseTable getRoomFromName:name];
}
+ (void)updataRoomWithNewRoom:(Room *)room withOldName:(NSString *)oldName{
    [CYM_DatabaseTable updataRoomWithRoom:room withOldName:oldName];
}
@end
