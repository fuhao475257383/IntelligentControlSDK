//
//  DoorlockNote.m
//  BWRemoter
//
//  Created by tc on 15/11/16.
//  Copyright © 2015年 ReSun. All rights reserved.
//

#import "DoorlockNote.h"

@implementation DoorlockNote

+ (DoorlockNote *)paserSecurityWithDict:(NSDictionary *)dict {
    DoorlockNote *note = [DoorlockNote new];
    note.alarmTime = dict[@"alarmTime"];
    note.devID = dict[@"devID"];
    note.operateNum = dict[@"operateNum"];
    note.partNum = dict[@"partNum"];
    note.powerMsg = dict[@"powerMsg"];
    note.alarmMsg = dict[@"alarmMsg"];
    return note;
}

@end
