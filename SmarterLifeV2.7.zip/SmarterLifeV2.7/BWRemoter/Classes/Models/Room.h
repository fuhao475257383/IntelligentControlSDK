//
//  Room.h
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RoomDevice.h"

@interface Room : NSObject

@property (nonatomic,copy)NSString * name;
@property(nonatomic,copy)NSString * prio;
@property(nonatomic,retain)NSMutableArray * deviceArr;


///Add By He.
///仅用于查询时 存储 该设备的 其他属性、或联合查询时 的应用
@property(nonatomic,copy)NSString * ID;//用于 查询

+(Room *)paserRoomWithDict:(NSDictionary *)dict;
-(id)copyWithZone:(NSZone*)zone;
//2.7添加
+ (void)insertRomm:(Room *)room;
+ (void)updataRomm:(Room *)room;
+ (void)deleteRoom:(NSString *)name;
+ (Room *)getRoomFromName:(NSString *)name;
+ (void)updataRoomWithNewRoom:(Room*)room withOldName:(NSString *)oldName;

@end
