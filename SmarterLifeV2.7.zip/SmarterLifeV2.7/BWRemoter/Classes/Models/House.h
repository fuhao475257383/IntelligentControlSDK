//
//  House.h
//  BWRemoter
//
//  Created by iceDiao on 15/3/13.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface House : NSObject
@property (nonatomic,strong)NSString *houseName;
@property (nonatomic,strong)NSString *houseImgUrl;
@end
