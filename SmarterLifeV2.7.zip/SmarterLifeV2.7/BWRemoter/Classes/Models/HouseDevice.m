//
//  HouseDevice.m
//  BWRemoter
//
//  Created by iceDiao on 15/3/12.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "HouseDevice.h"

@implementation HouseDevice

@end
