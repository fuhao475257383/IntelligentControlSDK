//
//  Control.h
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Control : NSObject
@property(nonatomic,copy)NSString * ID;
@property(nonatomic,copy)NSString * com;
@property(nonatomic,retain)NSMutableArray * deviceArr;

//2.7添加
@property (nonatomic,copy) NSString *comNumber;

+(Control *)paserControlWithDict:(NSDictionary *)dict;

@end
