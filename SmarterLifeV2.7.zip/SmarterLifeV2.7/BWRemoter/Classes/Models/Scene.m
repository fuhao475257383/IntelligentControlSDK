//
//  Scene.m
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "Scene.h"
#import "SceneDevice.h"
#import "CYM_DatabaseTable.h"

@implementation Scene


+(Scene *)paserSceneWithDict:(NSDictionary *)dict
{
    Scene * scene = [[Scene alloc]init];
    scene.deviceArr = [[NSMutableArray alloc]init];
    
    scene.ID = [CYM_DatabaseTable GenerateGUID];
    scene.sceneId = dict[@"id"];
    scene.name = dict[@"name"];
    scene.isedit = dict[@"isedit"];
    scene.status = dict[@"status"];
    scene.scene = dict[@"scene"];
    scene.delay = dict[@"delay"];
    scene.prio = dict[@"prio"];
    scene.type = dict[@"type"];
    scene.room = dict[@"room"];
    
    NSMutableArray * mutableArr = dict[@"device"];
    for (NSDictionary * dict in mutableArr) {
        SceneDevice * sceneDevice = [SceneDevice paserSceneDeviceWithDict:dict];
        [CYM_DatabaseTable insertToSceneDevice:sceneDevice andSceneID:scene.ID];
        [scene.deviceArr addObject:sceneDevice];
    }
    return scene;
}

-(id)copyWithZone:(NSZone*)zone{
    Scene *copy = [[[self class] allocWithZone:zone] init];
    copy.ID = self.ID;
    copy.sceneId = self.sceneId;
    copy.name = self.name;
    copy.isedit = self.isedit;
    copy.status = self.status;
    copy.scene = self.scene;
    copy.delay = self.delay;
    copy.prio = self.prio;
    copy.type = self.type;
    copy.room = self.room;
    copy.deviceArr = [[NSMutableArray alloc] init];
    for (SceneDevice *d in self.deviceArr) {
        [copy.deviceArr addObject:[d copy]];
    } 
    return copy;
}
@end
