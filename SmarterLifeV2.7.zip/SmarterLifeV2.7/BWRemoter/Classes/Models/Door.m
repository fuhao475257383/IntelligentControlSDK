//
//  Door.m
//  BWRemoter
//
//  Created by tc on 15/11/16.
//  Copyright © 2015年 ReSun. All rights reserved.
//

#import "Door.h"

@implementation Door

- (NSMutableArray *)doorlockArr {
    if (!_doorlockArr) {
        _doorlockArr = [NSMutableArray new];
    }
    return _doorlockArr;
}
- (NSMutableArray *)doorlockUserArr {
    if (!_doorlockUserArr) {
        _doorlockUserArr = [NSMutableArray new];
    }
    return _doorlockUserArr;
}

+ (Door *)paserDoorWithDict:(NSDictionary *)dict {
    Door *door = [Door new];
    NSArray *locks = dict[@"doorlocks"];
    NSArray *users = dict[@"doorlock_users"];
    for (NSDictionary *doorDic in locks) {
        Doorlock *doorlock = [Doorlock paserDoorlockWithDict:doorDic];
        [door.doorlockArr addObject:doorlock];
    }
    for (NSDictionary *userDic in users) {
        DoorlockUser *doorlockUser = [DoorlockUser paserDoorlockUserWithDict:userDic];
        [door.doorlockUserArr addObject:doorlockUser];
    }
    return door;
}

@end
