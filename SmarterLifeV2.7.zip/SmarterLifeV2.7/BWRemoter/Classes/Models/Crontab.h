//
//  Crontab.h
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Crontab : NSObject

@property(nonatomic,copy)NSString * crontabId;
@property(nonatomic,copy)NSString * time;
@property(nonatomic,copy)NSString * status;
@property(nonatomic,copy)NSString * name;
@property(nonatomic,copy)NSString * scene;
@property(nonatomic,copy)NSString * repeat;
@property(nonatomic,copy)NSString * date;
@property(nonatomic,copy)NSString * ID;//只用于查询的id （add by FXW）



@property(nonatomic,retain)NSMutableArray * instructionsArr;

+(Crontab *)paserCrontabWithDict:(NSDictionary *)dict;

@end
