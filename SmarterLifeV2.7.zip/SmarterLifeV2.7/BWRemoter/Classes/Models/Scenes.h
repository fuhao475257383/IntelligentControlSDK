//
//  Scenes.h
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Scenes : NSObject

@property(nonatomic,retain)NSMutableArray * scenesArr;

+(Scenes *)paserScenesWithDict:(NSDictionary *)dict;

@end
