//
//  Ipc.h
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Ipc : NSObject

@property(nonatomic,copy)NSString * ID;
@property(nonatomic,copy)NSString * name;
@property(nonatomic,copy)NSString * android;
@property(nonatomic,copy)NSString * IOS;
@property(nonatomic,copy)NSString * package;
@property(nonatomic,copy)NSString * androidActivity;
@property(nonatomic,copy)NSString * IOS2;
@property(nonatomic,copy)NSString * addState;
@property(nonatomic,copy)NSString * IOSto;


+(Ipc *)paserIpcWithDict:(NSDictionary *)dict;


@end
