//
//  ControlDeviceContentValueKey.h
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ControlDeviceContentValueKey : NSObject
@property(nonatomic,copy)NSString *ID;
@property(nonatomic,copy)NSString *value;
@property(nonatomic,copy)NSString *backkey;
@property(nonatomic,copy)NSString *query;
@property(nonatomic,copy)NSString *name;
@property(nonatomic,copy)NSString *time;

///Add By He.
///仅用于查询时 存储 该设备的 其他属性、或联合查询时 的应用
//..


+(ControlDeviceContentValueKey *)paserControlDeviceContentValueKeyWithDict:(NSDictionary *)dict
                                                               withValueID:(NSString *)valueID
                                                             withContentID:(NSString *)contentID
                                                              withDeviceID:(NSString *)deviceID
                                                             withControlID:(NSString *)controlId;
@end
