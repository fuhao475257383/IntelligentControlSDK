//
//  DeviceSettingModel.m
//  BWRemoter
//
//  Created by baiwei－mac on 16/1/11.
//  Copyright © 2016年 ReSun. All rights reserved.
//

#import "DeviceSettingModel.h"

@implementation DeviceSettingModel

- (NSMutableArray *)cmdArray {
    if (!_cmdArray) {
        _cmdArray = [NSMutableArray new];
    }
    return _cmdArray;
}

@end
