//
//  Doorlock.m
//  BWRemoter
//
//  Created by tc on 15/11/16.
//  Copyright © 2015年 ReSun. All rights reserved.
//

#import "Doorlock.h"

@implementation Doorlock

+ (Doorlock *)paserDoorlockWithDict:(NSDictionary *)dict {
    Doorlock *doorlock = [Doorlock new];
    doorlock.deviceNumber = dict[@"devId"];
    doorlock.enterScene = dict[@"enter_scene"];
    doorlock.leaveScene = dict[@"leave_scene"];
    doorlock.enterSecutityZone = dict[@"enter_security_zone"];
    doorlock.leaveSecutityZone = dict[@"leave_security_zone"];
    return doorlock;
}

@end
