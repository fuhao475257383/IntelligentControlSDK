//
//  Security.m
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "Security.h"
#import "SecurityContent_sensor.h"
#import "SecurityContent_zone.h"
#import "CYM_DatabaseTable.h"

@implementation Security

+(Security *)paserSecurityWithDict:(NSDictionary *)dict
{
    Security * security = [[Security alloc]init];
    security.contentArr = [[NSMutableArray alloc]init];
    security.ID = [CYM_DatabaseTable GenerateGUID];
    security.type = dict[@"type"];
    NSMutableArray * mutableArr = dict[@"content"];
    
    if ([security.type isEqualToString:@"sensor"]) {
        for (NSDictionary * dict in mutableArr) {
            SecurityContent_sensor * securityContent_sensor = [SecurityContent_sensor paserSecurityContent_sensorWithDict:dict withSecurityID:security.ID];
            [CYM_DatabaseTable insertTosecurityContentSensor:securityContent_sensor andSecurityID:security.ID];
            [security.contentArr addObject:securityContent_sensor];
        }
        
    }
    else
    {
        for (NSDictionary * dict in mutableArr) {
            SecurityContent_zone * securityContent_zone = [SecurityContent_zone paserSecurityContent_zoneWithDict:dict withSecurityID:security.ID];
            
            [CYM_DatabaseTable insertTosecurityContentZone:securityContent_zone andSecurityID:security.ID];
            [security.contentArr addObject:securityContent_zone];
        }
    }
    
    
    return security;
}

@end
