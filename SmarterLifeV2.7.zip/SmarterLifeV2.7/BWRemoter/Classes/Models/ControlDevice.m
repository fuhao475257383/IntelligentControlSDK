//
//  ControlDevice.m
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "ControlDevice.h"
#import "ControlDeviceContent.h"
#import "CYM_DatabaseTable.h"

@implementation ControlDevice

+(ControlDevice *)paserControlDeviceWithDict:(NSDictionary *)dict withControlID:(NSString *)controlID
{
    ControlDevice * controlDevice = [[ControlDevice alloc]init];
    controlDevice.contentArr = [[NSMutableArray alloc]init];
    controlDevice.ID = [CYM_DatabaseTable GenerateGUID];
    controlDevice.type = dict[@"type"];
    controlDevice.method = dict[@"method"];
    controlDevice.category = dict[@"category"];
    
    NSMutableArray * mutableArr = dict[@"content"];
    for (NSDictionary * dict in mutableArr) {
        ControlDeviceContent * controlDeviceContent = [ControlDeviceContent paserControlDeviceContentWithDict:dict andDeviceID:controlDevice.ID andControlID:controlID];
        
        [CYM_DatabaseTable insertToControlDeviceContent:controlDeviceContent andDeviceID:controlDevice.ID andControlID:controlID];
        
        [controlDevice.contentArr addObject:controlDeviceContent];
    }
    
    return controlDevice;
}

@end
