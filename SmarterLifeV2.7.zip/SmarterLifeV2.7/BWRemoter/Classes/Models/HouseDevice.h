//
//  HouseDevice.h
//  BWRemoter
//
//  Created by iceDiao on 15/3/12.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HouseDevice : NSObject
@property (nonatomic,copy) NSString *ID;
@property (nonatomic,copy) NSString *houseName;
@property (nonatomic,copy) NSString *deviceName;
@property (nonatomic,copy) NSString * pointX;
@property (nonatomic,copy) NSString * pointY;
@property (nonatomic,assign) float width;///存宽度
@end
