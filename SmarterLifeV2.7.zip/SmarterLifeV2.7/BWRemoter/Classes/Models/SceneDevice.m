//
//  SceneDevice.m
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "SceneDevice.h"
#import "CYM_DatabaseTable.h"

@implementation SceneDevice

+(SceneDevice *)paserSceneDeviceWithDict:(NSDictionary *)dict
{
    SceneDevice * sceneDevice = [[SceneDevice alloc]init];
    sceneDevice.ID = [CYM_DatabaseTable GenerateGUID];
    sceneDevice.interval = dict[@"interval"];
    sceneDevice.value = dict[@"value"];
    sceneDevice.operation = dict[@"operation"];
    sceneDevice.name = dict[@"name"];
    
    return sceneDevice;
}


-(id)copyWithZone:(NSZone*)zone{
    SceneDevice *copy = [[[self class] allocWithZone:zone] init];
    copy.ID = self.ID;
    copy.interval = self.interval;
    copy.value = self.value;
    copy.operation = self.operation;
    copy.name = self.name;
    return copy;
}
@end
