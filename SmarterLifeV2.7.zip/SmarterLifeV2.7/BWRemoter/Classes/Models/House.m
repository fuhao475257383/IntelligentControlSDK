//
//  House.m
//  BWRemoter
//
//  Created by iceDiao on 15/3/13.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "House.h"

@implementation House

@end
