//
//  SecurityContent_sensor.m
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "SecurityContent_sensor.h"
#import "CYM_DatabaseTable.h"

@implementation SecurityContent_sensor

+(SecurityContent_sensor *)paserSecurityContent_sensorWithDict:(NSDictionary *)dict withSecurityID:(NSString *)securityID
{
    SecurityContent_sensor * securityContent_sensor = [[SecurityContent_sensor alloc]init];
    securityContent_sensor.ID = [CYM_DatabaseTable GenerateGUID];
    securityContent_sensor.sensorName = dict[@"sensorName"];
    securityContent_sensor.sensorOldName = dict[@"sensorOldName"];
    securityContent_sensor.sensorMac = dict[@"sensorMac"];
    securityContent_sensor.sensorType = dict[@"sensorType"];
    securityContent_sensor.sensorSignal = dict[@"sensorSignal"];
    securityContent_sensor.sensor24h = dict[@"sensor24h"];
    securityContent_sensor.ctrlValue = dict[@"ctrlValue"];
    securityContent_sensor.maxValue = dict[@"maxValue"];
    securityContent_sensor.minValue = dict[@"minValue"];
    securityContent_sensor.alarmName = dict[@"alarmName"];
    securityContent_sensor.alarmOldName = dict[@"alarmOldName"];
    securityContent_sensor.alarmMac = dict[@"alarmMac"];
    securityContent_sensor.alarmType = dict[@"alarmType"];
    securityContent_sensor.alarmTime = dict[@"alarmTime"];
    securityContent_sensor.isElectromic = dict[@"isElectronic"];
    securityContent_sensor.isAlarm = dict[@"isAlarm"];
    securityContent_sensor.alarmMsg = dict[@"alarmMsg"];
    securityContent_sensor.powerMsg = dict[@"powerMsg"];

    return securityContent_sensor;


}



@end
