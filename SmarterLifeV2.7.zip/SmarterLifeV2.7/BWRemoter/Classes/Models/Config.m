//
//  Config.m
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "Config.h"
#import "CYM_DatabaseTable.h"

@implementation Config

+(Config *)paserConfigWithDict:(NSDictionary * )dict
{
    Config * config = [[Config alloc]init];
    config.ID = [CYM_DatabaseTable GenerateGUID];
    config.name = dict[@"name"];
    config.version = dict[@"version"];
    
    return config;
}

@end
