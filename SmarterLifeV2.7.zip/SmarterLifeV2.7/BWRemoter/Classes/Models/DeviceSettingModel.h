//
//  DeviceSettingModel.h
//  BWRemoter
//
//  Created by baiwei－mac on 16/1/11.
//  Copyright © 2016年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DeviceSettingModel : NSObject
//组网界面
@property (nonatomic,strong) NSString *name;
@property (nonatomic,strong) NSString *type;
@property (nonatomic,strong) NSString *property;
@property (nonatomic,strong) NSString *ID;
@property (nonatomic,strong) NSString *roomName;
@property (nonatomic,strong) NSString *com;
//传感器设置界面
@property (nonatomic,strong) NSString *trigger;
@property (nonatomic,strong) NSString *BD;
@property (nonatomic) BOOL sensor24h;
@property (nonatomic) BOOL isAlarm;
@property (nonatomic) BOOL powerMSG;
//多功能控制器
@property (nonatomic,strong) NSMutableArray *cmdArray;
//zigbee转TTL
//@property (nonatomic,strong) NSString *alarmType;
//是否是新设备
@property (nonatomic) BOOL isNewDevice;
//是否是传感器
@property (nonatomic) BOOL isSensor;

@end
