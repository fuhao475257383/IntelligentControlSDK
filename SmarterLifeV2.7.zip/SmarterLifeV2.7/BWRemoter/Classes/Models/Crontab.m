//
//  Crontab.m
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "Crontab.h"
#import "CrontabInstruction.h"
#import "CYM_DatabaseTable.h"

@implementation Crontab

+(Crontab *)paserCrontabWithDict:(NSDictionary *)dict
{
    Crontab * crontab = [[Crontab alloc]init];
    crontab.instructionsArr = [[NSMutableArray alloc]init];
//    crontab.ID =[CYM_DatabaseTable GenerateGUID];
    crontab.ID = dict[@"id"];
    crontab.crontabId = dict[@"id"];
    crontab.time = dict[@"time"];
    crontab.status = dict[@"status"];
    crontab.name = dict[@"name"];
    crontab.scene = dict[@"scene"];
    crontab.repeat = dict[@"repeat"];
    crontab.date = dict[@"date"];
//    NSLog(@"解析出来的定时数据:%@,%@,%@",crontab.ID,crontab.crontabId,crontab.name);
    NSMutableArray * mutableArr = dict[@"instructions"];
    for (NSDictionary * dict in mutableArr) {
        CrontabInstruction * crontabInstruction = [CrontabInstruction paserCrontabInstructionWithDict:dict];
        [CYM_DatabaseTable insertToCrontabInstruction:crontabInstruction andCrontabID:crontab.ID];
        [crontab.instructionsArr addObject:crontabInstruction];
    }
    return crontab;
}

-(id)copyWithZone:(NSZone *)zone{
    Crontab *copy = [[[self class] allocWithZone:zone]init];
    copy.crontabId = self.crontabId;
    copy.ID = self.ID;
    copy.name = self.name;
    copy.date = self.date;
    copy.repeat = self.repeat;
    copy.scene = self.scene;
    copy.status = self.status;
    copy.time = self.time;
    copy.instructionsArr = [[NSMutableArray alloc]init];
    for(CrontabInstruction * ci in self.instructionsArr){
        [copy.instructionsArr addObject:[ci copy]];
    }
    return copy;
}
@end
