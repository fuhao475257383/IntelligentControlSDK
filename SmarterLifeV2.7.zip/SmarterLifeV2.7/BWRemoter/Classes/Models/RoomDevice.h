//
//  RoomDevice.h
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RoomDevice : NSObject

@property(nonatomic,copy)NSString * property;
@property(nonatomic,retain)NSMutableArray * contentArr;

///Add By He.
///仅用于查询时 存储 该设备的 其他属性、或联合查询时 的应用
@property(nonatomic,copy)NSString * ID;//用于 查询

+(RoomDevice *)paserRoomDeviceWithDict:(NSDictionary *)dict withRoomID:(NSString *)roomID;
//add by fxw 用于设备列表
-(void)init:(RoomDevice *)roomDevice;
@end
