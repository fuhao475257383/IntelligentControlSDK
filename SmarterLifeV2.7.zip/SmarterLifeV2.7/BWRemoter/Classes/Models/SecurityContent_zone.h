//
//  SecurityContent_zone.h
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SecurityContent_zone : NSObject

@property(nonatomic,copy)NSString * ID;
@property(nonatomic,copy)NSString * name;
@property(nonatomic,copy)NSString * type;
@property(nonatomic,copy)NSString * state;
@property(nonatomic,copy)NSString * delay;
@property(nonatomic,copy)NSString * handled;

@property(nonatomic,retain)NSMutableArray * sensorArr;


+(SecurityContent_zone *)paserSecurityContent_zoneWithDict:(NSDictionary *)dict withSecurityID:(NSString *)securityID;
-(id)copyWithZone:(NSZone*)zone;
@end
