//
//  ControlDeviceContentValue.h
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ControlDeviceContentValue : NSObject

@property(nonatomic,copy)NSString * prio;
@property(nonatomic,copy)NSString * value;
@property(nonatomic,copy)NSString * name;
@property(nonatomic,retain)NSMutableArray * keyArr;


///Add By He.
///仅用于查询时 存储 该设备的 其他属性、或联合查询时 的应用
@property(nonatomic,copy)NSString * ID;//用于 查询
@property(nonatomic, copy)NSString *com;
@property(nonatomic, copy)NSString *category;
@property(nonatomic, copy)NSString *property;


+(ControlDeviceContentValue *)paserControlDeviceContentValueWithDict:(NSDictionary *)dict withContentID:(NSString *)contentID withDeviceID:(NSString *)deviceID withControlID:(NSString *)controlID;

@end
