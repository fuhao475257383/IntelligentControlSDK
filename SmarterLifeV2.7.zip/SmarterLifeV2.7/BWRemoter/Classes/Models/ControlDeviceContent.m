//
//  ControlDeviceContent.m
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "ControlDeviceContent.h"
#import "ControlDeviceContentValue.h"
#import "CYM_DatabaseTable.h"

@implementation ControlDeviceContent

+(ControlDeviceContent *)paserControlDeviceContentWithDict:(NSDictionary *)dict andDeviceID:(NSString *)deviceID andControlID:(NSString *)controlID
{
    ControlDeviceContent * controlDeviceContent = [[ControlDeviceContent alloc]init];
    controlDeviceContent.valueArr = [[NSMutableArray alloc]init];
    controlDeviceContent.ID = [CYM_DatabaseTable GenerateGUID];
    controlDeviceContent.property = dict[@"property"];
    NSMutableArray * mutableArr = dict [@"value"];
    for (NSDictionary * dict in mutableArr) {
        ControlDeviceContentValue * controlDeviceContentValue =
            [ControlDeviceContentValue paserControlDeviceContentValueWithDict:dict
                                                                withContentID:controlDeviceContent.ID
                                                                 withDeviceID:deviceID
                                                                withControlID:controlID];
        
        [CYM_DatabaseTable insertToControlDeviceContentValue:controlDeviceContentValue
                                                andContentID:controlDeviceContent.ID
                                                 andDeviceID:deviceID
                                                andControlID:controlID];
        
        [controlDeviceContent.valueArr addObject:controlDeviceContentValue];
    }
    
    return controlDeviceContent;
}

@end
