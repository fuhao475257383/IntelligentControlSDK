//
//  SecurityContent_zone.m
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "SecurityContent_zone.h"
#import "SecurityContent_zone_sensor.h"
#import "CYM_DatabaseTable.h"

@implementation SecurityContent_zone


+(SecurityContent_zone *)paserSecurityContent_zoneWithDict:(NSDictionary *)dict withSecurityID:(NSString *)securityID
{
    SecurityContent_zone * securityContent_zone = [[SecurityContent_zone alloc]init];
    securityContent_zone.sensorArr = [[NSMutableArray alloc]init];

    
    securityContent_zone.ID = [CYM_DatabaseTable GenerateGUID];
    securityContent_zone.name = dict[@"name"];
    securityContent_zone.type = dict[@"type"];
    securityContent_zone.state = dict[@"state"];
    securityContent_zone.delay = dict[@"delay"];
    securityContent_zone.handled = dict[@"handled"];
    
    NSMutableArray * mutableArr = dict[@"sensor"];
    for (NSDictionary * dict in mutableArr) {
        SecurityContent_zone_sensor * securityContent_zone_sensor = [SecurityContent_zone_sensor paserSecurityContent_zone_sensorWithDict:dict withContentID:securityContent_zone.ID withSecurityID:securityID];
        
        [CYM_DatabaseTable insertTosecurityContentZoneSensor:securityContent_zone_sensor andContentID:securityContent_zone.ID andSecurityID:securityID];
        [securityContent_zone.sensorArr addObject:securityContent_zone_sensor];
        
    }
    
    return securityContent_zone;
}
-(id)copyWithZone:(NSZone*)zone{
    SecurityContent_zone *copy = [[[self class] allocWithZone:zone] init];
    copy.ID = self.ID;
    copy.name = self.name;
    copy.state = self.state;
    copy.delay = self.delay;
    copy.type = self.type;
    copy.handled = self.handled;
    copy.sensorArr = [[NSMutableArray alloc] init];
    for (SecurityContent_zone_sensor *d in self.sensorArr) {
        [copy.sensorArr addObject:[d copy]];
    }
    return copy;
}
@end
