//
//  Scenes.m
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "Scenes.h"
#import "Scene.h"
#import "CYM_DatabaseTable.h"

@implementation Scenes

+(Scenes *)paserScenesWithDict:(NSDictionary *)dict
{
    Scenes * scenes = [[Scenes alloc]init];
    scenes.scenesArr = [[NSMutableArray alloc]init];
    NSMutableArray * mutableArr = dict[@"scenes"];
    for (NSDictionary * dict in mutableArr) {
        Scene * scene = [Scene paserSceneWithDict:dict];
        
        [CYM_DatabaseTable insertToScene:scene];
        
        [scenes.scenesArr addObject:scene];
    }
//    NSLog(@"解析出了: %ld", mutableArr.count);
    return scenes;
}
@end
