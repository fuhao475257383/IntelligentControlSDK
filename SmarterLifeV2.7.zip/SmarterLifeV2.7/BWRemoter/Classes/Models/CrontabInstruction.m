//
//  CrontabInstruction.m
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "CrontabInstruction.h"
#import "CYM_DatabaseTable.h"

@implementation CrontabInstruction

+(CrontabInstruction *)paserCrontabInstructionWithDict:(NSDictionary *)dict
{
    CrontabInstruction * crontabInstruction = [[CrontabInstruction alloc]init];
    crontabInstruction.ID = [CYM_DatabaseTable GenerateGUID];
    crontabInstruction.cmd = dict[@"cmd"];
    crontabInstruction.delay = dict[@"delay"];
    
    return crontabInstruction;
}
-(id)copyWithZone:(NSZone *)zone{
    CrontabInstruction *copy = [[[self class] allocWithZone:zone]init];
    copy.ID = self.ID;
    copy.cmd = self.cmd;
    copy.delay = self.delay;
    return copy;
}
@end
