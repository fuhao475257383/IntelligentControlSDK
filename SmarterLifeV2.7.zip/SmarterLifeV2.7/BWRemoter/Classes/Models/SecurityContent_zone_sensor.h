//
//  SecurityContent_zone_sensor.h
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SecurityContent_zone_sensor : NSObject

@property(nonatomic,copy)NSString * ID;
@property(nonatomic,copy)NSString * name;
@property(nonatomic,copy)NSString * mac;
@property(nonatomic,copy)NSString * type;
@property(nonatomic,copy)NSString * state;
@property(nonatomic,copy)NSString * contentId;//外键 by FXW


+(SecurityContent_zone_sensor *)paserSecurityContent_zone_sensorWithDict:(NSDictionary *)dict withContentID:(NSString *)contentID withSecurityID:(NSString *)securityID;

-(id)copyWithZone:(NSZone*)zone;
@end
