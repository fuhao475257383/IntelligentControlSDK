//
//  Scene.h
//  BWRemoter
//
//  Created by cym on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Scene : NSObject
@property(nonatomic,copy)NSString* sceneId;
@property(nonatomic,copy)NSString * name;

@property(nonatomic,copy)NSString * isedit;
@property(nonatomic,copy)NSString * status;
@property(nonatomic,copy)NSString * scene;
@property(nonatomic,copy)NSString * delay;
@property(nonatomic,copy)NSString * prio;
@property(nonatomic,copy)NSString * type;
@property(nonatomic,copy)NSString * room;
@property(nonatomic,retain)NSMutableArray * deviceArr;


/////ADD By He
@property(nonatomic,copy)NSString* ID;


+(Scene *)paserSceneWithDict:(NSDictionary *)dict;


@end
