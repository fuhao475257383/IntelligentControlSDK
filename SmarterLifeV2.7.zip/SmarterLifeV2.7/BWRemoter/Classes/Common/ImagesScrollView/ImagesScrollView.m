//
//  ImagesScrollView.m
//  Judge
//
//  Created by 王斌 on 14-9-8.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "ImagesScrollView.h"
#define SCREENWIDTH [[UIScreen mainScreen] bounds].size.width
@implementation ImagesScrollView

@synthesize delegate,noteView,noteTitle,pageControl;
@synthesize scrollPoint,scale_;
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
    }
    return self;
}

#pragma mark -
#pragma mark 使用URL加载图片的初始化函数
- (id)initWith:(CGRect) rect ImagesArray:(NSArray *)imgArr TitleArray:(NSArray *)titArr isURL:(BOOL) isURL curPoint:(NSInteger)curPoint
{
    offset = 0.0;
    scale_ = 1.0;
    if(self = [super initWithFrame: rect])
    {
        /*------初始化基本数据---------*/
        NSMutableArray *tempArray = [NSMutableArray arrayWithArray: imgArr];
        /*------初始化滚动视图---------*/
        viewSize = rect;
        scrollview = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, viewSize.size.width, viewSize.size.height)];
        scrollview.pagingEnabled = YES;
        scrollview.scrollEnabled = YES;
        scrollview.showsHorizontalScrollIndicator = NO;
        scrollview.showsVerticalScrollIndicator = NO;
        scrollview.scrollsToTop = NO;
        //[scrollview setUserInteractionEnabled:NO];
        scrollview.delegate = self;
        [scrollview setTag:999];
        [self addSubview: scrollview];
        [scrollview setContentSize:CGSizeMake(SCREENWIDTH, 0)];
        if(tempArray.count > 0)
        {
            imagesArray = [[NSArray alloc] initWithArray: tempArray];
            NSUInteger pageCount = [imagesArray count];
            scrollview.contentSize = CGSizeMake(viewSize.size.width * pageCount, viewSize.size.height);
            imageViewArray = [NSMutableArray arrayWithCapacity: pageCount];
            /*------在滚动视图中加入图片---------*/
            for(int i = 0; i < pageCount; i++)
            {
//                UIImageView *imgView = [[UIImageView alloc] init];
//                

//
//                [imgView setFrame: CGRectMake(viewSize.size.width*i, 0, viewSize.size.width, viewSize.size.height)];
//                [imgView.layer setMasksToBounds: YES];
//                [imgView setTag: i+1000];
//                [scrollview addSubview: imgView];
//                [imageViewArray addObject: imgView];
                
                UIScrollView *s = [[UIScrollView alloc] initWithFrame:CGRectMake(360*i, 0, 360, 460)];
                s.backgroundColor = [UIColor clearColor];
                s.contentSize = CGSizeMake(360, 460);
                s.showsHorizontalScrollIndicator = NO;
                s.showsVerticalScrollIndicator = NO;
                s.delegate = self;
                s.minimumZoomScale = 1.0;
                s.maximumZoomScale = 3.0;
                [s setZoomScale:1.0];
                UIImageView *imageview = [[UIImageView alloc] init];
                UIImage *tempImage= [UIImage imageWithData: [imagesArray objectAtIndex: i]];
                if(tempImage == nil)
                {
                    [imageview setImage: [UIImage imageNamed: @"commonDefault.png"]];
                }
                else
                {
                    [imageview setImage: tempImage];
                }
                imageview.frame = CGRectMake(20, 0, SCREENWIDTH, SCREENWIDTH);
                [imageview setContentMode:UIViewContentModeScaleAspectFit];
                [s addSubview:imageview];
                [scrollview addSubview:s];
                [imageViewArray addObject: imageview];
            }
            
            /*------默认显示哪张图片---------*/
            if(curPoint == 0){
                [scrollview setContentOffset: CGPointMake(viewSize.size.width*(tempArray.count-1), 0)];
            }
            else
            {
                [scrollview setContentOffset: CGPointMake(viewSize.size.width*(curPoint-1), 0)];
            }
        }
        else
        {
            UIImageView *imgView = [[UIImageView alloc] initWithFrame: CGRectMake(0.0f, 0.0f, viewSize.size.width, viewSize.size.height)];
            [imgView setImage: [UIImage imageNamed: @"house_icon.png"]];
            imgView.tag = 4321;
            [scrollview addSubview: imgView];
        }
    }
    return  self;
}






#pragma mark -
#pragma mark 自定义初始化函数
- (id)initWith:(CGRect)rect ImagesArray:(NSArray *)imgArr TitleArray:(NSArray *)titArr curPoint:(NSInteger) curPoint
{
    return [self initWith: rect ImagesArray: imgArr TitleArray: titArr isURL:NO curPoint:curPoint];
}
//左移动scrollView
-(NSInteger)TurnLeft
{
    if(currentPageIndex == 0)
    {
        if([delegate respondsToSelector: @selector(GetTag:curPageIndex:)])
        {
            NSArray *arrayimageview = [scrollview subviews];
            [delegate GetTag:[[arrayimageview objectAtIndex:currentPageIndex+1]tag] curPageIndex:currentPageIndex];
        }
        return 1;
    }
    else
    {
        currentPageIndex = currentPageIndex-1;
        if([delegate respondsToSelector: @selector(GetTag:curPageIndex:)])
        {
            NSArray *arrayimageview = [scrollview subviews];
            [delegate GetTag:[[arrayimageview objectAtIndex:currentPageIndex+1]tag] curPageIndex:currentPageIndex];
        }
        [UIView beginAnimations:nil context:NULL];//此处添加动画，使之变化平滑一点
        [UIView setAnimationDuration:0.3];//设置动画时间 秒为单位
        [scrollview setContentOffset: CGPointMake(viewSize.size.width*(currentPageIndex), 0)];
        [UIView commitAnimations];//开始动画效果
        return 0;
    }
}
//右移动scrollView
-(NSInteger)TurnRight
{
    if(currentPageIndex == imagesArray.count-1)
    {
        if([delegate respondsToSelector: @selector(GetTag:curPageIndex:)])
        {
            NSArray *arrayimageview = [scrollview subviews];
            [delegate GetTag:[[arrayimageview objectAtIndex:currentPageIndex+1]tag] curPageIndex:currentPageIndex];
        }
        return 1;
    }
    else
    {
        currentPageIndex = currentPageIndex+1;
        if([delegate respondsToSelector: @selector(GetTag:curPageIndex:)])
        {
            NSArray *arrayimageview = [scrollview subviews];
            [delegate GetTag:[[arrayimageview objectAtIndex:currentPageIndex+1]tag] curPageIndex:currentPageIndex];
        }
        [UIView beginAnimations:nil context:NULL];//此处添加动画，使之变化平滑一点
        [UIView setAnimationDuration:0.3];//设置动画时间 秒为单位
        [scrollview setContentOffset: CGPointMake(viewSize.size.width*(currentPageIndex), 0)];
        [UIView commitAnimations];//开始动画效果
        return 0;
    }
}

#pragma mark -
#pragma mark 添加一个图片view
- (void)AddImageView:(NSArray *)imgArr
{
    /*------初始化基本数据---------*/
    NSMutableArray *tempArray = [NSMutableArray arrayWithArray: imgArr];
    if(tempArray.count > 0)
    {
        imagesArray = [[NSArray alloc] initWithArray: tempArray];
        NSUInteger pageCount = [imagesArray count];
        scrollview.contentSize = CGSizeMake(viewSize.size.width * pageCount, viewSize.size.height);
        imageViewArray = [NSMutableArray arrayWithCapacity: pageCount];
        
        ///////////////////
        UIScrollView *s = [[UIScrollView alloc] initWithFrame:CGRectMake(viewSize.size.width*(imagesArray.count-1), 0, viewSize.size.width, viewSize.size.height)];
        s.backgroundColor = [UIColor whiteColor];
        s.contentSize = CGSizeMake(SCREENWIDTH, 0);
        s.showsHorizontalScrollIndicator = NO;
        s.showsVerticalScrollIndicator = NO;
        s.delegate = self;
        s.minimumZoomScale = 1.0;
        s.maximumZoomScale = 3.0;
        [s setZoomScale:1.0];
        UIImageView *imageview = [[UIImageView alloc] init];
        UIImage *tempImage= [UIImage imageWithData: [imagesArray objectAtIndex: imagesArray.count-1]];
        if(tempImage == nil){
            [imageview setImage: [UIImage imageNamed: @"commonDefault.png"]];
        }
        else{
            [imageview setImage: tempImage];
        }
        imageview.clipsToBounds = YES;
        imageview.frame = CGRectMake(0, 0, SCREENWIDTH, SCREENWIDTH);
       // [imageview.layer setMasksToBounds: YES];
        [imageview setContentMode:UIViewContentModeScaleAspectFit];
        NSArray *tempArrayView = [scrollview subviews];
        int k=1000,isContinue=0;
        while (isContinue == 0)
        {
            for(int i=0;i<tempArrayView.count;i++)
            {
                if([[tempArrayView objectAtIndex:i] tag]!=k)
                {
                    isContinue = 1;
                }
                else
                {
                    isContinue = 0;
                    break;
                }
            }
            if(isContinue==0)
            {
                k++;
            }
        }
        [s setTag:k];
        [imageview setUserInteractionEnabled: YES]; //一定要将用户交互性设置为YES
        [s addSubview:imageview];
        [scrollview addSubview:s];
        [imageViewArray addObject:imageview];
        ///////////////////
//        UIImageView *imgView = [[UIImageView alloc] init];
//        UIImage *tempImage= [UIImage imageWithData: [imagesArray objectAtIndex: imagesArray.count-1]];
//        if(tempImage == nil){
//            [imgView setImage: [UIImage imageNamed: @"commonDefault.png"]];
//        }
//        else{
//            [imgView setImage: tempImage];
//        }
//        [imgView setFrame: CGRectMake(viewSize.size.width*(imagesArray.count-1), 0, viewSize.size.width, viewSize.size.height)];
//        [imgView.layer setMasksToBounds: YES];
//        NSArray *tempArrayView = [scrollview subviews];
//        int k=1000,isContinue=0;
//        while (isContinue == 0)
//        {
//            for(int i=0;i<tempArrayView.count;i++)
//            {
//                if([[tempArrayView objectAtIndex:i] tag]!=k)
//                {
//                    isContinue = 1;
//                }
//                else
//                {
//                    isContinue = 0;
//                    break;
//                }
//            }
//            if(isContinue==0)
//            {
//                k++;
//            }
//        }
//        [imgView setTag:k];
//        [imgView setUserInteractionEnabled: YES]; //一定要将用户交互性设置为YES
//        [scrollview addSubview: imgView];
//        [imageViewArray addObject: imgView];
        //////////////////////////
        [scrollview setContentOffset: CGPointMake(viewSize.size.width*(imagesArray.count-1), 0)];
        if([delegate respondsToSelector: @selector(GetTag:curPageIndex:)]){
            NSArray *arrayimageview = [scrollview subviews];
            [delegate GetTag:[[arrayimageview objectAtIndex:currentPageIndex+1]tag] curPageIndex:currentPageIndex];
        }
    }
}
- (void)pinchView:(UIPinchGestureRecognizer *)pinchGestureRecognizer
{
    UIView *view = pinchGestureRecognizer.view;
    imgViewPro   = pinchGestureRecognizer.view;
    if(imgframe.size.width==0){
        imgframe = view.frame;
    }
    if (pinchGestureRecognizer.state == UIGestureRecognizerStateBegan || pinchGestureRecognizer.state == UIGestureRecognizerStateChanged) {
        view.transform = CGAffineTransformScale(view.transform, pinchGestureRecognizer.scale, pinchGestureRecognizer.scale);
        
        if (view.frame.size.width < SCREENWIDTH) {
            //让图片无法缩得比原图小
        }
        if (view.frame.size.width > 3 * view.frame.size.width) {
            //view.frame = cgre;
        }
        
        pinchGestureRecognizer.scale = 1;
        NSLog(@"%f",view.frame.size.width);
    }
    view.transform = CGAffineTransformScale(view.transform, 1, 1);
}
- (void) handlePan:(UIPanGestureRecognizer*) recognizer
{
//    if(recognizer.view.frame.size.width>320){
//        CGPoint translation = [recognizer translationInView:self];
//        recognizer.view.center = CGPointMake(recognizer.view.center.x + translation.x,
//                                         recognizer.view.center.y + translation.y);
//        [recognizer setTranslation:CGPointZero inView:self];
//    }
    imgViewPro.clipsToBounds = YES;
    [imgViewPro setFrame:imgframe];
}
#pragma mark -
#pragma mark 删除一个图片view
- (void)DeleteImageView:(NSArray *)imgArr
{
    /*------初始化基本数据---------*/
    NSMutableArray *tempArray = [NSMutableArray arrayWithArray: imgArr];

    if(tempArray.count > 0)
    {
        imagesArray = [[NSArray alloc] initWithArray: tempArray];
        NSUInteger pageCount = [imagesArray count];
        scrollview.contentSize = CGSizeMake(viewSize.size.width * pageCount, viewSize.size.height);
    
        int j=0;
        for(UIImageView *tmpView in [scrollview subviews])
        {
            if(tmpView.tag !=4321){
                if([tmpView tag]!=0)
                {
                    [UIView beginAnimations:nil context:NULL];//此处添加动画，使之变化平滑一点
                    [UIView setAnimationDuration:0.3];//设置动画时间 秒为单位
                    tmpView.frame = CGRectMake(j*SCREENWIDTH, 0, SCREENWIDTH, SCREENWIDTH);//整体屏幕位置的y坐标移动到offY
                    [UIView commitAnimations];//开始动画效果
                    j++;
                }
            }
        }
        [scrollview setContentOffset: CGPointMake(viewSize.size.width*(currentPageIndex), 0)];
 
        if([delegate respondsToSelector: @selector(GetTag:curPageIndex:)])
        {
            NSArray *arrayimageview = [scrollview subviews];
            [delegate GetTag:[[arrayimageview objectAtIndex:currentPageIndex+1]tag] curPageIndex:currentPageIndex];
        }
    }
    else
    {
        NSUInteger pageCount = [imagesArray count];
        scrollview.contentSize = CGSizeMake(viewSize.size.width * pageCount, viewSize.size.height);
    }
}


#pragma mark -
#pragma mark [Scrollview的委托方法]
- (void)scrollViewDidScroll:(UIScrollView *)_scrollView
{
    
    CGFloat pageWith = scrollview.frame.size.width;
    int page = floor((scrollview.contentOffset.x - pageWith / 2) /pageWith) + 1;
    currentPageIndex = page;
    pageControl.currentPage = (page - 1);
    if(titleArray.count > 0)
    {
        long titleIndex=page-1;
        if (titleIndex==[titleArray count]) {
            titleIndex=0;
        }
        if (titleIndex<0) {
            titleIndex=[titleArray count]-1;
        }
        [noteTitle setText:[titleArray objectAtIndex:titleIndex]];
    }
    
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)_scrollView
{
    if([delegate respondsToSelector: @selector(GetTag:curPageIndex:)])
    {
        NSArray *arrayimageview = [scrollview subviews];
        if(!(arrayimageview.count==1 && ((UIImageView *)arrayimageview[0]).tag ==4321)){
            [delegate GetTag:[[arrayimageview objectAtIndex:currentPageIndex+1]tag] curPageIndex:currentPageIndex];
        }
    }
    
    /*--当超出第一张图片时，显示最后一张--*/
    
    if(currentPageIndex == 0)
    {
    }
    /*--当超出最后一张图片时，显示第一张--*/
    if(currentPageIndex == [imagesArray count] - 1)
    {
    }
    
    if (_scrollView ==scrollview){
        CGFloat x = _scrollView.contentOffset.x;
        if (x!=offset){
            offset = x;
            for (UIScrollView *s in _scrollView.subviews){
                if ([s isKindOfClass:[UIScrollView class]]){
                    [s setZoomScale:1.0];
                    UIImageView *image = [[s subviews] objectAtIndex:0];
                    image.frame = CGRectMake(0, 0, SCREENWIDTH, SCREENWIDTH);
                }
            }
        }
    }
}
-(UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView{
    for (UIView *v in scrollView.subviews){
        return v;
    }
    return nil;
}
@end
