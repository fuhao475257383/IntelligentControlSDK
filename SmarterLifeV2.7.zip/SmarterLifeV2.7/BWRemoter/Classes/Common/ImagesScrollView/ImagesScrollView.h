//
//  ImagesScrollView.h
//  Judge
//
//  Created by 王斌 on 14-9-8.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol XZJ_ImagesScrollViewDelegate <NSObject>
@optional
- (void)XZJ_ImagesScrollViewDidClicked: (NSUInteger)index; //图片点击时的委托
-(void)GetTag:(NSInteger)curtag curPageIndex:(NSInteger)curpageindex;
@end

@interface ImagesScrollView : UIView <UIScrollViewDelegate>
{
    CGRect viewSize;//滚动视图的矩形区域
    UIScrollView *scrollview;//滚动视图
    NSArray *imagesArray;//存放图片的数组
    NSArray *titleArray;//存放标题的数组
    UIPageControl *pageControl;//分页控件
    id<XZJ_ImagesScrollViewDelegate> delegate;//委托对象
    int currentPageIndex;//当前view（图片）的下标
    UILabel *noteTitle;//显示标题的Label
    UIView *noteView; //添加存放标题和分页控件的view
    //NSInteger scrollPoint; //滚动指针(指示现在滚动到什么地方)
    NSMutableArray *imageViewArray; //已经加载的imageView
    
    UIView *imgViewPro;//用来保存上一个显示过的img
    CGRect imgframe;/////用来保存上一个显示过的frame
    CGFloat offset;
}

@property(nonatomic,retain) id<XZJ_ImagesScrollViewDelegate> delegate;
@property(nonatomic,retain) UIView *noteView;
@property(nonatomic,retain) UIPageControl *pageControl;//分页控件
@property(nonatomic,retain)  UILabel *noteTitle;
@property NSInteger scrollPoint;

- (id)initWith:(CGRect) rect ImagesArray:(NSArray *)imgArr TitleArray:(NSArray *)titArr curPoint:(NSInteger)curPoint; //初始化函数
- (id)initWith:(CGRect) rect ImagesArray:(NSArray *)imgArr TitleArray:(NSArray *)titArr isURL:(BOOL) isURL curPoint:(NSInteger)curPoint; //使用URL加载图片的初始化函数
- (void)AddImageView:(NSArray *)imgArr;
- (void)DeleteImageView:(NSArray *)imgArr;
- (NSInteger)TurnLeft;
- (NSInteger)TurnRight;
@property float scale_;
@end
