//
//  HE_FileOperation.h
//  DDLOG_TEST
//
//  Created by JianBo He on 15/1/18.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>


///文件操作类 -》》 目录:~/Document
@interface HE_FileOperation : NSObject
{
    NSString *path;
}
///Document Path
-(NSString *)dirDoc;

///创建文件、文件以JSON格式保存
- (BOOL)saveJSONFileName:(NSString *)name WithDic:(NSDictionary *)dic;
///数组保存为JSON文件
- (BOOL)saveJSONFileName:(NSString *)name WithAry:(NSArray *)ary;

///创建文件、当文件存在时 将覆盖
- (BOOL)createFileName:(NSString *)name WithData:(NSData *)data;

///读取文件
- (NSString *)readFileWithName:(NSString *)name;


@end
