//
//  HE_FileOperation.m
//  DDLOG_TEST
//
//  Created by JianBo He on 15/1/18.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "HE_FileOperation.h"

@implementation HE_FileOperation

- (id)init{
    self = [super init];
    if (self) {
        ///判断文件是否存在
        NSString *documentsPath =[self dirDoc];
        NSFileManager *fileManager = [NSFileManager defaultManager];
        path = documentsPath;
        // 创建目录
        [fileManager createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:nil];
    }
    return self;
}

///字典保存为JSON文件
- (BOOL)saveJSONFileName:(NSString *)name WithDic:(NSDictionary *)dic{
    ///1.解析字典
    ///2.转化为DATA
    ///3.保存
    NSData *data = [[self parseDictionary:dic] dataUsingEncoding:NSUTF8StringEncoding];
    return [self createFileName:name WithData:data];
}
///数组保存为JSON文件
- (BOOL) saveJSONFileName:(NSString *)name WithAry:(NSArray *)ary{
    ///1.解析数组
    ///2.转化为DATA
    ///3.保存
    NSMutableString *tmpResult = [[NSMutableString alloc] init];
    [tmpResult appendString:@"["];
    for (NSDictionary *dic in ary) {
        [tmpResult appendString:[self parseDictionary:dic]];
        if (![dic isEqual:ary.lastObject]) {
            [tmpResult appendString:@","];
        }
        
    }
    [tmpResult appendString:@"]"];
    NSData *data = [tmpResult dataUsingEncoding:NSUTF8StringEncoding];
    return [self createFileName:name WithData:data];
}

///创建文件
-(BOOL)createFileName:(NSString *)name WithData:(NSData *)data{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSString *filePath = [path stringByAppendingPathComponent:name];
    return [fileManager createFileAtPath:filePath contents:data attributes:nil];
}

- (NSString *)readFileWithName:(NSString *)name{
    NSString *filePath = [path stringByAppendingPathComponent:name];
    return [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
}

#pragma mark - 
#pragma mark Private Method
//获取Documents目录
-(NSString *)dirDoc{
    //[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    return documentsDirectory;
}

//
- (NSString *)parseDictionary:(NSDictionary *)dic{
    NSMutableString *resultStr  = [[NSMutableString alloc] init];
    ///解析Dictionary
    NSArray* key1 = [dic allKeys];
    [resultStr appendString:@"{"];
    for (NSString *k1 in key1) {
        id obj = [dic objectForKey:k1];
        //判断是否为数组
        [resultStr appendFormat:@"\"%@\":", k1];
        if ([obj isKindOfClass:[NSArray class]]) {
            [resultStr appendString:@"["];
            for (NSDictionary *d in obj) {
                [resultStr appendString:[self parseDictionary:d]];
                [resultStr appendString:@","];
            }
            //去掉 最后多余的 ',' 号
            char last = [resultStr characterAtIndex:resultStr.length - 1];
            if (last == ',') {
                resultStr = [[NSMutableString alloc] initWithString:[resultStr substringToIndex:resultStr.length - 1]];
            }
            [resultStr appendString:@"],"];
        }
        else{
            [resultStr appendFormat:@"\"%@\",", obj];
        }
    }
    //去掉 最后多余的 ',' 号
    char last = [resultStr characterAtIndex:resultStr.length - 1];
    if (last == ',') {
        resultStr = [[NSMutableString alloc] initWithString:[resultStr substringToIndex:resultStr.length - 1]];
    }
    [resultStr appendString:@"}"];
    //去掉最后一个 ',' 号
    return resultStr;
}
@end
