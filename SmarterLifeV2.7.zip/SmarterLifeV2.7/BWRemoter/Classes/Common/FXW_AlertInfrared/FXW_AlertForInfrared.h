//
//  FXW_AlertForInfrared.h
//  FXW_TestProject0304
//
//  Created by 6602_Loop on 15-3-10.
//  Copyright (c) 2015年 范兴文. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef enum{
    FXWAlertTypeEdit = 0,
    FXWAlertTypeAdd,
}FXWAlertType;
typedef enum{
    FXWAlertActionDelete,
    FXWAlertActionSave,
}FXWAlertActionType;
@protocol alertDelegate;
@interface FXW_AlertForInfrared : UIView<UITextFieldDelegate>
{
    NSString *title;
    FXWAlertType alertType;
    UITapGestureRecognizer *bgTap;
}
@property id<alertDelegate>alertDelegate;
@property (nonatomic,strong)UIView * backview;
@property (nonatomic,strong)UIView * alertback;
@property (nonatomic,strong)UIView * downview;
@property (nonatomic,strong)UILabel *labTitle;
@property (nonatomic,strong)UILabel *labName;
@property (nonatomic,strong)UITextField *txtName;
@property (nonatomic,strong)UIButton *btnCancel;
@property (nonatomic,strong)UIButton *btnClick;
@property (nonatomic,strong)UIButton *btnDelete;
@property (nonatomic,strong) NSString *name;

@property (nonatomic,strong)UIButton *sender;
-(void)setTitle:(NSString *)Text andAlertType:(FXWAlertType)type;
- (void)setDefaultName:(NSString *)name;
@end


@protocol alertDelegate <NSObject>
@optional
//-(void)BtnClick:(NSString *)name withBtnType:(FXWAlertActionType)actiontype withBtnSender:(UIButton *)btn;
-(void)alertView:(FXW_AlertForInfrared *)alertView inputText:(NSString *) aText actionType:(FXWAlertActionType) type andBtnSender:(UIButton *)btn;
@end