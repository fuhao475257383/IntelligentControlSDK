//
//  FXW_AlertForInfrared.m
//  FXW_TestProject0304
//
//  Created by 6602_Loop on 15-3-10.
//  Copyright (c) 2015年 范兴文. All rights reserved.
//

#import "FXW_AlertForInfrared.h"
#define Screenwidth [UIScreen mainScreen].bounds.size.width
#define Screenheight [UIScreen mainScreen].bounds.size.height
@implementation FXW_AlertForInfrared
-(id)init{
    self = [super init];
    [self setFrame:CGRectMake(0, 0, Screenwidth, Screenheight)];
    [self setBackgroundColor:[UIColor clearColor]];
    return self;
}

- (void)drawRect:(CGRect)rect {
    // Drawing code
    _backview = [[UIView alloc]initWithFrame:CGRectMake(0, 0, Screenwidth, Screenheight)];
    [_backview setBackgroundColor:[UIColor grayColor]];
    _backview.alpha = 0.6;
    bgTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(removeView:)];
    [self addSubview:_backview];
   // [_backview addGestureRecognizer:bgTap];
    
    _alertback = [[UIView alloc]initWithFrame:CGRectMake(Screenwidth*0.15, 100, Screenwidth*0.7, 200)];
    [self addSubview:_alertback];
    UIView *alert = [[UIView alloc]initWithFrame:CGRectMake(0, 0, Screenwidth*0.7, 100)];
    [alert setBackgroundColor:[UIColor whiteColor]];
    [_alertback addSubview:alert];
    
    _labTitle = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, Screenwidth*0.7, 40)];
    [_labTitle setText:title];
    [_labTitle setFont:[UIFont boldSystemFontOfSize:18]];
    [_labTitle setTextAlignment:NSTextAlignmentCenter];
    [alert addSubview:_labTitle];
    UIView *line = [[UIView alloc]initWithFrame:CGRectMake(0, 39, Screenwidth*0.7, 1)];
    [line setBackgroundColor:[UIColor grayColor]];
    [alert addSubview:line];
    
    _labName = [[UILabel alloc]initWithFrame:CGRectMake(0, 50, alert.frame.size.width*0.4, 30)];
    [_labName setText:@"名称 :"];
    [_labName setTextAlignment:NSTextAlignmentCenter];
    [alert addSubview:_labName];
    
    _txtName = [[UITextField alloc]initWithFrame:CGRectMake(alert.frame.size.width*0.4, 50, alert.frame.size.width*0.5, 30)];
    [alert addSubview:_txtName];
    _txtName.delegate  = self;
    [_txtName setReturnKeyType:UIReturnKeyDone];
    [_txtName setBorderStyle:UITextBorderStyleLine];
    
    _btnClick = [UIButton buttonWithType:UIButtonTypeSystem];
    _btnClick.tag = 1000;

    _btnCancel = [UIButton buttonWithType:UIButtonTypeSystem];
  //  _btnCancel.tag = 2000;
    _downview = [[UIView alloc]init];
    [_alertback addSubview:_downview];
    [self setContent];

    
    CAKeyframeAnimation* animation = [CAKeyframeAnimation animationWithKeyPath:@"transform"];
    animation.duration = 0.5;
    
    NSMutableArray *values = [NSMutableArray array];
    [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(0.1, 0.1, 1.0)]];
    [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(1.2, 1.2, 1.0)]];
    [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(0.9, 0.9, 1.0)]];
    [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(1.0, 1.0, 1.0)]];
    animation.values = values;
    [_alertback.layer addAnimation:animation forKey:nil];
    self.txtName.text = self.name;
}

////自定义内容
-(void)setContent{
    if(alertType == 0){///如果是编辑alert
        [_downview setFrame:CGRectMake(0, 100, Screenwidth*0.7, 80)];
        [_downview setBackgroundColor:[UIColor whiteColor]];
        [_btnClick setFrame:CGRectMake(20, 0,50, 30)];

        [_btnClick setBackgroundColor:[UIColor colorWithRed:150/255.0f green:150/255.0f blue:150/255.0f alpha:1]];
        [_btnClick.layer setCornerRadius:5];
        [_btnClick setTitle:@"确定" forState:UIControlStateNormal];
        [_btnClick setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_downview addSubview:_btnClick];
        
        [_btnCancel setFrame:CGRectMake(_downview.frame.size.width*0.7, 0,50, 30)];
        [_btnCancel setBackgroundColor:[UIColor colorWithRed:150/255.0f green:150/255.0f blue:150/255.0f alpha:1]];        [_btnCancel.layer setCornerRadius:5];
        [_btnCancel setTitle:@"取消" forState:UIControlStateNormal];
        [_btnCancel setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_downview addSubview:_btnCancel];
        
        _btnDelete  = [UIButton buttonWithType:UIButtonTypeSystem];
        [_btnDelete setFrame:CGRectMake(20, _btnClick.frame.size.height+_btnClick.frame.origin.y+10, _downview.frame.size.width-40, 30)];
        [_btnDelete.layer setBorderWidth:1];
        [_btnDelete.layer setCornerRadius:5];
        _btnDelete.layer.borderColor = [[UIColor colorWithRed:180/255.0f green:180/255.0f blue:180/255.0f alpha:1]CGColor];
        [_btnDelete setTitle:@"删除按键" forState:UIControlStateNormal];
        [_btnDelete setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        _btnDelete.tag = 3000;
        [_btnDelete addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        [_downview addSubview:_btnDelete];
    }
    else{
        [_downview setFrame:CGRectMake(0,  100, Screenwidth*0.7, 39)];
        [_downview setBackgroundColor:[UIColor whiteColor]];
        UIView *line= [[UIView alloc]initWithFrame:CGRectMake(0, 0, Screenwidth*0.7, 1)];
        [line setBackgroundColor:[UIColor grayColor]];
        [_downview addSubview:line];
        [_btnClick setFrame:CGRectMake(0, 1, _downview.frame.size.width*0.5, 40)];
        [_btnClick setTitle:@"保存" forState:UIControlStateNormal];
        [_btnClick setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_downview addSubview:_btnClick];
        UIView *lin = [[UIView alloc]initWithFrame:CGRectMake(_downview.frame.size.width*0.5, 1, 1, 40)];
        [lin setBackgroundColor:[UIColor grayColor]];
        [_downview addSubview:lin];
        
        [_btnCancel setFrame:CGRectMake(_downview.frame.size.width*0.5+1, 1, _downview.frame.size.width*0.5, 40)];
        [_btnCancel setTitle:@"取消" forState:UIControlStateNormal];
        [_btnCancel setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_downview addSubview:_btnCancel];
    }
    [_btnClick addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    [_btnCancel addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
}

-(void)btnClick:(id)sender{
    if(((UIButton *)sender).tag==1000){///保存按钮
        if (self.txtName.text == nil || [self.txtName.text isEqualToString:@""]) {
            UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"提示：" message:@"按钮名称不能为空" delegate:nil cancelButtonTitle:@"确认" otherButtonTitles: nil];
            [alertView show];
            return;
        }
        if ([_alertDelegate respondsToSelector:@selector(alertView:inputText:actionType:andBtnSender:)]) {
            [_alertDelegate alertView:self inputText:_txtName.text actionType:FXWAlertActionSave andBtnSender:_sender];
        }
    }
    else if(((UIButton *)sender).tag==3000){//删除按钮
        if ([_alertDelegate respondsToSelector:@selector(alertView:inputText:actionType:andBtnSender:)]) {
            [_alertDelegate alertView:self inputText:_txtName.text actionType:FXWAlertActionDelete andBtnSender:_sender];
        }
    }
    [self removeView:nil];
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [_txtName resignFirstResponder];    //主要是[receiver resignFirstResponder]在哪调用就能把receiver对应的键盘往下收
    return YES;
}
-(void)setTitle:(NSString *)Text andAlertType:(FXWAlertType)type{
    title = Text;
    alertType = type;
}
- (void)setDefaultName:(NSString *)name {
    self.name = name;
}
-(void)removeView:(id)sender{
    [UIView animateWithDuration:0.2 animations:^{
        CGAffineTransform newTransform = CGAffineTransformMakeScale(0.01, 0.01);
        [_alertback setTransform:newTransform];
      //  [_backview setBackgroundColor:[UIColor whiteColor]];
        
    } completion:^(BOOL finish){
        [self removeFromSuperview];
        
    }];
}
@end
