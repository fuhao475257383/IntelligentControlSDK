//
//  FXW_alertView.m
//  DropDownDemo
//
//  Created by 6602_Loop on 15-1-14.
//  Copyright (c) 2015年  All rights reserved.
//

#import "FXW_alertView.h"
#import "DropDownlistView.h"
#import "CYM_Engine.h"
#define Screenwidth [UIScreen mainScreen].bounds.size.width
#define Screenheight [UIScreen mainScreen].bounds.size.height
@implementation FXW_alertView
@synthesize BackView;
@synthesize AlertView;
@synthesize Title;
@synthesize areaName;
@synthesize radio;
@synthesize dropDownView;
@synthesize table;
@synthesize sensor;
@synthesize zone;
@synthesize zoneCopy;
-(id)initWithFrame:(CGRect)frame Delegate:(id)delegate Datasourse:(id)datasourse{
    self = [super initWithFrame:frame];
    self.FXW_alertDelegate = delegate;
    BackView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, Screenwidth, Screenheight)];
    [BackView setBackgroundColor:[UIColor grayColor]];
    [self addSubview:BackView];
    
    UITapGestureRecognizer *bgTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(bgTappedAction:)];
    [BackView addGestureRecognizer:bgTap];
    
    //alert 出现位置及高度后面再说
    AlertView =[[UIView alloc]init];
    [AlertView setFrame:CGRectMake(Screenwidth*0.15, Screenheight * 0.2, Screenwidth*0.7, 80)];
    [AlertView setBackgroundColor:[UIColor whiteColor]];
    AlertView.alpha=1;
    [self addSubview:AlertView];
    [UIView animateWithDuration:0.3 delay:0 options:UIViewAnimationOptionTransitionFlipFromLeft
                     animations:^{
                         self.BackView.alpha = 0.2;
                         self.BackView.alpha = 0.4;
                         self.BackView.alpha = 0.6;
                         AlertView.alpha =0;
                         AlertView.alpha =0.3;
                         AlertView.alpha =0.6;
                         AlertView.alpha =0.8;
                         AlertView.alpha =1;
                         

                     } completion:^(BOOL finish){
                     }];
    //titleline
    UIView *titleline = [[UIView alloc]initWithFrame:CGRectMake(AlertView.frame.size.width*0.05, 40, AlertView.frame.size.width*0.9, 1)];
    [titleline setBackgroundColor:[UIColor grayColor]];
    titleline.alpha=0.6;
    [AlertView addSubview:titleline];
    //标题
    Title = [[UILabel alloc]initWithFrame:CGRectMake(0, 3, AlertView.frame.size.width, 37)];
    [Title setFont:[UIFont boldSystemFontOfSize:18]];
    [Title setTextAlignment:NSTextAlignmentCenter];
    [AlertView addSubview:Title];
    return self;
}
///添加保存取消按钮
-(void)AddButton{
    //bottomline
    UIView *bottomline = [[UIView alloc]initWithFrame:CGRectMake(0, AlertView.frame.size.height-40, AlertView.frame.size.width, 1)];
    [bottomline setBackgroundColor:[UIColor grayColor]];
    bottomline.alpha=0.4;
    [AlertView addSubview:bottomline];
    //保存
    UIButton *save = [[UIButton alloc]initWithFrame:CGRectMake(0, AlertView.frame.size.height-40, AlertView.frame.size.width*0.5, 40)];
    [save setTitle:@"保存" forState:UIControlStateNormal];
    [save setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [save addTarget:self action:@selector(saveBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [AlertView addSubview:save];
    //取消
    UIButton *cancel = [[UIButton alloc]initWithFrame:CGRectMake(AlertView.frame.size.width*0.5, AlertView.frame.size.height-40, AlertView.frame.size.width*0.5, 40)];
    [cancel setTitle:@"取消" forState:UIControlStateNormal];
    [cancel setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [cancel addTarget:self action:@selector(bgTappedAction:) forControlEvents:UIControlEventTouchUpInside];
    [AlertView addSubview:cancel];
    //分割线
    UIView *cutline = [[UIView alloc]initWithFrame:CGRectMake(AlertView.frame.size.width*0.5, AlertView.frame.size.height-40, 1, 40)];
    [cutline setBackgroundColor:[UIColor grayColor]];
    cutline.alpha=0.4;
    [AlertView addSubview:cutline];
//    [UIView animateWithDuration:0.5
//                     animations:^{
//        self.BackView.alpha = 0.2;
//        self.BackView.alpha = 0.5;
//        self.BackView.alpha = 0.8;
//    }];
}

///自定义内容
-(void)setContent:(Alerttype)content andTitle:(NSString *)title{
    alertType =content;
    switch (content) {
        case defineArea:
            [self defineArea:title];
            break;
        case addArea:
            [self addArea];
            break;
        case safe:
            [self safeButton:title];
            break;
        default:
            break;
    }
}
///
-(void)defineArea:(NSString *)title{
    arySensor = [CYM_Engine getAllSensorInfo];
    [self setZoneCopy:zone];
    [Title setText:title];
    UIView *back_view = [[UIView alloc]initWithFrame:CGRectMake(0, 41, AlertView.frame.size.width, 160)];
    CGRect frame =  AlertView.frame;
    frame.size.height+=160;
    [AlertView setFrame:frame];
    [AlertView addSubview:back_view];
    table = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, AlertView.frame.size.width,160)];
    table.separatorStyle=NO;
    table.delegate = self;
    table.dataSource = self;
    [back_view addSubview:table];
    [self AddButton];
}
///添加防区
-(void)addArea{
    [Title setText:@"添加防区"];
    UIView *back_view = [[UIView alloc]initWithFrame:CGRectMake(0, 40, AlertView.frame.size.width, 100)];
    CGRect frame =  AlertView.frame;
    frame.size.height+=100;
    [AlertView setFrame:frame];
    [AlertView addSubview:back_view];
    [self AddButton];
    //label
    UILabel *areaLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, back_view.frame.size.height/3, back_view.frame.size.width/3, back_view.frame.size.height/3)];
    [areaLabel setText:@"名称:"];
    [areaLabel setTextAlignment:NSTextAlignmentCenter];
    [back_view addSubview:areaLabel];
    //文本框
    areaName = [[UITextField alloc]initWithFrame:CGRectMake(back_view.frame.size.width/3,  back_view.frame.size.height/3,  back_view.frame.size.width*0.6,  back_view.frame.size.height/3)];
    areaName.borderStyle=UITextBorderStyleRoundedRect;
    areaName.keyboardType=UIKeyboardTypeDefault;
    areaName.clearButtonMode = UITextFieldViewModeAlways;
    areaName.returnKeyType = UIReturnKeyDone;
    areaName.minimumFontSize=10;
    areaName.delegate = self;
    [back_view addSubview:areaName];
}
///安全按钮
-(void)safeButton:(NSString *)title{
    array = [NSMutableArray arrayWithArray:@[@[@"常开",@"常闭"]]];
    [Title setText:title];
    UIView *back_view = [[UIView alloc]initWithFrame:CGRectMake(0, 40, AlertView.frame.size.width, 120)];
    CGRect frame =  AlertView.frame;
    frame.size.height+=120;
    [AlertView setFrame:frame];
    [AlertView addSubview:back_view];
    [self AddButton];
    //信号源
    UILabel *singlelable = [[UILabel alloc]initWithFrame:CGRectMake(back_view.frame.size.width*0.1,0, back_view.frame.size.width*0.4, back_view.frame.size.height/2)];
    [singlelable setText:@"信号源"];
    [singlelable setTextAlignment:NSTextAlignmentLeft];
    [back_view addSubview:singlelable];
    //下拉框
    dropDownView = [[DropDownListView alloc]initWithFrame:CGRectMake(back_view.frame.size.width*0.55, 15, back_view.frame.size.width*0.4, 30) dataSource:self delegate:self];
        dropDownView.mSuperView = self;
    [back_view addSubview:dropDownView];

    //24小时设备
    UILabel *device24 = [[UILabel alloc]initWithFrame:CGRectMake(back_view.frame.size.width*0.1,back_view.frame.size.height/2, back_view.frame.size.width*0.4, back_view.frame.size.height/4)];
    [device24 setText:@"24小时设备"];
    [device24 setTextAlignment:NSTextAlignmentLeft];
    [back_view addSubview:device24];
    //radiobutton
    radio = [[UIButton alloc]initWithFrame:CGRectMake(back_view.frame.size.width*0.55, back_view.frame.size.height/2, 30, 30)];
    [radio setBackgroundImage:[UIImage imageNamed:@"radionocheckd.png"] forState:UIControlStateNormal];
    [radio addTarget:self action:@selector(radioClick) forControlEvents:UIControlEventTouchUpInside];
    [back_view addSubview:radio];
}
///自定义防区

#pragma mark --消失alert
-(void)bgTappedAction:(UITapGestureRecognizer *)tap
{
    if(![areaName resignFirstResponder])
    {
        [UIView animateWithDuration:0.2 delay:0 options:UIViewAnimationOptionTransitionFlipFromLeft
                         animations:^{
                             self.BackView.alpha = 0.4;
                             self.BackView.alpha = 0.2;
                             self.BackView.alpha = 0;
                             AlertView.alpha =0.8;
                             AlertView.alpha =0.6;
                             AlertView.alpha =0.3;
                             AlertView.alpha =0;
                         } completion:^(BOOL finish){
                            [self removeFromSuperview];
                         }];

    }
}
-(void)saveBtnClick{
    areaText = areaName.text;
    if([self.FXW_alertDelegate respondsToSelector:@selector(saveBtn:withareatext:withsignal:withdeviceIson:withSensor:)]){
        if([self.FXW_alertDelegate saveBtn:alertType withareatext:areaText withsignal:signal withdeviceIson:deviceIson withSensor:sensor]){
            [self removeFromSuperview];
        }
        return;
    }
    if([self.FXW_alertDelegate respondsToSelector:@selector(saveDefineArea)]){
        [zone.sensorArr removeAllObjects];
        for(int i =0;i<zoneCopy.sensorArr.count;i++){
            [zone.sensorArr addObject:zoneCopy.sensorArr[i]];
        }
        if([self.FXW_alertDelegate saveDefineArea]){
            [self removeFromSuperview];
        }
        return;
    }
    if([self.FXW_alertDelegate respondsToSelector:@selector(saveBtnAddArea:)]){
        if([self.FXW_alertDelegate saveBtnAddArea:areaText]){
            [self removeFromSuperview];
        }
        return;
    }


//    else
//    {
//        //异常处理
//        NSLog(@"111");
//    }
}
///点击radio
-(void)radioClick{
    if(deviceIson){
        [radio setBackgroundImage:[UIImage imageNamed:@"radionocheckd.png"] forState:UIControlStateNormal];
        deviceIson = false;
    }
    else{
        [radio setBackgroundImage:[UIImage imageNamed:@"radiochecked.png"] forState:UIControlStateNormal];
        deviceIson = true;
    }
}
#pragma mark Table DataSourse and Delegate
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell= [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    if (cell==nil) {
        cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"qe"];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    [cell.textLabel setText:((SecurityContent_sensor *)arySensor[indexPath.row]).sensorName];
    UIImageView *imgSwitch = [[UIImageView alloc]initWithFrame:CGRectMake(cell.frame.size.width*0.5, 5, 30, 30)];
    imgSwitch.tag = 2000+indexPath.row;
    [imgSwitch setImage:[UIImage imageNamed:@"no.png"]];
    for(int i =0;i<zoneCopy.sensorArr.count;i++){
        if([((SecurityContent_zone_sensor *)zoneCopy.sensorArr[i]).name isEqualToString:((SecurityContent_sensor *)arySensor[indexPath.row]).sensorName]){
            [imgSwitch setImage:[UIImage imageNamed:@"yes.png"]];
        }
    }

    [cell addSubview:imgSwitch];
    return cell;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return arySensor.count;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    UIImageView *imgTmp = (UIImageView *)[cell viewWithTag:2000+indexPath.row];
    BOOL isOn=NO;
    for(int i =0;i<zoneCopy.sensorArr.count;i++){
        if([((SecurityContent_zone_sensor *)zoneCopy.sensorArr[i]).name isEqualToString:[NSString stringWithFormat:@"%@",cell.textLabel.text]]){
            [imgTmp setImage:[UIImage imageNamed:@"no.png"]];
            [zoneCopy.sensorArr removeObjectAtIndex:i];
             isOn = YES;
        }
    }
    if(!isOn){
        SecurityContent_zone_sensor * sensorTmp = [[SecurityContent_zone_sensor alloc]init];
        sensorTmp.name = ((SecurityContent_sensor *)arySensor[indexPath.row]).sensorName;
        sensorTmp.ID = ((SecurityContent_sensor *)arySensor[indexPath.row]).ID;
        sensorTmp.mac = ((SecurityContent_sensor *)arySensor[indexPath.row]).sensorMac;
        sensorTmp.type = ((SecurityContent_sensor *)arySensor[indexPath.row]).sensorType;
        sensorTmp.state = ((SecurityContent_sensor *)arySensor[indexPath.row]).isAlarm;
        sensorTmp.contentId = zoneCopy.ID;
        [zoneCopy.sensorArr addObject:sensorTmp];
        [imgTmp setImage:[UIImage imageNamed:@"yes.png"]];
    }
    
}
#pragma mark -- dropDownListDelegate
-(void) chooseAtSection:(NSInteger)section index:(NSInteger)index
{
//    NSLog(@"section:%ld ,index:%ld",(long)section,(long)index);
    signal = index==0?true:false;
}
#pragma mark -- dropdownList DataSource
-(NSInteger)numberOfSections
{
    return [array count];
}
-(NSInteger)numberOfRowsInSection:(NSInteger)section
{
    NSArray *arry =array[section];
    return [arry count];
}
-(NSString *)titleInSection:(NSInteger)section index:(NSInteger) index
{
    return array[section][index];
}
-(NSInteger)defaultShowSection:(NSInteger)section
{
    return 0;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [areaName resignFirstResponder];    //主要是[receiver resignFirstResponder]在哪调用就能把receiver对应的键盘往下收
    return YES;
}
#pragma mark --设置安全按钮初始状态接口
-(void)SetdeviceIson:(BOOL)Ison withSignal:(BOOL)sign{
    deviceIson=true;
    signal =sign;
    [dropDownView setTitleDefault:signal?0:1];
    deviceIson=Ison;
    if(deviceIson){
        [radio setBackgroundImage:[UIImage imageNamed:@"radiochecked.png"] forState:UIControlStateNormal];
    }
    else{
        [radio setBackgroundImage:[UIImage imageNamed:@"radionocheckd.png"] forState:UIControlStateNormal];
    }
}
@end
