//
//  FXW_alertView.h
//  DropDownDemo
//
//  Created by 6602_Loop on 15-1-14.
//  Copyright (c) 2015年 童明城. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DropDownChooseProtocol.h"
#import "DropDownListView.h"
#import "SecurityContent_sensor.h"
#import "SecurityContent_zone.h"
#import "SecurityContent_zone_sensor.h"
typedef enum{
    ///自定义防区
    defineArea,
    ///添加防区
    addArea,
    ///安全按钮
    safe,
}Alerttype;

@protocol FXW_alertDelegate <NSObject>
@optional
-(BOOL) saveBtn:(Alerttype)content withareatext:(NSString*)text withsignal:(BOOL)signal  withdeviceIson:(BOOL)Ison withSensor:(SecurityContent_sensor *)sensor;
-(BOOL) saveBtnAddArea:(NSString*)test;
-(BOOL) saveDefineArea;
@end
@interface FXW_alertView : UIView<UITextFieldDelegate,DropDownChooseDelegate,DropDownChooseDataSource,UITableViewDataSource,UITableViewDelegate>
{
    //弹出框类型
    Alerttype alertType;
    //添加防区文本
    NSString *areaText;
    //true代表常开，false代表常闭
    BOOL signal;
    //24小时设备,true代表开启，flase代表关闭
    BOOL deviceIson;
    //常开常闭数组
    NSMutableArray *array;
    
    ////////自定义防区//////
    NSMutableArray *arySensor;//用来存所有传感器
//    NSMutableArray *aryIndex;//用于暂存选中传感器的索引

}
@property (nonatomic, assign) id<FXW_alertDelegate> FXW_alertDelegate;
//背景灰
@property (nonatomic, strong) UIView *BackView;
//alert
@property (nonatomic, strong) UIView *AlertView;
//标题
@property (nonatomic, strong) UILabel *Title;
//文本框
@property (nonatomic, strong) UITextField *areaName;
//radioButton
@property (nonatomic, strong) UIButton *radio;
//下拉框
@property (nonatomic, strong) DropDownListView *dropDownView;
//自定义防区的table
@property UITableView *table;
@property (retain)  SecurityContent_sensor *sensor;//传感器
@property (retain) SecurityContent_zone *zone;
@property (copy) SecurityContent_zone *zoneCopy;///用于暂存数据使用

-(id)initWithFrame:(CGRect)frame Delegate:(id)delegate Datasourse:(id)datasourse;
///title
-(void)setContent:(Alerttype)content andTitle:(NSString *)title ;
-(void)SetdeviceIson:(BOOL)Ison withSignal:(BOOL)sign;
@end

