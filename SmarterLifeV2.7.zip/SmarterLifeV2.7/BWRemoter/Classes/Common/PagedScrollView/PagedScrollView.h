//
//  PagedScrollView.h
//  PagedScrollView
//
//  Created by HeJianBo on 15/5/31.
//  Copyright (c) 2015年 JianBo. All rights reserved.
//

#import <UIKit/UIKit.h>

@class PagedScrollView;

typedef void (^PagedCallBack)(PagedScrollView *pageView, NSInteger toIndex);

@interface PagedScrollView : UIScrollView


- (id)initWithFrame:(CGRect)frame andViews:(NSArray *)aryViews pagedHanlder:(PagedCallBack)hanlder;
- (void)toNextPage;
- (void)toPrePage;

@end
