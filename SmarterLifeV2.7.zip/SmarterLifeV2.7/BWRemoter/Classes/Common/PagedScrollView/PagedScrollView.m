//
//  PagedScrollView.m
//  PagedScrollView
//
//  Created by HeJianBo on 15/5/31.
//  Copyright (c) 2015年 JianBo. All rights reserved.
//

#import "PagedScrollView.h"

const NSInteger defatulPageNum = 1;
@interface PagedScrollView()<UIScrollViewDelegate>{
    ///////////////Data
    NSArray      *arySubViews;
    NSInteger     nowViewIndex;
    PagedCallBack pagedHandler;
}
@end

@implementation PagedScrollView

- (id)initWithFrame:(CGRect)frame andViews:(NSArray *)aryViews pagedHanlder:(PagedCallBack)hanlder{
    self = [super initWithFrame:frame];
    if (self) {
        self.pagingEnabled = YES;
        self.delegate      = self;
        self.showsHorizontalScrollIndicator = NO;
        self.showsVerticalScrollIndicator   = NO;
        nowViewIndex       = 0;
        arySubViews        = aryViews;
        pagedHandler       = hanlder;
        [self reDrawSubViews];
    }
    return self;
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
}
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    if (arySubViews.count > 1) {
        NSInteger pageNum = scrollView.contentOffset.x/self.frame.size.width;
        if (pageNum != defatulPageNum) {
            nowViewIndex += (pageNum-defatulPageNum) > 0 ? 1: -1;
            if (nowViewIndex < 0) {
                nowViewIndex += arySubViews.count;
            }
            if (nowViewIndex >= arySubViews.count) {
                nowViewIndex -= arySubViews.count;
            }
            [self reDrawSubViews];
            pagedHandler(self, nowViewIndex);
        }
    }
}
- (void)toNextPage{
    if (arySubViews.count > 1) {
        nowViewIndex += 1;
        if (nowViewIndex < 0) {
            nowViewIndex += arySubViews.count;
        }
        if (nowViewIndex >= arySubViews.count) {
            nowViewIndex -= arySubViews.count;
        }
        [self reDrawSubViews];
        pagedHandler(self, nowViewIndex);
    }

}
- (void)toPrePage{
    if (arySubViews.count  > 1) {
        nowViewIndex -= 1;
        if (nowViewIndex < 0) {
            nowViewIndex += arySubViews.count;
        }
        if (nowViewIndex >= arySubViews.count) {
            nowViewIndex -= arySubViews.count;
        }
        [self reDrawSubViews];
        pagedHandler(self, nowViewIndex);
    }
}

-(void)reDrawSubViews{
    if (arySubViews.count > 1) {
        NSArray *aryTmp = [self getNeedDisplayView:arySubViews andPosition:nowViewIndex];
        self.contentOffset = CGPointMake(self.frame.size.width, 0);
        for (int i=0; i<aryTmp.count; i++) {
            UIView *v = aryTmp[i];
            [v setFrame:CGRectMake(i*self.frame.size.width, 0, self.frame.size.width, self.frame.size.height)];
            
            [self addSubview:v];
        }
        nowViewIndex     = [arySubViews indexOfObject:aryTmp[1]];
        self.contentSize = CGSizeMake(self.frame.size.width * aryTmp.count, self.frame.size.height);
    }
    else if(arySubViews.count == 1){
        UIView *v = arySubViews[0];
        [v setFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
        [self addSubview:v];
        self.contentSize = CGSizeMake(self.frame.size.width, self.frame.size.height);
        self.contentOffset = CGPointMake(0, 0);
    }
}
-(NSArray *)getNeedDisplayView:(NSArray *)aryViews andPosition:(NSInteger)index2{
    NSInteger index1 = index2-1,
    index3 = index2+1;
    if (index2 < 0 || index2 > aryViews.count - 1) {
        return nil;
    }
    
    if (index1 < 0) {
        index1 += aryViews.count;
    }
    if (index3 >= aryViews.count) {
        index3 -= aryViews.count;
    }
    return @[aryViews[index1], aryViews[index2], aryViews[index3]];
}
@end
