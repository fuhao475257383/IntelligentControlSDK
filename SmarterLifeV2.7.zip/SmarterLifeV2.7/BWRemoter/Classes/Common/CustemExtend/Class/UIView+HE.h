//
//  UIView+HE.h
//  BWRemoter
//
//  Created by JianBo He on 15/1/25.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView(HE)


- (CGFloat)frameX;
-(void)setFrameX:(CGFloat)x;
- (CGFloat)frameY;
-(void)setFrameY:(CGFloat)y;
- (CGFloat)frameW;
- (CGFloat)frameH;
- (CGFloat)frameSumX_W;
- (CGFloat)frameSumY_H;
@end
