//
//  UIColor+HE.h
//  ZBCK
//
//  Created by JianBo He on 15/1/9.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor(HE)
{
}

+ (UIColor*)colorOfTurnToUIColor:(NSString*)colorString;
+ (UIColor*)colorOfTurnToUIColor:(NSString*)colorString alpha:(CGFloat) alpha;
@end
