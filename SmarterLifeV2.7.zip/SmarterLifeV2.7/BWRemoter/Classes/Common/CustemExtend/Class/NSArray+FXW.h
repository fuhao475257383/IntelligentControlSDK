//
//  NSArray+FXW.h
//  BWRemoter
//
//  Created by iceDiao on 15/3/20.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray(FXW)

-(BOOL)isContainsStringObj:(NSString *)str;

@end
