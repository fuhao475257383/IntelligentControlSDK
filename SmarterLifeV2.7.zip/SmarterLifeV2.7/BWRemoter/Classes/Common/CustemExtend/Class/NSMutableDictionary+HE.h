//
//  NSMutableArray+HE.h
//  BWRemoter
//
//  Created by JianBo He on 15/1/29.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSMutableDictionary(HE)
- (void)setMayNilObject:(id)anObject forKey:(id<NSCopying>)aKey;
@end
