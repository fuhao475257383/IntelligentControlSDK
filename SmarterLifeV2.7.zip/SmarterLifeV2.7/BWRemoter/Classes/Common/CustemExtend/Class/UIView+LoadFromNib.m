//
//  UIView+LoadFromNib.m
//  ZBCK
//
//  Created by JianBo He on 15/1/6.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "UIView+LoadFromNib.h"

@implementation UIView (LoadFromNib)


+ (id)loadFromNib
{
    id view = nil;
    NSString *xibName = NSStringFromClass([self class]);
    UIViewController *temporaryController = [[UIViewController alloc] initWithNibName:xibName bundle:nil];
    if(temporaryController){
        view = temporaryController.view;
    }
    return view;
}
@end
