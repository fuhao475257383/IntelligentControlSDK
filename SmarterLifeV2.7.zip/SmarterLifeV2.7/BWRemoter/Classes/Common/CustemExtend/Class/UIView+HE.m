//
//  UIView+HE.m
//  BWRemoter
//
//  Created by JianBo He on 15/1/25.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "UIView+HE.h"

@implementation UIView(HE)



- (CGFloat)frameX{
    return self.frame.origin.x;
}

-(void)setFrameX:(CGFloat)x{
    CGRect rect = self.frame;
    rect.origin.x = x;
    [self setFrame:rect];
}
- (CGFloat)frameY{
    return self.frame.origin.y;
}
-(void)setFrameY:(CGFloat)y{
    CGRect rect = self.frame;
    rect.origin.y = y;
    [self setFrame:rect];
}
- (CGFloat)frameW{
    return self.frame.size.width;
}
- (CGFloat)frameH{
    return self.frame.size.height;
}
- (CGFloat)frameSumX_W{
    return (self.frame.origin.x + self.frame.size.width);
}
- (CGFloat)frameSumY_H{
    return (self.frame.origin.y + self.frame.size.height);
}
@end
