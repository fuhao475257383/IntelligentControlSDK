//
//  NSString+HE.h
//  BWRemoter
//
//  Created by JianBo He on 14/12/17.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (HE)
{

}
///替换特殊字符XML 替换特殊字符
- (NSString *)stringByDecodingXMLEntities;

/// 十六进制转换为普通字符串的。
+ (NSString *)stringFromHexString:(NSString *)hexString;

///普通字符串转换为十六进制的。
+ (NSString *)hexStringFromString:(NSString *)string;
///16进制字符串 转化为10进制字符串
- (NSString *)IntString;
- (BOOL)myContainsString:(NSString*)other;

- (BOOL)isNotEmptyAndNil;

///子字符串的索引
- (NSRange)indexofString:(NSString *)str;
@end
