//
//  NSData+Bytes.h
//  BWRemoter
//
//  Created by HeJianBo on 15/8/25.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSData(Bytes)

- (NSString *)string;
- (NSString *)utf8String;

@end
