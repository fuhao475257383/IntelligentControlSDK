//
//  UIImage+HE.m
//  ZBCK
//
//  Created by JianBo He on 15/1/10.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "UIImage+HE.h"

@implementation UIImage(HE)


+ (UIImage*) createImageWithColor: (UIColor*) color
{
    CGRect rect=CGRectMake(0.0f, 0.0f, 1.0f, 1.0f);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    UIImage *theImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return theImage;
}
@end
