//
//  NSMutableArray+HE.m
//  BWRemoter
//
//  Created by JianBo He on 15/1/29.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "NSMutableDictionary+HE.h"

@implementation NSMutableDictionary(HE)


- (void)setMayNilObject:(id)anObject forKey:(id<NSCopying>)aKey{
    
    if (anObject == nil) {
        [self setObject:@"null" forKey:aKey];
    }
    else{
        [self setObject:anObject forKey:aKey];
    }
}
@end
