//
//  UIView+LoadFromNib.h
//  ZBCK
//
//  Created by JianBo He on 15/1/6.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (LoadFromNib)

+ (id)loadFromNib;
@end
