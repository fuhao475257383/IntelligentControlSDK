//
//  UIImage+HE.h
//  ZBCK
//
//  Created by JianBo He on 15/1/10.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage(HE)

+ (UIImage*) createImageWithColor: (UIColor*) color;
@end
