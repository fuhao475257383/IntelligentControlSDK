//
//  HE_UIDevice+HUD.h
//  BWRemoter
//
//  Created by HeJianBo on 15/4/30.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "HE_UIDevice.h"

@interface HE_UIDevice(HUD)

- (void)showHudInView:(UIView *)view hint:(NSString *)hint;

- (void)hideHud;

- (void)showHint:(NSString *)hint;

// 从默认(showHint:)显示的位置再往上(下)yOffset
//- (void)showHint:(NSString *)hint yOffset:(float)yOffset;

@end
