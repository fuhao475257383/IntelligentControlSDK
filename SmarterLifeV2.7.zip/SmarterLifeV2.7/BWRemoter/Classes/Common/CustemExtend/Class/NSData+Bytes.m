//
//  NSData+Bytes.m
//  BWRemoter
//
//  Created by HeJianBo on 15/8/25.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "NSData+Bytes.h"

@implementation NSData(Bytes)


/**
 
 将 data 十六进制直译为NSString
 
 @return
 
 */
- (NSString *)string{
    
    NSMutableString *result = [[NSMutableString alloc] init];
    for (NSUInteger i = 0; i < self.length; i++) {
        Byte value = ((Byte *)self.bytes)[i];
        [result appendFormat:@"%02x", value];
    }
    return result;
}

/**
 
 返回 UTF-8 编码的字符串
 
 @return
 
 */
- (NSString *)utf8String {
    return [[NSString alloc] initWithData:self encoding:NSUTF8StringEncoding];
}
@end
