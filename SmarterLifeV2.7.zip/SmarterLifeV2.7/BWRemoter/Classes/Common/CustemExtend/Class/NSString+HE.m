//
//  NSString+HE.m
//  BWRemoter
//
//  Created by JianBo He on 14/12/17.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "NSString+HE.h"

@implementation NSString (HE)



#pragma mark -
#pragma mark 替换特殊字符
- (NSString *)stringByDecodingXMLEntities {
    
    NSUInteger myLength = [self length];
    NSUInteger ampIndex = [self rangeOfString:@"&" options:NSLiteralSearch].location;
    
    // Short-circuit if there are no ampersands.
    if (ampIndex == NSNotFound) {
        return self;
    }
    // Make result string with some extra capacity.
    
    NSMutableString *result = [NSMutableString stringWithCapacity:(myLength * 1.25)];
    
    
    // First iteration doesn't need to scan to & since we did that already, but for code simplicity's sake we'll do it again with the scanner.
    NSScanner *scanner = [NSScanner scannerWithString:self];
    
    [scanner setCharactersToBeSkipped:nil];
    
    NSCharacterSet *boundaryCharacterSet = [NSCharacterSet characterSetWithCharactersInString:@" \t\n\r;"];
    
    do {
        // Scan up to the next entity or the end of the string.
        NSString *nonEntityString;
        if ([scanner scanUpToString:@"&" intoString:&nonEntityString]) {
            [result appendString:nonEntityString];
        }
        if ([scanner isAtEnd]) {
            return result;
        }
        // Scan either a HTML or numeric character entity reference.
        if ([scanner scanString:@"&amp;" intoString:NULL])
            [result appendString:@"&"];
        else if ([scanner scanString:@"&apos;" intoString:NULL])
            [result appendString:@"'"];
        else if ([scanner scanString:@"&quot;" intoString:NULL])
            [result appendString:@"\""];
        else if ([scanner scanString:@"&lt;" intoString:NULL])
            [result appendString:@"<"];
        else if ([scanner scanString:@"&gt;" intoString:NULL])
            [result appendString:@">"];
        else if ([scanner scanString:@"&#" intoString:NULL]) {
            BOOL gotNumber;
            unsigned charCode;
            NSString *xForHex = @"";
            
            // Is it hex or decimal?
            if ([scanner scanString:@"x" intoString:&xForHex]) {
                gotNumber = [scanner scanHexInt:&charCode];
            }
            else {
                gotNumber = [scanner scanInt:(int*)&charCode];
            }
            
            if (gotNumber) {
                [result appendFormat:@"%C", (unichar)charCode];
                [scanner scanString:@";" intoString:NULL];
            }
            else {
                NSString *unknownEntity = @"";
                [scanner scanUpToCharactersFromSet:boundaryCharacterSet intoString:&unknownEntity];
                [result appendFormat:@"&#%@%@", xForHex, unknownEntity];
                //[scanner scanUpToString:@";" intoString:&unknownEntity];
                //[result appendFormat:@"&#%@%@;", xForHex, unknownEntity];
                NSLog(@"Expected numeric character entity but got &#%@%@;", xForHex, unknownEntity);
            }
        }
        else {
            NSString *amp;
            [scanner scanString:@"&" intoString:&amp];      //an isolated & symbol
            [result appendString:amp];
        }
    }
    while (![scanner isAtEnd]);
    return result;
}

+ (NSString *)stringFromHexString:(NSString *)hexString {
    int len = (int)[hexString length] / 2 + 1;
    unsigned char *myBuffer = (unsigned char *)malloc(len);
    bzero(myBuffer, [hexString length] / 2 + 1);
    for (int i = 0; i < [hexString length] - 1; i += 2) {
        unsigned int anInt;
        NSString * hexCharStr = [hexString substringWithRange:NSMakeRange(i, 2)];
        NSScanner * scanner = [[NSScanner alloc] initWithString:hexCharStr];
        [scanner scanHexInt:&anInt];
        myBuffer[i / 2] = (unsigned char)anInt;
    }
    myBuffer[len - 1] = 0;
    NSMutableString *unicodeString = [[NSMutableString alloc] init];
    while (*myBuffer != 0) {
        [unicodeString appendString:[NSString stringWithFormat:@"%c", *myBuffer]];
        myBuffer ++;
    }
    return unicodeString.uppercaseString;
}

+ (NSString *)hexStringFromString:(NSString *)string{
    NSData *myD = [string dataUsingEncoding:NSUTF8StringEncoding];
    Byte *bytes = (Byte *)[myD bytes];
    //下面是Byte 转换为16进制。
    NSString *hexStr=@"";
    for(int i=0;i<[myD length];i++)
    {
        NSString *newHexStr = [NSString stringWithFormat:@"%x",bytes[i]&0xff];///16进制数
        if([newHexStr length]==1)
            hexStr = [NSString stringWithFormat:@"%@0%@",hexStr,newHexStr];
        else
            hexStr = [NSString stringWithFormat:@"%@%@",hexStr,newHexStr];
    }
    return hexStr.uppercaseString;
}

- (NSString *)IntString{
    long len = self.length;
    long long sum=0;
    int i = 0;
    while (i<len) {
        int tmp =  [self intWithChar:[self characterAtIndex:i]];
        long long weight = pow(16,len-i-1);
        sum += (tmp * weight);
        i++;
    }
    return [NSString stringWithFormat:@"%lld", sum];
}

- (BOOL)myContainsString:(NSString*)other {
    NSRange range = [self rangeOfString:other];
    return range.length != 0;
}

- (BOOL)isNotEmptyAndNil{
    if (self == nil || [self isEqualToString:@""]) {
        return false;
    }
    else{
        return true;
    }
}

- (NSRange)indexofString:(NSString *)str{
    NSRange range = NSMakeRange(0, 0);
    NSArray *aryTMP = [self componentsSeparatedByString:str];
    if (aryTMP.count > 1) {
        NSString *s = aryTMP[0];
        range.location = s.length;
        range.length = str.length;
    }
    return range;
}




//////
- (int)intWithChar:(char)c{
    switch (c) {
        case '1':return 1;
        case '2':return 2;
        case '3':return 3;
        case '4':return 4;
        case '5':return 5;
        case '6':return 6;
        case '7':return 7;
        case '8':return 8;
        case '9':return 9;
        case 'A':case 'a': return 10;
        case 'B':case 'b': return 11;
        case 'C':case 'c': return 12;
        case 'D':case 'd': return 13;
        case 'E':case 'e': return 14;
        case 'F':case 'f': return 15;

        default:
            break;
    }
    return 0;
}
@end
