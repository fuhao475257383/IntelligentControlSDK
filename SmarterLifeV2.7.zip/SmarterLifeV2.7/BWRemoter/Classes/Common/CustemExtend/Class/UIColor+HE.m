//
//  UIColor+HE.m
//  ZBCK
//
//  Created by JianBo He on 15/1/9.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "UIColor+HE.h"

@implementation UIColor(HE)


#pragma mark -
#pragma mark 将16进制颜色转UIColor
+ (UIColor*)colorOfTurnToUIColor:(NSString*)colorString
{
    NSInteger starIndex = 0, colorLength = [colorString length];
    if([colorString hasPrefix: @"#"])
    {
        starIndex = 1;
        colorLength -= 1;
    }
    CGFloat red = 0.0f,green = 0.0f,blue = 0.0f;
    //alpha=[self colorComponentFrom:colorString start:starIndex length:2];
    if(colorLength >= 2)
        red=[self colorComponentFrom:colorString start:starIndex length:2];
    if(colorLength >= 4)
        green=[self colorComponentFrom:colorString start:starIndex+2 length:2];
    if(colorLength >= 6)
        blue=[self colorComponentFrom:colorString start:starIndex+4 length:2];
    
    return [UIColor colorWithRed:red green:green blue:blue alpha:1.0f];
}

#pragma mark -
#pragma mark 将16进制颜色转UIColor 并设置透明度
+ (UIColor*)colorOfTurnToUIColor:(NSString*)colorString alpha:(CGFloat) alpha
{
    NSInteger starIndex = 0, colorLength = [colorString length];
    if([colorString hasPrefix: @"#"])
    {
        starIndex = 1;
        colorLength -= 1;
    }
    CGFloat red = 0.0f,green = 0.0f,blue = 0.0f;
    //alpha=[self colorComponentFrom:colorString start:starIndex length:2];
    if(colorLength >= 2)
        red=[self colorComponentFrom:colorString start:starIndex length:2];
    if(colorLength >= 4)
        green=[self colorComponentFrom:colorString start:starIndex+2 length:2];
    if(colorLength >= 6)
        blue=[self colorComponentFrom:colorString start:starIndex+4 length:2];
    
    return [UIColor colorWithRed:red green:green blue:blue alpha: alpha];
}

+ (CGFloat) colorComponentFrom:(NSString*)string start:(NSUInteger)start length:(NSUInteger)length
{
    NSString *substring = [string substringWithRange: NSMakeRange(start, length)];
    NSString *fullHex = length == 2 ? substring : [NSString stringWithFormat: @"%@%@", substring, substring];
    unsigned hexComponent;
    [[NSScanner scannerWithString: fullHex] scanHexInt: &hexComponent];
    return hexComponent / 255.0;
}
@end
