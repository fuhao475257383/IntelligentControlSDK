//
//  NSArray+FXW.m
//  BWRemoter
//
//  Created by iceDiao on 15/3/20.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "NSArray+FXW.h"

@implementation NSArray(FXW)


-(BOOL)isContainsStringObj:(NSString *)str{
    for (NSString *tmp in self) {
        if ([tmp isEqualToString:str]) {
            return YES;
        }
    }
    return NO;
}

@end
