//
//  HE_TabBarController.h
//  BWRemoter
//
//  Created by JianBo He on 14/12/5.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HE_TabBarController : UITabBarController

@end
