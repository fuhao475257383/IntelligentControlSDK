//
//  FXW_Slider.m
//  BWRemoter
//
//  Created by 6602_Loop on 15-1-16.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "FXW_Slider.h"

@implementation FXW_Slider
-(id)initWithFrame:(CGRect)frame Delegate:(id)delegate Datasourse:(id)datasourse{
    self = [super initWithFrame:frame];
    if(self){
        self.FXW_SliderDelegate = delegate;
        self.FXW_SliderDataSource = datasourse;
//        ///设置左右两边图片
//        [self setMinimumValueImage:[UIImage imageNamed:minValueimg]];
//        [self setMaximumValueImage:[UIImage imageNamed:maxValueimg]];
//        ///设置最小值和最大值
//        [self setMinimumValue:minValue];
//        [self setMaximumValue:maxValue];
//        ///设置滑块图片
//        [self setThumbImage:[UIImage imageNamed:thumbImg] forState:UIControlStateNormal];
//        ///设置滑块左边和滑块右边的图片
//        [self setMinimumTrackImage:[UIImage imageNamed:minTrackimg] forState:UIControlStateNormal];
//        [self setMaximumTrackImage:[UIImage imageNamed:maxTrackimg] forState:UIControlStateNormal];
    }
    return self;
}
//-(CGRect)thumbRectForBounds:(CGRect)bounds trackRect:(CGRect)rect value:(float)value{
//    
//}

-(CGRect)trackRectForBounds:(CGRect)bounds
{
    bounds.origin.x=bounds.size.width*0.15;
    bounds.size.width=bounds.size.width*0.65;
    bounds.size.height = bounds.size.height*0.9;
    return bounds;
}
@end
