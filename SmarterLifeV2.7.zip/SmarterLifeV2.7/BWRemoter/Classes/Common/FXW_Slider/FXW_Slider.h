//
//  FXW_Slider.h
//  BWRemoter
//
//  Created by 6602_Loop on 15-1-16.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FXW_SliderProtocol.h"
@interface FXW_Slider : UISlider
{
    ///左右两边的图片
    NSString *maxValueimg;
    NSString *minValueimg;
    ///最大值和最小值
    float maxValue;
    float minValue;
    ///滑块图片
    NSString *thumbImg;
    ///滑块左边和滑块右边的图片
    NSString *minTrackimg;
    NSString *maxTrackimg;
}
//代理
@property (nonatomic, assign) id<FXW_SliderDelegate> FXW_SliderDelegate;
//数据源
@property (nonatomic, assign) id<FXW_SliderDataSourse> FXW_SliderDataSource;
//初始化方法
-(id)initWithFrame:(CGRect)frame Delegate:(id)delegate Datasourse:(id)datasourse;
@end
