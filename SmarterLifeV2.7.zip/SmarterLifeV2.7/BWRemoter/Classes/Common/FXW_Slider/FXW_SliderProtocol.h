//
//  FXW_SliderProtocol.h
//  BWRemoter
//
//  Created by 6602_Loop on 15-1-16.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

@protocol FXW_SliderDelegate <NSObject>
@optional
@end
@protocol FXW_SliderDataSourse <NSObject>
@optional
@end
