//
//  FXW_ScrollView.m
//  scrollview
//
//  Created by 6602_Loop on 15-3-7.
//  Copyright (c) 2015年 范兴文. All rights reserved.
//

#import "FXW_ScrollView.h"
#import "HE_CustemExtend.h"
@implementation FXW_ScrollView
@synthesize sdelegate;
-(id)initWithFrame:(CGRect)frame andMaxVal:(CGFloat)max andMinVal:(CGFloat)min andDefaultValue:(NSInteger)defaultValue{
    _maxVal = max;
    _minVal = min;
    defaultVal = defaultValue;
    num = _maxVal - _minVal;
    self = [super initWithFrame:frame];
    self.layer.borderWidth = 1;
    self.layer.borderColor = [[UIColor colorWithRed:210/255.0f green:210/255.0f blue:210/255.0f alpha:1] CGColor];
    _leftBackview = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.frame.size.width*0.8, self.frame.size.height)];
    [_leftBackview setBackgroundColor:[UIColor colorWithRed:220/255.0f green:220/255.0f blue:220/255.0f alpha:1]];
    [self addSubview:_leftBackview];
    everyPageWidth = _leftBackview.frame.size.width/3;
    _scroll  = [[UIScrollView alloc]initWithFrame:CGRectMake(0,(self.frame.size.height-everyPageWidth)/2, self.frame.size.width*0.8, everyPageWidth)];
    _scroll.delegate = self;
    _scroll.bounces = NO;
    _scroll.showsHorizontalScrollIndicator = NO;
    [_leftBackview addSubview:_scroll];

    
    _scroll.contentSize=CGSizeMake((num+3)*everyPageWidth,0);
    
    UILabel *labNumleft = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, everyPageWidth, everyPageWidth)];
    [labNumleft setText:@""];
    [labNumleft setTextAlignment:NSTextAlignmentCenter];
    [labNumleft setTextColor:[UIColor colorWithRed:100/255.0 green:20/255.0 blue:30/255.0 alpha:1]];
    [labNumleft setFont:[UIFont systemFontOfSize:24]];
    [_scroll addSubview:labNumleft];
    
    UILabel *labNumrigth = [[UILabel alloc]initWithFrame:CGRectMake(everyPageWidth*(num+2), 0, everyPageWidth, everyPageWidth)];
    [labNumrigth setText:@""];
    [labNumrigth setTextAlignment:NSTextAlignmentCenter];
    [labNumrigth setTextColor:[UIColor colorWithRed:100/255.0 green:20/255.0 blue:30/255.0 alpha:1]];
    [labNumrigth setFont:[UIFont systemFontOfSize:24]];
    [_scroll addSubview:labNumrigth];
    
    for(int i =1;i < num+2; i++){
        UILabel *labNum = [[UILabel alloc]initWithFrame:CGRectMake(i*everyPageWidth,0, everyPageWidth, everyPageWidth)];
        [labNum setText:[NSString stringWithFormat:@"%.f℃",_minVal+i-1]];
        [labNum setTextAlignment:NSTextAlignmentCenter];
        [labNum setTextColor:[UIColor colorWithRed:100/255.0 green:20/255.0 blue:30/255.0 alpha:1]];
        labNum.tag = 1000+i;
        [labNum setFont:[UIFont systemFontOfSize:24]];
        [_scroll addSubview:labNum];
    }
    labTag = defaultVal+1000-_minVal;
    labtmp = (UILabel *)[self viewWithTag:labTag];
    _scroll.contentOffset = CGPointMake((defaultVal-_minVal)*everyPageWidth, 0);
    [self changeFontwithTemperature:defaultVal-_minVal];

    UIImageView *imgBack = [[UIImageView alloc]initWithFrame:CGRectMake(everyPageWidth-10,0, everyPageWidth+20, self.frame.size.height)];
    [imgBack setImage:[UIImage imageNamed:@"conditon_back_icon.png"]];
    [_leftBackview addSubview:imgBack];
    
    ////////////////////Right
    _btnSwithMode = [[UIButton alloc] initWithFrame:CGRectMake(_leftBackview.frameSumX_W + 8, _leftBackview.frameY + 5 , self.frameW - _leftBackview.frameW - 16 , _leftBackview.frameH -10)];
    UIImage *imgModeCold = [UIImage imageNamed:@"ic_AirCold.png"];
    UIImage *imgModeFire = [UIImage imageNamed:@"ic_AirFire.png"];
    [_btnSwithMode setImage:imgModeFire forState:UIControlStateNormal];
    [_btnSwithMode setImage:imgModeCold forState:UIControlStateSelected];
    [_btnSwithMode addTarget:self action:@selector(touchedSwithMode:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_btnSwithMode];
    return self;
}
- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    if(scrollView.contentOffset.x/everyPageWidth==_minVal-_minVal||scrollView.contentOffset.x/everyPageWidth==_maxVal-_minVal){
        if (!isNeedSendMsg) {
            isNeedSendMsg = true;
            return;
        }
        /********发消息********/
        if([sdelegate respondsToSelector:@selector(sendMsgwithNum:isMakeCold:)]){
            [sdelegate sendMsgwithNum:(NSInteger)(scrollView.contentOffset.x/everyPageWidth)+_minVal isMakeCold:isMakeCold];
        }
    }
}
- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView{
    if (!isNeedSendMsg) {
        isNeedSendMsg = true;
        return;
    }
    if(scrollView.contentOffset.x/everyPageWidth!=_minVal-_minVal&&scrollView.contentOffset.x/everyPageWidth!=_maxVal-_minVal){
        /********发消息********/
        if([sdelegate respondsToSelector:@selector(sendMsgwithNum:isMakeCold:)]){
            [sdelegate sendMsgwithNum:(NSInteger)(scrollView.contentOffset.x/everyPageWidth)+_minVal isMakeCold:isMakeCold];
        }
    }
}
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
    if(!decelerate){
        ///没滑就要处理位置咯
        NSString *page = [NSString stringWithFormat:@"%.f",scrollView.contentOffset.x/everyPageWidth];//取商
        CGFloat contentx = scrollView.contentOffset.x/everyPageWidth;
        if(([page floatValue]-contentx)>0.5){//＋1
            [scrollView setContentOffset:CGPointMake(([page floatValue]+1)*everyPageWidth, 0) animated:YES];
            [self changeFontwithTemperature:[page floatValue]+1];
            
        }
        else{
            [scrollView setContentOffset:CGPointMake(([page floatValue])*everyPageWidth, 0) animated:YES];
            [self changeFontwithTemperature:[page floatValue]];
        }
    }
}
///停止滚动时调整位置
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    NSString *page = [NSString stringWithFormat:@"%.f",scrollView.contentOffset.x/everyPageWidth];//取商
    CGFloat contentx = scrollView.contentOffset.x/everyPageWidth;
    if(([page floatValue]-contentx)>0.5){//＋1
        [scrollView setContentOffset:CGPointMake(([page floatValue]+1)*everyPageWidth, 0) animated:YES];
        [self changeFontwithTemperature:[page floatValue]+1];
    }
    else{
        [scrollView setContentOffset:CGPointMake(([page floatValue])*everyPageWidth, 0) animated:YES];
        [self changeFontwithTemperature:[page floatValue]];
    }
}

-(void)changeFontwithTemperature:(NSInteger)temperature{
    ///变大前把上一次变大的恢复
    [UIView animateWithDuration:0.2 animations:^{
        CGAffineTransform newTransform = CGAffineTransformMakeScale(1,1);
        labtmp = (UILabel *)[self viewWithTag:labTag];
        [labtmp setTransform:newTransform];
        [labtmp setTextColor:[UIColor colorWithRed:100/255.0 green:20/255.0 blue:30/255.0 alpha:1]];
    } completion:^(BOOL finished){
    }];
    labTag = 1001+temperature;
    [UIView animateWithDuration:0.2 animations:^{
        CGAffineTransform newTransform = CGAffineTransformMakeScale(1.6, 1.6);
        labtmp = (UILabel *)[self viewWithTag:labTag];
        [labtmp setTransform:newTransform];
        [labtmp setTextColor:[UIColor redColor]];
    } completion:^(BOOL finished){
    }];
}

- (void)touchedSwithMode:(UIButton *)sender{
    sender.selected = ! sender.isSelected;
    isMakeCold = sender.selected;//////选中则为制冷
    if([sdelegate respondsToSelector:@selector(sendMsgwithNum:isMakeCold:)]){
        [sdelegate sendMsgwithMode:isMakeCold];
    }
}
-(void)setValue:(NSInteger)value isAnimate:(BOOL)animate{
    if((NSInteger)(value-_minVal+1001)!=labTag){
        isNeedSendMsg = false;
        [_scroll setContentOffset:CGPointMake((value-_minVal)*everyPageWidth, 0) animated:YES];
        [self changeFontwithTemperature:value-_minVal];
    }
}
-(void)setMode:(BOOL)isCold{
    _btnSwithMode.selected = isCold;
    isMakeCold             = isCold;
}
@end
