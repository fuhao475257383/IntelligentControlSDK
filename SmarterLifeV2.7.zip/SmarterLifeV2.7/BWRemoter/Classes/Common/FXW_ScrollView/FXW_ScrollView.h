//
//  FXW_ScrollView.h
//  scrollview
//
//  Created by 6602_Loop on 15-3-7.
//  Copyright (c) 2015年 范兴文. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol FXW_ScrollViewDelegate<NSObject>
@optional
-(void)sendMsgwithNum:(NSInteger)Temperature isMakeCold:(BOOL) isCold;
-(void)sendMsgwithMode:(BOOL)isCold;
@end
@interface FXW_ScrollView : UIView<UIScrollViewDelegate>
{
    id<FXW_ScrollViewDelegate> sdelegate;
    NSInteger  num;//所有数的数量
    CGFloat    everyPageWidth;//每页的宽度
    NSInteger  defaultVal;
    NSInteger  labTag;//用来记录上一次变大的label的tag
    UILabel    *labtmp ;
    //////////////////////Mode.   记录模式(制冷/制热)
    BOOL       isMakeCold;
    BOOL       isNeedSendMsg;
}
@property (nonatomic,strong) id<FXW_ScrollViewDelegate> sdelegate;
@property (nonatomic) CGFloat maxVal;
@property (nonatomic) CGFloat minVal;
/////////Left
@property (nonatomic,strong)UIView *leftBackview;
@property (nonatomic,strong)UIScrollView *scroll;
/////////Right
@property (nonatomic,strong)UIButton *btnSwithMode;

-(id)initWithFrame:(CGRect)frame andMaxVal:(CGFloat)max andMinVal:(CGFloat)min andDefaultValue:(NSInteger)defaultValue;
-(void)setValue:(NSInteger)value isAnimate:(BOOL)animate;
-(void)setMode:(BOOL)isCold;
@end
