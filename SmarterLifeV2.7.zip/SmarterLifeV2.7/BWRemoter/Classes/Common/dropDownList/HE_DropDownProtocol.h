//
//  DropDownChooseProtocol.h
//  DropDownDemo
//
//  Created by 童明城 on 14-5-28.
//  Copyright (c) 2014年 童明城. All rights reserved.
//

#import <Foundation/Foundation.h>


@class HE_DropDownListView;
@protocol HE_DDDelegate <NSObject>

@optional

-(void)dropDownList:(HE_DropDownListView *)dropDown chooseAtSection:(NSInteger)section index:(NSInteger)index;
@end

@protocol HE_DDDataSource <NSObject>


-(NSInteger)numberOfSections:(HE_DropDownListView *)dropDown;
-(NSInteger)dropDownList:(HE_DropDownListView *)dropDown numberOfRowsInSection:(NSInteger)section;
-(NSString *)dropDownList:(HE_DropDownListView *)dropDown titleInSection:(NSInteger)section index:(NSInteger) index;
-(NSInteger)dropDownList:(HE_DropDownListView *)dropDown defaultShowSection:(NSInteger)section;

@end



