//
//  DropDownListView.m
//  DropDownDemo
//
//  Created by 童明城 on 14-5-28.
//  Copyright (c) 2014年 童明城. All rights reserved.
//

#import "HE_DropDownListView.h"
#define MAX_DDHEIGHT 40 * 5
#define DEGREES_TO_RADIANS(angle) ((angle)/180.0 *M_PI)
#define RADIANS_TO_DEGREES(radians) ((radians)*(180.0/M_PI))

@implementation HE_DropDownListView
@synthesize sectionBtn;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame dataSource:(id)datasource delegate:(id) delegate ddTag:(NSInteger)viewTag;
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        currentExtendSection = -1;// －1表示都没有展开
        self.dropDownDataSource = datasource;
        self.dropDownDelegate = delegate;
        self.tag = viewTag;
        
        NSInteger sectionNum =0;
        if ([self.dropDownDataSource respondsToSelector:@selector(numberOfSections:)] ) {
            sectionNum = [self.dropDownDataSource numberOfSections:self];
        }
        if (sectionNum == 0) {
            self = nil;
        }
        //初始化默认显示view
       CGFloat sectionWidth = frame.size.width;
        for (int i = 0; i <sectionNum; i++) {
            UIView *boder = [[UIView alloc]initWithFrame:CGRectMake(0, 0,sectionWidth, 30)];
            boder.layer.borderWidth=1.0f;
            boder.layer.borderColor = [[UIColor grayColor]CGColor];
            boder.layer.cornerRadius = 3.0f;
            [self addSubview:boder];
            
            sectionBtn = [[UIButton alloc] initWithFrame:CGRectMake(10, 0,sectionWidth-10, 30)];
            sectionBtn.tag = SECTION_BTN_TAG_BEGIN + i;
            [sectionBtn addTarget:self action:@selector(sectionBtnTouch:) forControlEvents:UIControlEventTouchUpInside];
            NSString *sectionBtnTitle = @"--";
            if ([self.dropDownDataSource respondsToSelector:@selector(dropDownList:titleInSection:index:)]) {
                if ([self.dropDownDataSource dropDownList:self defaultShowSection:i] != -1) {
                    sectionBtnTitle = [self.dropDownDataSource dropDownList:self titleInSection:i index:[self.dropDownDataSource dropDownList:self defaultShowSection:i]];
                }
            }
            [sectionBtn  setTitle:sectionBtnTitle forState:UIControlStateNormal];
            [sectionBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
            sectionBtn.titleLabel.font = [UIFont boldSystemFontOfSize:14.0f];
            sectionBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
            [boder addSubview:sectionBtn];
            //三角形
            UIView *boder2 = [[UIImageView alloc] initWithFrame:CGRectMake(sectionWidth-28,3, 24, 24)];
            boder2.layer.borderWidth = 1.0f;
            boder2.layer.borderColor = [[UIColor grayColor]CGColor];
            [boder addSubview:boder2];
            UIImageView *sectionBtnIv = [[UIImageView alloc] initWithFrame:CGRectMake(sectionWidth-28+5,8, 15, 10)];
            [sectionBtnIv setImage:[UIImage imageNamed:@"downlog.png"]];
            [sectionBtnIv setContentMode:UIViewContentModeScaleToFill];
            sectionBtnIv.tag = SECTION_IV_TAG_BEGIN + i;
            
            [boder addSubview: sectionBtnIv];
        }
        
    }
    
    return self;
}
#pragma mark --默认选项的接口
-(void)setTitleDefault:(NSInteger)index{
    [sectionBtn setTitle:[self.dropDownDataSource dropDownList:self titleInSection:0 index:index] forState:UIControlStateNormal];
}
-(void)sectionBtnTouch:(UIButton *)btn
{
    NSInteger section = btn.tag - SECTION_BTN_TAG_BEGIN;
    
    UIImageView *currentIV= (UIImageView *)[self viewWithTag:(SECTION_IV_TAG_BEGIN +currentExtendSection)];
    //动画先旋转180度
    [UIView animateWithDuration:0.3 animations:^{
        currentIV.transform = CGAffineTransformRotate(currentIV.transform, DEGREES_TO_RADIANS(180));
    }];
    
    //如果已经点开了table，就隐藏
    if (currentExtendSection == section) {
        [self hideExtendedChooseView];
    }else{
        //刚点
        currentExtendSection = section;
        currentIV = (UIImageView *)[self viewWithTag:SECTION_IV_TAG_BEGIN + currentExtendSection];
        
        [UIView animateWithDuration:0.3 animations:^{
            currentIV.transform = CGAffineTransformRotate(currentIV.transform, DEGREES_TO_RADIANS(180));
        }];
        //展开table
        [self showChooseListViewInSection:currentExtendSection choosedIndex:[self.dropDownDataSource dropDownList:self defaultShowSection:currentExtendSection]];
    }
}

- (void)setTitle:(NSString *)title inSection:(NSInteger) section
{
    UIButton *btn = (id)[self viewWithTag:SECTION_BTN_TAG_BEGIN +section];
    [btn setTitle:title forState:UIControlStateNormal];
}

- (BOOL)isShow
{
    if (currentExtendSection == -1) {
        return NO;
    }
    return YES;
}
-  (void)hideExtendedChooseView
{
    if (currentExtendSection != -1) {
        currentExtendSection = -1;
        CGRect rect = self.mTableView.frame;
        rect.size.height = 0;
        [UIView animateWithDuration:0.3 animations:^{
            self.mTableBaseView.alpha = 1.0f;
            self.mTableView.alpha = 1.0f;
            
            self.mTableBaseView.alpha = 0.2f;
            self.mTableView.alpha = 0.2;
            
            self.mTableView.frame = rect;
        }completion:^(BOOL finished) {
            [self.mTableView removeFromSuperview];
            [self.mTableBaseView removeFromSuperview];
        }];
    }
}
//展开table
-(void)showChooseListViewInSection:(NSInteger)section choosedIndex:(NSInteger)index
{
    if (!self.mTableView) {
        self.mTableBaseView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
        self.mTableBaseView.backgroundColor = [UIColor colorWithWhite:0.0f alpha:0.5];
     //   self.mTableBaseView.backgroundColor = [UIColor redColor];
        
        //点击遮盖层隐藏table
        UITapGestureRecognizer *bgTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(bgTappedAction:)];
        [self.mTableBaseView addGestureRecognizer:bgTap];
        
        self.mTableView = [[UITableView alloc]init];
        self.mTableView.delegate = self;
        self.mTableView.dataSource = self;
    }
    //修改tableview的frame
    int sectionWidth = (self.frame.size.width)/[self.dropDownDataSource numberOfSections:self];
    CGRect rect = self.frame;
//    rect.origin.x =self.frame.origin.x;
//    rect.origin.y = self.frame.origin.y+self.frame.size.height+10;
    rect.size.width = sectionWidth;
    CGRect recttable= [self.superview convertRect:self.frame toView:self.mSuperView];
    rect.origin.x=recttable.origin.x;
    rect.origin.y=recttable.origin.y+self.frame.size.height+10;
    self.mTableView.frame = rect;
    
    [self.mSuperView addSubview:self.mTableBaseView];
    [self.mSuperView addSubview:self.mTableView];

//    [self.mSuperView addSubview:self.mTableView];
    
    //动画设置位置
    rect.size.height = [self.dropDownDataSource dropDownList:self numberOfRowsInSection:currentExtendSection]*40;
    rect.size.height =  rect.size.height >= MAX_DDHEIGHT?MAX_DDHEIGHT: rect.size.height;
    [UIView animateWithDuration:0.3 animations:^{
        self.mTableBaseView.alpha = 0.2;
        self.mTableView.alpha = 0.2;
        
        self.mTableBaseView.alpha = 1.0;
        self.mTableView.alpha = 1.0;
        self.mTableView.contentSize = rect.size;
        self.mTableView.frame =  rect;
    }];
    [self.mTableView reloadData];
}

-(void)bgTappedAction:(UITapGestureRecognizer *)tap
{
    UIImageView *currentIV = (UIImageView *)[self viewWithTag:(SECTION_IV_TAG_BEGIN + currentExtendSection)];
    [UIView animateWithDuration:0.3 animations:^{
        currentIV.transform = CGAffineTransformRotate(currentIV.transform, DEGREES_TO_RADIANS(180));
    }];
    [self hideExtendedChooseView];
}
#pragma mark -- UITableView Delegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 40;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([self.dropDownDelegate respondsToSelector:@selector(dropDownList: chooseAtSection:index:)]) {
        NSString *chooseCellTitle = [self.dropDownDataSource dropDownList:self titleInSection:currentExtendSection index:indexPath.row];
        
        UIButton *currentSectionBtn = (UIButton *)[self viewWithTag:SECTION_BTN_TAG_BEGIN + currentExtendSection];
        [currentSectionBtn setTitle:chooseCellTitle forState:UIControlStateNormal];
        
        [self.dropDownDelegate dropDownList:self chooseAtSection:currentExtendSection index:indexPath.row];
        //在转半圈
        UIImageView *currentIV = (UIImageView *)[self viewWithTag:(SECTION_IV_TAG_BEGIN + currentExtendSection)];
        [UIView animateWithDuration:0.3 animations:^{
            currentIV.transform = CGAffineTransformRotate(currentIV.transform, DEGREES_TO_RADIANS(180));
        }];
        [self hideExtendedChooseView];
    }
}

#pragma mark -- UITableView DataSource


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.dropDownDataSource dropDownList:self numberOfRowsInSection:currentExtendSection];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * cellIdentifier = @"cellIdentifier";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    
    cell.textLabel.text = [self.dropDownDataSource dropDownList:self titleInSection:currentExtendSection index:indexPath.row];
    cell.textLabel.font = [UIFont systemFontOfSize:14];
    return cell;
}

@end
