//
//  HE_NavgationController.m
//  BWRemoter
//
//  Created by JianBo He on 14/12/5.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//
#import "P2PCameraDemoViewController.h"
#import "HE_NavgationController.h"
#import "HE_APPManager.h"

@interface HE_NavgationController ()

@end

@implementation HE_NavgationController

- (void)viewDidLoad {
    [super viewDidLoad];
//    [self.navigationBar setTranslucent:NO];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didRotate:) name:UIDeviceOrientationDidChangeNotification object:nil];

}

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated{
    [super pushViewController:viewController animated:animated];
    [[[HE_APPManager sharedManager] aryActiveDevice] removeAllObjects];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSUInteger)supportedInterfaceOrientations{
    return UIInterfaceOrientationMaskAll;
}

- (BOOL)shouldAutorotate{
    if ([self.topViewController isKindOfClass:[P2PCameraDemoViewController class]]) {
        return YES;
    }else{
        return NO;
    }
}


- (void) didRotate:(NSNotification *)notification
{
    UIDeviceOrientation toInterfaceOrientation = [[UIDevice currentDevice] orientation];
    CGRect rx = [ UIScreen mainScreen ].bounds;
    
    if ([self.topViewController isKindOfClass:[P2PCameraDemoViewController class]]) {
        P2PCameraDemoViewController * viewController = self.topViewController;
        
        if (toInterfaceOrientation == UIInterfaceOrientationPortrait || toInterfaceOrientation == UIDeviceOrientationPortraitUpsideDown) {
            self.navigationBarHidden = NO;
            [[UIApplication sharedApplication] setStatusBarHidden:NO];
            viewController.playView.transform = CGAffineTransformMakeRotation(0);
            viewController.playView.frame = CGRectMake(0, 64, rx.size.width, rx.size.width*0.6);
        }else{
            self.navigationBarHidden = YES;
            [[UIApplication sharedApplication] setStatusBarHidden:YES];
            viewController.playView.transform = CGAffineTransformMakeRotation(M_PI/2);
            viewController.playView.frame = CGRectMake(0, 0, rx.size.width, rx.size.height);
        }
    }
}


@end
