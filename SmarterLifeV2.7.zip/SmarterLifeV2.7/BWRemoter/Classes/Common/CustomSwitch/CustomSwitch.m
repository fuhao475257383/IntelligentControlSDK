//
//  CustomSwitch.m
//  BWRemoter
//
//  Created by tc on 15/11/12.
//  Copyright © 2015年 ReSun. All rights reserved.
//

#import "CustomSwitch.h"

@interface CustomSwitch ()

//移动的视图
@property (nonatomic,strong) UIView *rectangle;

@end

@implementation CustomSwitch

- (instancetype)initWithFrame:(CGRect)frame andState:(BOOL)isChoice {
    self = [super initWithFrame:frame];
    if (self) {
        self.isChoice = isChoice;
        self.frame = frame;
        [self addViewInfo];
    }
    return self;
}
- (void)addViewInfo {
    //背景view
    CGRect backRectangleRect = self.bounds;
    backRectangleRect.size.height = self.bounds.size.height * 0.8;
    backRectangleRect.origin.y = self.bounds.size.height * 0.1;
    UIView *backRectangle = [[UIView alloc]initWithFrame:backRectangleRect];
    backRectangle.layer.cornerRadius = 5;
    backRectangle.layer.borderWidth = 1;
    backRectangle.layer.borderColor = [UIColor blackColor].CGColor;
    CGRect onRect = CGRectMake(0, 0, backRectangleRect.size.width/2, backRectangleRect.size.height);
    CGRect offRect = CGRectMake(backRectangleRect.size.width/2, 0, backRectangleRect.size.width/2, backRectangleRect.size.height);
    //on
    UILabel *noLabel = [[UILabel alloc]initWithFrame:onRect];
    noLabel.text = @"ON";
    noLabel.font = [UIFont systemFontOfSize:15];
    noLabel.textColor = [UIColor blackColor];
    noLabel.textAlignment = NSTextAlignmentCenter;
    //off
    UILabel *offLabel = [[UILabel alloc]initWithFrame:offRect];
    offLabel.text = @"OFF";
    offLabel.font = [UIFont systemFontOfSize:15];
    offLabel.textColor = [UIColor blackColor];
    offLabel.textAlignment = NSTextAlignmentCenter;
    [backRectangle addSubview:noLabel];
    [backRectangle addSubview:offLabel];
    [self addSubview:backRectangle];
    
    //添加遮蔽层
    CGRect rectangleRect = self.bounds;
    rectangleRect.size.width = self.bounds.size.width/2;
    if (self.isChoice) {
        rectangleRect.origin.x = self.bounds.size.width/2;
    }
    self.rectangle = [[UIView alloc]initWithFrame:rectangleRect];
    self.rectangle.backgroundColor = [UIColor colorWithRed:230/255.0 green:230/255.0 blue:230/255.0 alpha:1];
    self.rectangle.layer.cornerRadius = 5;
    self.rectangle.layer.masksToBounds = YES;
    self.rectangle.layer.borderWidth = 1;
    self.rectangle.layer.borderColor = [UIColor colorWithRed:100/255.0 green:100/255.0 blue:100/255.0 alpha:1].CGColor;
    [self addSubview:self.rectangle];
    
    //在最上层添加一个透明的按钮
    UIButton *transparentButton = [[UIButton alloc]initWithFrame:self.bounds];
    transparentButton.backgroundColor = [UIColor clearColor];
    transparentButton.selected = self.isChoice;
    [transparentButton addTarget:self action:@selector(changeButtonState:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:transparentButton];
}
//点击事件
- (void)changeButtonState:(UIButton *)sender {
    sender.selected = !sender.selected;
    self.isChoice = sender.selected;
    [self.delegate switchStateChangeWithState:self.isChoice];
    [self changeRectangleRect];
}
//变换位置
- (void)changeRectangleRect {
    CGRect newRect = self.rectangle.frame;
    newRect.origin.x = self.bounds.size.width/2*self.isChoice;
    [UIView animateWithDuration:0.3 animations:^{
        self.rectangle.frame = newRect;
    }];
}
@end