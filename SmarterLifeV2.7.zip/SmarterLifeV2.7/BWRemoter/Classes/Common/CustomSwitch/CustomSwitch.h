//
//  CustomSwitch.h
//  BWRemoter
//
//  Created by tc on 15/11/12.
//  Copyright © 2015年 ReSun. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol CustomSwitchDelegate <NSObject>
//当被点击后，调用该方法
- (void)switchStateChangeWithState:(BOOL)isChoice;

@end

@interface CustomSwitch : UIView

//是否是选中状态，查询用，设置请到构造方法设置
@property (nonatomic) BOOL isChoice;
//代理
@property (nonatomic,weak) id<CustomSwitchDelegate> delegate;

//构造方法
- (instancetype)initWithFrame:(CGRect)frame andState:(BOOL)isChoice;

@end
