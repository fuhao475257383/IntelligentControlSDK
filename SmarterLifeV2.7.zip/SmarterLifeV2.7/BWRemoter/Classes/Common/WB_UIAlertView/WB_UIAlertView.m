//
//  WB_UIAlertView.m
//  TeachingAssistant
//
//  Created by wangbin on 15/2/20.
//  Copyright (c) 2015年 wangbin. All rights reserved.
//

#import "WB_UIAlertView.h"

#define Screenwidth [UIScreen mainScreen].bounds.size.width
#define Screenheight [UIScreen mainScreen].bounds.size.height

@implementation WB_UIAlertView
@synthesize BackView;
@synthesize AlertView;
@synthesize Title;
@synthesize areaName;
@synthesize addPictureBtn;

-(id)initWithFrame:(CGRect)frame Delegate:(id)delegate Datasourse:(id)datasourse{
    self = [super initWithFrame:frame];
    self.WB_alertDelegate = delegate;
    BackView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, Screenwidth, Screenheight)];
    [BackView setBackgroundColor:[UIColor grayColor]];
    [self addSubview:BackView];
    
    UITapGestureRecognizer *bgTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(bgTappedAction:)];
    [BackView addGestureRecognizer:bgTap];
    
    AlertView =[[UIView alloc]init];
    [AlertView setFrame:CGRectMake(Screenwidth*0.1, Screenheight * 0.1, Screenwidth*0.8, 80)];
    [AlertView setBackgroundColor:[UIColor whiteColor]];
    AlertView.alpha=1;
    [self addSubview:AlertView];
    [UIView animateWithDuration:0.3 delay:0 options:UIViewAnimationOptionTransitionFlipFromLeft
                     animations:^{
                         self.BackView.alpha = 0.2;
                         self.BackView.alpha = 0.4;
                         self.BackView.alpha = 0.6;
                         AlertView.alpha =0;
                         AlertView.alpha =0.3;
                         AlertView.alpha =0.6;
                         AlertView.alpha =0.8;
                         AlertView.alpha =1;
                         
                         
                     } completion:^(BOOL finish){
                     }];
    
    UIView *titleline = [[UIView alloc]initWithFrame:CGRectMake(AlertView.frame.size.width*0.05, 40, AlertView.frame.size.width*0.9, 1)];
    [titleline setBackgroundColor:[UIColor grayColor]];
    titleline.alpha=0.6;
    [AlertView addSubview:titleline];
    //标题
    Title = [[UILabel alloc]initWithFrame:CGRectMake(0, 3, AlertView.frame.size.width, 37)];
    [Title setFont:[UIFont boldSystemFontOfSize:18]];
    [Title setTextAlignment:NSTextAlignmentCenter];
    [AlertView addSubview:Title];
    return self;
}
///添加保存取消按钮
-(void)AddButton:(NSInteger)ActionType{
    
    UIView *bottomline = [[UIView alloc]initWithFrame:CGRectMake(AlertView.frame.size.width*0.05, AlertView.frame.size.height-40, AlertView.frame.size.width*0.9, 1)];
    [bottomline setBackgroundColor:[UIColor grayColor]];
    bottomline.alpha=0.4;
    [AlertView addSubview:bottomline];
    //保存
    UIButton *save = [[UIButton alloc]initWithFrame:CGRectMake(0, AlertView.frame.size.height-40, AlertView.frame.size.width*0.5, 40)];
    [save setTitle:@"保存" forState:UIControlStateNormal];
    [save setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [save setTag:ActionType];
    [save addTarget:self action:@selector(saveBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [AlertView addSubview:save];
    //取消
    UIButton *cancel = [[UIButton alloc]initWithFrame:CGRectMake(AlertView.frame.size.width*0.5, AlertView.frame.size.height-40, AlertView.frame.size.width*0.5, 40)];
    [cancel setTitle:@"取消" forState:UIControlStateNormal];
    [cancel setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [cancel addTarget:self action:@selector(bgTappedAction:) forControlEvents:UIControlEventTouchUpInside];
    [AlertView addSubview:cancel];
    //分割线
    UIView *cutline = [[UIView alloc]initWithFrame:CGRectMake(AlertView.frame.size.width*0.5, AlertView.frame.size.height-40, 1, 40)];
    [cutline setBackgroundColor:[UIColor grayColor]];
    cutline.alpha=0.4;
    [AlertView addSubview:cutline];
}

///自定义内容
-(void)setContent:(Alerttype)content andBaseInfo:(NSString *)BaseInfo andActionType:(NSInteger)actionTypeNum{
    alertType =content;
    switch (content) {
        case AddHouse:
            [self AddHouseClick:BaseInfo ActionType:actionTypeNum];
            break;
        default:
            break;
    }
}

///添加房间
-(void)AddHouseClick:(NSString*)Content ActionType:(NSInteger)actionTypeNum{
    [Title setText:@"添加房间"];
    UIView *back_view = [[UIView alloc]initWithFrame:CGRectMake(0, 40, AlertView.frame.size.width, 140)];
    CGRect frame =  AlertView.frame;
    frame.size.height+=140;
    [AlertView setFrame:frame];
    [AlertView addSubview:back_view];
    [self AddButton:actionTypeNum];
    
    
    //label
    UILabel *areaLabel = [[UILabel alloc]initWithFrame:CGRectMake(30, back_view.frame.size.height/5, back_view.frame.size.width/3, back_view.frame.size.height/4)];
    [areaLabel setText:@"房间名称:"];
    [areaLabel setTextAlignment:NSTextAlignmentCenter];
    [back_view addSubview:areaLabel];
    //文本框
    areaName = [[UITextField alloc]initWithFrame:CGRectMake(back_view.frame.size.width/2,  back_view.frame.size.height/5,  back_view.frame.size.width*0.4,  back_view.frame.size.height/4)];
    areaName.borderStyle=UITextBorderStyleRoundedRect;
    areaName.keyboardType=UIKeyboardTypeDefault;
    areaName.clearButtonMode = UITextFieldViewModeAlways;
    areaName.returnKeyType = UIReturnKeyDone;
    
    areaName.minimumFontSize=10;
    areaName.delegate = self;
    [back_view addSubview:areaName];
    
    //label
    UILabel *scoreLabel = [[UILabel alloc]initWithFrame:CGRectMake(30, back_view.frame.size.height/2+10, back_view.frame.size.width/3, back_view.frame.size.height/4)];
    [scoreLabel setText:@"添加图片:"];
    [scoreLabel setTextAlignment:NSTextAlignmentCenter];
    [back_view addSubview:scoreLabel];
    
    addPictureBtn = [[UIButton alloc]initWithFrame:CGRectMake(back_view.frame.size.width/2,  back_view.frame.size.height/2+10,  back_view.frame.size.width*0.4,  back_view.frame.size.height/4)];
    [addPictureBtn setTitle:@"+" forState:UIControlStateNormal];
    [addPictureBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [addPictureBtn.layer setBorderWidth:0.5f];
    [addPictureBtn setTag:10012];
    [addPictureBtn.layer setBorderColor:[[UIColor grayColor] CGColor]];
    [addPictureBtn addTarget:self action:@selector(openMenu) forControlEvents:UIControlEventTouchUpInside];
    [back_view addSubview:addPictureBtn];
}

#pragma mark --消失alert
-(void)bgTappedAction:(UITapGestureRecognizer *)tap
{
    if([self.WB_alertDelegate respondsToSelector:@selector(CancelAlert)]){
        [self.WB_alertDelegate CancelAlert];
    }
    if(![areaName resignFirstResponder])
    {
        [UIView animateWithDuration:0.2 delay:0 options:UIViewAnimationOptionTransitionFlipFromLeft
                         animations:^{
                             self.BackView.alpha = 0.4;
                             self.BackView.alpha = 0.2;
                             self.BackView.alpha = 0;
                             AlertView.alpha =0.8;
                             AlertView.alpha =0.6;
                             AlertView.alpha =0.3;
                             AlertView.alpha =0;
                         } completion:^(BOOL finish){
                             [self removeFromSuperview];
                         }];
        
    }
}

//点击添加（“+”）按钮调用委托
-(void)openMenu
{
    if([self.WB_alertDelegate respondsToSelector:@selector(AddHousePicture)]){
        [self.WB_alertDelegate AddHousePicture];
    }
}

//点击保存按钮
-(void)saveBtnClick:(id)sender{
    areaText = areaName.text;
    UIButton *btnSender = (UIButton *)sender;
    
    if(btnSender.tag==10011)
    {
        if([self.WB_alertDelegate respondsToSelector:@selector(saveBtnAddHouse:actionType:)]){
            if([self.WB_alertDelegate saveBtnAddHouse:areaText actionType:btnSender.tag]){
                [self removeFromSuperview];
            }
        }
    }
}

//隐藏键盘
-(void)dismissKeyboard {
    [areaName resignFirstResponder];
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
@end
