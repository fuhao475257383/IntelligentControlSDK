//
//  WB_UIAlertView.h
//  TeachingAssistant
//
//  Created by wangbin on 15/2/20.
//  Copyright (c) 2015年 wangbin. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum{
    AddHouse
}Alerttype;

@protocol WB_alertDelegate <NSObject>

@optional

-(BOOL) saveBtnAddHouse:(NSString *)picname actionType:(NSInteger)actionType;
-(void) AddHousePicture;
-(void) CancelAlert;

@end


@interface WB_UIAlertView : UIView<UITextFieldDelegate>
{
    //弹出框类型
    Alerttype alertType;
    //添加人数
    NSString *areaText;
    
    NSInteger actionType;
}

@property (nonatomic, assign) id<WB_alertDelegate> WB_alertDelegate;
//背景灰
@property (nonatomic, strong) UIView *BackView;
//alert
@property (nonatomic, strong) UIView *AlertView;
//标题
@property (nonatomic, strong) UILabel *Title;
//文本框
@property (nonatomic, strong) UITextField *areaName;
//添加图片按钮
@property (nonatomic, strong) UIButton *addPictureBtn;

-(id)initWithFrame:(CGRect)frame Delegate:(id)delegate Datasourse:(id)datasourse;
///title

-(void)setContent:(Alerttype)content andBaseInfo:(NSString *)title andActionType:(NSInteger)actionType;
@end
