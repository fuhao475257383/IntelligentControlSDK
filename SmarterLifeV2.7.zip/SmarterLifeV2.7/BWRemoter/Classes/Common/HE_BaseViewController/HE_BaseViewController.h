//
//  HE_BaseViewController.h
//  
//
//  Created by JianBo He on 14/12/2.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HE_APPManager.h"
#import "HE_CustemExtend.h"


@protocol BaseViewControllDelegate;
@interface HE_BaseViewController : UIViewController <UITextFieldDelegate>
{
    CGSize curScreenSize;
    ///
    HE_APPManager *appManager;
    ///
    HE_MsgBuilder *msgB;
    HE_MsgParser *msgP;
    HE_CMDBuilder *cmdB;
    HE_CMDParser *cmdP;
}
@property UIView *fristResponse;
- (void)hideKeyBord;
- (HE_APPManager *)appManager;

- (float)NavgationBarHeight;

- (void)touchedBackButton:(id)sender;
- (void)reloadData:(NSString *)strCMD;
@end



@protocol BaseViewControllDelegate <NSObject>

@optional
- (void)reloadData:(NSString *)cmd;
- (void)reciveGateWayMsg:(NSString *)strMsg;
- (void)dataBaseDidUpdate;

@end