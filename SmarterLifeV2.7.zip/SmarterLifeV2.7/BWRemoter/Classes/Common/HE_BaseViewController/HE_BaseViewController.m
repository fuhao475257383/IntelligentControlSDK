//
//  HE_BaseViewController.m
//
//
//  Created by JianBo He on 14/12/2.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "HE_BaseViewController.h"

@interface HE_BaseViewController ()

@end

@implementation HE_BaseViewController
@synthesize fristResponse;
- (id)init{
    self = [super init];
    if (self) {
        appManager = [HE_APPManager sharedManager];
        if (!msgB) {
            msgB = [[HE_MsgBuilder alloc] init];
            msgP = [[HE_MsgParser alloc] init];
            cmdB = [[HE_CMDBuilder alloc] init];
            cmdP = [[HE_CMDParser alloc] init];
        }
    }
    return self;
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [appManager setDelegateViewCtrl:self];    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor whiteColor]];
    /*****      获取屏幕当前尺寸     *****/
    curScreenSize = [UIScreen mainScreen].bounds.size;
    
    /*****     清除实时设备检测     *****/
    [[[HE_APPManager sharedManager] aryActiveDevice] removeAllObjects];
    /*****         后退按钮        *****/
    UIButton *btnBack = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 30, 30)];
    [btnBack setBackgroundImage:[UIImage imageNamed:@"ic_back.png"] forState:UIControlStateNormal];
    [btnBack setBackgroundImage:[UIImage imageNamed:@"ic_back_H.png"] forState:UIControlStateHighlighted];
//    [btnBack setBackgroundColor:[UIColor clearColor]];
    [btnBack addTarget:self action:@selector(touchedBackButton:) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:btnBack];
    
    /*****         键盘通知          ****/
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillChangeFrame:)
                                                 name:UIKeyboardWillChangeFrameNotification
                                               object:nil];
    
    /*****      点击隐藏键盘手势      ****/
//    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self
//                                                                                 action:@selector(hideKeyBord)];
//    [self.view addGestureRecognizer:tapGesture];
//    if (self.navigationController != nil) {
//        [self.navigationController setDelegate:self];
//    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark -
#pragma mark NavgationControll Delegate
//- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated {
//    [appManager setDelegateViewCtrl:self];
//}

#pragma mark -
#pragma mark TextFeild Delegates
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    
    if (textField.returnKeyType == UIReturnKeyNext){
        NSInteger tag = [textField tag];
        UIView *txt = [self.view viewWithTag:tag +1];
        [txt becomeFirstResponder];
    }
    else if (textField.returnKeyType == UIReturnKeyGo
             || textField.returnKeyType == UIReturnKeySend
             || textField.returnKeyType == UIReturnKeyDone){
        [textField resignFirstResponder];
        CGRect frame = self.view.frame;
        frame.origin.y = 0;
        [self.view setFrame:frame];
        return YES;
    }
    return YES;
}
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    fristResponse = textField;
}
#pragma mark -
#pragma mark Public Method
- (float)NavgationBarHeight{
    return self.navigationController.navigationBar.frame.size.height + 20.f;
}

- (HE_APPManager *)appManager{
    return appManager;
}

- (void)reloadData:(NSString *)strCMD{
    ;
}
#pragma mark -
#pragma mark Private Method
- (void)hideKeyBord {
    [self.view endEditing:YES];
    CGRect frame = self.view.frame;
    frame.origin.y = 0;
    [UIView animateWithDuration:0.3
                     animations:^(){
                         [self.view setFrame:frame];
                     } completion:nil];
    
}
- (void)keyboardWillChangeFrame:(NSNotification *)notification{
    NSDictionary *info = [notification userInfo];
    CGRect endKeyboardRect = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];

    CGRect value = [self.view convertRect:fristResponse.frame fromView:fristResponse.superview];
    CGFloat yOffSet = (value.origin.y + value.size.height)- endKeyboardRect.origin.y;
    if (yOffSet>=0) {
        //调整view的高度 使第一响应者不被键盘挡住
        CGRect frame = self.view.frame;
        frame.origin.y = -yOffSet-5.f;
        [self.view setFrame:frame];
    }
    
}

- (void)touchedBackButton:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

@end
