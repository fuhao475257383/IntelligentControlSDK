//
//  HE_SceneDevice.h
//  BWRemoter
//
//  Created by JianBo He on 15/1/25.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HE_SceneDevice : UITableViewCell


@property  UILabel  *labName;
@property  UILabel  *labOperation;
@property  UILabel  *labInterval;
@property  UIButton *btnEdit;

@end
