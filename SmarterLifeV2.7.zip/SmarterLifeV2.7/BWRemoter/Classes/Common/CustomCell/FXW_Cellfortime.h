//
//  FXW_Cellfortime.h
//  BWRemoter
//
//  Created by 6602_Loop on 15-1-24.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FXW_Cellfortime : UITableViewCell
{
    NSString *_Mode;
    NSString *_Time;
    NSString *_Weeks;
    NSString *_Date;
}
@property UIView *backview;
@property UIButton *Edit;
@property UIButton *Delete;
@property UILabel *Modename;
@property UILabel *Time;
@property UILabel *Weeks;
-(void)setMode:(NSString *)_mode andTime:(NSString *)_time andWeeks:(NSString *)_weeks andDate:(NSString *)_date;
-(void)removeforadd;
@end
