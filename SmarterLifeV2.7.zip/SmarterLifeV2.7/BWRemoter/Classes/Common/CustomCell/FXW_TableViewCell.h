//
//  FXW_TableViewCell.h
//  BWRemoter
//
//  Created by 6602_Loop on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FXW_TableViewCell : UITableViewCell
{
    BOOL Ischecked;
}
@property  IBOutlet UIImageView *logo;
@property  IBOutlet UILabel *network;
@property  IBOutlet UILabel *sn;
@property  IBOutlet UILabel *ip;

- (void)setTitle:(NSString *)title IP:(NSString *)ipStr SN:(NSString *) snStr Logo:(UIImage *) img;
- (void)changeBG:(id)sender;
- (void)toggleState;
@end

