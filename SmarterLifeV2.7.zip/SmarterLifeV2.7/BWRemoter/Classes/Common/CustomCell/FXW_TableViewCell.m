//
//  FXW_TableViewCell.m
//  BWRemoter
//
//  Created by 6602_Loop on 15-1-5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "FXW_TableViewCell.h"

@implementation FXW_TableViewCell
@synthesize logo;
@synthesize network;
@synthesize sn;
@synthesize ip;


- (void)awakeFromNib {
    // Initialization code
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    [sn setTintColor:[UIColor blueColor]];
    [ip setTintColor:[UIColor blueColor]];

}
- (void)setTitle:(NSString *)title IP:(NSString *)ipStr SN:(NSString *) snStr Logo:(UIImage *) img{
    [logo setImage: img];
    [sn setText:snStr];
    ip.text = ipStr;
    [network setText:title];
    
    //
//    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(changeBG:)];
//    [self.contentView addGestureRecognizer:tap];
}

- (void)changeBG:(id)sender{
    if(Ischecked==false){
        [sn setTextColor:[UIColor colorWithRed:29/255.0 green:164/255.0 blue:233/255.0 alpha:1]];
        [ip setTextColor:[UIColor colorWithRed:29/255.0 green:164/255.0 blue:233/255.0 alpha:1]];
        [network setTextColor:[UIColor colorWithRed:29/255.0 green:164/255.0 blue:233/255.0 alpha:1]];
        [logo setImage:[UIImage imageNamed:@"radiobox_checked.png"]];
        Ischecked=true;
    }
    else{
        [sn setTextColor:[UIColor blackColor]];
        [ip setTextColor:[UIColor blackColor]];
        [network setTextColor:[UIColor blackColor]];
        [logo setImage:[UIImage imageNamed:@"radiobox_uncheck.png"]];
        Ischecked =false;
    }
}
- (void)toggleState{
    
}
@end
