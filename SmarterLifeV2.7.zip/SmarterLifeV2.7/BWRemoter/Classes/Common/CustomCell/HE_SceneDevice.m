//
//  HE_SceneDevice.m
//  BWRemoter
//
//  Created by JianBo He on 15/1/25.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "HE_SceneDevice.h"
#import "HE_CustemExtend.h"

@implementation HE_SceneDevice
@synthesize labName,labOperation,labInterval, btnEdit;
- (void)awakeFromNib {
    // Initialization code
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        CGFloat labWidth = 0.255;
        if ([UIScreen mainScreen].bounds.size.width > 320) {
            labWidth = 0.3;
        }
        labName      = [[UILabel alloc] initWithFrame:CGRectMake(0, 7, self.frameW*labWidth, self.frameH)];
        labOperation = [[UILabel alloc] initWithFrame:CGRectMake(labName.frameSumX_W, labName.frameY,
                                                                 self.frameW*labWidth, self.frameH)];
        labInterval  = [[UILabel alloc] initWithFrame:CGRectMake(labOperation.frameSumX_W, labName.frameY,
                                                                 self.frameW*labWidth, self.frameH)];
        btnEdit      = [[UIButton alloc] initWithFrame:CGRectMake(labInterval.frameSumX_W, 13, self.frameW * 0.2, self.frameH - 15)];
        
        labName.adjustsFontSizeToFitWidth = YES;
        labName.font = [UIFont systemFontOfSize:16.f];
        labName.textAlignment = NSTextAlignmentCenter;
        
        labOperation.adjustsFontSizeToFitWidth = YES;
        labOperation.font = [UIFont systemFontOfSize:16.f];
        labOperation.textAlignment = NSTextAlignmentCenter;
        
        labInterval.adjustsFontSizeToFitWidth = YES;
        labInterval.font = [UIFont systemFontOfSize:16.f];
        labInterval.textAlignment = NSTextAlignmentCenter;
        
        [btnEdit setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [btnEdit setTitleColor:[UIColor blueColor] forState:UIControlStateHighlighted];
        [btnEdit setTitle:@"编辑" forState:UIControlStateNormal];
        [btnEdit.titleLabel setFont:[UIFont systemFontOfSize:17.f]];
        btnEdit.layer.borderColor = [UIColor grayColor].CGColor;
        btnEdit.layer.borderWidth = 0.8f;
        btnEdit.layer.cornerRadius = 3.f;
        
        [self addSubview:labName];
        [self addSubview:labOperation];
        [self addSubview:labInterval];
        [self addSubview:btnEdit];
    }
    return self;
}
@end
