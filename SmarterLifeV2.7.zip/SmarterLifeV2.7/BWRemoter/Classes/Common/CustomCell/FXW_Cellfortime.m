//
//  FXW_Cellfortime.m
//  BWRemoter
//
//  Created by 6602_Loop on 15-1-24.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "FXW_Cellfortime.h"

@implementation FXW_Cellfortime
@synthesize Modename;
@synthesize Time;
@synthesize Weeks;
@synthesize Edit;
@synthesize Delete;
@synthesize backview;
- (void)awakeFromNib {
    ///
    CGRect rect = self.frame;
    rect.size.width = [UIScreen mainScreen].bounds.size.width;
    [self setFrame:rect];
    backview = [[UIView alloc]initWithFrame:CGRectMake(0, self.frame.size.height*0.05, self.frame.size.width*0.92, self.frame.size.height*0.9)];
    [self addSubview:backview];
    backview.backgroundColor = [UIColor whiteColor];
    backview.layer.borderWidth=1;
    backview.layer.cornerRadius =10.f;
    backview.layer.borderColor = [[UIColor colorWithRed:200/255.0f green:200/255.0f blue:200/255.0f alpha:1]CGColor];
    
    ///名称
    Modename = [[UILabel alloc]initWithFrame:CGRectMake(10, 0, backview.frame.size.width*0.5,  backview.frame.size.height)];
    [Modename setFont:[UIFont boldSystemFontOfSize:18]];
    [Modename setTextAlignment:NSTextAlignmentLeft];
    [backview addSubview:Modename];
//    [[self textLabel] setFont:[UIFont boldSystemFontOfSize:18]];
//    [[self textLabel] setTextAlignment:NSTextAlignmentLeft];
    
    ///时间
    Time = [[UILabel alloc]initWithFrame:CGRectMake(backview.frame.size.width*0.2, 0, backview.frame.size.width*0.3,  backview.frame.size.height*0.5)];
    [Time setFont:[UIFont boldSystemFontOfSize:16]];
    [backview addSubview:Time];
    ///周次
    Weeks = [[UILabel alloc]initWithFrame:CGRectMake(backview.frame.size.width*0.2, backview.frame.size.height*0.55, backview.frame.size.width,  backview.frame.size.height*0.45)];
    [Weeks setFont:[UIFont systemFontOfSize:12]];
    [backview addSubview:Weeks];
    

}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    // Configure the view for the selected state
}

///数据源
-(void)setMode:(NSString *)_mode andTime:(NSString *)_time andWeeks:(NSString *)_weeks andDate:(NSString *)_date{
    [Modename setText:_mode];
    [Time setText:_time];
    if(![_weeks isEqual:@"0"])
    {///如果是每周
        NSArray *array=[_weeks componentsSeparatedByString:@","];
        NSString *tmpweek=@"";
        for(int i=0;i<array.count;i++){
            tmpweek = [tmpweek stringByAppendingFormat:@"周%@",array[i]];
        }
        [Weeks setText:tmpweek];
    }
    else{
        [Weeks setText:_date];
    }
}
-(void)removeforadd{
    [Modename removeFromSuperview];
    [Time removeFromSuperview];
    [Weeks removeFromSuperview];
    [Edit removeFromSuperview];
    [Delete removeFromSuperview];
    UILabel *add = [[UILabel alloc]initWithFrame:CGRectMake(10, 0, backview.frame.size.width*0.4,  backview.frame.size.height)];
    [add setText:@"添加定时"];
    [add setTextAlignment:NSTextAlignmentLeft];
    [add setFont:[UIFont boldSystemFontOfSize:18]];
    [backview addSubview:add];
    UIImageView *rightgogo = [[UIImageView alloc] initWithFrame: CGRectMake(backview.frame.size.width*0.8,30.0f, 20.0f, 20.0f)];
    [rightgogo setImage:[UIImage imageNamed:@"arrowicon.png"]];
    [backview addSubview:rightgogo];
}
@end
