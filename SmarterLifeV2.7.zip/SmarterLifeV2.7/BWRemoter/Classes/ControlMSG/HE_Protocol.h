 //
//  HE_Protocol.h
//  BWRemoter
//
//  Created by JianBo He on 14/12/16.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#ifndef BWRemoter_HE_Protocol_h
#define BWRemoter_HE_Protocol_h

///

#import "HE_MsgKit.h"
#import "HE_xmppFileTransfer.h"
#import "HE_XmppMsgManager.h"
#import "HE_socketMsgManager.h"
#import "WB_socketFileTransfer.h"
///

@protocol HE_ManagerDelegate <NSObject>
@required

///discover
- (void)didDiscover;
- (void)discoverTimeOut;
- (void)notDiscoverSameSN;
///连接
- (void)didConnect;
- (void)didNotConnectToHost:(NSError *)err;
- (void)didDisConnectToHost;
///发送消息
- (void)didSendMsg;
-(void)didNotSendMsg:(NSError *)err;

///接受消息
- (void)didRecive:(NSString *)strMsg;

//同步网关时间
- (void)needUpdateGatewayTimeWithGTime:(NSString *)gatewayTime;
//同步成功
- (void)updateGatewayTimeSucceed;
//同步失败
- (void)updateGatewayTimeFail;

@optional

@end


///文件传输委托
@protocol HE_FileTransfer <NSObject>
@optional
///文件下载 委托
//未实现该方法，不知道有什么用
- (void)fileTransferProcess:(CGFloat )process;
//更新文件
- (void)didUpdateFile;
//文件下载失败(不知为何，socket和xmpp都没有调用)
- (void)didNotUpdateFile:(NSError *)error;
//上传文件成功
- (void)didUploadFile;
//上传文件失败
- (void)didNotUploadFile:(NSError *)error;
@end

#endif
