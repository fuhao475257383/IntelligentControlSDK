//
//  FXW_User.m
//  BWRemoter
//
//  Created by 6602_Loop on 14-12-15.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "FXW_User.h"


@implementation FXW_User
@synthesize strName;
@synthesize strPwd;
@synthesize strSN;
@synthesize strDefaultPWD;
@synthesize strPermission, isRememberPWD;

+ (id)initUserWithUserDefault{
    NSData *data   = [[NSUserDefaults standardUserDefaults] objectForKey:@"USER"];
    FXW_User *user = [NSKeyedUnarchiver unarchiveObjectWithData:data];
    if (user == nil) {
        user = [[FXW_User alloc] init];
    }
    return user;
}


- (id)init{
    self = [super init];
    if (self) {
        IsAuthencate  = false;
        IsAdmin       = false;
        strDefaultPWD = @"baiweiszrndcenter20140415";
        strPermission = @"FF";
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder{
    self = [super init];
    if (self) {
        strName       = [aDecoder decodeObjectForKey:@"NAME"];
        strPwd        = [aDecoder decodeObjectForKey:@"PWD"];
        strSN         = [aDecoder decodeObjectForKey:@"SN"];
        
        strDefaultPWD = @"baiweiszrndcenter20140415";
        strPermission = @"FF";
        
        isRememberPWD = YES;
        IsAuthencate  = NO;
    }
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder{
    [aCoder encodeObject:strName forKey:@"NAME"];
    [aCoder encodeObject:strPwd forKey:@"PWD"];
    [aCoder encodeObject:strSN forKey:@"SN"];
}

- (void)saveToUserDefalt{
    NSString *tmp = strPwd;
    if (!isRememberPWD) {
        strPwd = @"";
    }
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:self];
    [[NSUserDefaults standardUserDefaults] setObject:data forKey:@"USER"];
    
    strPwd = tmp;
}
- (void)authencateCompelete{
    IsAuthencate = true;
}
- (BOOL)IsAuthencate{
    return IsAuthencate;
}
- (void)setAdmin{
    IsAdmin = true;
}
- (BOOL)IsAdmin{
    return IsAdmin;
}


@end
