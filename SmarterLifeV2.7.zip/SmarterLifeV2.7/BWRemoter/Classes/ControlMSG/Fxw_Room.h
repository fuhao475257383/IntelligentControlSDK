//
//  Fxw_Room.h
//  BWRemoter
//
//  Created by 6602_Loop on 14-12-21.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface Fxw_Room : UIView<UITableViewDelegate,UITableViewDataSource>{
    NSMutableArray *device;
}

@property id delegate;
@property(nonatomic,retain) UITableView *table;
@property UILabel *labName;
-(void)SetName:(NSArray *)aryname;

-(NSString *)ReturnIcon:(NSString *)deviceName;
@end
