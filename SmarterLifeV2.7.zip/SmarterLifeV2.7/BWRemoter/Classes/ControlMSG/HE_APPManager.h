//
//  HE_APPManager.h
//  BWRemoter
//
//  Created by JianBo He on 14/12/14.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//
//#ifndef _HE_APPMANAGER_H_
//#define _HE_APPMANAGER_H_
//#endif


#import <Foundation/Foundation.h>
#import "CYM_Engine.h"
#import "AppDelegate.h"
#import "MBProgressHUD.h"
#import "HE_Protocol.h"
#import "FXW_User.h"


///APP 网络状态
typedef enum {
    ///离线
    NET_OFF_LINE = 0,
    ///局域网 Socket
    NET_WAN_SOCKET,
    ///公网 XMPP
    NET_XMPP,
    ///演示
    NET_DEMO
}NET_STATE;

typedef enum {
    ///////离线
    APPSTATE_OFF_LINE = 0,
    ///////连接、验证
    APPSTATE_CONNECT,
    ///////正在下载配置文件
    APPSTATE_DOWNFILE,
    ///////更新 缓存DeviceState中
    APPSTATE_UPDATE,
    ///////已完成登录
    APPSTATE_LOGIN_SUCCESS,
}APPSTATE;


///APP管理核心类 单例，封装了Sockt通信、XMPP通信、配置文件下载、网络监测等等
@interface HE_APPManager : NSObject  <HE_ManagerDelegate, HE_FileTransfer, MBProgressHUDDelegate>
{
    
}
///
@property (nonatomic,strong) FXW_User *User;

///登录参数
@property (nonatomic,strong) NSString *strSN;
@property (nonatomic,strong) NSString *strUName;
@property (nonatomic,strong) NSString *strPassword;

//假如同时上传了两个文件，需要设置该值为yes
@property (nonatomic) BOOL uploadTwoFile;
//收到了几条上传回馈信息，假如是上传两个文件，需要设置为0，默认为2
@property (nonatomic,assign) NSInteger recFileFeedback;

///需要实时更新的的HE_UIDevice
@property (nonatomic,strong) NSMutableArray *aryActiveDevice;
//新入网设备
@property (nonatomic,strong) NSMutableArray *deviceNewArray;


//特殊需求
@property (nonatomic, assign) BOOL isZoneView;


+ (id)sharedManager;//单例
- (HE_XmppMsgManager *)xmppManager;//xmpp通信
- (HE_socketMsgManager *)soktMangaer;//socket通信
- (NSArray *)aryRoom;//获取控制页面的房间、设备信息
- (NET_STATE)netState;//获取当前app网络状态（内、外、离）
- (NSArray *)aryRoomCtrlValue;//所有房间内的设备信息
- (NSDictionary *)dicRoomDeviceState;//获取当前所有设备的状态字典
- (void)setAryRoom:(NSArray *)ary;//所有房间
- (void)setDelegateViewCtrl:(id)delegate;//设置当前显示的viewctrl
- (void)reloadRoom;


- (void)discoverGateway;

///连接服务器
///XMPP包含连接＋验证＋建立XMPP会话格式+Roster+vCard过程
- (BOOL)connectToHost:(NET_STATE)type;

- (void)logout;

- (void)setFileTransferIP:(NSString *)ip;

///发送控制消息、 XMPP/Socket
- (void)SendMsg:(NSString *)msg withNameSpace:(NSString *)ns isShowLoading:(BOOL) isShow;

// 发送附带查询命令
- (void)SendQueryMsg:(NSString *)msg withNameSpace:(NSString *)ns after:(NSTimeInterval) time;

///上传文件
- (void)uploadFileWithName:(NSString *)fileName andData:(NSData *)data isShowHUD:(BOOL) isShowHud;

- (void)uploadFileWithName:(NSString *)fileName andData:(NSData *)data isShowHUD:(BOOL) isShowHud handler:(UploadHandler) handler;

- (void)handleAPPOffLineWithMsg:(NSString *)detail;

////MBProccess HUD
- (void)hudShowMsg:(NSString *)msg andInterval:(NSTimeInterval) inval;
- (void)hudShowMsgTitle:(NSString *)title details:(NSString *) details andInterval:(NSTimeInterval) inval;
- (void)hudShowLoadingTitle:(NSString *)title details:(NSString *)details;
- (void)hudDisplayLoadingWithTitle:(NSString *)aTitle details:(NSString *)aDetails;
//添加一个指示器
- (void)addHUDToViewWithDetails:(NSString *)details;
//移除该指示器
- (void)removeHUD;
- (void)hudHidden;
//修改HUD显示的数据
- (void)changeHUDDetail:(NSString *)detail;


////网络监测
- (BOOL)IsEnableWIFI;
- (BOOL)IsEnable3G;

///appDelegate
- (void)applicationWillEnterForeground:(UIApplication *)application;
- (void)applicationDidEnterBackground:(UIApplication *)application;

//获取到app得登陆状态
- (APPSTATE)getAppState;
//获取app网络状态
- (NET_STATE)getAppNetState;
@end


