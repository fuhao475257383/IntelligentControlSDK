//
//  HE_APPManager.m
//  BWRemoter
//
//  Created by JianBo He on 14/12/14.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "HE_APPManager.h"
#import "Reachability.h"
#import "AFNetworking.h"
#import "Room.h"
#import "RoomDevice.h"
#import "HE_UIDevice.h"
#import "FXW_ShowVC.h"
#import "FXW_SetVC.h"
#import "FXW_LocalSearchVC.h"
#import "HE_ScanTwoCodeVC.h"
#import "HE_MsgBuilder.h"
#import "HE_BaseViewController.h"

@interface HE_APPManager ()<UIAlertViewDelegate>
{
    ///AppDelegate
    AppDelegate *appDelegate;
    ///网络状态
    NET_STATE netState;
    ///APP当前状态
    APPSTATE  appState;
    ///提示框状态
    BOOL      isAlerting;
    /// 进入后台的时间
    NSUInteger backgroudTimeinterl;
    
    //第一次提示时弹框的时间
    NSUInteger bouncedTime;
    //假如是失败
    NSUInteger bouncedTimeFail;

    ///错误提示
    
    ///俩个通信管理类
    HE_XmppMsgManager *xmppManager;
    HE_socketMsgManager *soktManager;
    
    ///俩个文件下载类
    HE_xmppFileTransfer *xmppFileTransfer;
    WB_socketFileTransfer *sockFileTransfer;
    
    ///心跳线程
    NSThread *theadHeartBeat;
    
    ///当前活动的ViewController
    id<BaseViewControllDelegate> delegateViewCtrl;
    
    
    /******      DATA        ******/
    ///所有房间和 其内的设备信息
    NSArray             *aryRoom;
    ///所有房间内的设备信息
    NSMutableArray      *aryRoomCtrlValue;
    ///缓存每个设备的状态
    NSMutableDictionary *dicRoomDeviceState;
    ///网络中需要更新的所有设备
    NSMutableArray      *aryNeedQuery;
    dispatch_queue_t    queueSender;
}
//判断是否是文件上传失败
@property (nonatomic) BOOL isFileUploadFail;
//判断是否是重新登录
@property (nonatomic) BOOL isLogBackIn;
//判断是否是更新时间
@property (nonatomic) BOOL isUpdateTime;
//构造消息类
@property (nonatomic,strong) HE_MsgBuilder *msgB;

////HUD
@property MBProgressHUD  *HUD;
@property (nonatomic,strong) MBProgressHUD *hud;
///临时HUD 的数组
@property (nonatomic, retain) NSMutableArray *aryTempHUD;
@end

@implementation HE_APPManager
@synthesize User;
@synthesize aryActiveDevice,HUD, aryTempHUD;

#pragma mark -
#pragma mark 单例＋初始化
- (NSMutableArray *)deviceNewArray {
    if (!_deviceNewArray) {
        _deviceNewArray = [NSMutableArray new];
    }
    return _deviceNewArray;
}
+ (id)sharedManager{
    static HE_APPManager *Manger = nil;
    if (!Manger) {
        Manger = [[super allocWithZone:nil] init];
    }
    return Manger;
}
+ (id)allocWithZone:(struct _NSZone *)zone{
    return [self sharedManager];
}
- (id)init{
    self = [super init];
    if (self) {
        appDelegate      = [AppDelegate sharedAppDelegate];
        xmppManager      = [HE_XmppMsgManager sharedManager];
        soktManager      = [HE_socketMsgManager sharedManager];
        xmppFileTransfer = [HE_xmppFileTransfer sharedFileTransfer];
        sockFileTransfer = [[WB_socketFileTransfer alloc] init];
        
        User = [[FXW_User alloc] init];
        netState = NET_OFF_LINE;
        appState = APPSTATE_OFF_LINE;
        
        [xmppFileTransfer setDelegate:self];
        [sockFileTransfer setDelegate:self];
        
        aryRoomCtrlValue   = [NSMutableArray array];
        aryActiveDevice    = [NSMutableArray array];
        aryNeedQuery       = [NSMutableArray array];
        aryTempHUD         = [NSMutableArray array];
        dicRoomDeviceState = [NSMutableDictionary dictionary];
        queueSender        = dispatch_queue_create("com.APP.Sender", nil);
        
        self.msgB = [[HE_MsgBuilder alloc]init];
        _uploadTwoFile = NO;
        _recFileFeedback = 2;
        
        //初始化数据锁
        [CYM_DatabaseTable initializeThreadLock];
    }
    return self;
}

#pragma mark - 
#pragma mark Public Method
- (HE_XmppMsgManager *)xmppManager{
    return xmppManager;
}
- (HE_socketMsgManager *)soktMangaer{
    return soktManager;
}
- (void)setDelegateViewCtrl:(id)delegate;{
    delegateViewCtrl = delegate;
}
- (void)setAryRoom:(NSArray *)ary{
    aryRoom = ary;
}
- (NSArray *)aryRoom{
    return aryRoom;
}
- (NET_STATE)netState{
    return netState;
}
- (NSArray *)aryRoomCtrlValue{
    return aryRoomCtrlValue;
}
- (NSDictionary *)dicRoomDeviceState{
    return dicRoomDeviceState;
}
- (void)setFileTransferIP:(NSString *)ip{
    if (ip!=nil) {
        [sockFileTransfer setGatewayIP:ip];
    }
}

#pragma mark 搜索网关
- (void)discoverGateway {
    [soktManager setDelegate:self];
    [soktManager discoverGateway];
}
- (void)didDiscover{
    NSLog(@"didDiscover.");
    [self hudHidden];
    if ([delegateViewCtrl respondsToSelector:@selector(reloadData:)]) {
        [delegateViewCtrl performSelector:@selector(reloadData:) withObject:nil];
    }
}
- (void)discoverTimeOut{
    [self hudShowMsgTitle:@"响应超时" details:@"请检查网络" andInterval:1.5];
}

- (void)notDiscoverSameSN{
    [self hudShowMsgTitle:@"未识别网关设备" details:@"请核对网关设备号或检查网关连接" andInterval:2];
}
#pragma mark 连接服务器
- (void)reloadRoom {
    aryRoom = [CYM_Engine getRoomAllDevice];
}
- (BOOL)connectToHost:(NET_STATE)type{
    netState = type;
    appState = APPSTATE_CONNECT;
    ///////////////////如果为演示模式
    if (type == NET_DEMO) {
        [DatabaseUtil setDataBaseIsDemo:YES];
        appState = APPSTATE_LOGIN_SUCCESS;
        aryRoom = [CYM_Engine getRoomAllDevice];
        if ([delegateViewCtrl respondsToSelector:@selector(hudWasHidden:)]) {
            [delegateViewCtrl performSelector:@selector(hudWasHidden:) withObject:nil];
        }
        return YES;
    }
    
    ///////////////////开始链接
    [self hudDisplayLoadingWithTitle:nil details:@"连接网关..."];
    if (type == NET_XMPP) {
        ///////////////////先判断网络的可用性
        if(![self IsEnableWIFI]){
            if (![self IsEnable3G]) {
                [self hudShowMsg:@"网络连接异常，请检查网络设置" andInterval:1.0];
                return false;
            }
        }
        [xmppManager setDelegate:self];
        
        
        [xmppManager setStrMyJID:[NSString stringWithFormat:@"%@%@/%@",User.strSN, @"@server.cdbaiwei.com",User.strName]];
        [xmppManager setStrPassWord:@"baiweiszrndcenter20140415"];
        [xmppManager setJidRoot:[XMPPJID jidWithString:[NSString stringWithFormat:@"%@%@",User.strSN, @"@bw/root"]]];
        [xmppManager setStrGatewayPWD:User.strPwd];
        if ([xmppManager connect]) {
            return true;
        }
        else{
            return false;
        }
    }
    else if (type == NET_WAN_SOCKET){
        ////////////////判断WIFI的可用性
        if(![self IsEnableWIFI]){
            [self hudShowMsg:@"网络连接异常，请检查网络设置" andInterval:1.0];
            return false;
        }
        [soktManager setDelegate:self];
        [soktManager connectHostWithSN:User.strSN];
        return true;
    }
    else if (type == NET_OFF_LINE){
        //GO
        ;
    }
    return false;
}

- (void)logout{
    NSLog(@"appmanager退出");
    
    xmppManager.managerDelegate = nil;
    [xmppManager disconnect];
    
    [soktManager setDelegate:nil];
    [soktManager disconnect];
    
    [theadHeartBeat cancel];
    theadHeartBeat = nil;
    HUD = nil;
    self.uploadTwoFile = NO;
    self.recFileFeedback = 2;
    
    netState = NET_OFF_LINE;
    appState = APPSTATE_OFF_LINE;
    
    aryRoomCtrlValue   = [NSMutableArray array];
    aryActiveDevice    = [NSMutableArray array];
    aryNeedQuery       = [NSMutableArray array];
    aryTempHUD         = [NSMutableArray array];
    dicRoomDeviceState = [NSMutableDictionary dictionary];
    
    [xmppFileTransfer resetSemaphore];
}

///连接成功     [HE_APPManger Delegate]
- (void)didConnect{
    //1.启动心跳线程
    [theadHeartBeat cancel];
    theadHeartBeat = nil;
    theadHeartBeat = [[NSThread alloc] initWithTarget:self selector:@selector(threadHeartBeatTask) object:nil];
    [theadHeartBeat start];
    
    
    appState = APPSTATE_DOWNFILE;
    //2.下载文件
    [HUD setDetailsLabelText:@"更新配置文件..."];
    if (netState == NET_WAN_SOCKET) {
        //
        [sockFileTransfer startUpdateFile];
    }
    else if (netState == NET_XMPP){
        [xmppFileTransfer startUpdateFile];
    }
    [User saveToUserDefalt];
}
- (void)changeHUDDetail:(NSString *)detail {
    [HUD setDetailsLabelText:detail];
}
///APPManager的连接动作失败       
- (void)didNotConnectToHost:(NSError *)err{
    
    if (self.hud) {
        [self.hud removeFromSuperview];
        self.hud = nil;
    }
    
    netState = NET_OFF_LINE;
    appState = APPSTATE_OFF_LINE;
    if (err.code == 1) {
        [self hudShowMsgTitle:@"登录失败" details:@"用户名不存在" andInterval:2.0];
    }
    else if (err.code == 2){
        [self hudShowMsgTitle:@"登录失败" details:@"密码错误" andInterval:2.0];
    }
    else if (err.code == 503){
        [self handleAPPOffLineWithMsg:@"您已离线\n请核对网关设备号或检查网关连接"];
    }
    else if (err.code == 60) {
        [self hudShowMsgTitle:@"连接超时" details:@"请重试" andInterval:2];
    }
    else if (err.code == 7) {
        [self handleAPPOffLineWithMsg:@"您已离线，请重新登录！"];
    }
    else if (err.code >= 1000){
        NSString *errMsg   = [err.userInfo objectForKey:@"errMsg"];
        NSString *errTitle = [err.userInfo objectForKey:@"errTitle"];
        if (errTitle == nil) {
            errTitle = @"连接失败";
        }
        [self hudShowMsgTitle:errTitle details:errMsg andInterval:2.0];
    }
    else {
        if (!err) {
            NSLog(@"err = nil");
            [self handleAPPOffLineWithMsg:@"与网关或服务器断开连接"];
        }else {
            [self handleAPPOffLineWithMsg:@"由于未知原因，与网关断开连接！"];
        }
    }
    NSLog(@"err.description:%@", err.description);
    [User saveToUserDefalt];
}

- (void)didDisConnectToHost{
    netState = NET_OFF_LINE;
    appState = APPSTATE_OFF_LINE;
    [self handleAPPOffLineWithMsg:@"您已经离线请重新登录"];
    NSLog(@"断开连接");
}
#pragma mark 发送控制消息
- (void)SendMsg:(NSString *)msg withNameSpace:(NSString *)ns isShowLoading:(BOOL) isShow {
    /////////////////在进行正常的操作
    //isShow:设备是否在当前页面
    //netState设备网络状态
    NSLog(@"发送出去的msg  %@",msg);
    if (isShow &&
        (netState != NET_OFF_LINE && netState != NET_DEMO)) {
        //消息解析类
        HE_MsgParser *msgP = [[HE_MsgParser alloc] init];
        //命令类
        HE_CMDParser *cmdP = [[HE_CMDParser alloc] init];
        //百微A4协议
        HE_BaiWeiMsgDefine_A4 *A4 = [[HE_BaiWeiMsgDefine_A4 alloc] init];
        NSString *strLog = @"正在控制";
        
        @try {
            // CMD 中Action 为03
            if ([[cmdP getActionWithCMD:[msgP getCMDWithMsg:msg]] isEqualToString:[A4 actioncCodeWithCode:A4_ACTION_QUERY]]) {
                strLog = @"获取设备状态中";
            };

            // Data为bwtenquer
            //打开数据库
            NSString *strData = [cmdP getDataWithoutNum:[msgP getCMDWithMsg:msg]];
            strData = [strData substringFromIndex:2];
            if ([CYM_Engine isQueryValue:strData]) {
                strLog = @"获取设备状态中";
            };
        }
        @catch (NSException *exception) {
            ;
        }
        @finally {
            //如果已经登录，显示提示框，显示获取设备状态中
            appState == APPSTATE_LOGIN_SUCCESS?[self hudShowLoadingTitle:nil details:strLog]:NO;
        }
    }
    //如果是XMPP连接
    if (netState == NET_XMPP) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(){
            dispatch_sync(queueSender, ^{
                //不知道为毛原作者要延时，我也不想去深究，将就着这样
                [NSThread sleepForTimeInterval:0.1];
                [xmppManager sendIQCMDToRoot:msg withNamespace:ns];
                NSLog(@"Send: %@", msg);
            });
        });
    }
    else if (netState == NET_WAN_SOCKET){
        ///GO
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(){
            dispatch_sync(queueSender, ^{
                [NSThread sleepForTimeInterval:0.25];
                [soktManager sendMsg:msg];
                if ([msg isEqualToString:@"@#$%1000000EFF"]) {
                    NSLog(@"发送心跳");
                }else {
                    NSLog(@"Send: %@", msg);
                }
            });
        });
    }
    else if (netState == NET_OFF_LINE){
        ////////////////////// 离线处理
        [self handleAPPOffLineWithMsg:@"你已经离线请重新登录"];
    }
    else{//////演示模式
        ////1.将其改为反馈报告、并调用自己
        NSString *s1 = [msg substringToIndex:18];
        NSString *s2 = [msg substringFromIndex:20];
        NSString *reMsg = [NSString stringWithFormat:@"%@04%@",s1,s2];
        [self didRecive:reMsg];
    }
}

- (void)SendQueryMsg:(NSString *)msg withNameSpace:(NSString *)ns after:(NSTimeInterval) time {
    if (netState == NET_XMPP) {
        time += 0.1;
    }else {
        time += 0.25;
    }
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(time * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSLog(@"delay Send: %@ 延时：%f", msg,time);
        if (netState == NET_WAN_SOCKET) {
            [soktManager sendMsg:msg];
        }
        else if (netState == NET_XMPP) {
            [xmppManager sendIQCMDToRoot:msg withNamespace:ns];
        }
    });
}

///发送控制消息成功
- (void)didSendMsg{
    
}
///发送控制消息失败
-(void)didNotSendMsg:(NSError *)err{
    [self hudShowMsg:@"消息发送失败." andInterval:1];
    NSLog(@"AppManager:  DidNotSendMsg");
    //发送失败，需要恢复数据
    [[NSNotificationCenter defaultCenter] postNotificationName:@"MSGSendFail" object:self userInfo:nil];
}

///开启新线程执行心跳
- (void)threadHeartBeatTask{
    // 得到当前运行线程
    while (![[NSThread currentThread] isCancelled]) {
        // 发送心跳命令
        if (appState >= APPSTATE_DOWNFILE) {
            [self SendMsg:@"@#$%1000000EFF" withNameSpace:@"gateway" isShowLoading:NO];
        }
        [NSThread sleepForTimeInterval:5.0];
    }
}

#pragma mark - 接受消息返回
- (void)didRecive:(NSString *)strMsg{
    if (appState < APPSTATE_UPDATE) {
        return;
    }
    NSString *com = @"";
    HE_JiuZhouMsgDefine *JiuZhou = [[HE_JiuZhouMsgDefine alloc] init];
    HE_BaiWeiMsgDefine_A4 *A4 = [[HE_BaiWeiMsgDefine_A4 alloc] init];
    HE_CMDParser *cmdP = [[HE_CMDParser alloc] init];
    HE_CMDBuilder*cmdB = [[HE_CMDBuilder alloc] init];
    HE_MsgParser *msgP = [[HE_MsgParser alloc] init];
    HE_CMDQueue *cmdQueue = [HE_CMDQueue sharedQueue];
    
//    NSLog(@"NOPMSG: %@",strMsg);
    NSArray *aryMsg = [msgP parseMutableCMDWithMsg:strMsg];
//    NSLog(@"Msg: %@", aryMsg);
    for (NSString *aMsg in aryMsg) {
//         [self hudHidden];
        com = [aMsg substringWithRange:NSMakeRange(4, 2)];
        NSString *cmd = [msgP getCMDWithMsg:aMsg];
        if ([msgP isAJiuZhouMsg:aMsg] ) {///为九州命令
            NSLog(@"Recv1: %@", aMsg);
            if ([cmd isEqualToString:[JiuZhou msgCommodWithCode:CMD_UPDATE_CONFIG]]) {
                //配置文件更新
                NSLog(@"更新配置文件(%@).", aMsg);
                //2.下载文件
                if (netState == NET_WAN_SOCKET) {
                    [sockFileTransfer startUpdateFileInBackGround];
                }
                else if (netState == NET_XMPP){
                    [xmppFileTransfer startUpdateFileInBackGround];
                }
            }
            else{
                [self hudHidden];
                if ([delegateViewCtrl respondsToSelector:@selector(reciveGateWayMsg:)]) {
                    [delegateViewCtrl performSelector:@selector(reciveGateWayMsg:) withObject:aMsg];
                }
            }
        }
        else{///A4命令->放入队列中管理
            NSArray *aryComplteCMD = [cmdQueue getCompeleteCMDWith:cmd];
            //////如果为 com口直接数据。或分包后的数据
            if (aryComplteCMD == nil || aryComplteCMD.count ==0) {
                //更新实时设备
                NSNotification *notfic = [NSNotification notificationWithName:@"NEW_CMD_MSG" object:cmd];
                [[NSNotificationCenter defaultCenter] postNotification:notfic];
            }
            
            for (NSString *compeleteCMD in aryComplteCMD) {
                NSLog(@"Recv CMD: %@  com:%@", compeleteCMD,com);
                
                if ([[compeleteCMD substringWithRange:NSMakeRange(0, 8)]isEqualToString:@"A55A0610"]) {
                    [[NSNotificationCenter defaultCenter]postNotificationName:@"InNet" object:self];
                    continue;
                }
                if ([[compeleteCMD substringWithRange:NSMakeRange(0, 8)]isEqualToString:@"A55A0A02"]) {
                    [[NSNotificationCenter defaultCenter]postNotificationName:@"InNetMSG" object:self userInfo:@{@"msg":compeleteCMD,@"com":com}];
                    continue;
                }
                if ([[compeleteCMD substringWithRange:NSMakeRange(0, 10)]isEqualToString:@"A55A0F7F09"]) {
                    [[NSNotificationCenter defaultCenter]postNotificationName:@"baudRate" object:self userInfo:@{@"msg":compeleteCMD,@"com":com}];
                    continue;
                }
                if ([[compeleteCMD substringWithRange:NSMakeRange(0, 10)]isEqualToString:@"A55A0D040A"]) {
                    [[NSNotificationCenter defaultCenter]postNotificationName:@"InNetMSG" object:self userInfo:@{@"msg":compeleteCMD,@"com":com}];
                }
                
                if (compeleteCMD != nil && compeleteCMD.length >= 12) {
                    A4_ActionCode action = [A4 codeWithActionCode:[compeleteCMD substringWithRange:NSMakeRange(6, 2)]];
                    switch (action) {
                        case A4_ACTION_QUERY_RE:{
                            /////////如果是初次缓存设备状态
                            NSString *strNum = [cmdP getDeviceNumWithCMD:compeleteCMD];
                            dicRoomDeviceState[strNum] = compeleteCMD;
                            //////////////移除已成功 查询到状态的设备
                            for(int i=0; i<aryRoomCtrlValue.count; i++){
                                ControlDeviceContentValue *v = aryRoomCtrlValue[i];
                                if ([strNum isEqualToString:[cmdP getDeviceNumWithBindCMD:v.value]]) {
                                    [aryRoomCtrlValue removeObject:v];
                                    if([cmdB getDeviceTypeCodeWithCNString:v.category] != A4_DEVICE_MUTIL){
                                        break;
                                    }
                                }
                            }
                            NSLog(@"c: %ld", (unsigned long)aryRoomCtrlValue.count);
                            if (appState == APPSTATE_UPDATE) {
                                ///////////登陆过程完成 进入已登陆状态
                                if ([delegateViewCtrl respondsToSelector:@selector(dataBaseDidUpdate)]) {
                                    appState = APPSTATE_LOGIN_SUCCESS;
                                    [delegateViewCtrl performSelector:@selector(dataBaseDidUpdate)];
                                }
                            }
                            //更新实时设备
                            [self updateActiveDeviceWithCmd:compeleteCMD];
                            //向页面发送重绘reloadData的消息
                            if ([delegateViewCtrl respondsToSelector:@selector(reloadData:)]) {
                                [delegateViewCtrl performSelector:@selector(reloadData:) withObject:compeleteCMD];
                            }
                        }break;
                        case A4_ACTION_ACK:{
                            ///Don't OP
                            if (appState == APPSTATE_LOGIN_SUCCESS) {
                                [self hudHidden];
                            }
                        }break;
                        default:
                            break;
                    }
                }
            }
        }
    }
}
//更新网关时间
- (void)needUpdateGatewayTimeWithGTime:(NSString *)gatewayTime {
    NSLog(@"获得的网关字符串:%@",gatewayTime);
    NSTimeInterval time = gatewayTime.floatValue;
    NSDate *gatewayDate = [NSDate dateWithTimeIntervalSince1970:time];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc]init];
    dateFormat.dateFormat = @"yyyy年MM月dd日 HH:mm:SS";
    NSString *dateToGatewayTime = [dateFormat stringFromDate:gatewayDate];
    NSLog(@"网关时间:%@",dateToGatewayTime);
    NSDate *appTimeDate = [NSDate date];
    NSString *appTime = [dateFormat stringFromDate:appTimeDate];
    NSString *messageDetail = [NSString stringWithFormat:@"网关时间:%@\nAPP时间:%@\n是否同步时间到网关？",dateToGatewayTime,appTime];
    UIAlertView *aler = [[UIAlertView alloc]initWithTitle:@"提示:APP时间与网关不同步" message:messageDetail delegate:self cancelButtonTitle:@"是" otherButtonTitles:@"否",nil];
    self.isUpdateTime = YES;
    [aler show];
}
//成功
- (void)updateGatewayTimeSucceed {
    [self hudShowMsg:@"同步成功" andInterval:2];
}
//失败
- (void)updateGatewayTimeFail {
    [self hudShowMsg:@"同步失败" andInterval:2];
}

#pragma mark -
#pragma mark 文件管理
- (void)uploadFileWithName:(NSString *)fileName andData:(NSData *)data isShowHUD:(BOOL) isShowHud{
    
    //打印上传的数据
    NSString *uploadString = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
    NSLog(@"%@",uploadString);
    
    if (netState == NET_XMPP) {
        if (isShowHud && self.hud == nil) {
//            [self hudDisplayLoadingWithTitle:nil details:@"保存中..."];
            [self addHUDToViewWithDetails:@"保存中..."];
        }
        [xmppFileTransfer uploadFileWithName:fileName andData:data];
    }
    else if (netState == NET_WAN_SOCKET){
        if (isShowHud && self.hud == nil) {
//            [self hudDisplayLoadingWithTitle:nil details:@"保存中..."];
            [self addHUDToViewWithDetails:@"保存中..."];
        }
        [sockFileTransfer uploadFileWithName:fileName andData:data];
    }
    else if(netState == NET_OFF_LINE){
        [self handleAPPOffLineWithMsg:@"你已经离线请重新登录"];
    }
    else if(netState == NET_DEMO){
        ;;
    }
}

- (void)uploadFileWithName:(NSString *)fileName andData:(NSData *)data isShowHUD:(BOOL) isShowHud handler:(UploadHandler) handler {
    
    //打印上传的数据
    NSString *uploadString = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
    NSLog(@"%@",uploadString);
    
    if (netState == NET_XMPP) {
        if (isShowHud && self.hud == nil) {
//            [self hudDisplayLoadingWithTitle:nil details:@"保存中..."];
            [self addHUDToViewWithDetails:@"保存中..."];
        }
        [xmppFileTransfer uploadFileWithName:fileName andData:data handler:handler];
    }
    else if (netState == NET_WAN_SOCKET){
        if (isShowHud && self.hud == nil) {
//            [self hudDisplayLoadingWithTitle:nil details:@"保存中..."];
            [self addHUDToViewWithDetails:@"保存中..."];
        }
        [sockFileTransfer uploadFileWithName:fileName andData:data handler:handler];
    }
    else if(netState == NET_OFF_LINE){
        [self handleAPPOffLineWithMsg:@"你已经离线请重新登录"];
    }
    else if(netState == NET_DEMO){
        if (handler) {
            handler(fileName, nil);
        }
    }
}

#pragma mark HE_FileTransfer Delegate
- (void)didUpdateFile{
    HE_CMDParser *cmdP = [[HE_CMDParser alloc] init];
    HE_CMDBuilder*cmdB = [[HE_CMDBuilder alloc] init];
    HE_MsgBuilder*msgB = [[HE_MsgBuilder alloc] init];
    
    if (appState == APPSTATE_DOWNFILE) {
        appState = APPSTATE_UPDATE;
        [HUD setDetailsLabelText:@"配置应用..."];
    }
    //1.本地更新完成 开始获取aryRoom 的数据
    appState==APPSTATE_LOGIN_SUCCESS?[HUD hide:YES afterDelay:0.5]:NO;
    aryRoom = [CYM_Engine getRoomAllDevice];
    [aryRoomCtrlValue removeAllObjects];
    [aryNeedQuery removeAllObjects];
    for (Room *r in aryRoom) {
        for (RoomDevice *rd in r.deviceArr) {
            for (ControlDeviceContentValue *val in rd.contentArr) {
                if ([val isKindOfClass:[ControlDeviceContentValue class]]) {
                    ///////////不需要查询的类型
                    A4_DeviceTypeCode deviceType = [cmdB getDeviceTypeCodeWithCNString:val.category];
                    if (deviceType == A4_DEVICE_SENCE   ||
                        deviceType == A4_DEVICE_UART    ||
                        deviceType == A4_DEVICE_SENSAR  ||
                        deviceType == A4_DEVICE_ALARM   ||
                        deviceType == A4_DEVICE_THREE) {
                        continue;
                    }
                    NSString *strNum  = [cmdP getDeviceNumWithBindCMD:val.value];
                    NSString *strTMP = [NSString stringWithFormat:@"%@|%@",val.com, val.category];
                    ///////当设备为第三方设备导入时则无"绑定报告" 则strNum = nil
                    if (strNum == nil) {
                        ;
                    }
                    else{
                        [dicRoomDeviceState setObject:@"" forKey:strNum];
                        [aryRoomCtrlValue addObject:val];
                        BOOL isHadExist = NO;
                        for (NSString *s in aryNeedQuery) {
                            if ([s isEqualToString:strTMP]) {
                                isHadExist = YES;break;
                            }
                        }
                        !isHadExist?[aryNeedQuery addObject:strTMP]:NO;
                    }
                }
            }
        }
    }
    //////////////如果为 APP状态为"更新缓存"则开始更新
    if (appState == APPSTATE_UPDATE) {
        for (NSString *s in aryNeedQuery) {
            NSArray *aryTMP  = [s componentsSeparatedByString:@"|"];
            NSString *strCMD = [cmdB getCMDWithAction:A4_ACTION_QUERY DeviceType:[cmdB getDeviceTypeCodeWithCNString:aryTMP[1]] Data:@"FFFFFF"];
            NSString *strMsg = [msgB getMessageWithType:[(NSString *)aryTMP[0] intValue]  action:ACTION_RESOLVING commond:strCMD];
            [self SendMsg:strMsg withNameSpace:@"control" isShowLoading:YES];
        }
        if ([delegateViewCtrl respondsToSelector:@selector(dataBaseDidUpdate)]) {
            [self hudHidden];
            [delegateViewCtrl performSelector:@selector(dataBaseDidUpdate)];
            appState = APPSTATE_LOGIN_SUCCESS;
            return;
        }
    }
    else if(appState == APPSTATE_LOGIN_SUCCESS){
        //2.发送配置文件更新消息
        NSLog(@"配置文件更新成功.");
        if ([delegateViewCtrl respondsToSelector:@selector(dataBaseDidUpdate)]) {
            [delegateViewCtrl performSelector:@selector(dataBaseDidUpdate)];
        }
    }
}
- (void)didNotUpdateFile:(NSError *)error{
    [self hudShowMsg:@"文件下载失败." andInterval:1];
    NSLog(@"文件下载失败.Err: %@", error);
    
}
- (void)didUploadFile{
    NSLog(@"文件上传成功!");
    [[NSNotificationCenter defaultCenter] postNotificationName:@"FileUpSuc" object:nil userInfo:nil];
//    if (!HUD.alpha <= 0.02) {
//        [self hudShowMsg:@"保存成功" andInterval:1.0];
    //防止多次弹框
//    NSInteger timeIntervalBetween = [NSDate dateWithTimeIntervalSinceNow:0].timeIntervalSince1970 - bouncedTime;
//    bouncedTime = [NSDate dateWithTimeIntervalSinceNow:0].timeIntervalSince1970;
//    NSLog(@"弹窗间隔：%lu",(unsigned long)timeIntervalBetween);
//    if (timeIntervalBetween < 3) {
//        return;
//    }
    if (self.uploadTwoFile == YES) {
        if (self.recFileFeedback == 0) {
            self.recFileFeedback++;
            return;
        }
        else if (self.recFileFeedback == 1){
            self.recFileFeedback++;
            self.uploadTwoFile = NO;
        }
    }
    
    UIAlertView *aler = [[UIAlertView alloc]initWithTitle:@"提示" message:@"操作成功" delegate:self cancelButtonTitle:@"确定" otherButtonTitles: nil];
    if (appState == APPSTATE_LOGIN_SUCCESS && self.hud) {
        [aler show];
    }
    if (self.hud) {
        [self.hud removeFromSuperview];
        self.hud = nil;
    }
    
//    }
}
- (void)didNotUploadFile:(NSError *)error{
    NSLog(@"文件上传失败");
//    [self hudShowMsg:@"保存失败..." andInterval:1.5];
    //防止多次弹框
//    NSInteger timeIntervalBetween = [NSDate dateWithTimeIntervalSinceNow:0].timeIntervalSince1970 - bouncedTimeFail;
//    bouncedTimeFail = [NSDate dateWithTimeIntervalSinceNow:0].timeIntervalSince1970;
//    NSLog(@"弹窗间隔：%lu",(unsigned long)timeIntervalBetween);
//    if (timeIntervalBetween < 3) {
//        return;
//    }
    if (self.uploadTwoFile == YES) {
        if (self.recFileFeedback == 0) {
            self.recFileFeedback++;
            return;
        }
        else if (self.recFileFeedback == 1){
            self.recFileFeedback++;
            self.uploadTwoFile = NO;
        }
    }
    UIAlertView *aler = [[UIAlertView alloc]initWithTitle:@"提示" message:@"操作失败" delegate:self cancelButtonTitle:@"确定" otherButtonTitles: nil];
    self.isFileUploadFail = YES;
    if (appState == APPSTATE_LOGIN_SUCCESS && self.hud) {
        [aler show];
    }
    if (self.hud) {
        [self.hud removeFromSuperview];
        self.hud = nil;
    }
    
}
#pragma mark -
#pragma mark 网络监测
////////是否为WIFI
- (BOOL) IsEnableWIFI {
    return ([[Reachability reachabilityForLocalWiFi] currentReachabilityStatus] != NotReachable);
}
///////是否3G
- (BOOL) IsEnable3G {
    return ([[Reachability reachabilityForInternetConnection] currentReachabilityStatus] != NotReachable);
}

#pragma mark -
#pragma mark 收到消息 更新  ActiveDevice
- (void)updateActiveDeviceWithCmd:(NSString *)cmdStr{
    HE_CMDParser *cmdP = [[HE_CMDParser alloc] init];
    NSString *tmpNum = [cmdP getDeviceNumWithCMD:cmdStr];
    if (tmpNum){
        //更新 ActiveDevice
        NSString *strData = [cmdP getDataWithoutNum:cmdStr];
        for (HE_UIDevice *dev in aryActiveDevice) {
            if ([tmpNum isEqualToString:dev.num]) {
                if ([dev respondsToSelector:@selector(updateTheDeviceStateWithData:)]) {
                    [dev updateTheDeviceStateWithData:strData];
                    dev.hasUpdate = YES;
                }
            }
        }
        ///判断是否可以隐藏HUD 了。
        BOOL hasAllUpdate = YES;
        for (HE_UIDevice *dev in aryActiveDevice) {
            hasAllUpdate = dev.hasUpdate;
            if (!hasAllUpdate)
                break;
        }
        if (hasAllUpdate)
            [self hudHidden];
    }
}

#pragma mark - 
#pragma mark MBProccessHUD
- (void)hudShowMsg:(NSString *)msg andInterval:(NSTimeInterval) inval{
    if(!HUD){
        HUD = [[MBProgressHUD alloc] init];
        [HUD setDelegate:self];
        [appDelegate.window addSubview:HUD];
    }
    [HUD setLabelFont:[UIFont systemFontOfSize:14.f]];
    [HUD setMode:MBProgressHUDModeText];
    [HUD setLabelText:@""];
    [HUD setDetailsLabelText:msg];
    [HUD show:YES];
    if (inval <= 0) {
        inval = 1.f;
    }
    [HUD hide:YES afterDelay:inval];
}
- (void)hudShowMsgTitle:(NSString *)title details:(NSString *) details andInterval:(NSTimeInterval) inval{
    if(!HUD){
        HUD = [[MBProgressHUD alloc] init];
        [HUD setDelegate:self];
        [appDelegate.window addSubview:HUD];
    }
    [HUD setMode:MBProgressHUDModeText];
    [HUD setLabelText:title];
    [HUD setDetailsLabelText:details];
    [HUD show:YES];
    [HUD hide:YES afterDelay:inval];

}
- (void)hudShowLoadingTitle:(NSString *)title details:(NSString *)details{
    MBProgressHUD *hudTmp = [[MBProgressHUD alloc] init];

    hudTmp.delegate                  = self;
    hudTmp.tag                       = 10000;
    hudTmp.removeFromSuperViewOnHide = YES;

    [hudTmp setMode:MBProgressHUDModeIndeterminate];
    [hudTmp setLabelText:title];
    [hudTmp setDetailsLabelText:details];
    [hudTmp show:YES];
    
    
    [appDelegate.window addSubview:hudTmp];
    [aryTempHUD addObject:hudTmp];
    
    [self performSelector:@selector(processTimeOut:) withObject:hudTmp afterDelay:8.0];
}

//////不设置超时的Loading
- (void)hudDisplayLoadingWithTitle:(NSString *)aTitle details:(NSString *)aDetails{
    if(!HUD){
        HUD = [[MBProgressHUD alloc] init];
        [HUD setDelegate:self];
        [appDelegate.window addSubview:HUD];
    }
    [HUD setLabelText:aTitle];
    [HUD setDetailsLabelText:aDetails];
    [HUD setMode:MBProgressHUDModeIndeterminate];
    [HUD show:YES];
}
//添加一个指示器
- (void)addHUDToViewWithDetails:(NSString *)details {
    if (self.hud) {
        [self.hud hide:YES];
        self.hud = nil;
    }//如果存在，先移除
    self.hud = [[MBProgressHUD alloc] initWithView:[[AppDelegate sharedAppDelegate] window]];
    self.hud.removeFromSuperViewOnHide = YES;
    self.hud.labelFont      = [UIFont systemFontOfSize:14.f];
    self.hud.labelText      = details;
    [self.hud show:YES];
    [self.hud performSelector:@selector(setLabelText:) withObject:@"操作失败，请重试" afterDelay:19.0];
    [self.hud hide:YES afterDelay:20];//增加一个延时消失
    [[[AppDelegate sharedAppDelegate] window] addSubview:self.hud];
}
- (void)removeHUD {
    if (self.hud) {
        self.hud.labelText = @"操作成功";
        [self.hud hide:YES afterDelay:1];
    }
}
- (void)hudHidden{
    [HUD hide:YES];
    @try {
        for (MBProgressHUD *hud in aryTempHUD) {
            [hud hide:YES];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"%@",exception);
    }
    @finally {
        ;
    }
}
- (void)processTimeOut:(MBProgressHUD *) hud{
    [hud setMode:MBProgressHUDModeText];
    [hud setLabelText:@""];
    [hud setDetailsLabelText:@"连接超时..."];
    [hud hide:YES afterDelay:1.5];
}

- (void)hudWasHidden:(MBProgressHUD *)hud{
    if (hud.tag == 10000) {
        [hud removeFromSuperview];
        [aryTempHUD removeObject:hud];
    }
}

#pragma mark - 异常处理
- (void)handleAPPOffLineWithMsg:(NSString *)msg{
    NSLog(@"离线处理");
    if (appState == APPSTATE_OFF_LINE) {
        @try {
            ///取消心跳线程
            [theadHeartBeat cancel];
            theadHeartBeat = nil;
            HUD            = nil;
            if (!isAlerting) {
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:msg delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
                [alert show];
                self.isLogBackIn = YES;
                isAlerting = true;
            }
        }
        @catch (NSException *exception) {
            ;
        }
        @finally {
            ;
        }
    }
}
#pragma mark - AlertView，有重新登录、复原、更新时间
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    isAlerting = false;
    if (self.isLogBackIn == YES) {
        self.isLogBackIn = NO;
        id delVC = delegateViewCtrl;
        if ([delVC respondsToSelector:@selector(navigationController)]) {
            FXW_ShowVC *vc = [[FXW_ShowVC alloc] init];
            [CYM_DatabaseTable logoutDataBase];
            [self logout];
            [[[AppDelegate sharedAppDelegate] window] setRootViewController:vc];
            
//            [[delVC navigationController] presentViewController:vc animated:YES completion:^{
//                ;
//            }];
        }
    }
    if (self.isFileUploadFail == YES) {
        [[NSNotificationCenter defaultCenter] postNotificationName:@"TheFileDidNotUpload" object:self userInfo:nil];
        self.isFileUploadFail = NO;
    }
    if (self.isUpdateTime == YES && buttonIndex == 0) {
        self.isUpdateTime = NO;
        NSUInteger nowTime = [[NSDate date] timeIntervalSince1970];
        NSString *appTime = [NSString stringWithFormat:@"%lu",(unsigned long)nowTime];
        NSString *appTimer = [NSString hexStringFromString:appTime];
        NSString *msg = [self.msgB updateGatewayTimeWithGT:appTimer];
        NSLog(@"发送本地时间到网关:%@",msg);
        [self SendMsg:msg withNameSpace:@"control" isShowLoading:NO];
    }
}


#pragma mark -  AppDeleate  
- (void)applicationWillEnterForeground:(UIApplication *)application{
    NSUInteger nowTime = [NSDate dateWithTimeIntervalSinceNow:0].timeIntervalSince1970;
    NSLog(@"appState: %d", appState);
    
    //1. 如果切换时间大于30s -> 跳转到登录页面
    if ((nowTime - backgroudTimeinterl) >= 25 && appState == APPSTATE_LOGIN_SUCCESS) {
        UIAlertView *aler = [[UIAlertView alloc]initWithTitle:@"提示" message:@"您已经离线请重新登录" delegate:self cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [self logout];
        id delVC = delegateViewCtrl;
        if ([delVC respondsToSelector:@selector(navigationController)]) {
            FXW_ShowVC *vc = [[FXW_ShowVC alloc] init];
            [CYM_DatabaseTable logoutDataBase];
            [self logout];
            [[[AppDelegate sharedAppDelegate] window] setRootViewController:vc];

//            [[delVC navigationController] presentViewController:vc animated:YES completion: nil];
        }
        [aler show];
    }
}
- (void)applicationDidEnterBackground:(UIApplication *)application{
    
    if (netState == NET_DEMO) {
        appState = APPSTATE_OFF_LINE;
    }
    
    backgroudTimeinterl = [NSDate dateWithTimeIntervalSinceNow:0].timeIntervalSince1970;
    NSLog(@"DidEnterBackground: %lu", (unsigned long)backgroudTimeinterl);
}

#pragma mark - 获取app的登陆状态
- (APPSTATE)getAppState {
    return appState;
}
- (NET_STATE)getAppNetState {
    return netState;
}
@end

