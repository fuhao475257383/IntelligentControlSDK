//
//  WB_socketFileTransfer.h
//  BWRemoter
//
//  Created by JianBo He on 15/1/13.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AFNetworking.h"

typedef void (^UploadHandler)(NSString *fileName, NSError *error);

@interface WB_socketFileTransfer : NSObject
{
    NSString *strGatewayIP;
    NSString *strBaseURL;
    NSMutableArray *aryNeedDownLoadFile;
    NSMutableArray *aryNeedParseFileName;
}

- (void)setDelegate:(id)del;//设置代理
- (void)setGatewayIP:(NSString *)strIP;//设置网关IP
- (void)startUpdateFile;//开始主线程同步配置文件，下载解析全部完成时才向delegate发送complete消息
- (void)startUpdateFileInBackGround;//后台同步配置，任务完成向delegate发送compelete消息
//上传文件
//ex: name=config data=XXX
- (void)uploadFileWithName:(NSString *)name andData:(NSData *)data;//上传一个文件
- (void)uploadFileWithName:(NSString *)name andData:(NSData *)data handler: (UploadHandler)handler;
//根据URL单独下载一个文件
-(void)download:(NSString *)downloadUrl asName:(NSString *)name;
@end
