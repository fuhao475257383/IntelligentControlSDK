//
//  HE_xmppFileTransfer.m
//  BWRemoter
//
//  Created by JianBo He on 14/12/23.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "HE_xmppFileTransfer.h"
#import "HE_APPManager.h"
#import "JSONKit.h"
#import "HE_FileOperation.h"

typedef enum {
    UPDATE_BACKGROUND,
    UPDATE_UITHREAD
}UPDATE_STATE;


@interface HE_xmppFileTransfer()<XMPPSIFileTransferDelegate>{
    id<HE_FileTransfer> delegate;
    UPDATE_STATE tag;
    //
    HE_XmppMsgManager *xmppManager;
    HE_FileOperation  *fileOperation;
    XMPPSIFileTransfer *siTransfer;
    
    NSMutableArray *aryNeedDownLoadFile;
    NSMutableArray *aryNeedParseFileName;
    
    dispatch_semaphore_t semaphoreRecv;
    dispatch_semaphore_t semaphoreUpload;
    dispatch_queue_t     queueUpload;
//    dispatch_queue_t     queueDownload;
    
    //////////文件上传时间字典   - 》  若收到文件更新 在上次字典中 且 时间间隔小于5s 则不更新
    NSMutableDictionary *dicUploadFile;
    /// Handler 字典, 即用即销毁
    NSMutableDictionary *dicUploadHandler;
}

//记录信号量
@property (nonatomic) NSInteger semaphoreNumber;
//用一个BOOL类型来记录，刚刚是否上传了文件，最终决定不这样做，先注释起来，实在没办法再说
//@property (nonatomic) BOOL isUploadFile;
//该属性用于记录本地登录时，一共需要下载多少个文件
@property (nonatomic) NSInteger needDownloadFileNumber;

@property (nonatomic, assign) BOOL isLoseNextConfig;

@end


@implementation HE_xmppFileTransfer

#pragma mark 单例＋初始化
+ (id)sharedFileTransfer{
    static HE_xmppFileTransfer *transfer = nil;
    if (!transfer) {
        transfer = [[super allocWithZone:nil] init];
    }
    return transfer;
}
+ (id)allocWithZone:(struct _NSZone *)zone{
    return [self sharedFileTransfer];
}
//这么做是为了防止信号量出现问题，导致下载出错
- (void)resetSemaphore {
    if (self.semaphoreNumber == 0) {
        NSLog(@"重置信号量为1");
        dispatch_semaphore_signal(semaphoreUpload);
        self.semaphoreNumber = 1;
    }
}

- (id)init{
    self = [super init];
    if (self) {
//        self.isUploadFile = NO;
        aryNeedDownLoadFile  = [NSMutableArray array];
        aryNeedParseFileName = [NSMutableArray array];
        dicUploadFile        = [[NSMutableDictionary alloc] init];
        ///////////////
        semaphoreRecv   = dispatch_semaphore_create(1);
        semaphoreUpload = dispatch_semaphore_create(1);
        self.semaphoreNumber = 1;
        NSLog(@"semaphore创建1");
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(resetSemaphore) name:@"RestoreSemaphore" object:nil];
        queueUpload     = dispatch_queue_create("com.BW.UPLOAD", 0);
//        queueDownload   = dispatch_queue_create("com.BW.DOWNLOAD", 0);
    }
    return self;
}

#pragma mark - Public Interface
- (void)setDelegate:(id)del{
    delegate = del;
}
- (void)setSITransfer:(XMPPSIFileTransfer *)siF{
    siTransfer = siF;
}
///初次登陆下载文件
- (void)startUpdateFile{
    tag = UPDATE_UITHREAD;
    [aryNeedParseFileName removeAllObjects];
    [aryNeedDownLoadFile removeAllObjects];
    if (!xmppManager) {
        xmppManager   = [HE_XmppMsgManager sharedManager];
        fileOperation = [[HE_FileOperation alloc] init];
    }
    [self sendFileRequestWithName:@"config.json"];
}

///APP运行过程当中需要下载文件
- (void)startUpdateFileInBackGround{
//    dispatch_async(queueDownload, ^(){
//    if (self.isUploadFile) {
//        NSLog(@"为了避免xmpp传输出错，不用下载该config文件");
//        
//        self.isUploadFile = NO;
//        
//        return;
//    }
    dispatch_async(queueUpload, ^(){
        tag = UPDATE_BACKGROUND;
        dispatch_semaphore_wait(semaphoreUpload, DISPATCH_TIME_FOREVER);
        self.semaphoreNumber = 0;
        NSLog(@"semaphore-1");
        /////需等待文件完全下载完成
        [aryNeedParseFileName removeAllObjects];
        [aryNeedDownLoadFile removeAllObjects];
        [self sendFileRequestWithName:@"config.json"];
    });
}

///上传文件
- (void)uploadFileWithName:(NSString *)name andData:(NSData *)data{
    [dicUploadFile setObject:[NSNumber numberWithDouble:[[NSDate date] timeIntervalSince1970]] forKey:name];
    
    dispatch_async(queueUpload, ^{
        dispatch_semaphore_wait(semaphoreUpload, DISPATCH_TIME_FOREVER);
        self.semaphoreNumber = 0;
//        if (![name isEqualToString:@"iospush.json"]) {
//            self.isUploadFile = YES;
//        }
        NSLog(@"semaphore-1");
        NSLog(@"开始进入上传了,当前线程：%@",[NSThread currentThread]);
        [siTransfer initiateFileTransferTo:xmppManager.jidRoot withData:data andName:name];
    });
}


- (void)uploadFileWithName:(NSString *)name andData:(NSData *)data handler:(UploadHandler) handler{
    if(!dicUploadHandler) {
        dicUploadHandler = [[NSMutableDictionary alloc] init];
    }
    dicUploadHandler[name] = handler;
    [self uploadFileWithName:name andData:data];
}

#pragma mark - Private
#pragma mark 下载文件操作
///比较版本信息得到需要跟新的数组
- (void)getNeedUpdateFileName{
    [aryNeedDownLoadFile removeAllObjects];
    NSArray  *docs      = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *path      = [docs[0] stringByAppendingPathComponent:@"1.json"];
    NSString *strConfig = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
    NSArray  *aryConfig = [strConfig objectFromJSONString];
    
    //////////不同网关登录时
    NSString *nowSN = [[HE_APPManager sharedManager] User].strSN;
    NSString *oldSN = [[NSUserDefaults standardUserDefaults] objectForKey:@"OLDSN"];
    if (oldSN == nil || [oldSN isEqualToString:@""]) {
        [[NSUserDefaults standardUserDefaults] setObject:nowSN forKey:@"OLDSN"];
        oldSN = nowSN;
    }
    if (![nowSN isEqualToString:oldSN]) {
        NSLog(@"旧的SN网关: %@",oldSN);
        for (NSDictionary *dic in aryConfig) {
            //1.当文件版本过旧
            NSString *fileName = [dic objectForKey:@"name"];
            NSInteger localVer = [CYM_Engine getVersionWithFileName:fileName];
            if (localVer == 0 && tag == UPDATE_UITHREAD) {
                localVer = 10000;
            }
            
            NSInteger serverVer = [[dic objectForKey:@"version"] integerValue];
            NSLog(@"%@ 本地版本号:%ld  网关版本号: %ld",fileName, (long)localVer, (long)serverVer);
            //////2.不需要关心的文件，门锁
            //            if ([fileName isEqualToString:@"doorlock"] || [fileName isEqualToString:@"doorlocknote"]) {
            //                continue;
            //            }
            
            if (serverVer != localVer || [fileName isEqualToString:@"securitynote"]) {
                NSNumber *timeUpload =  dicUploadFile[[NSString stringWithFormat:@"%@.json", fileName]];
                
                NSLog(@"上传时间%@  现在时间%f",timeUpload,[[NSDate date] timeIntervalSince1970]);
                
                NSTimeInterval subTime = [[NSDate date] timeIntervalSince1970] - timeUpload.doubleValue;
                NSLog(@"name: %@, 时间差: %lf", fileName,subTime);
                if (subTime < 5) {
                    NSLog(@"%@ 为自己上传的文件所以不更新", fileName);
                }
                else{
                    NSLog(@"%@ 需要更新.", fileName);
                    [aryNeedDownLoadFile addObject:[NSString stringWithFormat:@"%@.json", fileName]];
                }
            }
            //2.当设备上无该文件
        }
        
        NSLog(@"需要更新: %@", aryNeedDownLoadFile);
    }
    //////////同一个网关SN
    else{
        for (NSDictionary *dic in aryConfig) {
            //1.当文件版本过旧
            NSString *fileName = [dic objectForKey:@"name"];
            NSInteger localVer = [CYM_Engine getVersionWithFileName:fileName];
            if (localVer == 0 && tag == UPDATE_UITHREAD) {
                localVer = 10000;
            }
            
            NSInteger serverVer = [[dic objectForKey:@"version"] integerValue];
            NSLog(@"%@ 本地版本号:%ld  网关版本号: %ld",fileName, (long)localVer, (long)serverVer);
            //////2.不需要关心的文件，门锁
//            if ([fileName isEqualToString:@"doorlock"] || [fileName isEqualToString:@"doorlocknote"]) {
//                continue;
//            }
            
            if (serverVer != localVer || [fileName isEqualToString:@"securitynote"]) {
                NSNumber *timeUpload =  dicUploadFile[[NSString stringWithFormat:@"%@.json", fileName]];
                
                NSLog(@"上传时间%@  现在时间%f",timeUpload,[[NSDate date] timeIntervalSince1970]);
                
                NSTimeInterval subTime = [[NSDate date] timeIntervalSince1970] - timeUpload.doubleValue;
                NSLog(@"name: %@, 时间差: %lf", fileName,subTime);
                if (subTime < 5) {
                    NSLog(@"%@ 为自己上传的文件所以不更新", fileName);
                }
                else{
                    NSLog(@"%@ 需要更新.", fileName);
                    [aryNeedDownLoadFile addObject:[NSString stringWithFormat:@"%@.json", fileName]];
                }
            }
            //2.当设备上无该文件
        }
    }
    //3.无文件需要更新
    if (aryNeedDownLoadFile.count == 0){
        NSLog(@"无文件需要更新");
        [self fileDownloadCompelete];
    }
}
/////////文件下载完成
- (void)fileDownloadCompelete{
    if( [delegate respondsToSelector:@selector(didUpdateFile)] ){
        //解析所有更新的配置文件
        if (tag == UPDATE_UITHREAD) {
            NSArray *docs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
            for (NSString *name in aryNeedParseFileName) {
                NSString *path = [docs[0] stringByAppendingPathComponent:name];
                [CYM_Engine paserFileWithPath:path fileName:name];
            }
            [delegate didUpdateFile];
            [self updateOrDeleteDeviceToken];
            
            /// 改变OLDSN 记录, 已处理 网关切换配置文件不同步的情况
            NSString *nowSN = [[HE_APPManager sharedManager] User].strSN;
            [[NSUserDefaults standardUserDefaults] setObject:nowSN forKey:@"OLDSN"];
        }
        else{
            [self performSelectorInBackground:@selector(parseFileHandler) withObject:nil];
        }
    }
}

///////解析下载好的配置文件
- (void)parseFileHandler{
//    [[HE_APPManager sharedManager] changeHUDDetail:@"正在解析..."];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(){
        NSArray *docs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        for (NSString *name in aryNeedParseFileName) {
            NSString *path = [docs[0] stringByAppendingPathComponent:name];
            [CYM_Engine paserFileWithPath:path fileName:name];
        }
        if (self.semaphoreNumber == 0) {
            dispatch_semaphore_signal(semaphoreUpload);
            self.semaphoreNumber = 1;
            NSLog(@"semaphore+1");
        }
        //////////通知
        dispatch_async(dispatch_get_main_queue(),^(){
            NSNotification *notfic = [NSNotification notificationWithName:@"DATABASE_UPDATE" object:nil];
            [[NSNotificationCenter defaultCenter] postNotification:notfic];
            
        });
    });
}


#pragma mark XMPPSITransfer Delegate
- (void)receivedData:(NSData *)aData fileName:(NSString *)aName from:(XMPPJID *)from{
    ///////1.保存至沙盒
    if ([aName isEqualToString:@"config.json"]) {
        aName = @"1.json";
    }
    [fileOperation createFileName:aName WithData:aData];
    [aryNeedParseFileName addObject:aName];
    ///////2.若为config.json文件则解析判断出需要更新的文件
    if ([aName isEqualToString:@"1.json"]) {
        self.needDownloadFileNumber = 0;
        [self getNeedUpdateFileName];
        if (aryNeedDownLoadFile.count > 0) {
            [self sendFileRequestWithName:aryNeedDownLoadFile[0]];
        }
        self.needDownloadFileNumber = aryNeedDownLoadFile.count;
    }
    else{
        //文件下载队列
        [aryNeedDownLoadFile removeObject:aName];
        if (aryNeedDownLoadFile.count > 0) {
            NSLog(@"延时一秒下载,文件名%@",aryNeedDownLoadFile[0]);
//            NSRange range = {0,aName.length - 5};
//            NSString *detail = [aName substringWithRange:range];
            [[HE_APPManager sharedManager] changeHUDDetail:[NSString stringWithFormat:@"下载进度：%ld/%ld",self.needDownloadFileNumber - aryNeedDownLoadFile.count,self.needDownloadFileNumber]];
            [NSThread sleepForTimeInterval:1];
            [self sendFileRequestWithName:aryNeedDownLoadFile[0]];
        }
        else{
            [[HE_APPManager sharedManager] changeHUDDetail:@"解析文件中..."];
            [self fileDownloadCompelete];
        }
    }
}

- (void)hasSendFile:(NSString *)aName to:(XMPPJID *)to{
    NSLog(@"%@ 上传成功",aName);
    if (self.semaphoreNumber == 0) {
        dispatch_semaphore_signal(semaphoreUpload);
        self.semaphoreNumber = 1;
        NSLog(@"semaphore+1");
    }
    
    
    if ([delegate respondsToSelector:@selector(didUploadFile)]) {
        [delegate didUploadFile];
    }
    
    /// 调用 Handler 处理
    UploadHandler handler = dicUploadHandler[aName];
    if (handler) {
        handler(aName, nil);
    }
    
    
    //发送忽略下一条配置文件更新的消息
    if ([aName isEqualToString:@"security.json"] && ((HE_APPManager*)[HE_APPManager sharedManager]).isZoneView == YES) {
        self.isLoseNextConfig = YES;
    }
}

- (void)didNotCompleteFileName:(NSString *)aName error:(NSString *)aError opearate:(XMPPSIFileTransferState)state{
    NSLog(@"操作失败%@:%d",aName,state);
    //文件上传失败
    if (state == kXMPPSIFileTransferStateSending) {
        if ([delegate respondsToSelector:@selector(didNotUploadFile:)]) {
            [delegate didNotUploadFile:aError];
        }
//        if (![aName isEqualToString:@"iospush.json"]) {
            if (self.semaphoreNumber == 0) {
                dispatch_semaphore_signal(semaphoreUpload);
                self.semaphoreNumber = 1;
                NSLog(@"semaphore+1");
            }
        
//            self.isUploadFile = NO;
            
//        }
        
    }
    //文件下载失败
    else if (state == kXMPPSIFileTransferStateReceiving){
        if (tag == UPDATE_UITHREAD && [aName isEqualToString:@"config.json"]) {
            [CYM_DatabaseTable logoutDataBase];
            [[HE_APPManager sharedManager] logout];
            [[HE_APPManager sharedManager] handleAPPOffLineWithMsg:@"配置文件更新失败，请重试。"];
        }
        if (tag == UPDATE_BACKGROUND) {
            if (self.semaphoreNumber == 0) {
                dispatch_semaphore_signal(semaphoreUpload);
                self.semaphoreNumber = 1;
                NSLog(@"semaphore+1");
            }
//            self.isUploadFile = NO;
        }
        [aryNeedDownLoadFile removeObject:aName];
        if (aryNeedDownLoadFile.count == 0) {
            [self fileDownloadCompelete];
        }else {
            if (tag == UPDATE_BACKGROUND) {
                NSLog(@"这里感觉是多余的");
                if (self.semaphoreNumber == 0) {
                    dispatch_semaphore_signal(semaphoreUpload);
                    self.semaphoreNumber = 1;
                    NSLog(@"semaphore+1");
                }
                
                
            }
        }
    }
    
    /// 调用 Handler 处理
    UploadHandler handler = dicUploadHandler[aName];
    if (handler) {
        handler(aName, aError);
    }
}
#pragma mark 文件下载Msg请求
///发送下载config.json文件请求
- (void)sendFileRequestWithName:(NSString *)aName{
    if ([aName isEqualToString:@"config.json"]) {
        if (self.isLoseNextConfig == YES) {
            self.isLoseNextConfig = NO;
            [self resetSemaphore];
            return;
        }
        [xmppManager sendMsgToRoot:@"@#$%1002000E02"];
    }
    else if ([aName isEqualToString:@"control.json"]) {
        [xmppManager sendMsgToRoot:@"@#$%1002000E03"];
    }
    else if ([aName isEqualToString:@"ipc.json"]) {
        [xmppManager sendMsgToRoot:@"@#$%1002000E04"];
    }
    else if ([aName isEqualToString:@"room.json"]) {
        [xmppManager sendMsgToRoot:@"@#$%1002000E05"];
    }
    else if ([aName isEqualToString:@"scene.json"]) {
        [xmppManager sendMsgToRoot:@"@#$%1002000E06"];
    }
    else if ([aName isEqualToString:@"security.json"]) {
        [xmppManager sendMsgToRoot:@"@#$%1002000E07"];
    }
    else if ([aName isEqualToString:@"securitynote.json"]) {
        [xmppManager sendMsgToRoot:@"@#$%1002000E08"];
    }
    else if ([aName isEqualToString:@"crontab.json"]) {
        [xmppManager sendMsgToRoot:@"@#$%1002000E09"];
    }
    else if ([aName isEqualToString:@"iospush.json"]) {
        [xmppManager sendMsgToRoot:@"@#$%1002000EAF"];
    }
    //添加门锁
    else if ([aName isEqualToString:@"doorlock.json"]) {
        [xmppManager sendMsgToRoot:@"@#$%1002000EA0"];
    }
    else if ([aName isEqualToString:@"doorlocknote.json"]) {
        [xmppManager sendMsgToRoot:@"@#$%1002000EA1"];
    }
}


// 判断本地是否有iospush.json文件 & deviceToken 是否包含其中
- (void)updateOrDeleteDeviceToken {
    HE_FileOperation *fileOP = [[HE_FileOperation alloc] init];
    NSUserDefaults *usrDefault = [NSUserDefaults standardUserDefaults];
    NSString *fileName = @"iospush.json";
    NSString *strcontent = [fileOP readFileWithName:fileName];
    NSString *strDeviceT = [usrDefault objectForKey:kDeviceToken];
    
    // 未成功注册到DeviceToken
    if (!strDeviceT.isNotEmptyAndNil) {
        return;
    }
    
    NSMutableArray *aryTokens = nil;
    // 有文件
    if (strcontent.isNotEmptyAndNil) {
        // 取出文件内容, 并且初始化到数组
        NSArray *docs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *path = [docs[0] stringByAppendingPathComponent:fileName];
        NSData * data = [[NSData alloc] initWithContentsOfFile:path];
        aryTokens = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        // 解析成功
        if (aryTokens != nil){
            aryTokens = [NSMutableArray arrayWithArray:aryTokens];
            
            // 判断iospush.json文件 是否已经包含本机DeviceToken
            if ([strcontent myContainsString:strDeviceT]) { /* 包含则: 是否为开启通知, 没有开启着需要删除改DeviceToken */
                NSNumber *isEnable = [usrDefault objectForKey:kIsOpenNotfic];
                if (isEnable.boolValue) {
                    NSLog(@"iospush.json已经包含, 本机Token, 无需上传!");
                    return;
                } else {
                    /* 删除该项 */
                    for (NSDictionary * dict in aryTokens){
                        if ([dict[@"token"] isEqualToString:strDeviceT]) {
                            [aryTokens removeObject:dict];
                            NSLog(@"APP推送功能已关闭, 删除DeviceT: %@", strDeviceT);
                            break;
                        }
                    }
                }
            }
            else {/* 不包含token 加入到ary */
                // 计算index
                NSUInteger index = 0;
                for (NSDictionary * dict in aryTokens){
                    if (index < ((NSString *)dict[@"id"]).integerValue) {
                        index = ((NSString *)dict[@"id"]).integerValue;
                    }
                }
                NSLog(@"Add DeviceT: %@", strDeviceT);
                [aryTokens addObject:@{@"id": [NSString stringWithFormat:@"%lu", (unsigned long)++index], @"token": strDeviceT}];
            }
        }
    }
    else { /* 无文件 */
        aryTokens = [NSMutableArray array];
        NSMutableDictionary *dicDeviceT = [NSMutableDictionary dictionary];
        [dicDeviceT setObject:@"0" forKey:@"id"];
        dicDeviceT[@"token"] = strDeviceT;
        
        [aryTokens addObject:dicDeviceT];
        NSLog(@"New DeviceT: %@", strDeviceT);
    }
    
    // 生成文件 并上传
    [fileOP saveJSONFileName:fileName WithAry:aryTokens];
    strcontent = [fileOP readFileWithName:fileName];
    [self uploadFileWithName:fileName
                     andData:[strcontent dataUsingEncoding:NSUTF8StringEncoding]
                     handler:^(NSString *fileName, NSError *error) {
                         NSLog(@"文件上传完成: %@: %@", fileName, error);
                     }];
}
@end
