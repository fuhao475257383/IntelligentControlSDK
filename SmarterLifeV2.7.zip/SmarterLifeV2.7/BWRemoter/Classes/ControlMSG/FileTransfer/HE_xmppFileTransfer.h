//
//  HE_xmppFileTransfer.h
//  BWRemoter
//
//  Created by JianBo He on 14/12/23.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//
#import <Foundation/Foundation.h>
#import "XMPPFramework.h"

typedef void (^UploadHandler)(NSString *fileName, NSError *error);

@interface HE_xmppFileTransfer : NSObject



+ (id)sharedFileTransfer;

//信号量重置为1
- (void)resetSemaphore;

- (void)setSITransfer:(XMPPSIFileTransfer *)siF;//设置SI对象
- (void)setDelegate:(id)del;//设置代理

/////初次登陆下载文件
- (void)startUpdateFile;
/////APP运行过程中、需要更新文件
- (void)startUpdateFileInBackGround;
//上传文件
- (void)uploadFileWithName:(NSString *)name andData:(NSData *)data;
//上传或者下载失败后调用
- (void)uploadFileWithName:(NSString *)name andData:(NSData *)data handler:(UploadHandler) handler;

@end
