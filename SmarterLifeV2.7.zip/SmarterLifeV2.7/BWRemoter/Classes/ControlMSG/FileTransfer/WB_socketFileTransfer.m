//
//  WB_socketFileTransfer.m
//  BWRemoter
//
//  Created by JianBo He on 15/1/13.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "WB_socketFileTransfer.h"
#import "HE_APPManager.h"
#import "JSONKit.h"
#import "HE_FileOperation.h"

typedef enum {
    UPDATE_BACKGROUND,
    UPDATE_UITHREAD
}UPDATE_STATE;

@interface WB_socketFileTransfer()
{
    id<HE_FileTransfer> delegate;
    UPDATE_STATE tag;
    //
    dispatch_semaphore_t semaphore;
    
    //////////文件上传时间字典   - 》  若收到文件更新 在上次字典中 且 时间间隔小于5s 则不更新
    NSMutableDictionary *dicUploadFile;
}

//该属性用于记录本地登录时，一共需要下载多少个文件
@property (nonatomic) NSInteger needDownloadFileNumber;

@end

@implementation WB_socketFileTransfer
- (id)init{
    self = [super init];
    if (self) {
        strGatewayIP = @"";
        aryNeedDownLoadFile = [[NSMutableArray alloc] init];
        aryNeedParseFileName = [[NSMutableArray alloc] init];
        ///////////////
        semaphore = dispatch_semaphore_create(1);
        NSLog(@"本地semaphore创建=1");
        
        dicUploadFile  = [NSMutableDictionary dictionary];
    }
    return self;
}

- (void)setDelegate:(id)del{
    delegate = del;
}
- (void)setGatewayIP:(NSString *)strIP{
    strGatewayIP = [NSString stringWithFormat:@"http://%@", strIP];
    strBaseURL = [NSString stringWithFormat:@"%@/digitalhomephonev2/configfile/", strGatewayIP];
    NSLog(@"URL是:%@",strBaseURL);
}
- (void)startUpdateFile{
    //[socktManager downloadFile]
    //下载配置文件（请更改为正确的IP和端口号即可）
    //@"http://192.168.169.150/digitalhomephonev2/configfile/config.json"
    tag = UPDATE_UITHREAD;
    [aryNeedParseFileName removeAllObjects];
    [aryNeedDownLoadFile removeAllObjects];
    [self download:[NSString stringWithFormat:@"%@config.json", strBaseURL]asName:@"1.json"];
}

- (void)startUpdateFileInBackGround{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(){
        tag = UPDATE_BACKGROUND;
        dispatch_semaphore_wait(semaphore, DISPATCH_TIME_FOREVER);
        NSLog(@"本地semaphore-1");
        [aryNeedParseFileName removeAllObjects];
        [aryNeedDownLoadFile removeAllObjects];
        [self download:[NSString stringWithFormat:@"%@config.json", strBaseURL]asName:@"1.json"];
    });
}

///AFNetWorking 下载文件方法
-(void)download:(NSString *)downloadUrl asName:(NSString *)name{
    //对AFN文件下载中url,客户端，队列进行初始化
    NSURL *url = [NSURL URLWithString:downloadUrl];//待定url，这里传入目标文件所在url
    
    // 指定文件保存路径，将文件保存在沙盒中
    NSArray *docs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *path = [docs[0] stringByAppendingPathComponent:name];
    AFHTTPClient *httpClient = [[AFHTTPClient alloc] initWithBaseURL:url];
    // 1. 建立请求、 不缓存
    NSURLRequest *request = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:20];
    // 2. 操作
    AFHTTPRequestOperation *op = [[AFHTTPRequestOperation alloc] initWithRequest:request];
    
    op.outputStream = [NSOutputStream outputStreamToFileAtPath:path append:NO];
    // 设置下载完成操作
    [op setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
        //如果是config文件则 获取需要更新的版本
        //否则 下载下一个文件
        NSLog(@"%@ 下载成功.", name);
        [aryNeedParseFileName addObject:name];
        [[HE_APPManager sharedManager] changeHUDDetail:[NSString stringWithFormat:@"下载进度：%ld/%ld",aryNeedParseFileName.count,self.needDownloadFileNumber]];
        if ([name isEqualToString:@"1.json"]) {
            [self getNeedUpdateFileName];
        }
        else{
            //文件下载全部下载完成
            [aryNeedDownLoadFile removeObject:name];
            
            if (aryNeedDownLoadFile.count == 0) {
                
                [[HE_APPManager sharedManager] changeHUDDetail:@"解析文件中..."];
                
                [self fileDownloadCompelete];
            }
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        //删除下载失败的文件
        NSLog(@"%@ 下载失败", name);
        [aryNeedDownLoadFile removeObject:name];
        if ([name isEqualToString:@"1.json"] && tag == UPDATE_UITHREAD) {
            [CYM_DatabaseTable logoutDataBase];
            [[HE_APPManager sharedManager] logout];
            [[HE_APPManager sharedManager] handleAPPOffLineWithMsg:@"配置文件更新失败，请重试。"];
            return ;
        }
        if (aryNeedDownLoadFile.count == 0) {
            [self fileDownloadCompelete];
        }
    }];
    // 启动下载
    [httpClient.operationQueue addOperation:op];
}

///比较版本信息得到需要跟新的数组
- (void)getNeedUpdateFileName{
    self.needDownloadFileNumber = 0;
    [aryNeedDownLoadFile removeAllObjects];
    NSArray *docs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *path = [docs[0] stringByAppendingPathComponent:@"1.json"];
    NSString *strConfig = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
    NSArray *aryConfig = [strConfig objectFromJSONString];
    
    //////////不同网关登录时
    NSString *nowSN = [[HE_APPManager sharedManager] User].strSN;
    NSString *oldSN = [[NSUserDefaults standardUserDefaults] objectForKey:@"OLDSN"];
    if (oldSN == nil || [oldSN isEqualToString:@""]) {
        [[NSUserDefaults standardUserDefaults] setObject:nowSN forKey:@"OLDSN"];
        oldSN = nowSN;
    }
    if (![nowSN isEqualToString:oldSN]) {
        self.needDownloadFileNumber = 10;
        NSLog(@"旧的SN网关: %@",oldSN);
        [aryNeedDownLoadFile addObject:@"control.json"];
        [aryNeedDownLoadFile addObject:@"room.json"];
        [aryNeedDownLoadFile addObject:@"ipc.json"];
        [aryNeedDownLoadFile addObject:@"scene.json"];
        [aryNeedDownLoadFile addObject:@"security.json"];
        [aryNeedDownLoadFile addObject:@"securitynote.json"];
        [aryNeedDownLoadFile addObject:@"crontab.json"];
        
        //添加门锁
        [aryNeedDownLoadFile addObject:@"doorlock.json"];
        [aryNeedDownLoadFile addObject:@"doorlocknote.json"];
        [aryNeedDownLoadFile addObject:@"iospush.json"];
        
        NSLog(@"需要更新: %@", aryNeedDownLoadFile);
        for (NSString *s in aryNeedDownLoadFile) {
            [self download:[NSString stringWithFormat:@"%@%@",strBaseURL, s] asName:[NSString stringWithFormat:@"%@",s]];
        }
    }
    //////////同一个网关SN
    else{
        for (NSDictionary *dic in aryConfig) {
            NSString *fileName = [dic objectForKey:@"name"];
            //本地版本号
            NSInteger localVer = [CYM_Engine getVersionWithFileName:fileName];
            if (localVer == 0 && tag == UPDATE_UITHREAD) {
                localVer = 10000;
            }
            //网关版本号
            NSInteger serverVer = [[dic objectForKey:@"version"] integerValue];
            //假如网关的版本号不等于本地版本号
            if (serverVer != localVer || [fileName isEqualToString:@"securitynote"]) {
                self.needDownloadFileNumber++;
            }
        }
        for (NSDictionary *dic in aryConfig) {
            //1.当文件版本过旧
            NSString *fileName = [dic objectForKey:@"name"];
            //本地版本号
            NSInteger localVer = [CYM_Engine getVersionWithFileName:fileName];
            if (localVer == 0 && tag == UPDATE_UITHREAD) {
                localVer = 10000;
            }
            //网关版本号
            NSInteger serverVer = [[dic objectForKey:@"version"] integerValue];
            NSLog(@"%@ 本地版本号:%ld  网关版本号: %ld",fileName, (long)localVer, (long)serverVer);
            //假如网关的版本号不等于本地版本号
            if (serverVer != localVer || [fileName isEqualToString:@"securitynote"]) {
                
                //需要下载该文件
                NSNumber *timeUpload =  dicUploadFile[[NSString stringWithFormat:@"%@.json", fileName]];
                NSTimeInterval subTime = [[NSDate date] timeIntervalSince1970] - timeUpload.doubleValue;
                
                NSLog(@"当前时间%lf",[[NSDate date] timeIntervalSince1970]);
                NSLog(@"name: %@, 时间差: %lf", fileName,subTime);
                if (subTime < 3) {
                    NSLog(@"%@ 为自己上次的文件所以不更新", fileName);
                }
                else{
                    NSLog(@"%@ 需要更新.", fileName);
                    [aryNeedDownLoadFile addObject:[NSString stringWithFormat:@"%@.json", fileName]];
                    [self download:[NSString stringWithFormat:@"%@%@.json",strBaseURL, fileName] asName:[NSString stringWithFormat:@"%@.json",fileName]];
                    
                }
            }
            
            //2.当设备上无该文件
            //...
        }
    }
    //3.无文件需要更新
    if (aryNeedDownLoadFile.count == 0){
        NSLog(@"无文件需要更新");
        [self fileDownloadCompelete];
    }
}
//上传文件
- (void)uploadFileWithName:(NSString *)name andData:(NSData *)data{
    
    [dicUploadFile setObject:[NSNumber numberWithDouble:[[NSDate date] timeIntervalSince1970]] forKey:name];
    
    HE_FileOperation *fileOP = [[HE_FileOperation alloc] init];
    [fileOP createFileName:name WithData:data];
    NSString *strPath = [fileOP.dirDoc stringByAppendingPathComponent:name];
    
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/cgi-bin/cgipostfile.cgi", strGatewayIP]];
    AFHTTPClient *httpClient = [[AFHTTPClient alloc] initWithBaseURL:url];
    NSMutableURLRequest *request = [httpClient multipartFormRequestWithMethod:@"POST" path:nil parameters:nil constructingBodyWithBlock:^(id formData){
        [formData appendPartWithFileURL:[NSURL fileURLWithPath:strPath] name:@"file" error:nil];
    }];
    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
    [operation setUploadProgressBlock:^(NSUInteger bytesWritten, long long totalBytesWritten, long long totalBytesExpectedToWrite) {
        NSLog(@"Sent %lld of %lld bytes", totalBytesWritten, totalBytesExpectedToWrite);
    }];
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
        if ([delegate respondsToSelector:@selector(didUploadFile)]) {
            [delegate didUploadFile];
        }
        NSLog(@"Upload File %@ Success.", name);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if ([delegate respondsToSelector:@selector(didNotUploadFile:)]) {
            [delegate didNotUploadFile:error];
        }
        NSLog(@"Upload File %@ Failed. Err: %@", name, error);
    }];
    [httpClient.operationQueue addOperation:operation];
}

- (void)uploadFileWithName:(NSString *)name andData:(NSData *)data handler: (UploadHandler)handler {
    [dicUploadFile setObject:[NSNumber numberWithDouble:[[NSDate date] timeIntervalSince1970]] forKey:name];
    
    HE_FileOperation *fileOP = [[HE_FileOperation alloc] init];
    [fileOP createFileName:name WithData:data];
    NSString *strPath = [fileOP.dirDoc stringByAppendingPathComponent:name];
    
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/cgi-bin/cgipostfile.cgi", strGatewayIP]];
    AFHTTPClient *httpClient = [[AFHTTPClient alloc] initWithBaseURL:url];
    NSMutableURLRequest *request = [httpClient multipartFormRequestWithMethod:@"POST" path:nil parameters:nil constructingBodyWithBlock:^(id formData){
        [formData appendPartWithFileURL:[NSURL fileURLWithPath:strPath] name:@"file" error:nil];
    }];
    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
    [operation setUploadProgressBlock:^(NSUInteger bytesWritten, long long totalBytesWritten, long long totalBytesExpectedToWrite) {
        NSLog(@"Sent %lld of %lld bytes", totalBytesWritten, totalBytesExpectedToWrite);
    }];
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
        if (handler) {
            handler(name, nil);
        }
        NSLog(@"Upload File %@ Success.", name);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Upload File %@ Falied.", name);
        if (handler) {
            handler(name, error);
        }
    }];
    [httpClient.operationQueue addOperation:operation];
}

- (void)fileDownloadCompelete{
    if( [delegate respondsToSelector:@selector(didUpdateFile)] ){
        //解析所有更新的配置文件
        if (tag == UPDATE_UITHREAD) {
            NSArray *docs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
            for (NSString *name in aryNeedParseFileName) {
                NSString *path = [docs[0] stringByAppendingPathComponent:name];
                [CYM_Engine paserFileWithPath:path fileName:name];
            }
            [delegate didUpdateFile];
            [self updateOrDeleteDeviceToken];
            
            /// 改变OLDSN 记录, 已处理 网关切换配置文件不同步的情况
            NSString *nowSN = [[HE_APPManager sharedManager] User].strSN;
            [[NSUserDefaults standardUserDefaults] setObject:nowSN forKey:@"OLDSN"];
        }
        else{
            [self performSelectorInBackground:@selector(parseFileHandler) withObject:nil];
        }
    }
}

- (void)parseFileHandler{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(){
        NSArray *docs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        for (NSString *name in aryNeedParseFileName) {
            NSString *path = [docs[0] stringByAppendingPathComponent:name];
            [CYM_Engine paserFileWithPath:path fileName:name];
        }
        dispatch_semaphore_signal(semaphore);
        NSLog(@"本地semaphore+1");
        //////////通知
        dispatch_async(dispatch_get_main_queue(),^(){
            NSNotification *notfic = [NSNotification notificationWithName:@"DATABASE_UPDATE" object:nil];
            [[NSNotificationCenter defaultCenter] postNotification:notfic];

        });
    });
}

// 判断本地是否有iospush.json文件 & deviceToken 是否包含其中
- (void)updateOrDeleteDeviceToken {
    HE_FileOperation *fileOP = [[HE_FileOperation alloc] init];
    NSUserDefaults *usrDefault = [NSUserDefaults standardUserDefaults];
    NSString *fileName = @"iospush.json";
    NSString *strcontent = [fileOP readFileWithName:fileName];
    NSString *strDeviceT = [usrDefault objectForKey:kDeviceToken];
    
    // 未成功注册到DeviceToken
    if (!strDeviceT.isNotEmptyAndNil) {
        return;
    }
    
    NSMutableArray *aryTokens = nil;
    // 有文件
    if (strcontent.isNotEmptyAndNil) {
        // 取出文件内容, 并且初始化到数组
        NSArray *docs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *path = [docs[0] stringByAppendingPathComponent:fileName];
        NSData * data = [[NSData alloc] initWithContentsOfFile:path];
        aryTokens = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        // 解析成功
        if (aryTokens != nil){
            aryTokens = [NSMutableArray arrayWithArray:aryTokens];
            
            // 判断iospush.json文件 是否已经包含本机DeviceToken
            if ([strcontent myContainsString:strDeviceT]) { /* 包含则: 是否为开启通知, 没有开启着需要删除改DeviceToken */
                NSNumber *isEnable = [usrDefault objectForKey:kIsOpenNotfic];
                if (isEnable.boolValue) {
                    NSLog(@"iospush.json已经包含, 本机Token, 无需上传!");
                    return;
                } else {
                    /* 删除该项 */
                    for (NSDictionary * dict in aryTokens){
                        if ([dict[@"token"] isEqualToString:strDeviceT]) {
                            [aryTokens removeObject:dict];
                            NSLog(@"APP推送功能已关闭, 删除DeviceT: %@", strDeviceT);
                            break;
                        }
                    }
                }
            }
            else {/* 不包含token 加入到ary */
                // 计算index
                NSUInteger index = 0;
                for (NSDictionary * dict in aryTokens){
                    if (index < ((NSString *)dict[@"id"]).integerValue) {
                        index = ((NSString *)dict[@"id"]).integerValue;
                    }
                }
                [aryTokens addObject:@{@"id": [NSString stringWithFormat:@"%lu", (unsigned long)++index], @"token": strDeviceT}];
            }
        }
        else { /* 解析失败 */
            NSLog(@"解析iospush.json失败");
        }
    }
    else { /* 无文件 */
        aryTokens = [NSMutableArray array];
        NSMutableDictionary *dicDeviceT = [NSMutableDictionary dictionary];
        [dicDeviceT setObject:@"0" forKey:@"id"];
        dicDeviceT[@"token"] = strDeviceT;
        
        [aryTokens addObject:dicDeviceT];
    }
    
    // 生成文件 并上传
    [fileOP saveJSONFileName:fileName WithAry:aryTokens];
    strcontent = [fileOP readFileWithName:fileName];
    [self uploadFileWithName:fileName
                     andData:[strcontent dataUsingEncoding:NSUTF8StringEncoding]
                     handler:^(NSString *fileName, NSError *error) {
                         NSLog(@"文件上传完成: %@: %@", fileName, error);
                     }];
}


@end
