//
//  HE_MsgParse.h
//  BWRemoter
//
//  Created by JianBo He on 14/12/22.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HE_JiuZhouMsgDefine.h"

///解析命令 @#$%10030012010002
@interface HE_MsgParser : NSObject
{
    HE_JiuZhouMsgDefine *msgDefiner;
}

///获取类型位数据
- (NSString *)getTypeWithMsg:(NSString *)strMsg;
///获取动作位数据
- (NSString *)getActionWithMsg:(NSString *)strMsg;
///获取长度位数据
- (NSString *)getLengthWithMsg:(NSString *)strMsg;
///获取命令位数据
- (NSString *)getCMDWithMsg:(NSString *)strMsg;
///获取命令位的action位数据
- (NSString *)getCMDActionWithMsg:(NSString *)strMsg;
///获取命令位反馈位的数据
- (NSString *)getCMDFeedbackMsg:(NSString *)strMsg;

///解析验证命令
- (NSString *)parseAuthencateMsg:(NSString *)strMsg;
///解析用户权限
- (NSString *)parsePermissionMsg:(NSString *)strMsg;
///解析网关时间
- (NSString *)parseGatewayTimeMsg:(NSString *)strMsg;

///获取A4协议设备ID
- (NSString *)getCMDIDWithMsg:(NSString *)strMsg;
- (NSString *)getCMDCategoryWithMsg:(NSString *)strMsg;



///解析多命令返回
- (NSArray *)parseMutableCMDWithMsg:(NSString *)strMsg;

- (BOOL)isAJiuZhouMsg:(NSString *)strMsg;
@end
