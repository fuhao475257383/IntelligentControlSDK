//
//  HE_JiuZhouMsgDefine.m
//  BWRemoter
//
//  Created by JianBo He on 15/1/1.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "HE_JiuZhouMsgDefine.h"

@implementation HE_JiuZhouMsgDefine

- (id)init{
    self = [super init];
    if (self) {
        PROTOCOL_HEADER = @"@#$%";
        PROTOCOL_TYPE_CODE =    @[@"00", @"01", @"02", @"03",
                                  @"10", @"20", @"30", @"40",
                                  @"50", @"60", @"70", @"80"];
        
        PROTOCOL_ACTION_CODE =  @[@"00", @"01", @"02", @"03"];
        PROTOCOL_COMMOND_CODE = @[@"00", @"01", @"02", @"03",
                                  @"04", @"05", @"06", @"07",
                                  @"08",@"FF"];
    }
    return self;
}

#pragma mark -
#pragma mark Public Method 获取基本的控制信息
- (NSString *)PROTOCOL_HEADER{
    return PROTOCOL_HEADER;
}
- (NSString *)msgTpyeWithCode:(TypeCode)code{
    ////com = 3232235671 为 IP组网
    if (code >= TYPE_COM0 && code <= TYPE_CROONTAB) {
        return PROTOCOL_TYPE_CODE[code];
    }
    else if (code > TYPE_CROONTAB){
        return PROTOCOL_TYPE_CODE[9];
    }
    return @"-1";
}

- (NSString *)msgActionWithCode:(ActionCode)code{
    if (code >= ACTION_HEARTBEAT && code <= ACTION_AUTHENTICATION) {
        return PROTOCOL_ACTION_CODE[code];
    }
    return @"-1";
}

- (NSString *)msgCommodWithCode:(ComdCode)code{
    if (code >= CMD_UPDATE_CONFIG && code <= CMD_GATEWAY_HEARTBEAT) {
        return PROTOCOL_COMMOND_CODE[code];
    }
    return @"-1";
}

///根据msgtype值 获取关键字
- (TypeCode)typeCodeWithMsgType:(NSString *)str{
    NSString *tmp = [NSString stringWithFormat:@"%02d",[str intValue]];
    for (int i=0; i<PROTOCOL_TYPE_CODE.count; i++) {
        if ([PROTOCOL_TYPE_CODE[i] isEqualToString:tmp]) {
            return i;
        }
    }
    return -1;
}

///根据msgtype值 获取关键字
- (ActionCode)actionCodeWithMsgAction:(NSString *)str{
    for (int i=0; i<PROTOCOL_ACTION_CODE.count; i++) {
        if ([PROTOCOL_ACTION_CODE[i] isEqualToString:str]) {
            return i;
        }
    }
    return -1;
}

///根据msgtype值 获取关键字
- (ComdCode)comdCodeWithMsgCMD:(NSString *)str{
    for (int i=0; i<PROTOCOL_COMMOND_CODE.count; i++) {
        if ([PROTOCOL_COMMOND_CODE[i] isEqualToString:str]) {
            return i;
        }
    }
    return -1;
}
@end