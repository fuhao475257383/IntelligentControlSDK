
//
//  HE_MsgKit.h
//  BWRemoter
//
//  Created by JianBo He on 15/1/5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//
///
//    NSString *msg = @"@#$%0001002CA55A10040400730019BFE300000064A9";
//    HE_CMDParser *cmdP = [[HE_CMDParser alloc] init];
//    HE_MsgParser *msgP = [[HE_MsgParser alloc] init];
//
//    NSLog(@"Type: %@", [msgP getTypeWithMsg:msg]);
//    NSLog(@"Action: %@", [msgP getActionWithMsg:msg]);
//    NSLog(@"Length: %@", [msgP getLengthWithMsg:msg]);
//    NSLog(@"CMD: %@", [msgP getCMDWithMsg:msg]);
//
//    NSString *cmd = [msgP getCMDWithMsg:msg];
//    NSLog(@"Length: %@", [cmdP getLengthWithCMD:cmd]);
//    NSLog(@"Action: %@", [cmdP getActionWithCMD:cmd]);
//    NSLog(@"DevType: %@", [cmdP getDeviceTypeWithCMD:cmd]);
//    NSLog(@"Data: %@", [cmdP getDataWithCMD:cmd]);
//    NSLog(@"NData: %@", [cmdP getDataWithoutNum:cmd]);
//    NSLog(@"DevNum: %@", [cmdP getDeviceNumWithCMD:cmd]);
///

#ifndef BWRemoter_HE_MsgKit_h
#define BWRemoter_HE_MsgKit_h

#import "HE_CMDQueue.h"
#import "HE_BaiWeiMsgDefine_A4.h"
#import "HE_CMDBuilder.h"
#import "HE_CMDParser.h"

#import "HE_JiuZhouMsgDefine.h"
#import "HE_MsgBuilder.h"
#import "HE_MsgParser.h"



#endif


