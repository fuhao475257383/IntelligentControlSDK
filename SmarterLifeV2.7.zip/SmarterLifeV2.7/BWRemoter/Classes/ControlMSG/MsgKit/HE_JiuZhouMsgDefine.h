//
//  HE_JiuZhouMsgDefine.h
//  BWRemoter
//
//  Created by JianBo He on 15/1/1.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>



///类型位 控制代码
typedef enum {
    ///端口号
    TYPE_COM0 = 0, TYPE_COM1, TYPE_COM2, TYPE_COM4,
    ///网关
    TYPE_GATEWAY,
    ///摄像机
    TYPE_IPCAMERA,
    TYPE_UART,
    TYPE_DALI,
    TYPE_GROUP,
    TYPE_IPNET,
    TYPE_SECURITY,
    TYPE_CROONTAB
}TypeCode;

///动作位 控制代码
typedef enum {
    ///心跳
    ACTION_HEARTBEAT = 0,
    ///透传
    ACTION_TRANSMIT,
    ///解析
    ACTION_RESOLVING,
    ///认证
    ACTION_AUTHENTICATION,
}ActionCode;

///命令位 控制代码
typedef enum {
    ///更新文件通知
    CMD_UPDATE_CONFIG = 0,
    ///查询网关状态
    CMD_SELECT_GATEWAY,
    ///下载版本配置文件
    CMD_DL_VERSION,
    ///下载控制配置文件
    CMD_DL_CONTROL,
    ///下载监控配置文件
    CMD_DL_VIDEO,
    ///下载房间配置文件
    CMD_DL_HOUSE,
    ///下载场景配置文件
    CMD_DL_SENCE,
    ///下载安防配置文件
    CMD_DL_SAFE,
    ///下载定时配置文件
    CMD_DL_TIMER,
    ///网关心跳
    CMD_GATEWAY_HEARTBEAT
}ComdCode;
@interface HE_JiuZhouMsgDefine : NSObject
{
    NSString *PROTOCOL_HEADER;
    NSArray *PROTOCOL_TYPE_CODE;
    NSArray *PROTOCOL_ACTION_CODE;
    NSArray *PROTOCOL_COMMOND_CODE;
}
- (NSString *)PROTOCOL_HEADER;
/**
 *  获取控制消息的“类型位”的编码
 *  @par code   TypeCode类型
 *  @return     返回NSString具体编码 占2位、16进制
 */
- (NSString *)msgTpyeWithCode:(TypeCode)code;

/**
 *  获取控制消息的“动作位”的编码
 *  @par code   ActionCode类型
 *  @return     返回NSString具体编码 占2位、16进制
 */
- (NSString *)msgActionWithCode:(ActionCode)code;

/**
 *  获取控制消息的“命令位”的某几个基础编码
 *  @par code   ComdCode类型
 *  @return     返回NSString具体编码 占2位、16进制(其余命令不一定占俩位)
 */
- (NSString *)msgCommodWithCode:(ComdCode)code;


///根据msgtype值 获取关键字
- (TypeCode)typeCodeWithMsgType:(NSString *)str;

///根据msgtype值 获取关键字
- (ActionCode)actionCodeWithMsgAction:(NSString *)str;

///根据msgtype值 获取关键字
- (ComdCode)comdCodeWithMsgCMD:(NSString *)str;
@end

