//
//  HE_BaiWeiMsgDefine_A4.m
//  BWRemoter
//
//  Created by JianBo He on 15/1/5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//
//
//***********************        ZigBee A4 协议        ***********************///
//
//      命令格式: 同步头   帧长度    命令    设备类型    数据    校验和
//
//   长度(Bytes):  2       1        1      1         0~N       1
//
//
//   如： 控制所有灯开 A55A 0A 05 01 FFFFFF 01 0E
//
//***********************                             ***********************///
#import "HE_BaiWeiMsgDefine_A4.h"

@implementation HE_BaiWeiMsgDefine_A4

- (id)init{
    self = [super init];
    if (self) {
        A4_Header = @"A55A";
        aryActionCode = @[@"01", @"02", @"03", @"04",
                          @"05", @"06", @"07", @"08",
                          @"09", @"0a", @"7e", @"7f",
                          @"fa", @"fb", @"fc", @"fd",
                          @"fe", @"ff"];
        aryDeviceCode = @[@"01", @"02", @"03", @"04", @"05",
                          @"06", @"08", @"09", @"0A", @"0B",@"0C"];
    }
    return self;
}

#pragma mark - 
#pragma mark Public

- (NSString *)A4Header{
    return A4_Header;
}

- (NSString *)actioncCodeWithCode:(A4_ActionCode) code{
    if (code == A4_ACTION_DEVICE_INSTRUCTIO) {
        return @"0F";
    }
    if (code == a4_ACTION_CONFIG) {
        return @"7D";
    }
    if (code == A4_ACTION_CONFIG_CONFIG) {
        return @"7E";
    }
    return aryActionCode[code];
}

- (NSString *)deviceTypeCodeWithCode:(A4_DeviceTypeCode) code{
    if (code >=0 && code <=aryDeviceCode.count) {
        return aryDeviceCode[code];
    }
    return aryDeviceCode[0];
}

///获取 ActionCode关键字
- (A4_ActionCode)codeWithActionCode:(NSString *) str{
    for (int i=0; i<aryActionCode.count; i++) {
        if ([[aryActionCode[i] uppercaseString] isEqualToString:[str uppercaseString]]) {
            return i;
        }
    }
    return -1;
}

///获取 DeviceTypeCode关键字
- (A4_DeviceTypeCode)codeWithDeviceType:(NSString *)str{
    for (int i=0; i<aryDeviceCode.count; i++) {
        if ([aryDeviceCode[i] isEqualToString:str]) {
            return i;
        }
    }
    return -1;
}

@end
