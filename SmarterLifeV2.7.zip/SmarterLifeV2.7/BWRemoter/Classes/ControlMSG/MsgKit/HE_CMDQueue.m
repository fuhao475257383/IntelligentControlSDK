//
//  HE_CMDQueue.m
//  BWRemoter
//
//  Created by JianBo He on 15/2/9.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "HE_CMDQueue.h"
#import "HE_BaiWeiMsgDefine_A4.h"
#import "HE_CustemExtend.h"
#import "HE_CMDParser.h"

@interface HE_CMDQueue(){
    NSMutableString *cmdQueue;
}
@end

@implementation HE_CMDQueue
+ (id)sharedQueue{
    static HE_CMDQueue *queue = nil;
    if (!queue) {
        queue = [[super allocWithZone:nil] init];
    }
    return queue;
}
+ (id)allocWithZone:(struct _NSZone *)zone{
    return [self sharedQueue];
}
- (id) init{
    self = [super init];
    if (self) {
        cmdQueue = [[NSMutableString alloc] init];
    }
    return self;
}


- (NSArray *)getCompeleteCMDWith:(NSString *)aCmd{
    NSMutableArray *aryResult = [NSMutableArray array];
    HE_BaiWeiMsgDefine_A4 *A4 = [[HE_BaiWeiMsgDefine_A4 alloc] init];
    HE_CMDParser *cmdP = [[HE_CMDParser alloc] init];
    ////如果队列中有A55A 则可以Append任意cmd,
    if ([cmdQueue myContainsString: [A4 A4Header]]  ||  [aCmd myContainsString:[A4 A4Header]]) {
        [cmdQueue appendString:aCmd];
        NSArray *aryCMD = [cmdQueue componentsSeparatedByString:[A4 A4Header]];
        for (NSString *s in aryCMD) {
            if (![s isEqualToString:@""]) {
                NSMutableString *aTMP = [[NSMutableString alloc] initWithFormat:@"%@%@",[A4 A4Header], s];
                NSInteger len = [[[cmdP getLengthWithCMD:aTMP] IntString] intValue] * 2;
                if (aTMP.length == len) {//完整的串
                    [cmdQueue deleteCharactersInRange:[cmdQueue indexofString:aTMP]];
                    [aryResult addObject:aTMP];
                }
                ///////处理奇葩情况->删除废弃的指令
                //A55A0080E1
                if (len == 0) {
                    [cmdQueue deleteCharactersInRange:[cmdQueue indexofString:aTMP]];
                }
            }
        }
    }
    return aryResult;
}

#pragma mark -
#pragma mark Private Method

@end
