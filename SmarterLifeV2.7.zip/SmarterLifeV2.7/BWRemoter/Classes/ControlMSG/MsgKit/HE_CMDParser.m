//
//  HE_CMDParser.m
//  BWRemoter
//
//  Created by JianBo He on 15/1/5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "HE_CMDParser.h"

@implementation HE_CMDParser

- (id)init{
    self = [super init];
    if (self) {
        A4 = [[HE_BaiWeiMsgDefine_A4 alloc] init];
    }
    return self;
}



///根据A4命令 获取 长度位数据
- (NSString *)getLengthWithCMD:(NSString *)cmd{
    NSRange range;
    range.location = 4;
    range.length = 2;
    return [cmd substringWithRange:range];
}

///根据A4命令 获取 命令位数据
- (NSString *)getActionWithCMD:(NSString *)cmd{
    NSRange range;
    range.location = 6;
    range.length = 2;
    return [cmd substringWithRange:range];
}

///根据A4命令 获取 设备类型数据
- (NSString *)getCategoryWithCMD:(NSString *)cmd{
    NSRange range;
    range.location = 8;
    range.length = 2;
    return [cmd substringWithRange:range];
}

///根据A4命令 获取 所有数据位数据
- (NSString *)getDataWithCMD:(NSString *)cmd{
    NSRange range;
    range.location = 10;
    range.length =  cmd.length - 12;
    return [cmd substringWithRange:range];
}

///根据A4命令 获取 除设备编号的 数据
- (NSString *)getDataWithoutNum:(NSString *)cmd{
    if (cmd.length < 16) {
        return nil;
    }
    NSRange range;
    range.location = 16;
    range.length =  cmd.length - 18;
    return [cmd substringWithRange:range];
}

///根据A4命令 获取 设备的编号
- (NSString *)getDeviceNumWithCMD:(NSString *)cmd{
    if (cmd.length < 16) {
        return nil;
    }
    NSRange range;
    range.location = 10;
    range.length =  6;
    return [cmd substringWithRange:range];
}

///根据A4 绑定报告 获取 设备的编号
- (NSString *)getDeviceNumWithBindCMD:(NSString *)cmd{
    if (cmd.length < 18) {
        return nil;
    }
    NSRange range;
    range.location = 12;
    range.length =  6;
    return [cmd substringWithRange:range];
}
//新的,去获得全部，因为上面的方法会差两位，不知道为什么要这么做，下面获得全部
- (NSString *)getDeviceNumberWithCMD:(NSString *)cmd {
    if (cmd.length < 18) {
        return @"该设备ID为空";
    }
    NSRange range;
    range.location = 12;
    range.length =  6;
    return [cmd substringWithRange:range];
}

///解析出反馈报告的状态位  -1为非反馈报告
- (NSString *)parseACKWithCMD:(NSString *)cmd{
    //A55A06FF0105
    if (cmd.length < 10)
        return @"-1";
    NSString *subStr = [cmd substringWithRange:NSMakeRange(6, 2)].uppercaseString;
    if ([subStr isEqualToString:@"FF" ]) {
        return [cmd substringWithRange:NSMakeRange(8, 2)];
    }
    return @"-1";
}
@end
