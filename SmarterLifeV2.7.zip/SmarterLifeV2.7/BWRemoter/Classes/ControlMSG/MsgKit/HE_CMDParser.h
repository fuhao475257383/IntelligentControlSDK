//
//  HE_CMDParser.h
//  BWRemoter
//
//  Created by JianBo He on 15/1/5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HE_BaiWeiMsgDefine_A4.h"
#import "NSString+HE.h"

@interface HE_CMDParser : NSObject
{
    HE_BaiWeiMsgDefine_A4 *A4;
}

///判断A4 的 校验和 是否正确
//- (BOOL)isRightChecksum;

///根据A4命令 获取 长度位数据
- (NSString *)getLengthWithCMD:(NSString *)cmd;

///根据A4命令 获取 命令位数据
- (NSString *)getActionWithCMD:(NSString *)cmd;

///根据A4命令 获取 设备类型数据
- (NSString *)getCategoryWithCMD:(NSString *)cmd;

///根据A4命令 获取 所有数据位数据
- (NSString *)getDataWithCMD:(NSString *)cmd;

///根据A4命令 获取 除设备编号的 数据
- (NSString *)getDataWithoutNum:(NSString *)cmd;

///根据A4命令 获取 设备的编号
- (NSString *)getDeviceNumWithCMD:(NSString *)cmd;
- (NSString *)getDeviceNumWithBindCMD:(NSString *)cmd;

//去掉头尾，获得设备编号
- (NSString *)getDeviceNumberWithCMD:(NSString *)cmd;

///解析出反馈报告的状态位  -1为非反馈报告
- (NSString *)parseACKWithCMD:(NSString *)cmd;
@end
