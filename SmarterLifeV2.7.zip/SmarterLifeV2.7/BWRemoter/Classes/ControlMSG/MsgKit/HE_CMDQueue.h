//
//  HE_CMDQueue.h
//  BWRemoter
//
//  Created by JianBo He on 15/2/9.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HE_CMDQueue : NSObject
{

}
+ (id)sharedQueue;
- (NSArray *)getCompeleteCMDWith:(NSString *)aCmd;
@end
