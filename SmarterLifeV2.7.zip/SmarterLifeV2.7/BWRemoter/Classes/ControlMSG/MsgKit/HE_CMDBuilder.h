//
//  HE_CMDBuilder.h
//  BWRemoter
//
//  Created by JianBo He on 15/1/5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HE_BaiWeiMsgDefine_A4.h"
#import "NSString+HE.h"

@interface HE_CMDBuilder : NSObject
{
    HE_BaiWeiMsgDefine_A4 *A4;
}

/*!
 @brief 拼装一个A4协议的 CMD消息
 @param actionCode
 @param typeCode
 @param data       具体的数据位
 @return         包含协议头、长度、检验和的 完整格式命令
 */
- (NSString *)getCMDWithAction:(A4_ActionCode) actionCode DeviceType:(A4_DeviceTypeCode) typeCode Data:(NSString *) data;

///
- (A4_DeviceTypeCode)getDeviceTypeCodeWithCNString:(NSString *)strCN;

///////空调控制器
//设置 工作模式
- (NSString *)airConditionMode:(NSString *)strVaule WithData:(NSString *)strData;
//设置 摆风
- (NSString *)airConditionWindMode:(NSString *)strVaule WithData:(NSString *)strData;
//设置 风速
- (NSString *)airConditionWindSpeed:(NSString *)strVaule WithData:(NSString *)strData;
//设置 温度
- (NSString *)airConditionTemperature:(NSString *)strVaule WithData:(NSString *)strData;
@end
