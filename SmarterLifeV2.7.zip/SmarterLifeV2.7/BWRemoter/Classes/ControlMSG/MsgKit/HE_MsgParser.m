//
//  HE_MsgParse.m
//  BWRemoter
//
//  Created by JianBo He on 14/12/22.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "HE_MsgParser.h"
#import "HE_CMDParser.h"

@implementation HE_MsgParser

- (id)init{
    self = [super init];
    if (self) {
        msgDefiner = [[HE_JiuZhouMsgDefine alloc] init];
        
    }
    return self;
}



#pragma mark - 
#pragma mark Public Method
///获取类型位数据
- (NSString *)getTypeWithMsg:(NSString *)strMsg{
    NSRange range;
    range.length = 2;
    range.location = 4;
    NSString *val = [strMsg substringWithRange:range];
    return val;
}
///获取动作位数据
- (NSString *)getActionWithMsg:(NSString *)strMsg{
    NSRange range;
    range.length = 2;
    range.location = 6;
    if (strMsg.length >= range.length + range.location) {
        NSString *val = [strMsg substringWithRange:range];
        return val;
    }
    return nil;
}
///获取长度位数据
- (NSString *)getLengthWithMsg:(NSString *)strMsg{
    NSRange range;
    range.length = 4;
    range.location = 8;
    NSString *val = [strMsg substringWithRange:range];
    return val;
}
///获取命令位数据
- (NSString *)getCMDWithMsg:(NSString *)strMsg{
    if (strMsg.length < 12) {
        return nil;
    }
    NSString *val = [strMsg substringFromIndex:12];
    if ([[self getTypeWithMsg:strMsg] isEqualToString:@"60"]) {
        val = [val substringFromIndex:8];
    }
    return val;
}
- (NSString *)getCMDActionWithMsg:(NSString *)strMsg {
    NSRange range;
    range.length = 2;
    range.location = 12;
    NSString *val = [strMsg substringWithRange:range];
    return val;
}
///获取命令位反馈位的数据
- (NSString *)getCMDFeedbackMsg:(NSString *)strMsg {
    NSRange range;
    range.length = 2;
    range.location = 14;
    NSString *val = [strMsg substringWithRange:range];
    return val;
}

- (NSString *)parseAuthencateMsg:(NSString *)strMsg{
    NSString *action =  [self getActionWithMsg:strMsg];
    NSString *cmd = [self getCMDWithMsg:strMsg];
    NSRange range;
    @try {
        if ([action isEqualToString:[msgDefiner msgActionWithCode:ACTION_AUTHENTICATION]]) {
            range.location = 2;
            range.length = 2;
            return [cmd substringWithRange:range];
        }
    }
    @catch (NSException *exception) {
        return @"ff";
    }
    return @"ff";
}
- (NSString *)parsePermissionMsg:(NSString *)strMsg{
    NSString *action =  [self getActionWithMsg:strMsg];
    NSString *cmd = [self getCMDWithMsg:strMsg];
    NSRange range;
    if ([action isEqualToString:[msgDefiner msgActionWithCode:ACTION_AUTHENTICATION]] && cmd.length >= 6) {
        range.location = 4;
        range.length = 2;
        return [cmd substringWithRange:range];
    }
    return @"00";
}
- (NSString *)parseGatewayTimeMsg:(NSString *)strMsg {
    NSRange range;
    range.length = 10;
    range.location = 15;
    NSString *val = [strMsg substringWithRange:range];
    return val;
}

- (NSString *)getCMDIDWithMsg:(NSString *)strMsg{
    HE_CMDParser *cmdP = [[HE_CMDParser alloc] init];
    NSString *strCMD = [self getCMDWithMsg:strMsg];
    return  [cmdP getDeviceNumWithCMD:strCMD];
}
- (NSString *)getCMDCategoryWithMsg:(NSString *)strMsg{
    HE_CMDParser *cmdP = [[HE_CMDParser alloc] init];
    NSString *strCMD = [self getCMDWithMsg:strMsg];
    return [cmdP getCategoryWithCMD:strCMD];
}

- (NSArray *)parseMutableCMDWithMsg:(NSString *)strMsg{
    if (strMsg.isNotEmptyAndNil) {
        NSMutableArray *ary = [[NSMutableArray alloc] init];
        strMsg = [strMsg substringFromIndex:[msgDefiner PROTOCOL_HEADER].length];
        NSArray *tmp = [strMsg componentsSeparatedByString:[msgDefiner PROTOCOL_HEADER]];
        for (NSString *s in tmp) {
            [ary addObject:[NSString stringWithFormat:@"%@%@",[msgDefiner PROTOCOL_HEADER], s]];
        }
        return ary;
    }
    return nil;
}

- (BOOL)isAJiuZhouMsg:(NSString *)strMsg;{
    TypeCode typeCode = [msgDefiner typeCodeWithMsgType:[self getTypeWithMsg:strMsg]];
    
    if (typeCode <= TYPE_COM4 || typeCode == TYPE_IPNET) {
        return NO;
    }
    return YES;
}
@end
