//
//  HE_CMDBuilder.m
//  BWRemoter
//
//  Created by JianBo He on 15/1/5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "HE_CMDBuilder.h"

@implementation HE_CMDBuilder


- (id)init{
    self = [super init];
    if (self) {
        A4 = [[HE_BaiWeiMsgDefine_A4 alloc] init];
    }
    return self;
}
- (NSString *)getCMDWithAction:(A4_ActionCode) actionCode DeviceType:(A4_DeviceTypeCode) typeCode Data:(NSString *) data{
    NSMutableString *reslt = [[NSMutableString alloc] init];
    //1. 头部
    [reslt appendString:A4.A4Header];
    //2. 长度(单位字节)
    [reslt appendFormat:@"%02X", (int)(6 + data.length /2)];
    //3.命令位
    [reslt appendString:[A4 actioncCodeWithCode:actionCode]];
    //4.设备类型位
    [reslt appendString:[A4 deviceTypeCodeWithCode:typeCode]];
    //5. 数据位
    [reslt appendString:data];
    //6.校验位
    //除开校验和之外的每个字节相加， 最后的和，取最后一个字节作为校验和
    NSString *tmp = [NSString stringFromHexString:reslt];
    uint sum = 0;
    for (int i=0; i<tmp.length; i++) {
        unsigned int c = [tmp characterAtIndex:i];
        sum += c;
    }
    
    [reslt appendString:[self checkSumForStirng:reslt]];
    return reslt.self;
}

- (A4_DeviceTypeCode )getDeviceTypeCodeWithCNString:(NSString *)strCN{
    A4_DeviceTypeCode code = A4_DEVICE_THREE;
    if ([strCN myContainsString:@"灯"]) {
        code = A4_DEVICE_LIGHT;
    }
    else if ([strCN myContainsString:@"窗帘"]) {
        code = A4_DEVICE_CURTAIN;
    }
    else if ([strCN myContainsString:@"空调控制器"]) {
        code = A4_DEVICE_AIR_CONDITION;
    }
    else if ([strCN myContainsString:@"智能插座"]) {
        code = A4_DEVICE_SOCKET;
    }
    else if ([strCN myContainsString:@"场景控制器"]) {
        code = A4_DEVICE_SENCE;
    }
    else if ([strCN myContainsString:@"多功能控制器"]) {
        code = A4_DEVICE_MUTIL;
    }
    else if ([strCN myContainsString:@"zigbee转TTL"]) {
        code = A4_DEVICE_IO;
    }
    else if ([strCN myContainsString:@"数据透传"] || [strCN myContainsString:@"背景音乐"]) {
        code = A4_DEVICE_UART;
    }
    else if ([strCN myContainsString:@"传感器"]) {
        code = A4_DEVICE_SENSAR;
    }
    else if ([strCN myContainsString:@"报警"]) {
        code = A4_DEVICE_ALARM;
    }
    else if ([strCN myContainsString:@"智能门锁"]) {
        code = A4_DEVICE_DOORLOCK;
    }
    return  code;
}
#pragma mark - 空调控制器
//设置 工作模式
- (NSString *)airConditionMode:(NSString *)strVaule WithData:(NSString *)strData{
    NSMutableString *str = [[NSMutableString alloc] init];
    [str appendString:[strData substringWithRange:NSMakeRange(0, 6)]];
    [str appendString:strVaule];
    [str appendString:[strData substringFromIndex:8]];
    return str;
}
//设置 摆风
- (NSString *)airConditionWindMode:(NSString *)strVaule WithData:(NSString *)strData{
    NSMutableString *str = [[NSMutableString alloc] init];
    [str appendString:[strData substringWithRange:NSMakeRange(0, 8)]];
    [str appendString:strVaule];
    [str appendString:[strData substringFromIndex:10]];
    return str;
}
//设置 风速
- (NSString *)airConditionWindSpeed:(NSString *)strVaule WithData:(NSString *)strData{
    NSMutableString *str = [[NSMutableString alloc] init];
    [str appendString:[strData substringWithRange:NSMakeRange(0, 10)]];
    [str appendString:strVaule];
    [str appendString:[strData substringFromIndex:12]];
    return str;
}
//设置 温度
- (NSString *)airConditionTemperature:(NSString *)strVaule WithData:(NSString *)strData{
    NSMutableString *str = [[NSMutableString alloc] init];
    [str appendString:[strData substringWithRange:NSMakeRange(0, 12)]];
    [str appendString:strVaule];
//    [str appendString:[strData substringWithRange:NSMakeRange(14, 2)]];
    return str;
}
#pragma mark -
#pragma mark Private Method
- (NSString *)checkSumForStirng:(NSString *)str{
    int len = (int)[str length] / 2 + 1;
    unsigned char *myBuffer = (unsigned char *)malloc(len);
    bzero(myBuffer, [str length] / 2 + 1);
    for (int i = 0; i < [str length] - 1; i += 2) {
        unsigned int anInt;
        NSString * hexCharStr = [str substringWithRange:NSMakeRange(i, 2)];
        NSScanner * scanner = [[NSScanner alloc] initWithString:hexCharStr];
        [scanner scanHexInt:&anInt];
        myBuffer[i / 2] = (unsigned char)anInt;
    }
    myBuffer[len - 1] = 0;
    unsigned int sum = 0;
    for (int i=0; i<len; i++){
        sum += myBuffer[i];
    }
    NSString *ans = [NSString stringWithFormat:@"%X", sum];
    ans = [ans substringWithRange:NSMakeRange(ans.length-2, 2)];
    return ans;
}

- (BOOL)matchStringFormat:(NSString *)matchedStr withRegex:(NSString *)regex
{
    NSRange range=[matchedStr rangeOfString:regex];
    if(range.location!=NSNotFound)
    {
        return true;
    }
    else
    {
        return false;
    }
}
@end
