//
//  HE_BaiWeiMsgDefine_A4.h
//  BWRemoter
//
//  Created by JianBo He on 15/1/5.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>


///命令位 如控制、反馈、查询等等
typedef enum{
    ///请求设备绑定
    A4_ACTION_BIND = 0,
    ///设备绑定报告
    A4_ACTION_BIND_RE,
    ///查询设备状态
    A4_ACTION_QUERY,
    ///设备状态报告
    A4_ACTION_QUERY_RE,
    ///控制设备状态
    A4_ACTION_CONTROL,
    ///结束绑定
    A4_ACTION_END_BIND,
    ///信号学习
    A4_ACTION_SIGNAL_STUDY,
    //设备指示
    A4_ACTION_DEVICE_INSTRUCTIO,
    //自组网新增,查看配置
    a4_ACTION_CONFIG,
    //新增，配置配置
    A4_ACTION_CONFIG_CONFIG,
    ///......
    A4_ACTION_ACK = 17
}A4_ActionCode;

///类型位 如灯、窗帘、等等
typedef enum {
    A4_DEVICE_THREE = -1,
    ///灯
    A4_DEVICE_LIGHT = 0,
    ///窗帘
    A4_DEVICE_CURTAIN,
    ///空调控制器
    A4_DEVICE_AIR_CONDITION,
    ///智能插座
    A4_DEVICE_SOCKET,
    ///场景控制器
    A4_DEVICE_SENCE,
    ///多功能控制器
    A4_DEVICE_MUTIL,
    ///Zigbee to TTL IO
    A4_DEVICE_IO,
    ///数据透传模块
    A4_DEVICE_UART,
    ///传感器
    A4_DEVICE_SENSAR,
    ///报警设备
    A4_DEVICE_ALARM,
    ///门锁
    A4_DEVICE_DOORLOCK,
    //未知设备
    A4_DEVICE_UNKNOW
    
}A4_DeviceTypeCode;

@interface HE_BaiWeiMsgDefine_A4 : NSObject
{
    NSString *A4_Header;
    NSArray *aryActionCode;
    NSArray *aryDeviceCode;
}

///获取A4 协议的同步头
- (NSString *)A4Header;

///获取A4协议中的 命令位代码
- (NSString *)actioncCodeWithCode:(A4_ActionCode) code;

///获取A4协议中的 设备类型位的代码
- (NSString *)deviceTypeCodeWithCode:(A4_DeviceTypeCode) code;



///获取 ActionCode关键字
- (A4_ActionCode)codeWithActionCode:(NSString *) str;

///获取 DeviceTypeCode关键字
- (A4_DeviceTypeCode)codeWithDeviceType:(NSString *)str;
@end
