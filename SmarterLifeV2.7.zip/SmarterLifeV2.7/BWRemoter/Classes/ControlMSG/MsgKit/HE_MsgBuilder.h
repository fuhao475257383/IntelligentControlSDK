//
//  HE_MsgDefine.h
//  BWRemoter
//
//  Created by JianBo He on 14/12/13.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HE_JiuZhouMsgDefine.h"
#import "NSString+HE.h"
#include <openssl/rc4.h>

@interface HE_MsgBuilder : NSObject
{
    HE_JiuZhouMsgDefine *msgDefiner;
}

///通过每位数据 构造整个协议数据 大写字符
- (NSString *)getMessageWithType:(NSInteger)type action:(ActionCode)action commond:(NSString *)strCMD;

///拼装验证命令
- (NSString *)msgAuthencateName:(NSString *)strName withPWD: (NSString *)strPWD;

///添加用户
- (NSString *)msgAddUserWithName:(NSString *)name PWD:(NSString *)pwd;

///删除用户
- (NSString *)msgDeleteUserWithName:(NSString *)name;

///重置用户密码
//- (NSString *)msgReSetPWDWithName:(NSString *)name;

///修改用户密码
- (NSString *)msgSetNewPWDWithName:(NSString *)name oldPWD:(NSString *)oldPWD newPWD:(NSString *) newPWD;

///列出所有用户
- (NSString *)msgGetAllUser;

//更新网关时间的命令
- (NSString *)updateGatewayTimeWithGT:(NSString *)appTime;

///RC4加密
- (NSString *)getRC4EncryptWithPWD:(NSString *)pwd;
///RC4解密
- (NSString *)getRC4DecryptWithPWD:(NSString *)rc4PWD;
@end
