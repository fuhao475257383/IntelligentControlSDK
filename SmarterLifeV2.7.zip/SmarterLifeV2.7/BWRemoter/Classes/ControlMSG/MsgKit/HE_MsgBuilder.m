//
//  HE_MsgDefine.m
//  BWRemoter
//
//  Created by JianBo He on 14/12/13.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "HE_MsgBuilder.h"


@implementation HE_MsgBuilder


- (id)init{
    self = [super init];
    if (self) {
        msgDefiner = [[HE_JiuZhouMsgDefine alloc] init];
    }
    return self;
}

#pragma mark 一般方法
- (NSString *)getMessageWithType:(NSInteger)type action:(ActionCode)action commond:(NSString *)strCMD{
    NSMutableString *msg = [[NSMutableString alloc] init];
    
    NSString *strHeader = msgDefiner.PROTOCOL_HEADER;               //控制消息的 协议头
    NSString *strType   = [msgDefiner msgTpyeWithCode:type];        //控制消息的 类型
    NSString *strAction = [msgDefiner msgActionWithCode:action];    //控制消息的 动作
    NSString *strIP     = nil;
    
    [msg appendString:strHeader];
    [msg appendString:strType];
    [msg appendString:strAction];
    

    
    NSInteger msgLength = strHeader.length + strType.length + strAction.length + 4 + strCMD.length;
    
    /////IP组网
    if ([strType isEqualToString:@"60"]) {
        strIP = [NSString stringWithFormat:@"%lX",(long)type];
//        strIP = @"C0A80097";
        msgLength += strIP.length;
    }
    
    NSString *hexLength = [NSString stringWithFormat:@"%04lX", (long)msgLength];
    [msg appendString:hexLength];                       //控制消息的 整体长度
    if (strIP) {
        [msg appendString:strIP];
    }
    [msg appendString:strCMD];                          //控制消息的 具体命令
    return msg.uppercaseString;
}
- (NSString *)msgAuthencateName:(NSString *)strName withPWD: (NSString *)strPWD{
    NSString *msgAuthencate;
    NSString *rc4PWD = [self getRC4EncryptWithPWD:strPWD];
    NSString *hexName = [NSString stringWithFormat:@"%@%@",[NSString hexStringFromString:@"username="], [NSString hexStringFromString:strName]];
    NSString *hexPWD = [NSString stringWithFormat:@"%@%@", [NSString hexStringFromString:@"&password="], rc4PWD.uppercaseString];
    
    NSString *strCMD = [NSString stringWithFormat:@"%@%@%@",@"01",hexName, hexPWD];
    
    msgAuthencate =  [self getMessageWithType:TYPE_GATEWAY action:ACTION_AUTHENTICATION commond:strCMD];
    return msgAuthencate;
}


///添加用户
- (NSString *)msgAddUserWithName:(NSString *)name PWD:(NSString *)pwd{
    NSString *result;
    
    NSString *hexName = [NSString hexStringFromString:[NSString stringWithFormat:@"username=%@", name]];
    NSString *hexPWD =  [NSString stringWithFormat:@"%@%@", [NSString hexStringFromString:@"&password="],
                                                            [self getRC4EncryptWithPWD:pwd]];
    
    result = [self getMessageWithType:TYPE_GATEWAY
                               action:ACTION_AUTHENTICATION
                              commond:[NSString stringWithFormat:@"02%@%@", hexName, hexPWD]];
    return result;
}

///删除用户
- (NSString *)msgDeleteUserWithName:(NSString *)name{
    NSString *hexName = [NSString hexStringFromString:name];
    return [self getMessageWithType:TYPE_GATEWAY action:ACTION_AUTHENTICATION commond:[NSString stringWithFormat:@"03%@",hexName]];
}

///重置用户密码
//- (NSString *)msgReSetPWDWithName:(NSString *)name{
//    NSString *hexName = [NSString hexStringFromString:name];
//    return [self getMessageWithType:TYPE_GATEWAY action:ACTION_AUTHENTICATION commond:[NSString stringWithFormat:@"04%@",hexName]];
//}

///修改用户密码
- (NSString *)msgSetNewPWDWithName:(NSString *)name oldPWD:(NSString *)oldPWD newPWD:(NSString *) newPWD{
    NSString *result;
    NSString *hexName = [NSString hexStringFromString:[NSString stringWithFormat:@"username=%@", name]];
    NSString *hexOld  = [NSString stringWithFormat:@"%@%@",[NSString hexStringFromString:@"&password="],
                                                           [self getRC4EncryptWithPWD:oldPWD]];
    NSString *hexNew  = [NSString stringWithFormat:@"%@%@",[NSString hexStringFromString:@"&newpassword="],
                         [self getRC4EncryptWithPWD:newPWD]];
    
    result =  [self getMessageWithType:TYPE_GATEWAY
                                action:ACTION_AUTHENTICATION
                               commond:[NSString stringWithFormat:@"05%@%@%@", hexName, hexOld, hexNew]];
    return result;
}

///列出所有用户
- (NSString *)msgGetAllUser{
//    NSString *result =[NSString stringWithFormat:@"@#$%%1003001006%@",[NSString hexStringFromString:@"admin"]];
    NSString *hexName = [NSString hexStringFromString:@"admin"];
    return [self getMessageWithType:TYPE_GATEWAY action:ACTION_AUTHENTICATION commond:[NSString stringWithFormat:@"06%@",hexName]];
}

//更新网关时间
- (NSString *)updateGatewayTimeWithGT:(NSString *)appTime {
//    NSString *msg = [NSString stringWithFormat:@"%@1003002208%@",@"@#$%",appTime];
//    NSString *msg = [NSString stringWithFormat:@"%@1003001A08%@",@"@#$%",appTime];
    NSString *msg = [self getMessageWithType:TYPE_GATEWAY action:ACTION_AUTHENTICATION commond:[NSString stringWithFormat:@"08%@",appTime]];
    return msg;
}

///密码装换为RC4加密
- (NSString *)getRC4EncryptWithPWD:(NSString *)pwd{
    
    ///////////////获取时间的后6位
    NSString *strSecd = [NSString stringWithFormat:@"%lf",[[[NSDate alloc] init] timeIntervalSince1970]];
    NSRange secdRange;
    secdRange.location = strSecd.length - 6;
    secdRange.length = 6;
    NSString *passWord = [NSString stringWithFormat:@"%@%@",pwd, [strSecd substringWithRange:secdRange]];
    
    
    //////////////加密
    NSMutableString *rc4PWD = [[NSMutableString alloc] init];
    char * keystr = "BWDPH123!!";
    RC4_KEY keyEncrpty;
    RC4_set_key(&keyEncrpty, (int)strlen(keystr), (const unsigned char *)keystr);
    unsigned char * src = (unsigned char *)[passWord UTF8String];
    unsigned char dst[255] = {0};
    
    RC4(&keyEncrpty, passWord.length, src, dst);
    
    //////////////转换为hex码
    for (int i=0; i<passWord.length; i++) {
        [rc4PWD appendFormat:@"%02x",dst[i]];
    }
    return rc4PWD;
}

//////////////////RC4 解密
- (NSString *)getRC4DecryptWithPWD:(NSString *)rc4PWD{
    //////////////////设置密钥
    char * keystr = "BWDPH123!!";
    RC4_KEY keyDecrpty;
    RC4_set_key(&keyDecrpty, (int)strlen(keystr), (const unsigned char *)keystr);
    unsigned char src[255] = {0};
    unsigned char ans[255] = {0};
    int i=0;
    //////////////////RC4 hex码转换为正常字符
    for (i=0; i<rc4PWD.length/2; i++) {
        NSString *strTMP = [rc4PWD substringWithRange:NSMakeRange(i*2, 2)];
        src[i] = [strTMP IntString].intValue;
    }
    /////////////////解密
    RC4(&keyDecrpty, i, src, ans);
    NSMutableString *strAns = [NSMutableString string];
    for (int i=0; i<255; i++) {
        [strAns appendFormat:@"%c",ans[i]];
    }
    ////////////////截掉后6位无效的时间码
    if (strAns.length >= 6) {
        return [strAns substringToIndex:strAns.length - 6];
    }
    return @"";
}
@end
