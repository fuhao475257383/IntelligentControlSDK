//
//  HE_socketMsgManager.h
//  BWRemoter
//
//  Created by JianBo He on 14/12/14.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FXW_User.h"
#import "HE_Protocol.h"
#import "GCDAsyncSocket.h"
#import "GCDAsyncUdpSocket.h"

typedef struct _HE_UDPPkg
{
    UInt16  header;
    UInt8   len;
    UInt8   command;
    UInt8   devicesn[8];
    UInt32  ipaddress;
    UInt32  subnetmask;
    UInt32  hostaddress;
    UInt32  tcpport;
    UInt8   reversed;
} HE_UDPPkg;

typedef enum {
    STATE_LOGIN_ING = -2,
    STATE_NOT_SUCCESS = -1,
    STATE_DISCOVER_ING = 0,
    STATE_DISCOVER_0K,
    STATE_CONNECT,
    STATE_AUTHENCATE,//已认证
    STATE_RUN
}HE_SOCKET_STATE;
///SOCKET 消息管理类[单实例模式]
@protocol HE_ManagerDelegate;
@interface HE_socketMsgManager : NSObject <GCDAsyncSocketDelegate, GCDAsyncUdpSocketDelegate>
{
    GCDAsyncSocket *tcpSockt;
    GCDAsyncUdpSocket *udpSockt;
    id<HE_ManagerDelegate>  managerDelegate;
    HE_SOCKET_STATE OP_TAG;
    NSTimer *outTimer;
    ///本地网关IP列表
    NSMutableArray *aryGateway;
    NSMutableArray *aryGatewaySN;
    NSString       *usedSN;
    
    ///命令的解析和构造类
    HE_MsgBuilder *msgBuilder;
    HE_MsgParser *msgParser;
    
    ///
    NSInteger       reSendCount;
}


+ (HE_socketMsgManager *)sharedManager;//单例
- (GCDAsyncSocket *)tcpSockt;
- (NSArray *)aryGateway;
- (NSArray *)aryGatewaySN;
- (void)setDelegate:(id)delegate;//设置消息管理者的委托
///发送组播到局域网  并返回得到的网关
- (void)discoverGateway;
///连接到对应的网关
- (void)ConnectHost:(NSString *) gateway;//通过IP连接网关
- (void)connectHostWithSN:(NSString *)strSN;//通过SN号连接网关
- (void)disconnect;
///发送消息
- (void)sendMsg:(NSString *) msg;
@end
