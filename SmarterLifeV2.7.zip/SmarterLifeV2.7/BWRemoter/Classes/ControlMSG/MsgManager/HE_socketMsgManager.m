//
//  HE_socketMsgManager.m
//  BWRemoter
//
//  Created by JianBo He on 14/12/14.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "HE_socketMsgManager.h"
#import "HE_APPManager.h"
@implementation HE_socketMsgManager

+ (HE_socketMsgManager *)sharedManager{
    static HE_socketMsgManager *Manager = nil;
    if (!Manager) {
        Manager = [[super allocWithZone:nil] init];
    }
    return Manager;
}
+ (id)allocWithZone:(struct _NSZone *)zone
{
    return [self sharedManager];
}

- (id)init{
    self = [super init];
    if (self) {
        tcpSockt = [[GCDAsyncSocket alloc] initWithDelegate:self delegateQueue:dispatch_get_main_queue()];
        udpSockt = [[GCDAsyncUdpSocket alloc] initWithDelegate:self delegateQueue:dispatch_get_main_queue()];
        msgBuilder = [[HE_MsgBuilder alloc] init];
        msgParser = [[HE_MsgParser alloc] init];
        aryGateway = [[NSMutableArray alloc] init];
        aryGatewaySN = [NSMutableArray array];
        OP_TAG = STATE_NOT_SUCCESS;
    }
    return self;
}
- (void)setDelegate:(id)delegate{
    managerDelegate = delegate;
}
- (NSArray *)aryGateway{
    return aryGateway;
}
- (NSArray *)aryGatewaySN{
    return aryGatewaySN;
}
- (GCDAsyncSocket *)tcpSockt{
    return tcpSockt;
}
- (void)discoverGateway{
    ///发送组播到局域网
    OP_TAG = STATE_DISCOVER_ING;
    [aryGatewaySN removeAllObjects];
    [aryGateway removeAllObjects];
    [self sendUDPSearchMsg];
    

    ////超时定时器
    outTimer = [NSTimer scheduledTimerWithTimeInterval:3.0f target:self selector:@selector(discoverTimeOut) userInfo:nil repeats:NO];
}

- (void)ConnectHost:(NSString *) gateway{
    OP_TAG    = STATE_CONNECT;
    
    NSArray *ary = [gateway componentsSeparatedByString:@":"];
    UInt16 port = [ary[1] integerValue];
    [[HE_APPManager sharedManager] setFileTransferIP:ary[0]];
    if (![tcpSockt connectToHost:ary[0] onPort: port error:nil]) {
        [tcpSockt disconnect];
        return;
    }
}

- (void)connectHostWithSN:(NSString *)strSN{
    OP_TAG = STATE_LOGIN_ING;
    usedSN = strSN;
    [self sendUDPSearchMsg];
    
    outTimer = [NSTimer scheduledTimerWithTimeInterval:3.0f target:self selector:@selector(notDiscoverSameSN) userInfo:nil repeats:NO];
}

- (void)disconnect{
    [tcpSockt disconnect];
    OP_TAG = STATE_NOT_SUCCESS;
}

- (void)sendMsg:(NSString *)msg{
    NSData *data = [msg dataUsingEncoding:NSUTF8StringEncoding];
    OP_TAG = STATE_RUN;
    [tcpSockt writeData:data withTimeout:3.0 tag:STATE_RUN];
    [tcpSockt readDataWithTimeout:-1 tag:STATE_RUN];
}
#pragma mark -
#pragma mark GCDAsyncSocketDelegate
//socket成功连接
- (void)socket:(GCDAsyncSocket *)sock didConnectToHost:(NSString *)host port:(uint16_t)port{
    NSLog(@"Connected:%@:%d", host, port);
    //1.验证网关用户
    NSString *msgAuthen = [msgBuilder msgAuthencateName:[[HE_APPManager sharedManager] User].strName  withPWD:[[HE_APPManager sharedManager] User].strPwd];
    NSLog(@"nsgAuthen:%@",msgAuthen);
    NSData *data = [msgAuthen dataUsingEncoding:NSUTF8StringEncoding];
    OP_TAG = STATE_AUTHENCATE;
    [tcpSockt writeData:data withTimeout:3.0 tag:STATE_AUTHENCATE];
    [tcpSockt readDataWithTimeout:-1 tag:STATE_AUTHENCATE];
    [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(gatewayAutencateNotCallback) userInfo:nil repeats:NO];
    reSendCount = 0;
    
    // 2. 提供后台运行
    [sock performBlock:^{
        [sock enableBackgroundingOnSocket];
    }];
}

- (void)gatewayAutencateNotCallback{
    ////////重发次数>=4时 重发验证消息
    if (reSendCount++ >= 4) {
        NSError *err = [[NSError alloc] initWithDomain:@"Socket"
                                                  code:503
                                              userInfo:nil];
        [tcpSockt disconnect];
        if ([managerDelegate respondsToSelector:@selector(didNotConnectToHost:)]) {
            [managerDelegate didNotConnectToHost:err];
        }
        return;
    }
    if (OP_TAG == STATE_AUTHENCATE) {
        NSLog(@"重发验证消息: %ld", (long)reSendCount);
        NSString *msgAuthen = [msgBuilder msgAuthencateName:[[HE_APPManager sharedManager] User].strName  withPWD:[[HE_APPManager sharedManager] User].strPwd];
        NSData *data = [msgAuthen dataUsingEncoding:NSUTF8StringEncoding];
        [tcpSockt writeData:data withTimeout:3.0 tag:STATE_AUTHENCATE];
        [tcpSockt readDataWithTimeout:-1 tag:STATE_AUTHENCATE];
        [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(gatewayAutencateNotCallback) userInfo:nil repeats:NO];
    }
}
//socket断开连接后调用
- (void)socketDidDisconnect:(GCDAsyncSocket *)sock withError:(NSError *)err{
    if (OP_TAG  < STATE_RUN) {
//        NSLog(@"Connected fail.");
//        if ([managerDelegate respondsToSelector:@selector(didNotConnectToHost:)]) {
//            [managerDelegate didNotConnectToHost:err];
//        }
    }
    //如果设备状态是正在连接，那么显示断开连接
    else{
        if ([managerDelegate respondsToSelector:@selector(didDisConnectToHost)]) {
            [managerDelegate didDisConnectToHost];
            NSLog(@"Err: %@", err);
        }
    }
}
//socket发送控制消息成功
- (void)socket:(GCDAsyncSocket *)sock didWriteDataWithTag:(long)tag{
    if ([managerDelegate respondsToSelector:@selector(didSendMsg)]) {
        [managerDelegate didSendMsg];
    }
}

- (void)socket:(GCDAsyncSocket *)sock didReadData:(NSData *)data withTag:(long)tag{
    reSendCount = 0;
    NSString *strData = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    NSLog(@"收到消息strData%@",strData);
    
    //验证时间
//    NSString *strDat = @"@#$%1003001A08#1417276858#";
//    NSString *strDat = @"@#$%100300100800";
    NSString *action = [msgParser getActionWithMsg:strData];
    NSString *CMDAction = [msgParser getCMDActionWithMsg:strData];
    if ([action isEqualToString:@"03"] && [CMDAction isEqualToString:@"08"]) {
        NSString *CMDFeedback = [msgParser getCMDFeedbackMsg:strData];
        if ([CMDFeedback isEqualToString:@"00"]) {
            NSLog(@"同步时间成功");
            [managerDelegate updateGatewayTimeSucceed];
        }
        else if ([CMDFeedback isEqualToString:@"01"]) {
            NSLog(@"同步时间失败");
            [managerDelegate updateGatewayTimeFail];
        }else {
            NSString *gatewayTime = [msgParser parseGatewayTimeMsg:strData];
            [managerDelegate needUpdateGatewayTimeWithGTime:gatewayTime];
        }
    }
    
    NSString *authen = [msgParser parseAuthencateMsg:strData];
    if (tag == STATE_AUTHENCATE) {
        NSString *permission = [msgParser parsePermissionMsg:strData];
        if ([authen isEqualToString:@"00"]) {
            [[HE_APPManager sharedManager] User].strPermission = permission;
            [[[HE_APPManager sharedManager] User] authencateCompelete];
            [managerDelegate didConnect];
            NSLog(@"Autencate Success");
        }
        else{
            NSString *errCode = [msgParser parsePermissionMsg:strData];
            NSLog(@"Autencate False :%@, ErrCode:%@", strData, errCode);
            NSError *err = [[NSError alloc] initWithDomain:@"Socket"
                                                      code:errCode.integerValue
                                                  userInfo:@{@"Data": strData}];
            [tcpSockt disconnect];
            if ([managerDelegate respondsToSelector:@selector(didNotConnectToHost:)]) {
                [managerDelegate didNotConnectToHost:err];
            }
        }
        OP_TAG = STATE_NOT_SUCCESS;
    }
    else if(tag == STATE_RUN){
        if ([managerDelegate respondsToSelector:@selector(didRecive:)]) {
            [managerDelegate didRecive:strData];
        }
        [tcpSockt readDataWithTimeout:-1 tag:STATE_RUN];
    }
}

#pragma mark -
#pragma mark GCDAsyncUdpSocketDelegate
- (void)udpSocket:(GCDAsyncUdpSocket *)sock didReceiveData:(NSData *)data
      fromAddress:(NSData *)address
withFilterContext:(id)filterContext{
    if([data length] > 14)
    {
        ////解析应答包
        HE_UDPPkg pkg;
        memcpy(&pkg, [data bytes], sizeof(HE_UDPPkg));
        
        UInt8 * udppkg = (UInt8 *)[data bytes];
        ///////////////SN号
        UInt8 serialNum[28] = {0};
        memcpy(&serialNum, udppkg+4 , 28);
        NSMutableString *strSerialNum = [NSMutableString string];
        for (int i=0; i<28; i++) {
            NSString *s = [NSString stringFromHexString:[NSString stringWithFormat:@"%02X",serialNum[i]]];
            [strSerialNum appendString:s];
        }
        ///////////////IP
        UInt32  ipAddress;
        memcpy(&ipAddress, udppkg+33, 4);
        ipAddress = CFSwapInt32(ipAddress);
        unsigned char octet[4]  = {0,0,0,0};
        for (int i=0; i<4; i++)
        {
            octet[i] = ( ipAddress >> (i*8) ) & 0xFF;
        }
        NSString * ipstr = [NSString stringWithFormat: @"%d.%d.%d.%d",octet[3],octet[2],octet[1],octet[0]];
        
        //////////////Port
        UInt32 port;
        memcpy(&port, udppkg+45, 4);
        port = CFSwapInt32(port);
        NSLog(@"GateWay:%@[%@:%d]",strSerialNum , ipstr, (unsigned int)port);
        NSString *strIPAndPort = [NSString stringWithFormat:@"%@:%u", ipstr,(unsigned int)port];
        
        //1.加入到已搜索到得数组
        if (![self hasContains:strSerialNum withAry:aryGatewaySN]) {
            [aryGateway addObject:strIPAndPort];
            [aryGatewaySN addObject:strSerialNum];
        }
        //2.
        //////////Login时搜索网关
        if (OP_TAG == STATE_LOGIN_ING) {
            /////已搜索到匹配的SN号. 否则继续搜索
            if ([self hasContains:usedSN withAry:aryGatewaySN]) {
                NSInteger index = 0;
                for (int i=0; i<aryGatewaySN.count; i++) {
                    if ([usedSN isEqualToString:aryGatewaySN[i]]) {
                        index = i;
                        break;
                    }
                }
                [self ConnectHost:aryGateway[index]];
            }else{
                [self sendUDPSearchMsg];
            }
        }
        /////////搜索网关
        else if(OP_TAG == STATE_DISCOVER_ING){
            if ([managerDelegate respondsToSelector:@selector(didDiscover)]) {
                [managerDelegate didDiscover];
            }
        }
    }
    else{
        //////////没有搜到 便继续发送搜索消息
        if (OP_TAG == STATE_DISCOVER_ING || OP_TAG == STATE_LOGIN_ING) {
            [self performSelector:@selector(sendUDPSearchMsg) withObject:nil afterDelay:0.5];
        }
    }
}

- (void)discoverTimeOut{
    if (aryGatewaySN == nil || aryGatewaySN.count ==0) {
        OP_TAG = STATE_NOT_SUCCESS;
        if ([managerDelegate respondsToSelector:@selector(discoverTimeOut)]) {
            [managerDelegate discoverTimeOut];
        };
    }
    else{
        OP_TAG = STATE_DISCOVER_0K;
        [[HE_APPManager sharedManager] hudHidden];
    }
}

- (void)notDiscoverSameSN{
    if (![self hasContains:usedSN withAry:aryGatewaySN]) {
        OP_TAG = STATE_NOT_SUCCESS;
        if ([managerDelegate respondsToSelector:@selector(notDiscoverSameSN)]) {
            [managerDelegate notDiscoverSameSN];
        };
    }
    else{
        //        [self ConnectHost:strIPAndPort];
    }
}


#pragma mark - Private
//发送组播到局域网
//查询网关指令9d9d05e000
//网关反馈信息9d9d+帧长度+命令+设备编号+IP地址+子网掩码+网关+TCP端口号+校验和
//示例9d9d 1e e1 1234567887654321 010a02075e ffffff00 0a020701 00001f90 00
- (void)sendUDPSearchMsg{
    unsigned char sendd[64] = {0x9d, 0x9d, 0x05, 0xe0, 0x00};
    //将C语言字符数组转换成NSData类型
    NSData * senddata = [NSData dataWithBytes: sendd length: 5];
    //端口号
    int port = 4321;
    [udpSockt bindToPort: port error: nil];
    //组播地址224.30.30.200
    [udpSockt joinMulticastGroup: @"224.30.30.200" error: nil];
    [udpSockt beginReceiving: nil];
    [udpSockt sendData: senddata toHost: @"224.30.30.200" port: 4321 withTimeout: 10.0 tag: STATE_DISCOVER_ING];
}

- (BOOL)hasContains:(NSString *)strSN withAry:(NSArray *)ary{
    for (NSString *s in ary) {
        if ([s isEqualToString:strSN]) {
            return YES;
        }
    }
    return NO;
}
@end
