//
//  HE_XmppMsgManager.m
//  BWRemoter
//
//  Created by JianBo He on 14/12/14.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//
#import "DDLog.h"
#import "DDTTYLogger.h"
#import "HE_XmppMsgManager.h"
#import "HE_APPManager.h"
#import "HE_xmppFileTransfer.h"


#if DEBUG
static const int ddLogLevel = XMPP_LOG_FLAG_ERROR;
#else
static const int ddLogLevel = LOG_LEVEL_INFO;
#endif

//static const int ddLogLevel = LOG_LEVEL_OFF;

@implementation HE_XmppMsgManager
@synthesize managerDelegate;
@synthesize jidRoot;
@synthesize strMyJID;
@synthesize strPassWord;
@synthesize xmppStream;
@synthesize xmppReconnect;
@synthesize xmppRoster;
@synthesize xmppRosterStorage;
@synthesize xmppvCardTempModule;
@synthesize xmppvCardAvatarModule;
@synthesize xmppCapabilities;
@synthesize xmppCapabilitiesStorage;
@synthesize strGatewayPWD;


+ (HE_XmppMsgManager *)sharedManager{ 
    static HE_XmppMsgManager *sharedManger = nil;
    if(!sharedManger){
        sharedManger = [[super allocWithZone:nil] init];
    }
    return sharedManger;
}
+ (id)allocWithZone:(struct _NSZone *)zone
{
    return [self sharedManager];
}

- (id)init{
    self = [super init];
    if (self) {
        // Configure logging framework
        [DDLog addLogger:[DDTTYLogger sharedInstance] withLogLevel:XMPP_LOG_FLAG_SEND_RECV];
        [[DDTTYLogger sharedInstance] setColorsEnabled:YES];
        msgBuilder = [[HE_MsgBuilder alloc] init];
        msgParser = [[HE_MsgParser alloc] init];
        // Setup the XMPP stream
        [self setupStream];
    }
    return self;
}
- (void)setDelegate:(id)delegate{
    managerDelegate = delegate;
}
- (void)dealloc
{
    [self teardownStream];
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark Core Data
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

- (NSManagedObjectContext *)managedObjectContext_roster
{
    return [xmppRosterStorage mainThreadManagedObjectContext];
}

- (NSManagedObjectContext *)managedObjectContext_capabilities
{
    return [xmppCapabilitiesStorage mainThreadManagedObjectContext];
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark Private
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

- (void)setupStream
{
    NSAssert(xmppStream == nil, @"Method setupStream invoked multiple times");
    
    // Setup xmpp stream
    //
    // The XMPPStream is the base class for all activity.
    // Everything else plugs into the xmppStream, such as modules/extensions and delegates.
    
    xmppStream = [[XMPPStream alloc] init];
    
#if !TARGET_IPHONE_SIMULATOR
    {
        // Want xmpp to run in the background?
        //
        // P.S. - The simulator doesn't support backgrounding yet.
        //        When you try to set the associated property on the simulator, it simply fails.
        //        And when you background an app on the simulator,
        //        it just queues network traffic til the app is foregrounded again.
        //        We are patiently waiting for a fix from Apple.
        //        If you do enableBackgroundingOnSocket on the simulator,
        //        you will simply see an error message from the xmpp stack when it fails to set the property.
        
        xmppStream.enableBackgroundingOnSocket = YES;
    }
#endif
    
    // Setup reconnect
    //
    // The XMPPReconnect module monitors for "accidental disconnections" and
    // automatically reconnects the stream for you.
    // There's a bunch more information in the XMPPReconnect header file.
    
    xmppReconnect = [[XMPPReconnect alloc] init];
    
    // Setup roster
    //
    // The XMPPRoster handles the xmpp protocol stuff related to the roster.
    // The storage for the roster is abstracted.
    // So you can use any storage mechanism you want.
    // You can store it all in memory, or use core data and store it on disk, or use core data with an in-memory store,
    // or setup your own using raw SQLite, or create your own storage mechanism.
    // You can do it however you like! It's your application.
    // But you do need to provide the roster with some storage facility.
    
    xmppRosterStorage = [[XMPPRosterCoreDataStorage alloc] init];
    //	xmppRosterStorage = [[XMPPRosterCoreDataStorage alloc] initWithInMemoryStore];
    
    xmppRoster = [[XMPPRoster alloc] initWithRosterStorage:xmppRosterStorage];
    
    xmppRoster.autoFetchRoster = YES;
    xmppRoster.autoAcceptKnownPresenceSubscriptionRequests = YES;
    
    // Setup vCard support
    //
    // The vCard Avatar module works in conjuction with the standard vCard Temp module to download user avatars.
    // The XMPPRoster will automatically integrate with XMPPvCardAvatarModule to cache roster photos in the roster.
    
    xmppvCardStorage = [XMPPvCardCoreDataStorage sharedInstance];
    xmppvCardTempModule = [[XMPPvCardTempModule alloc] initWithvCardStorage:xmppvCardStorage];
    
    xmppvCardAvatarModule = [[XMPPvCardAvatarModule alloc] initWithvCardTempModule:xmppvCardTempModule];
    
    // Setup capabilities
    //
    // The XMPPCapabilities module handles all the complex hashing of the caps protocol (XEP-0115).
    // Basically, when other clients broadcast their presence on the network
    // they include information about what capabilities their client supports (audio, video, file transfer, etc).
    // But as you can imagine, this list starts to get pretty big.
    // This is where the hashing stuff comes into play.
    // Most people running the same version of the same client are going to have the same list of capabilities.
    // So the protocol defines a standardized way to hash the list of capabilities.
    // Clients then broadcast the tiny hash instead of the big list.
    // The XMPPCapabilities protocol automatically handles figuring out what these hashes mean,
    // and also persistently storing the hashes so lookups aren't needed in the future.
    //
    // Similarly to the roster, the storage of the module is abstracted.
    // You are strongly encouraged to persist caps information across sessions.
    //
    // The XMPPCapabilitiesCoreDataStorage is an ideal solution.
    // It can also be shared amongst multiple streams to further reduce hash lookups.
    
    xmppCapabilitiesStorage = [XMPPCapabilitiesCoreDataStorage sharedInstance];
    xmppCapabilities = [[XMPPCapabilities alloc] initWithCapabilitiesStorage:xmppCapabilitiesStorage];
    
    xmppCapabilities.autoFetchHashedCapabilities = YES;
    xmppCapabilities.autoFetchNonHashedCapabilities = NO;
    
    // Activate xmpp modules
    
    siFileTransfer = [[XMPPSIFileTransfer alloc] initWithDispatchQueue:dispatch_get_main_queue()];
    
    [siFileTransfer activate:xmppStream];
    [xmppReconnect  activate:xmppStream];
    
//////////取消注册Roster. vCard等组件
//    [xmppRoster            activate:xmppStream];
//    [xmppvCardTempModule   activate:xmppStream];
//    [xmppvCardAvatarModule activate:xmppStream];
//    [xmppCapabilities      activate:xmppStream];
    
    // Add ourself as a delegate to anything we may be interested in
    
    [xmppStream addDelegate:self delegateQueue:dispatch_get_main_queue()];
    [siFileTransfer addDelegate:[HE_xmppFileTransfer sharedFileTransfer] delegateQueue:dispatch_get_main_queue()];
    [[HE_xmppFileTransfer sharedFileTransfer] setSITransfer:siFileTransfer];
    
    [xmppRoster addDelegate:self delegateQueue:dispatch_get_main_queue()];
    
    // Optional:
    //
    // Replace me with the proper domain and port.
    // The example below is setup for a typical google talk account.
    //
    // If you don't supply a hostName, then it will be automatically resolved using the JID (below).
    // For example, if you supply a JID like 'user@quack.com/rsrc'
    // then the xmpp framework will follow the xmpp specification, and do a SRV lookup for quack.com.
    //
    // If you don't specify a hostPort, then the default (5222) will be used.
    
    //	[xmppStream setHostName:@"talk.google.com"];
    //	[xmppStream setHostPort:5222];
    
    
    // You may need to alter these settings depending on the server you're connecting to
    customCertEvaluation = YES;

}

- (void)teardownStream
{
    [xmppStream removeDelegate:self];
    [xmppRoster removeDelegate:self];
    
    [xmppReconnect         deactivate];
    [xmppRoster            deactivate];
    [xmppvCardTempModule   deactivate];
    [xmppvCardAvatarModule deactivate];
    [xmppCapabilities      deactivate];
    
    [xmppStream disconnect];
    
    xmppStream = nil;
    xmppReconnect = nil;
    xmppRoster = nil;
    xmppRosterStorage = nil;
    xmppvCardStorage = nil;
    xmppvCardTempModule = nil;
    xmppvCardAvatarModule = nil;
    xmppCapabilities = nil;
    xmppCapabilitiesStorage = nil;
}

// It's easy to create XML elments to send and to read received XML elements.
// You have the entire NSXMLElement and NSXMLNode API's.
//
// In addition to this, the NSXMLElement+XMPP category provides some very handy methods for working with XMPP.
//
// On the iPhone, Apple chose not to include the full NSXML suite.
// No problem - we use the KissXML library as a drop in replacement.
//
// For more information on working with XML elements, see the Wiki article:
// https://github.com/robbiehanson/XMPPFramework/wiki/WorkingWithElements

- (void)goOnline
{
    XMPPPresence *presence = [XMPPPresence presence]; // type="available" is implicit
    
    NSString *domain = [xmppStream.myJID domain];
    
    //Google set their presence priority to 24, so we do the same to be compatible.
    
    if([domain isEqualToString:@"gmail.com"]
       || [domain isEqualToString:@"gtalk.com"]
       || [domain isEqualToString:@"talk.google.com"])
    {
        NSXMLElement *priority = [NSXMLElement elementWithName:@"priority" stringValue:@"24"];
        [presence addChild:priority];
    }
    [[self xmppStream] sendElement:presence];
    
    ///网关验证
    
    [self AuthencateGateway];
}

- (void)goOffline
{
    XMPPPresence *presence = [XMPPPresence presenceWithType:@"unavailable"];
    
    [[self xmppStream] sendElement:presence];
}
- (void)AuthencateGateway{
    OP_TAG = STATE_GATEWAY_AUTHENCATE;
    NSString * cmdAuthen = [msgBuilder msgAuthencateName:[[XMPPJID jidWithString:strMyJID] resource] withPWD:strGatewayPWD];
    NSLog(@"cmdAuthen%@",cmdAuthen);
    [self sendIQCMDToRoot:cmdAuthen withNamespace:@"gateway"];
    //////////////设置一个定时器-在5s内未收到应答 则提示"未识别..."
    [NSTimer scheduledTimerWithTimeInterval:5.f target:self selector:@selector(authencateFailture) userInfo:nil repeats:false];
}
- (void)authencateFailture{
    if (OP_TAG == STATE_GATEWAY_AUTHENCATE) {
        [xmppStream disconnect];
        OP_TAG = STATE_XMPP_DISCONNET;
        NSError *err = [NSError errorWithDomain:@"xmpp"
                                           code:503
                                       userInfo:@{@"errTitle":@"未识别网关设备",@"errMsg": @"请核对网关设备号或检查网关连接"}];
        if ([managerDelegate respondsToSelector:@selector(didNotConnectToHost:)]) {
            [managerDelegate didNotConnectToHost:err];
        }
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark Connect/disconnect
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

- (BOOL)connect
{
    if (![xmppStream isDisconnected]) {
        
        return YES;
    }
    if (strMyJID == nil || strPassWord == nil) {
        return NO;
    }

    [xmppStream setMyJID:[XMPPJID jidWithString:strMyJID]];
    [xmppStream setHostPort:5222];
    OP_TAG = STATE_XMPP_CONNECT;
    NSError *error = nil;
    if (![xmppStream connectWithTimeout:XMPPStreamTimeoutNone error:&error])
//    if (![xmppStream connectToHost:[jidRoot domain] onPort:5222 withTimeout:XMPPStreamTimeoutNone error:&error])
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Error connecting"
                                                            message:@"See console for error details."
                                                           delegate:nil
                                                  cancelButtonTitle:@"Ok"
                                                  otherButtonTitles:nil];
        [alertView show];
        
        DDLogError(@"Error connecting: %@", error);
        
        return NO;
    }
    
    return YES;
}

- (void)disconnect
{
    
    [self goOffline];
    [xmppStream disconnect];
    OP_TAG = STATE_XMPP_DISCONNET;
    if ([managerDelegate respondsToSelector:@selector(didDisConnectToHost)]) {
        [managerDelegate didDisConnectToHost];
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark XMPPStream Delegate
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

- (void)xmppStream:(XMPPStream *)sender socketDidConnect:(GCDAsyncSocket *)socket
{
    DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
}

- (void)xmppStream:(XMPPStream *)sender willSecureWithSettings:(NSMutableDictionary *)settings
{
    DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
    
    NSString *expectedCertName = [xmppStream.myJID domain];
    if (expectedCertName)
    {
        [settings setObject:expectedCertName forKey:(NSString *)kCFStreamSSLPeerName];
    }
    
    if (customCertEvaluation)
    {
        [settings setObject:@(YES) forKey:GCDAsyncSocketManuallyEvaluateTrust];
    }
}

/**
 * Allows a delegate to hook into the TLS handshake and manually validate the peer it's connecting to.
 *
 * This is only called if the stream is secured with settings that include:
 * - GCDAsyncSocketManuallyEvaluateTrust == YES
 * That is, if a delegate implements xmppStream:willSecureWithSettings:, and plugs in that key/value pair.
 *
 * Thus this delegate method is forwarding the TLS evaluation callback from the underlying GCDAsyncSocket.
 *
 * Typically the delegate will use SecTrustEvaluate (and related functions) to properly validate the peer.
 *
 * Note from Apple's documentation:
 *   Because [SecTrustEvaluate] might look on the network for certificates in the certificate chain,
 *   [it] might block while attempting network access. You should never call it from your main thread;
 *   call it only from within a function running on a dispatch queue or on a separate thread.
 *
 * This is why this method uses a completionHandler block rather than a normal return value.
 * The idea is that you should be performing SecTrustEvaluate on a background thread.
 * The completionHandler block is thread-safe, and may be invoked from a background queue/thread.
 * It is safe to invoke the completionHandler block even if the socket has been closed.
 *
 * Keep in mind that you can do all kinds of cool stuff here.
 * For example:
 *
 * If your development server is using a self-signed certificate,
 * then you could embed info about the self-signed cert within your app, and use this callback to ensure that
 * you're actually connecting to the expected dev server.
 *
 * Also, you could present certificates that don't pass SecTrustEvaluate to the client.
 * That is, if SecTrustEvaluate comes back with problems, you could invoke the completionHandler with NO,
 * and then ask the client if the cert can be trusted. This is similar to how most browsers act.
 *
 * Generally, only one delegate should implement this method.
 * However, if multiple delegates implement this method, then the first to invoke the completionHandler "wins".
 * And subsequent invocations of the completionHandler are ignored.
 **/
- (void)xmppStream:(XMPPStream *)sender didReceiveTrust:(SecTrustRef)trust
 completionHandler:(void (^)(BOOL shouldTrustPeer))completionHandler
{
    DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
    
    // The delegate method should likely have code similar to this,
    // but will presumably perform some extra security code stuff.
    // For example, allowing a specific self-signed certificate that is known to the app.
    
    dispatch_queue_t bgQueue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_async(bgQueue, ^{
        
        SecTrustResultType result = kSecTrustResultDeny;
        OSStatus status = SecTrustEvaluate(trust, &result);
        
        if (status == noErr && (result == kSecTrustResultProceed || result == kSecTrustResultUnspecified)) {
            completionHandler(YES);
        }
        else {
            completionHandler(NO);
        }
    });
}

- (void)xmppStreamDidSecure:(XMPPStream *)sender
{
    DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
}

#pragma mark -
#pragma mark Authencation 成功/失败
- (void)xmppStreamDidAuthenticate:(XMPPStream *)sender
{
    DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
    OP_TAG = STATE_XMPP_ONLINE;
    [self goOnline];
}
//与网关连接失败
- (void)xmppStream:(XMPPStream *)sender didNotAuthenticate:(NSXMLElement *)error
{
    DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
    [xmppStream disconnect];
    OP_TAG = STATE_XMPP_DISCONNET;
    NSError *err = [NSError errorWithDomain:@"xmpp"
                                         code:503
                                     userInfo:@{@"errTitle":@"未识别网关设备",@"errMsg": @"请核对网关设备号或检查网关连接"}];
    if ([managerDelegate respondsToSelector:@selector(didNotConnectToHost:)]) {
        [managerDelegate didNotConnectToHost:err];
    }
}

#pragma mark -
#pragma mark 服务器 连接处理
- (void)xmppStreamDidConnect:(XMPPStream *)sender
{
    DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
    
    isXmppConnected = YES;
    OP_TAG = STATE_XMPP_AUTHENCATE;
    
    NSError *error = nil;
    
    if (![[self xmppStream] authenticateWithPassword:strPassWord error:&error])
    {
        DDLogError(@"Error authenticating: %@", error);
    }
}

- (void)xmppStreamDidDisconnect:(XMPPStream *)sender withError:(NSError *)error
{
    DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
    
    if (!isXmppConnected)
    {
        DDLogError(@"Unable to connect to server. Check xmppStream.hostName");
    }
    
    OP_TAG = STATE_NOT_SUCCESS;
    if ([managerDelegate respondsToSelector:@selector(didNotConnectToHost:)]) {
        [managerDelegate didNotConnectToHost:error];
    }
}

#pragma mark -
#pragma mark 消息处理 Msg
- (void)xmppStream:(XMPPStream *)sender didReceiveMessage:(XMPPMessage *)message
{
    DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
    
    // A simple example of inbound message handling.
    
    if ([message isChatMessageWithBody])
    {
        XMPPUserCoreDataStorageObject *user = [xmppRosterStorage userForJID:[message from]
                                                                 xmppStream:xmppStream
                                                       managedObjectContext:[self managedObjectContext_roster]];
        
        NSString *body = [[message elementForName:@"body"] stringValue];
        NSString *displayName = [user displayName];
        
        if ([[UIApplication sharedApplication] applicationState] == UIApplicationStateActive)
        {
//            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:displayName
//                                                                message:body
//                                                               delegate:nil
//                                                      cancelButtonTitle:@"Ok"
//                                                      otherButtonTitles:nil];
////            [alertView show];
        }
        else
        {
            // We are not active, so use a local notification instead
            UILocalNotification *localNotification = [[UILocalNotification alloc] init];
            localNotification.alertAction = @"Ok";
            localNotification.alertBody = [NSString stringWithFormat:@"From: %@\n\n%@",displayName,body];
            
            [[UIApplication sharedApplication] presentLocalNotificationNow:localNotification];
        }
    }
}


- (void)sendMsgToRoot:(NSString *)msg{
    XMPPMessage *msgXMPP = [XMPPMessage messageWithType:@"chat" to:jidRoot];
    [msgXMPP addBody:msg];

    [self.xmppStream sendElement:msgXMPP];
}

- (void)xmppStream:(XMPPStream *)sender didSendMessage:(XMPPMessage *)message{
    DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
}
- (void)xmppStream:(XMPPStream *)sender didFailToSendMessage:(XMPPMessage *)message error:(NSError *)error{
    DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
}

#pragma mark IQ 处理
- (BOOL)xmppStream:(XMPPStream *)sender didReceiveIQ:(XMPPIQ *)iq
{///IQ节点类型:
    //1.建立会话
    //2.网关验证登陆、控制消息收发
    //3.配置文件下载
    DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
    //////////////////如果IQ type为ERROR
    if (iq.isErrorIQ) {
        NSArray *nodeArry = [iq elementsForName:@"error"];
        if (nodeArry.count > 0) {
            NSXMLElement *errorNode = nodeArry[0];
            if ([errorNode attributeIntegerValueForName:@"code"] == 503) {
                NSError *err = [NSError errorWithDomain:@"xmpp"
                                                   code:503
                                               userInfo:@{@"errMsg": @"与网关断开连接"}];

                [xmppStream disconnect];
                OP_TAG = STATE_XMPP_DISCONNET;
                if ([managerDelegate respondsToSelector:@selector(didNotConnectToHost:)]) {
                    [managerDelegate didNotConnectToHost:err];
                }
            }
            
            // 被挤掉线
            if ([[errorNode attributeStringValueForName:@"type"] isEqualToString:@"cancel"] &&
                [iq.fromStr myContainsString:@"root"] ) {
                [xmppStream disconnect];
                OP_TAG = STATE_XMPP_DISCONNET;
                NSError *err = nil;
                [managerDelegate didNotConnectToHost:err];
            }
            
        }
    }
    ///////////////////如果IQ type为Set
    if (iq.isSetIQ) {
//        NSXMLElement *si    = [iq elementForName:@"si" xmlns:@"http://jabber.org/protocol/si"];
//        NSXMLElement *query = [iq elementForName:@"query" xmlns:@"http://jabber.org/protocol/bytestreams"];
//        
//        if (si != nil) {
//            [[HE_xmppFileTransfer sharedFileTransfer] communicationFileTransferWithIQ:iq];
//        }
//        if (query) {
//            [[HE_xmppFileTransfer sharedFileTransfer] confimStreamHost:iq];
//        }
//        return YES;
    }
    ///////////////////如果IQ type为Result
    if (iq.isResultIQ) {
        //////////////文件传输
//        NSXMLElement *query = [iq elementForName:@"query" xmlns:@"http://jabber.org/protocol/bytestreams"];
//        if (query) {
//            [[HE_xmppFileTransfer sharedFileTransfer] establishSOCKS5WithIQ:iq];
//        }
        //////////////控制
        NSXMLElement *contrlNode  = [iq elementForName:@"control" xmlns:@"com:jiuzhou:control"];
        NSXMLElement *gatewayNode = [iq elementForName:@"gateway" xmlns:@"com:jiuzhou:gateway"];
        NSXMLElement *ipcNode     = [iq elementForName:@"ipc" xmlns:@"com:jiuzhou:ipc"];
        
        if (contrlNode) {
            NSXMLElement *cmd =[contrlNode elementForName:@"cmd"];
            if (OP_TAG == STATE_GATEWAY_AUTHENCATE &&
                [[msgParser getActionWithMsg:cmd.stringValue] isEqualToString:@"03"]) {
                NSString *authen = [msgParser parseAuthencateMsg:cmd.stringValue];
                NSString *permission = [msgParser parsePermissionMsg:cmd.stringValue];
                
                NSLog(@"收到消息stringValue:%@",cmd.stringValue);
//                cmd.stringValue = @"@#$%1003001A08#1417276858#";
//                cmd.stringValue = @"@#$%1003001A0800";
                NSString *action = [msgParser getActionWithMsg:cmd.stringValue];
                NSString *CMDAction = [msgParser getCMDActionWithMsg:cmd.stringValue];
                if ([action isEqualToString:@"03"] && [CMDAction isEqualToString:@"08"]) {
                    NSString *CMDFeedback = [msgParser getCMDFeedbackMsg:cmd.stringValue];
                    if ([CMDFeedback isEqualToString:@"00"]) {
                        NSLog(@"同步时间成功");
                        [managerDelegate updateGatewayTimeSucceed];
                    }
                    else if ([CMDFeedback isEqualToString:@"01"]) {
                        NSLog(@"同步时间失败");
                        [managerDelegate updateGatewayTimeFail];
                    }else {
                        NSString *gatewayTime = [msgParser parseGatewayTimeMsg:cmd.stringValue];
                        [managerDelegate needUpdateGatewayTimeWithGTime:gatewayTime];
                    }
                }
                
                if ([authen isEqualToString:@"00"]) {
                    [[HE_APPManager sharedManager] User].strPermission = permission;
                    [[[HE_APPManager sharedManager] User] authencateCompelete];
                    OP_TAG = STATE_SUCCESS;
                    [managerDelegate didConnect];
                    NSLog(@"Autencate Success");
                }
                else{
                    NSLog(@"Autencate False :%@, ErrCode: %@", cmd.stringValue, permission);;
                    NSError *err = [[NSError alloc] initWithDomain:@"Socket"
                                                              code:permission.integerValue
                                                          userInfo:@{@"Data": cmd.stringValue}];
                    [xmppStream disconnect];
                    OP_TAG = STATE_XMPP_DISCONNET;
                    if ([managerDelegate respondsToSelector:@selector(didNotConnectToHost:)]) {
                        [managerDelegate didNotConnectToHost:err];
                    }
                }
            }
            else if (OP_TAG == STATE_SUCCESS){
                [managerDelegate didRecive:cmd.stringValue];
            }
        }
        if (gatewayNode) {
            NSXMLElement *cmd =[gatewayNode elementForName:@"cmd"];
            if (OP_TAG == STATE_SUCCESS) {
                [managerDelegate didRecive:cmd.stringValue];
            }
        }
        if (ipcNode) {
            ;
        }
        return YES;
    }
    return NO;
}
- (void)sendIQCMDToRoot:(NSString *) strCMD withNamespace:(NSString *)strNS{
    NSString *uuid         = [xmppStream generateUUID];
    NSXMLElement *transfer = [[NSXMLElement alloc] initWithName:strNS.lowercaseString xmlns:[NSString stringWithFormat:@"com:jiuzhou:%@", strNS.lowercaseString]];
    
    NSXMLElement *cmd = [[NSXMLElement alloc] initWithName:@"cmd"];
    [cmd setStringValue:strCMD];
    
    XMPPIQ *IQ = [XMPPIQ iqWithType:@"get" to:jidRoot elementID:uuid];
    [transfer addChild:cmd];
    [IQ addChild:transfer];
    [xmppStream sendElement:IQ];


}
#pragma mark 收到消息IQ/Msg/Presence/Error

- (void)xmppStream:(XMPPStream *)sender didReceivePresence:(XMPPPresence *)presence
{
    DDLogVerbose(@"%@: %@ - %@", THIS_FILE, THIS_METHOD, [presence fromStr]);
}

- (void)xmppStream:(XMPPStream *)sender didReceiveError:(id)error
{
    DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark XMPPRosterDelegate
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

- (void)xmppRoster:(XMPPRoster *)sender didReceiveBuddyRequest:(XMPPPresence *)presence
{
    DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
    
    XMPPUserCoreDataStorageObject *user = [xmppRosterStorage userForJID:[presence from]
                                                             xmppStream:xmppStream
                                                   managedObjectContext:[self managedObjectContext_roster]];
    
    NSString *displayName = [user displayName];
    NSString *jidStrBare = [presence fromStr];
    NSString *body = nil;
    
    if (![displayName isEqualToString:jidStrBare])
    {
        body = [NSString stringWithFormat:@"Buddy request from %@ <%@>", displayName, jidStrBare];
    }
    else
    {
        body = [NSString stringWithFormat:@"Buddy request from %@", displayName];
    }
    
    
    if ([[UIApplication sharedApplication] applicationState] == UIApplicationStateActive)
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:displayName
                                                            message:body
                                                           delegate:nil
                                                  cancelButtonTitle:@"Not implemented"
                                                  otherButtonTitles:nil];
        [alertView show];
    }
    else
    {
        // We are not active, so use a local notification instead
        UILocalNotification *localNotification = [[UILocalNotification alloc] init];
        localNotification.alertAction = @"Not implemented";
        localNotification.alertBody = body;
        
        [[UIApplication sharedApplication] presentLocalNotificationNow:localNotification];
    }
    
}



@end
