//
//  HE_XmppMsgManager.h
//  BWRemoter
//
//  Created by JianBo He on 14/12/14.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HE_Protocol.h"
#import "XMPPFramework.h"
#include <openssl/rc4.h>

@protocol HE_ManagerDelegate;

/////////APP 和网关 通信状态枚举
typedef enum {
    STATE_XMPP_DISCONNET = 0,
    STATE_XMPP_CONNECT   = 1,
    STATE_XMPP_AUTHENCATE,
    STATE_XMPP_ONLINE,
    STATE_GATEWAY_AUTHENCATE,
    STATE_SUCCESS
}HE_XMPP_STATE;
///XMPP消息管理类[单实例模式]
@interface HE_XmppMsgManager : NSObject <XMPPStreamDelegate>
{
    ///APPManager 委托
//    id<HE_ManagerDelegate> managerDelegate;
    ///
    HE_MsgBuilder *msgBuilder;
    HE_MsgParser *msgParser;
    ///状态
    HE_XMPP_STATE OP_TAG;
    
    
    ///XMPP 通信方式
    XMPPStream *xmppStream;
    XMPPReconnect *xmppReconnect;
    XMPPRoster *xmppRoster;
    XMPPRosterCoreDataStorage *xmppRosterStorage;
    XMPPvCardCoreDataStorage *xmppvCardStorage;
    XMPPvCardTempModule *xmppvCardTempModule;
    XMPPvCardAvatarModule *xmppvCardAvatarModule;
    XMPPCapabilities *xmppCapabilities;
    XMPPCapabilitiesCoreDataStorage *xmppCapabilitiesStorage;
    /////
    XMPPSIFileTransfer *siFileTransfer;
    
    BOOL customCertEvaluation;
    BOOL isXmppConnected;
}
+ (HE_XmppMsgManager *)sharedManager;

@property (nonatomic,strong) XMPPJID *jidRoot;//网关JID
@property (nonatomic,strong) NSString *strMyJID;//本机JID
@property (nonatomic,strong) NSString *strPassWord;//登陆XMPP密码

@property (nonatomic,strong) NSString *strGatewayPWD;//登陆网关密码

///APPManager 委托
@property (nonatomic,weak) id<HE_ManagerDelegate> managerDelegate;

@property (nonatomic, strong, readonly) XMPPStream *xmppStream;
@property (nonatomic, strong, readonly) XMPPReconnect *xmppReconnect;
@property (nonatomic, strong, readonly) XMPPRoster *xmppRoster;
@property (nonatomic, strong, readonly) XMPPRosterCoreDataStorage *xmppRosterStorage;
@property (nonatomic, strong, readonly) XMPPvCardTempModule *xmppvCardTempModule;
@property (nonatomic, strong, readonly) XMPPvCardAvatarModule *xmppvCardAvatarModule;
@property (nonatomic, strong, readonly) XMPPCapabilities *xmppCapabilities;
@property (nonatomic, strong, readonly) XMPPCapabilitiesCoreDataStorage *xmppCapabilitiesStorage;

- (NSManagedObjectContext *)managedObjectContext_roster;
- (NSManagedObjectContext *)managedObjectContext_capabilities;

- (BOOL)connect;//连接XMPP服务器
- (void)disconnect;//断开XMPP连接
- (void)AuthencateGateway;//与网关通信验证当前登陆用户
- (void)setDelegate:(id)delegate;//设置代理
- (void)sendMsgToRoot:(NSString *) msg;//发送消息给网关


- (void)sendIQCMDToRoot:(NSString *) strCMD withNamespace:(NSString *)strNS;//发送消息给网关，带上命名空间
@end
