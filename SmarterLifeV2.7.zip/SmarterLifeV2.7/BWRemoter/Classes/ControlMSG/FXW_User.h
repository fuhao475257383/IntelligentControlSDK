//
//  FXW_User.h
//  BWRemoter
//
//  Created by 6602_Loop on 14-12-15.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FXW_User : NSObject<NSCoding>
{
    BOOL IsAuthencate;
    BOOL IsAdmin;
}

@property (nonatomic,strong) NSString *strName;
@property (nonatomic,strong) NSString *strPwd;
@property (nonatomic,strong) NSString *strSN;
@property (nonatomic,strong) NSString *strDefaultPWD;
@property (nonatomic,strong) NSString *strPermission; //00 or 01 or 03 ...


@property BOOL      isRememberPWD;

+ (id)initUserWithUserDefault;

- (void)authencateCompelete;
- (BOOL)IsAuthencate;
- (void)setAdmin;
- (BOOL)IsAdmin;

- (void)saveToUserDefalt;
@end
