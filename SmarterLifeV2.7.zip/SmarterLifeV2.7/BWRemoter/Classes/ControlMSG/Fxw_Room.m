
 //   code
//  Fxw_Room.m
//  BWRemoter
//
//  Created by 6602_Loop on 14-12-21.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "Fxw_Room.h"
#import "FXW_LightVC.h"
#import "HE_BaseViewController.h"
#import "FXW_CurtainVC.h"
#import "FXW_ScenoModeVC.h"
#import "HE_TVControlVC.h"
#import "FXW_ConditionVC.h"
#import "FXW_CenterConditionVC.h"
#import "FXW_PowerVC.h"
#import "RoomDevice.h"
#import "FXW_BackmusicVC.h"
#import "HE_CustomeInfraredVC.h"
#import "DoorLockVC.h"

#define SCREENHEIGHT [[UIScreen mainScreen] bounds].size.height
@implementation Fxw_Room
@synthesize table;
@synthesize delegate;


- (id)init{
    return [self initWithFrame:CGRectMake(0, 0, 1, 1)];
}
- (id)initWithFrame:(CGRect)frame{
    
    self = [super initWithFrame:frame];
    if (self) {
        if (table == nil) {
            
            table = [[UITableView alloc] init];
            table.tableFooterView = [[UIView alloc] init];
            [table setFrame:CGRectMake(0, 0, [[UIScreen mainScreen] bounds].size.width ,[[UIScreen mainScreen] bounds].size.height-110)];
            table.delegate = self;
            table.dataSource = self;
            table.separatorInset = UIEdgeInsetsMake(0, 3, 0, 17);
            [self addSubview:table];
        }
    }
    return self;
}

-(void)SetName:(NSMutableArray*)aryname{
    [self setBackgroundColor:[UIColor whiteColor]];
    device = aryname;
    // 将0项 的内容移除
    for (NSUInteger i = 0; i < device.count; i++) {
        RoomDevice *rd = [device objectAtIndex:i];
        if (rd.contentArr.count <= 0) {
            [device removeObject:rd];
            i--;
        }
    }
}

#pragma mark -
#pragma mark UITableViewDataSourse Delegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return device.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 77.f;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ROOM_FXW"];
    
    UIView *backView = [[UIView alloc] initWithFrame: CGRectMake(0.0f, 0.0f,[[UIScreen mainScreen] bounds].size.width, 90.0f)];
    UIImageView *rightgogo = [[UIImageView alloc] initWithFrame: CGRectMake([[UIScreen mainScreen] bounds].size.width*0.8,30.0f, 20.0f, 20.0f)];
    
    UILabel *ListName = [[UILabel alloc]initWithFrame:CGRectMake([[UIScreen mainScreen] bounds].size.width*0.3, 25.0f, 200.0f, 30.0f)];
    ListName.adjustsFontSizeToFitWidth = YES;
    [rightgogo setImage:[UIImage imageNamed:@"arrowicon.png"]];
    
    UIImageView *logo = [[UIImageView alloc]initWithFrame:CGRectMake([[UIScreen mainScreen] bounds].size.width*0.1, 17.0f, 40.0f, 40.0f)];
    [backView addSubview:rightgogo];
    [backView addSubview:ListName];
    [backView addSubview:logo];
    [cell addSubview:backView];
    
    RoomDevice *roomDevices = (RoomDevice *)device[indexPath.row];
    
    if([roomDevices.property myContainsString:@"灯"]){
        [ListName setText:@"灯       光"];
    }
    else if([roomDevices.property myContainsString:@"窗"]){
        [ListName setText:@"窗       帘"];
    }
    else if([roomDevices.property myContainsString:@"场景"]){
        [ListName setText:@"情景模式"];
    }
    else if([roomDevices.property myContainsString:@"电源"]){
        [ListName setText:@"电       源"];
    }
    else if([roomDevices.property myContainsString:@"智能门锁"]){
        [ListName setText:@"智能门锁"];
    }
    else{
        NSArray *aryTmp = roomDevices.contentArr;
        ListName.text   = roomDevices.property;
        if (aryTmp.count > 0) {
            ListName.text = ((ControlDeviceContentValue *)aryTmp[0]).name;
        }
    }
    /////////权限判断
    if ([self dontHaveAPermission:roomDevices.contentArr withProperty:roomDevices.property]) {
        backView.alpha = 0.5;
        cell.alpha = 0.5;
        cell.userInteractionEnabled = NO;
    }
    [logo setImage:[UIImage imageNamed:[self ReturnIcon:((RoomDevice *)device[indexPath.row]).property]]];
    return cell;
}

#pragma mark -
#pragma mark UITableView Delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    RoomDevice *roomDevice = (RoomDevice *)device[indexPath.row];
    
    if([roomDevice.property myContainsString:@"灯"]){
        FXW_LightVC *Light = [[FXW_LightVC alloc]init];
        [Light setAryLight:roomDevice.contentArr];
        
        [Light setModalTransitionStyle:UIModalTransitionStyleCoverVertical];
        if ([delegate respondsToSelector:@selector(pushViewController:animated:)]) {
            Light.hidesBottomBarWhenPushed=YES;
            UINavigationItem *title = [Light navigationItem];
            [title setTitle:@"灯光"];
            NSDictionary *attr = [NSDictionary dictionaryWithObjectsAndKeys:[UIColor blackColor], NSForegroundColorAttributeName, nil];
            [Light.navigationController.navigationBar setTitleTextAttributes:attr];
            
            [delegate pushViewController:Light animated:YES];
        }
    }
    
    else if ([roomDevice.property myContainsString:@"智能门锁"]){
        DoorLockVC *door = [[DoorLockVC alloc]init];
        door.allDoorArray = roomDevice.contentArr;
        
        [door setModalTransitionStyle:UIModalTransitionStyleCoverVertical];
        if ([delegate respondsToSelector:@selector(pushViewController:animated:)]) {
            door.hidesBottomBarWhenPushed=YES;
            UINavigationItem *title = [door navigationItem];
            [title setTitle:@"智能门锁"];
            NSDictionary *attr = [NSDictionary dictionaryWithObjectsAndKeys:[UIColor blackColor], NSForegroundColorAttributeName, nil];
            [door.navigationController.navigationBar setTitleTextAttributes:attr];
            
            [delegate pushViewController:door animated:YES];
        }
    }
    
    else if([roomDevice.property myContainsString:@"窗"]){
        FXW_CurtainVC *Curtain = [[FXW_CurtainVC alloc]init];
        
        [Curtain setAryCurtain1:roomDevice.contentArr];
        [Curtain setFrameType:1];
        [Curtain setModalTransitionStyle:UIModalTransitionStyleCoverVertical];
        if ([delegate respondsToSelector:@selector(pushViewController:animated:)]) {
            Curtain.hidesBottomBarWhenPushed=YES;
            
            UINavigationItem *title = [Curtain navigationItem];
            [title setTitle:@"窗帘"];
            NSDictionary *attr = [NSDictionary dictionaryWithObjectsAndKeys:[UIColor blackColor], NSForegroundColorAttributeName, nil];
            [Curtain.navigationController.navigationBar setTitleTextAttributes:attr];
            
            [delegate pushViewController:Curtain animated:YES];
        }
    }
    else if([roomDevice.property myContainsString:@"场景"]){
        FXW_ScenoModeVC *ScenoMode = [[FXW_ScenoModeVC alloc]init];
        [ScenoMode setSceneList:((RoomDevice *)device[indexPath.row]).contentArr];
        [ScenoMode setModalTransitionStyle:UIModalTransitionStyleCoverVertical];
        if ([delegate respondsToSelector:@selector(pushViewController:animated:)]) {
            ScenoMode.hidesBottomBarWhenPushed=YES;
            
            UINavigationItem *title = [ScenoMode navigationItem];
            [title setTitle:@"场景控制器"];
            NSDictionary *attr = [NSDictionary dictionaryWithObjectsAndKeys:[UIColor blackColor], NSForegroundColorAttributeName, nil];
            [ScenoMode.navigationController.navigationBar setTitleTextAttributes:attr];
            [delegate pushViewController:ScenoMode animated:YES];
        }
    }
    else if([roomDevice.property isEqualToString:@"电视/播放器/DVD"]){
        HE_TVControlVC *vc = [[HE_TVControlVC alloc] init];
        [vc setIsStudyMode:NO];
        [vc setDeviceTV:((RoomDevice *)device[indexPath.row]).contentArr[0]];
        if ([delegate respondsToSelector:@selector(pushViewController:animated:)]) {
            [vc setHidesBottomBarWhenPushed:YES];
            [delegate pushViewController:vc animated:YES];
        }
    }
    else if([roomDevice.property isEqualToString:@"中央空调"]){
        FXW_CenterConditionVC *CenterCondition = [[FXW_CenterConditionVC alloc]init];
        [CenterCondition setModalTransitionStyle:UIModalTransitionStyleCoverVertical];
        if ([delegate respondsToSelector:@selector(pushViewController:animated:)]) {
            CenterCondition.hidesBottomBarWhenPushed=YES;
            [CenterCondition setConditionValue:((RoomDevice *)device[indexPath.row]).contentArr[0]];
            [delegate pushViewController:CenterCondition animated:YES];
        }
    }
    else if([roomDevice.property isEqualToString:@"单体空调"]){
        FXW_ConditionVC *vc = [[FXW_ConditionVC alloc] init];
        [vc  setIsStudyMode:NO];
        [vc setSingleAircondition:((RoomDevice *)device[indexPath.row]).contentArr[0]];
        if ([delegate respondsToSelector:@selector(pushViewController:animated:)]) {
            vc.hidesBottomBarWhenPushed = YES;
            [delegate pushViewController:vc animated:YES];
        }
    }
    else if([roomDevice.property myContainsString:@"电源"]){
        FXW_PowerVC *Power = [[FXW_PowerVC alloc]init];
        NSArray *aryPower = [NSMutableArray arrayWithArray:((RoomDevice *)device[indexPath.row]).contentArr];
        [Power setModalTransitionStyle:UIModalTransitionStyleCoverVertical];
        if ([delegate respondsToSelector:@selector(pushViewController:animated:)]) {
            Power.hidesBottomBarWhenPushed = YES;
            [Power setAryPower:aryPower];
            [delegate pushViewController:Power animated:YES];
        }
    }
    else if([roomDevice.property isEqualToString:@"背景音乐"]){
        FXW_BackmusicVC *music = [[FXW_BackmusicVC alloc]init];
        if ([delegate respondsToSelector:@selector(pushViewController:animated:)]) {
            music.hidesBottomBarWhenPushed = YES;
            
            NSArray *aryDev = [NSMutableArray arrayWithArray:((RoomDevice *)device[indexPath.row]).contentArr];
            [music setAryMuiscDev:aryDev];
            [delegate pushViewController:music animated:YES];
        }
    }
    ////////////自定义设备
    else if([roomDevice.property myContainsString:@"自定义"]){
        NSArray *aryDeviceValue = ((RoomDevice *)device[indexPath.row]).contentArr;
        if (aryDeviceValue.count > 0) {
            ControlDeviceContentValue *anyValue = aryDeviceValue[0];
            HE_CustomeInfraredVC      *vc       = [[HE_CustomeInfraredVC alloc] init];
            
            vc.hidesBottomBarWhenPushed         = YES;
            vc.deviceValue                      = anyValue;
            vc.isStudyMode                      = NO;
            [delegate pushViewController:vc animated:YES];
        }
    }
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

-(NSString *)ReturnIcon:(NSString *)deviceName{
    if([deviceName myContainsString:@"灯"]){
        return @"lighticon.png";
    }
    else if([deviceName myContainsString:@"电视"]){
        return @"tvicon.png";
    }
    else if([deviceName myContainsString:@"空调"]){
        return @"conicon.png";
    }
    else if([deviceName myContainsString:@"场景"]){
        return @"senceicon.png";
    }
    else if([deviceName myContainsString:@"音乐"]){
        return @"musicicon.png";
    }
    else if([deviceName myContainsString:@"窗帘"]){
        return @"win1icon.png";
    }
    else if([deviceName myContainsString:@"电源"]){
        return @"icSmartSocket";
    }
    else if([deviceName myContainsString:@"智能门锁"]){
        return @"hc_doorlock.png";
    }
    return @"otherDeviceicon";
}

///////数组中所有设备都无权限则返回YES
-(BOOL)dontHaveAPermission:(NSArray *)aryDevices withProperty:(NSString *) property{
    BOOL result = YES;
    NSString *permission = [[HE_APPManager sharedManager] User].strPermission;
    for (int i=0; i<aryDevices.count; i++) {
        ControlDeviceContentValue *tmp = aryDevices[i];
        if(![permission integerValue]==0){
            UInt64 prioH = [tmp.prio IntString].longLongValue;
            prioH =  prioH >> ([permission IntString].intValue -1);
            if (prioH&1) {
                result = NO;break;
            }
        }
        else{
            result = NO;break;
        }
    }
    return result;
}


@end
