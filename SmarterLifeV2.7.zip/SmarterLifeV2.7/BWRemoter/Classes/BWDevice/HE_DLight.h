//
//  HE_DLight.h
//  BWRemoter
//
//  Created by JianBo He on 14/12/4.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HE_UIDevice.h"



///灯光设备类
@interface HE_DLight : HE_UIDevice
{
    NSString *strOnImg;
    NSString *strOffImg;
    BOOL isOn;

    UIView *LED;
    NSTimer *timer;
}

@property UIImageView *backImage;
@property UILabel *labName;

- (void)turnOn;
- (void)turnOff;
- (void)tiggleState;

@end
