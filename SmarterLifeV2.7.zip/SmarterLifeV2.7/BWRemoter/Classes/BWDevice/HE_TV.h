//
//  HE_TV.h
//  BWRemoter
//
//  Created by HeJianBo on 15/3/13.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HE_UIDevice.h"

@interface HE_TV : HE_UIDevice


////////////进入红外学习Mode
- (void)enterStudyMode;
//////////////////保存更改到网关
- (void)saveAsStateToGateway;

@end
