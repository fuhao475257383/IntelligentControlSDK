//
//  FXW_Scene.h
//  BWRemoter
//
//  Created by 6602_Loop on 14-12-27.
//  Copyright (c) 2014年 . All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FXW_TableProtocol.h"
#import "HE_UIDevice.h"
@interface FXW_Scene : HE_UIDevice<UITableViewDelegate,UITableViewDataSource>
{
//    NSArray *array;
//    float num;
    NSInteger index;//当前表格显示位置使用
    NSInteger i;//用于当前表格数是否小于4
    NSInteger rowsnum;//表格总行数
    NSInteger sum;
    NSMutableArray *scene_list;
    
    //用于标识控制的那个场景的index
    NSInteger ctrlIndex;
}

@property (nonatomic, assign) id<FXW_tableDelegate> FXW_tableDelegate;
@property (nonatomic, assign) id<FXW_tableDataSourse> FXW_tableDataSource;
//背景灰
@property (nonatomic, strong) UIView *BackView;
//下面白色背景
@property (nonatomic, strong)UIView *TableBaseView;
//场景执行中...
@property (nonatomic, strong)UILabel *TableTitle;
//table
@property (nonatomic, strong) UITableView *Table;
- (id)initWithFrame:(CGRect)frame Delegate:(id)delegate Datasourse:(id)datasourse;
-(void)runtime;
-(void)SetsceneList:(NSMutableArray *)array andindex:(NSInteger)listindex;
@end
