//
//  HE_UIDevice.h
//  BWRemoter
//
//  Created by JianBo He on 15/1/14.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HE_APPManager.h"
#import "CYM_Engine.h"
#import "NSString+HE.h"

///所有设备的 父类、 用于设备状态的管理
@interface HE_UIDevice : UIView
{
    ///
    NSString *ID;
    ///设备的编号
    NSString *num;
    ///设备名称
    NSString *name;
    ///设备的类别
    NSString *category;
    A4_DeviceTypeCode deviceType;
    ///设备的属性
    NSString *property;
    ///设备的 com口
    NSString *com;
    ///设备权限码
    NSString *prio;
    ///设备绑定报告
    NSString *value;
    ///设备的反馈报告
    NSString *strAns;
    ///设备的Key 数组
    NSArray *aryKey;
    
    HE_MsgBuilder *msgB;
    HE_MsgParser *msgP;
    
    HE_CMDBuilder *cmdB;
    HE_CMDParser *cmdP;
}
//Get Set
@property BOOL isNeedQuery;
@property BOOL hasUpdate;

- (NSString *)ID;
- (void)setID:(NSString *)str;

- (NSString *)num;
- (void)setNum:(NSString *)str;
- (void)setNumWithValue:(NSString *)val;

- (NSString *)name;
- (void)setName:(NSString *)str;

- (NSString *)category;
- (void)setCategory:(NSString *)str;

- (A4_DeviceTypeCode)deviceType;

- (NSString *)property;
- (void)setProperty:(NSString *)str;

- (NSString *)com;
- (void)setCom:(NSString *)str;

- (NSString *)prio;
- (void)setPrio:(NSString *)str;

- (NSString *)value;
- (void)setValue:(NSString *)str;

- (NSString *)strAns;
- (void)setStrAns:(NSString *)str;

- (NSArray *)aryKey;
- (void)setAryKey:(NSArray *)ary;

- (HE_MsgBuilder *)msgB;
- (HE_MsgParser *)msgP;
- (HE_CMDBuilder *)cmdB;
- (HE_CMDParser *)cmdP;

- (BOOL)isNeedShowLoading:(NSString *)strMsg;
//用设备的数据模型初始化设备
- (void)setAttrWithCtrlValue:(ControlDeviceContentValue *)val;
///当收到设备反馈报告时、 更新设备的状态  [子类必须重载需要该方法、以支持实时更新UI状态]
- (void)updateTheDeviceStateWithData:(NSString *)strData;


///工具类方法

- (ControlDeviceContentValueKey *)getValueKeyForName:(NSString *)strName withArray:(NSArray *)ary;

- (NSArray *)parseTxt:(NSString *)strName;

@end
