//
//  FXW_BackMusic.m
//  BWRemoter
//
//  Created by 6602_Loop on 15-1-15.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "FXW_BackMusic.h"
#import "HE_CustemExtend.h"
#import <objc/runtime.h>

#define ScreenSize [UIScreen mainScreen].bounds.size
#define groupNum  1000

static char      kButtonType;



@interface FXW_BackMusic(){
    
    /////////////////View
    UIScrollView *mainScroll;
    
    FXW_Slider  *voice;//声音
    UIButton    *power_btn;//开
    UIButton    *power_btnoff;//关
    //操作
    UIButton    *back;//返回
    UIButton    *stop;//停止
    UIButton    *play;//播放
    UIButton    *go;//下一曲
    //音源
    UIButton    *aux1;//各种格式
    UIButton    *fm;
    UIButton    *mp3;
    UIButton    *aux2;
    
    UIButton   *voice_btn;//静音
    UILabel    *labMuicName;//歌名
    
    /////////////////Msg Quene
    NSMutableString *strQuene;
}
@end

@implementation FXW_BackMusic

-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    strQuene = [[NSMutableString alloc] init];
    mainScroll = [[UIScrollView alloc] initWithFrame:frame];
    
    [self addSubview:mainScroll];
    return self;
}

-(void)setAttrWithCtrlValue:(ControlDeviceContentValue *)val{
    [super setAttrWithCtrlValue:val];
    
    //所有按钮
    ///电源按钮on
    power_btn = [[UIButton alloc]initWithFrame:CGRectMake(ScreenSize.width*0.05,30,ScreenSize.width*0.35,ScreenSize.width*0.18)];
    [power_btn setImage:[UIImage imageNamed:@"power_on_icon.png"] forState:UIControlStateNormal];
    [power_btn setImage:[UIImage imageNamed:@"power_on_icon_H.png"] forState:UIControlStateSelected];
    objc_setAssociatedObject(power_btn, &kButtonType, @(groupNum), OBJC_ASSOCIATION_COPY);
    [power_btn setTitle:@"开" forState:UIControlStateNormal];
    [power_btn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [power_btn addTarget:self action:@selector(BtnClick:) forControlEvents:UIControlEventTouchUpInside];
    
    [mainScroll addSubview:power_btn];
    //off
    power_btnoff = [[UIButton alloc]initWithFrame:CGRectMake(ScreenSize.width*0.38,30,ScreenSize.width*0.35,ScreenSize.width*0.18)];
    [power_btnoff setImage:[UIImage imageNamed:@"power_off_icon.png"] forState:UIControlStateNormal];
    [power_btnoff setImage:[UIImage imageNamed:@"power_off_icon_H.png"] forState:UIControlStateSelected];
    objc_setAssociatedObject(power_btnoff, &kButtonType, @(groupNum), OBJC_ASSOCIATION_COPY);
    [power_btnoff setTitle:@"关" forState:UIControlStateNormal];
    [power_btnoff setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [power_btnoff addTarget:self action:@selector(BtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [mainScroll addSubview:power_btnoff];
    
    //静音
    voice_btn = [[UIButton alloc]initWithFrame:CGRectMake(ScreenSize.width*0.7,30,ScreenSize.width*0.18,ScreenSize.width*0.18)];
    [voice_btn setImage:[UIImage imageNamed:@"icMusic_voiceoff"] forState:UIControlStateNormal];
    [voice_btn setImage:[UIImage imageNamed:@"icMusic_voiceoff_H"] forState:UIControlStateSelected];
    objc_setAssociatedObject(voice_btn, &kButtonType, @(groupNum + 1), OBJC_ASSOCIATION_COPY);
    [voice_btn setTitle:@"静音" forState:UIControlStateNormal];
    [voice_btn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [voice_btn addTarget:self action:@selector(BtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [mainScroll addSubview:voice_btn];
    
    //背景
    UIImageView *backv = [[UIImageView alloc]initWithFrame:CGRectMake(ScreenSize.width*0.1, 130, ScreenSize.width*0.8, ScreenSize.width*0.3)];
    [backv setImage:[UIImage imageNamed:@"backmusic"]];
    ///歌曲名称
    labMuicName = [[UILabel alloc] initWithFrame:CGRectMake(15, 10, backv.frameW - 30, 30)];
    labMuicName.textAlignment = NSTextAlignmentCenter;
    labMuicName.font          = [UIFont boldSystemFontOfSize:15.f];
    labMuicName.textColor     = [UIColor whiteColor];
    labMuicName.text          = @"歌曲名称";
    [backv addSubview:labMuicName];
    [mainScroll addSubview:backv];
    
    ////////////////Animation
    
    //背景view
    UIView *backview = [[UIView alloc]initWithFrame:CGRectMake(ScreenSize.width*0.1, 130, ScreenSize.width*0.8, ScreenSize.width*0.3)];
    [backview setBackgroundColor:[UIColor clearColor]];
    [mainScroll addSubview:backview];
    
    voice = [[FXW_Slider alloc]initWithFrame:CGRectMake(backview.frame.size.width*0.05, backview.frame.size.height*0.65, backview.frame.size.width*0.9,10) Delegate:self Datasourse:self];
    [voice addTarget:self action:@selector(voiceChanged:) forControlEvents:UIControlEventValueChanged];
    voice.continuous = NO;
    
    [voice setThumbImage:[UIImage imageNamed:@"point.png"] forState:UIControlStateNormal];
    [voice setMinimumTrackImage:[UIImage imageNamed:@"maxtrack.png"] forState:UIControlStateNormal];
    [voice setMaximumTrackImage:[UIImage imageNamed:@"mintrack.png"] forState:UIControlStateNormal];
    [backview addSubview:voice];
    ///音量最小
    UIImageView *voicel = [[UIImageView alloc]initWithFrame:CGRectMake(backview.frame.size.width*0.05, backview.frame.size.height*0.475, backview.frame.size.height*0.2, backview.frame.size.height*0.4)];
    [voicel setImage:[UIImage imageNamed:@"voicel.png"]];
    [backview addSubview:voicel];
    ///音量最大
    UIImageView *voiceh = [[UIImageView alloc]initWithFrame:CGRectMake(backview.frame.size.width*0.8, backview.frame.size.height*0.475, backview.frame.size.height*0.4, backview.frame.size.height*0.4)];
    [voiceh setImage:[UIImage imageNamed:@"voiceh.png"]];
    [backview addSubview:voiceh];
    
    
    //快退
    back = [[UIButton alloc]initWithFrame:CGRectMake(ScreenSize.width*0.05, 250, ScreenSize.width*0.2, ScreenSize.width*0.2)];
    [back setBackgroundImage:[UIImage imageNamed:@"tv_perItem"] forState:UIControlStateNormal];
    [back setBackgroundImage:[UIImage imageNamed:@"tv_perItem_H"] forState:UIControlStateSelected];
    objc_setAssociatedObject(back, &kButtonType, @(groupNum ), OBJC_ASSOCIATION_COPY);
    [back setTitle:@"上一曲" forState:UIControlStateNormal];
    [back setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [back addTarget:self action:@selector(BtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [mainScroll addSubview:back];
    
    //暂停
    stop = [[UIButton alloc]initWithFrame:CGRectMake(ScreenSize.width*0.28, 250, ScreenSize.width*0.2, ScreenSize.width*0.2)];
    [stop setBackgroundImage:[UIImage imageNamed:@"icMusic_stop.png"] forState:UIControlStateNormal];
    objc_setAssociatedObject(stop, &kButtonType, @(groupNum ), OBJC_ASSOCIATION_COPY);
    [stop setTitle:@"暂停" forState:UIControlStateNormal];
    [stop setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [stop addTarget:self action:@selector(BtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [stop setBackgroundImage:[UIImage imageNamed:@"icMusic_stop_H.png"] forState:UIControlStateSelected];
    [mainScroll addSubview:stop];
    //播放
    play = [[UIButton alloc]initWithFrame:CGRectMake(ScreenSize.width*0.52, 250, ScreenSize.width*0.2, ScreenSize.width*0.2)];
    [play setBackgroundImage:[UIImage imageNamed:@"icMusic_play.png"] forState:UIControlStateNormal];
    objc_setAssociatedObject(play, &kButtonType, @(groupNum ), OBJC_ASSOCIATION_COPY);
    [play setTitle:@"播放" forState:UIControlStateNormal];
    [play setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [play setBackgroundImage:[UIImage imageNamed:@"icMusic_play_H.png"] forState:UIControlStateSelected];
    [play addTarget:self action:@selector(BtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [mainScroll addSubview:play];
    //下一曲
    go = [[UIButton alloc]initWithFrame:CGRectMake(ScreenSize.width*0.75, 250, ScreenSize.width*0.2, ScreenSize.width*0.2)];
    [go setTitle:@"下一曲" forState:UIControlStateNormal];
    [go setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    
    [go setBackgroundImage:[UIImage imageNamed:@"tv_nextItem"] forState:UIControlStateNormal];
    [go setBackgroundImage:[UIImage imageNamed:@"tv_nextItem_H"] forState:UIControlStateSelected];
    
    
    objc_setAssociatedObject(go, &kButtonType, @(groupNum ), OBJC_ASSOCIATION_COPY);
    [go addTarget:self action:@selector(BtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [mainScroll addSubview:go];
    
    //aux1
    aux1 = [[UIButton alloc]initWithFrame:CGRectMake(ScreenSize.width*0.05, 330, ScreenSize.width*0.225, ScreenSize.width*0.225)];
    [aux1 setBackgroundImage:[UIImage imageNamed:@"icMusic_aux1.png"] forState:UIControlStateNormal];
    [aux1 setBackgroundImage:[UIImage imageNamed:@"icMusic_aux1_H.png"] forState:UIControlStateSelected];
    objc_setAssociatedObject(aux1, &kButtonType, @(groupNum + 3), OBJC_ASSOCIATION_COPY);
    [aux1 setTitle:@"AUX1" forState:UIControlStateNormal];
    [aux1 setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [aux1 addTarget:self action:@selector(BtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [mainScroll addSubview:aux1];
    //FM
    fm = [[UIButton alloc]initWithFrame:CGRectMake(ScreenSize.width*0.275, 330, ScreenSize.width*0.225, ScreenSize.width*0.225)];
    [fm setBackgroundImage:[UIImage imageNamed:@"icMusic_fm.png"] forState:UIControlStateNormal];
    [fm setBackgroundImage:[UIImage imageNamed:@"icMusic_fm_H.png"] forState:UIControlStateSelected];
    objc_setAssociatedObject(fm, &kButtonType, @(groupNum + 3), OBJC_ASSOCIATION_COPY);
    [fm setTitle:@"FM" forState:UIControlStateNormal];
    [fm setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [fm addTarget:self action:@selector(BtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [mainScroll addSubview:fm];
    //MP3
    mp3 = [[UIButton alloc]initWithFrame:CGRectMake(ScreenSize.width*0.5, 330, ScreenSize.width*0.225, ScreenSize.width*0.225)];
    [mp3 setTitle:@"MP3" forState:UIControlStateNormal];
    [mp3 setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [mp3 setBackgroundImage:[UIImage imageNamed:@"icMusic_mp3.png"] forState:UIControlStateNormal];
    [mp3 setBackgroundImage:[UIImage imageNamed:@"icMusic_mp3_H.png"] forState:UIControlStateSelected];
    objc_setAssociatedObject(mp3, &kButtonType, @(groupNum + 3), OBJC_ASSOCIATION_COPY);
    [mp3 addTarget:self action:@selector(BtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [mainScroll addSubview:mp3];
    //aux2
    aux2 = [[UIButton alloc]initWithFrame:CGRectMake(ScreenSize.width*0.725, 330, ScreenSize.width*0.225, ScreenSize.width*0.225)];
    [aux2 setBackgroundImage:[UIImage imageNamed:@"icMusic_aux2.png"] forState:UIControlStateNormal];
    [aux2 setBackgroundImage:[UIImage imageNamed:@"icMusic_aux2_H.png"] forState:UIControlStateSelected];
    objc_setAssociatedObject(aux2, &kButtonType, @(groupNum + 3), OBJC_ASSOCIATION_COPY);
    [aux2 setTitle:@"AUX2" forState:UIControlStateNormal];
    [aux2 setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [aux2 addTarget:self action:@selector(BtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [mainScroll addSubview:aux2];
    
    mainScroll.contentSize = CGSizeMake(mainScroll.frameW, aux2.frameSumY_H);
    
    //音量校正
    [voice setMaximumValue:[self getMaxValueForKeyArray:aryKey]];
    
    //使能校正
    [self disable:power_btn ifString:@"开" notContainIn:aryKey];
    [self disable:power_btnoff ifString:@"关" notContainIn:aryKey];
    [self disable:voice_btn ifString:@"静音" notContainIn:aryKey];
    
    [self disable:back ifString:@"上一曲" notContainIn:aryKey];
    [self disable:stop ifString:@"暂停" notContainIn:aryKey];
    [self disable:play ifString:@"播放" notContainIn:aryKey];
    [self disable:go ifString:@"下一曲" notContainIn:aryKey];
    
    [self disable:aux1 ifString:@"AUX1" notContainIn:aryKey];
    [self disable:fm ifString:@"FM" notContainIn:aryKey];
    [self disable:mp3 ifString:@"MP3" notContainIn:aryKey];
    [self disable:aux2 ifString:@"AUX2" notContainIn:aryKey];
    
    //绘制自定义按钮
    #define BTN_MARGIN_S     ScreenSize.width * 0.04
    #define BTN_WIDTH        ScreenSize.width * 0.32
    #define BTN_HEIGTH_S     55
    #define BOTOM_VIEW_H     60
    
    CGFloat marginX4 = (ScreenSize.width - BTN_MARGIN_S*2 - BTN_WIDTH*3)/2.f;
    NSArray *aryCustomeName = [self getCustomeNameWith:aryKey];
    for (int i=0; i<aryCustomeName.count; i++) {
        UIButton *btnTMP = [[UIButton alloc] initWithFrame:CGRectMake(BTN_MARGIN_S + i%3*(BTN_WIDTH + marginX4),
                                                                      aux2.frameSumY_H + i/3*(BTN_HEIGTH_S + 5),
                                                                      BTN_WIDTH, BTN_HEIGTH_S)];
        [btnTMP setBackgroundImage:[UIImage imageNamed:@"tv_backGround2.png"] forState:UIControlStateNormal];
        [btnTMP setBackgroundImage:[UIImage imageNamed:@"tv_backGround2.png"] forState:UIControlStateHighlighted];
        [btnTMP setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [btnTMP setTitleColor:[UIColor colorWithRed:110/255.0f green:220/255.0f blue:80/255.0f alpha:1] forState:UIControlStateHighlighted];
        [btnTMP setTitleColor:[UIColor colorWithRed:110/255.0f green:220/255.0f blue:80/255.0f alpha:1] forState:UIControlStateSelected];
        [btnTMP setTitle:aryCustomeName[i] forState:UIControlStateNormal];
        btnTMP.titleLabel.font = [UIFont boldSystemFontOfSize:14.f];
        [btnTMP addTarget:self action:@selector(BtnClick:) forControlEvents:UIControlEventTouchUpInside];
        objc_setAssociatedObject(aux2, &kButtonType, @(groupNum + 4 + i), OBJC_ASSOCIATION_COPY);
        
        [mainScroll addSubview:btnTMP];
        [mainScroll setContentSize:CGSizeMake(mainScroll.frameW, btnTMP.frameSumY_H)];
    }
}
-(void)BtnClick:(UIButton *)sender{
    ControlDeviceContentValueKey *key = [self getValueKeyForName:sender.titleLabel.text withArray:aryKey];
    if (key) {
        NSString *cmd = @"";
        if (deviceType == A4_DEVICE_THREE) {
            cmd = key.value;
        }
        else{
            cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType Data:[NSString stringWithFormat:@"%@%02X%@",self.num, (int)key.value.length/2,key.value]];
        }
        NSString *msg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:cmd ];
        [[HE_APPManager sharedManager] SendMsg:msg withNameSpace:@"control" isShowLoading:[self isNeedShowLoading: msg]];
        
        /////如果有查询。需要发送则发送查询命令
//        if([key.query isNotEmptyAndNil]  && ![key.query isEqualToString:@"null"]){
//            NSString *cmdQuery = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType
//                                                   Data:[NSString stringWithFormat:@"%@%02X%@",self.num, (int)key.query.length/2,key.query]];
//            NSString *msgQuery = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:cmdQuery];
//            // 延时发送查询消息
//            NSTimeInterval time = key.time.doubleValue / 1000;
//            [[HE_APPManager sharedManager] SendQueryMsg:msgQuery withNameSpace:@"control" after:time];
//        }
    }
}

-(void)voiceChanged:(id)sender{
    UISlider *slider = (UISlider *)sender;
    int progressAsInt = (int)roundf(slider.value);
    ControlDeviceContentValueKey *key = [self getValueKeyForName:[NSString stringWithFormat:@"音量%d", progressAsInt] withArray:aryKey];
    NSString *cmd = @"";
    if (deviceType == A4_DEVICE_THREE) {
        cmd = key.value;
    }
    else{
        cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType Data:[NSString stringWithFormat:@"%@%02X%@",self.num, (int)key.value.length/2,key.value]];
    }
    NSString *msg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:cmd];
    [[HE_APPManager sharedManager] SendMsg:msg withNameSpace:@"control" isShowLoading:[self isNeedShowLoading: msg]];
    
}

#pragma mark -
#pragma mark Manager Device
//- (void)willMoveToWindow:(UIWindow *)newWindow{
//    [super willMoveToWindow:newWindow];
    /////////发送该设备背景音乐的查询命令
    //a300a300a3
//    ControlDeviceContentValueKey *key = [self getValueKeyForName:@"bwenterqu" withArray:aryKey];
//    NSString *cmd = @"";
//    if (deviceType == A4_DEVICE_THREE) {
//        cmd = key.value;
//    }
//    else{
//        cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType
//                                Data:[NSString stringWithFormat:@"%@%02X%@",self.num, (int)key.value.length/2,key.value]];
//    }
//    NSString *msg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:cmd];
//    [[HE_APPManager sharedManager] SendMsg:msg withNameSpace:@"control" isShowLoading:self.isNeedShowLoading];

//}

- (void)updateTheDeviceStateWithData:(NSString *)strData{
    ///////将不完整命令拼接
    NSLog(@"收到的Muisc: %@",strData);
    if (strData.length == 96 || (strQuene.length > 0 && strData.length < 96)){
        [strQuene appendString:strData];
        if (strData.length == 96) {///避免刚刚为96的倍数时
            [self parseQueryBackWith:strQuene];
            [self parseSongNameWith:strQuene];
            return;
        }
        else {
            strData = [NSString stringWithString:strQuene];
            [strQuene deleteCharactersInRange:NSMakeRange(0, strQuene.length)];
        }
    }
    [self parseQueryBackWith:strData];
    [self parseSongNameWith:strData];
    //////////////获取按钮反馈
    
    if ([strData.uppercaseString myContainsString:@"E900040004"]) {
        voice_btn.selected = NO;
        return;
    }
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(){
        for (ControlDeviceContentValueKey *k in aryKey) {
            ////////有此反馈
            if ([strData.uppercaseString myContainsString:k.backkey.uppercaseString]) {
                NSLog(@"反馈按钮：%@",k.name);
                NSArray *allViews = [mainScroll subviews];
                ////////////////特殊情况 bw取消静音
//                if ([k.name myContainsString:@"取消静音"]) {
//                    dispatch_async(dispatch_get_main_queue(), ^{
//                       voice_btn.selected = NO;
//                    });
//                    break;
//                }

                
                ////////////////1.滑竿音量反馈
                if ([k.name myContainsString:@"音量"]) {
                    NSArray *aryTMP = [k.name componentsSeparatedByString:@"音量"];
                    float  val = voice.value;
                    
                    NSLog(@"音量:%g",val);
                    
                    if (aryTMP.count >= 2) {
                        val = ((NSString *)aryTMP[1]).floatValue;
                    }
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [voice setValue:val animated:YES];
                    });
                }
                ////////////////2.按钮反馈
                else{
                    for (UIView *v in allViews) {
                        if([v isKindOfClass:[UIButton class]]){
                            if ([((UIButton *)v).titleLabel.text isEqualToString:k.name]) {
                                NSNumber *selcedNum = objc_getAssociatedObject(v, &kButtonType);
                                dispatch_async(dispatch_get_main_queue(), ^{
                                    ((UIButton *)v).selected = YES;
                                });
                                ////////将本组其他按钮置为 未选中
                                for (UIView *v2 in allViews) {
                                    if ([v2 isKindOfClass:[UIButton class]]) {
                                        NSNumber *tmp = objc_getAssociatedObject(v2, &kButtonType);
                                        if (selcedNum.integerValue == tmp.integerValue && v != v2) {
                                            dispatch_async(dispatch_get_main_queue(), ^{
                                                ((UIButton *)v2).selected = NO;
                                            });
                                        }
                                    }
                                }
                            }
//                            else{
//                                dispatch_async(dispatch_get_main_queue(), ^{
//                                    ((UIButton *)v).selected = NO;
//                                });
//                            }
                        }
                    }
                }
                break;
            }
        }
    });
}

#pragma mark -
#pragma mark Private Method
- (ControlDeviceContentValueKey *)getValueKeyForName:(NSString *)strName withArray:(NSArray *)ary{
    for (ControlDeviceContentValueKey *obj in ary) {
        if ([obj.name isEqualToString:strName]) {
            return obj;
        }
    }
    return nil;
}

- (NSInteger)getMaxValueForKeyArray:(NSArray *)ary{
    NSInteger max = 0;
    for (ControlDeviceContentValueKey *obj in ary) {
        if ([obj.name myContainsString:@"音量"] ){
            NSString *s = [obj.name componentsSeparatedByString:@"音量"][1];
            NSInteger tmp = [s integerValue];
            if (max < tmp) {
                max = tmp;
            }
        }
    }
    if (max <= 0) {
        voice.alpha = 0.5;
        voice.userInteractionEnabled = false;
    }
    
    return max;
}

- (void)parseQueryBackWith:(NSString *)strData{
    ///////////////获取查询反馈(FC00) 中的音量,音源,开/关机,静音
    NSRange backRange  = [strData rangeOfString:@"FC00"];
    backRange.length   = 16*2;
    ///完整命令
    if (strData.length > backRange.length + backRange.location) {
        NSString *backCMD= [strData substringWithRange:backRange];
        NSInteger Status = [backCMD substringWithRange:NSMakeRange(6, 2)].IntString.integerValue;
        NSInteger Voice  = [backCMD substringWithRange:NSMakeRange(8, 2)].IntString.integerValue;
        NSInteger Src    = [backCMD substringWithRange:NSMakeRange(14,2)].IntString.integerValue;
        
        NSLog(@"音量第一次进入%lu",(long)Voice);
        
        /////Status = 1B
        //          +-----+-----------+----------+------+-------+--------+-----+
        // NAME     | N/A |  开/关机   |  播放暂停 |  静音 |  循环 | 播放顺序 | N/A |
        //          +-----+-----------+----------+------+-------+--------+-----+
        // SIZE(b)  |  1  |    1      |     1    |   1  |   2   |    1   |  1  |
        //          +-----+-----------+----------+------+-------+--------+-----+
        // N/A    =  忽略
        // 开/关机 = 1开、0关机则该byte其余为全无效
        // 播放暂停 = 1播放、0暂停
        // 静音    = 0为非静音，1为静音
        // 循环    = 0为全循环，1为专辑内循环，2为单曲循环。
        // 播放顺序 = 0为顺序播放，1为随机播放。
        // N/A    = 忽略
        
        NSInteger tmp = Status;
        ////开/关机
        if (tmp>>6 & 0x01) {
            /////播放
            if (tmp>>5 & 0x01)
                play.selected = YES;
            else
                stop.selected = YES;
            //////静音
            if (tmp>>4 & 0x01)
                voice_btn.selected = YES;
        }
        else{//关机
            power_btnoff.selected = YES;
        }
        
        /////Voice = 1B 0~31音量
        voice.value = Voice;
        
        /////Src   = 1B 0x00=AUX1 0x01=FM 0x02=MP3 0x03=AUX2
        switch (Src) {
            case 0: aux1.selected = YES;
                break;
            case 1: fm.selected   = YES;
                break;
            case 2: mp3.selected  = YES;
                break;
            case 3: aux2.selected = YES;
                break;
            default:
                break;
        }
    }
}

- (void)parseSongNameWith:(NSString *)strData{
    ///////////////获取歌名反馈的位置
    //搜索strData字符串内，F100 F200的位置
    NSRange beginRange = [strData rangeOfString:@"F100"];
    NSRange endRange   = [strData rangeOfString:@"F200"];
    //歌名的位置
    NSRange nameRange  = NSMakeRange(beginRange.location, endRange.location - beginRange.location);
    
    ///////////////获取歌名
    //1.取到有效的Loaction
    if ((beginRange.length >0 && endRange.length > 0)
        && beginRange.location < endRange.location) {
        NSString *strTmp   = [strData substringWithRange:nameRange];
        NSString *strName  = [strTmp substringWithRange:NSMakeRange(8, strTmp.length - 10)];
        
        ////////////////获取得到的GBK 歌名字符
        //GBK转UFT8
        NSStringEncoding enc = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
        NSMutableString *strNew = [NSMutableString string];
        Byte *buff    =  malloc(strName.length/2);
        for (int i=0; i<strName.length/2; i++) {
            NSString *subString = [strName substringWithRange:NSMakeRange(i*2, 2)];
            buff[i]             = subString.IntString.integerValue;
            [strNew appendFormat:@"%c",buff[i]];
        }
        NSData *data = [NSData dataWithBytes:buff length:strName.length/2];
        NSLog(@"%@", [[NSString alloc] initWithData:data encoding:enc]);
        [labMuicName setText:[[NSString alloc] initWithData:data encoding:enc]];
    }
}


//将未出现键值的按钮 变灰
- (void)disable:(UIView *)view ifString:(NSString *)str notContainIn:(NSArray *)aryDefaultKey {
    BOOL isContained = false;
    for (ControlDeviceContentValueKey *key in aryDefaultKey) {
        if ([key.name isEqualToString:str]) {
            isContained = true;break;
        }
    }
    if (!isContained) {
        view.alpha = 0.5f;
        view.userInteractionEnabled = NO;
    }
}

//得到自定义的按钮名称
- (NSArray *)getCustomeNameWith:(NSArray *)keys {
    NSArray *aryDefaultName    = [NSArray arrayWithObjects: @"开", @"关", @"静音",
                                                            @"上一曲", @"暂停", @"播放", @"下一曲",
                                                            @"AUX1", @"FM", @"MP3",@"AUX2", nil];
    NSMutableArray *aryCustome = [NSMutableArray array];
    for (ControlDeviceContentValueKey *key in keys) {
        BOOL isCustome = true;
        for (NSString *str in aryDefaultName) {
            if ([str isEqualToString:key.name]) {
                isCustome = false;
            }
        }
        if (isCustome && ![key.name myContainsString:@"bw"] && ![key.name myContainsString:@"音量"]) {
            [aryCustome addObject:key.name];
            
        }
    }
    return aryCustome;
}
@end
