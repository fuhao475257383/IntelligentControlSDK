//
//  FXW_SingleCondition.m
//  BWRemoter
//
//  Created by 6602_Loop on 15-3-7.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "FXW_SingleCondition.h"
#import "FXW_ScrollView.h"
#import "FXW_AlertForInfrared.h"
#import "CYM_Engine.h"
#import "HE_CustemExtend.h"

#define ScreenSize       [UIScreen mainScreen].bounds.size
#define COLOR_SELECTED   [UIColor colorWithRed:110/255.0f green:220/255.0f blue:80/255.0f alpha:1]
#define BTN_MARGIN       ScreenSize.width * 0.14
#define BTN_WIDTH        ScreenSize.width * 0.29
#define BTN_HEIGTH       35
#define BTN_HEIGTH_S     55
#define BOTOM_VIEW_H     60
#define TAG_BUTTON       1000000
#define TAG_ALERT_NEW    100001
#define TAG_ALERT_EDIT   100002


@interface FXW_SingleCondition() <alertDelegate>{
    //////////Sate
    BOOL            isBeginStudy;               //按下"红外学习"按钮。 进入红外学习模式
    BOOL            isStudyMode;                //可以进行红外学习
    BOOL            isModifed;                  //判断是否进行了更改
    BOOL            isFristUpate;
    //////////Data
    NSMutableArray *aryDefaultName;             //默认存在的 控制按钮名称
    NSMutableArray *aryCustomeName;             //算法计算   用户自定义的控制按钮
    NSMutableArray *aryStudedIndex;             //数据库查询 该控制器 已学习的索引(十进制) -- 用于判断 剩余索引值
    //////////////  aryKey                      //自身已学习的Key数组  ------  转为 NSMutableArray
    NSMutableArray *aryStudedKey;
    
    /////////DataSoures
    NSMutableArray *aryNeedDrawName;            //算法计算   需要绘制的按钮
    /////////Views
    UIScrollView   *mainScroll;                 //主 滑动视图
    UIView         *bottomView;                 //底部红外学习视图
    UIButton       *btnPlus;                    //添加按钮
    UIButton       *btnStudy;
    UIButton       *btnEndStudy;
}
@end

@implementation FXW_SingleCondition

-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];

    return self;
}

-(void)setAttrWithCtrlValue:(ControlDeviceContentValue *)val{
    [super setAttrWithCtrlValue:val];
    
    ///////////////Data Array Init
    aryDefaultName   = [NSMutableArray arrayWithObjects:@"开" ,@"关",@"风速+",@"上下排风",@"风速-",@"左右排风",@"除湿", nil];
    if (deviceType == A4_DEVICE_AIR_CONDITION) {
        aryDefaultName   = [NSMutableArray arrayWithObjects:@"开" ,@"关",@"高速",@"中速",@"低速",@"送风",@"除湿", nil];
    }
    aryStudedIndex   = [self getDeviceStudedIndex:self.name];//[CYM_Engine getContrlKeyWithValueID:self.ID];
    aryStudedKey     = [CYM_Engine getContrlKeyWithValueName:self.name];//[NSMutableArray arrayWithArray:aryKey];
    aryCustomeName   = [self getCustomeWithDefault:aryDefaultName Studed:aryStudedKey];
    aryKey           = aryStudedKey;
    aryNeedDrawName  = [NSMutableArray array];
    isFristUpate     = YES;
    

    for (id obj in aryDefaultName) {
        [aryNeedDrawName addObject:obj];
    }
    for (id obj in aryCustomeName) {
        [aryNeedDrawName addObject:obj];
    }
    //////////////滑动视图
    mainScroll = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, self.frameW, self.frameH)];
    [self initScrollContent];
    
    [self addSubview:mainScroll];
}

-(void)initScrollContent{
    NSInteger defaultIndex  = 0;
    CGFloat   contentHeight = 0.f;
    ///////////////Button     - 开/关
    UIButton *btnSwithOn  = [self getButtonWithIndex:defaultIndex++ defaultAry:aryNeedDrawName studedAry:aryStudedKey];
    UIButton *btnSwithOff = [self getButtonWithIndex:defaultIndex++ defaultAry:aryNeedDrawName studedAry:aryStudedKey];
    [btnSwithOn setFrame:CGRectMake(BTN_MARGIN * 0.6, 10, BTN_WIDTH*1.2, BTN_HEIGTH*1.7)];
    [btnSwithOff setFrame:CGRectMake(btnSwithOn.frameSumX_W + BTN_MARGIN, btnSwithOn.frameY, BTN_WIDTH*1.2, BTN_HEIGTH*1.7)];
    
    
    ///////////////ScrollView - 温度
    _scrollTemperature = [[FXW_ScrollView alloc]initWithFrame:CGRectMake(10, btnSwithOff.frameSumY_H + 20, ScreenSize.width - 20, 120) andMaxVal:30 andMinVal:16 andDefaultValue:18];
    _scrollTemperature.sdelegate = self;
    contentHeight = _scrollTemperature.frameSumY_H;
    //////////////Button     -  绘制按钮\和添加按钮
    CGRect rectPlusButton      = [self drawDeviceButton:defaultIndex needAry:aryNeedDrawName andY:contentHeight];
    btnPlus          = [[UIButton alloc] initWithFrame:rectPlusButton];
    btnPlus.hidden   = YES;
    btnPlus.layer.cornerRadius = 5.f;
    btnPlus.layer.borderWidth  = 1.f;
    btnPlus.layer.borderColor  = [UIColor grayColor].CGColor;
    btnPlus.titleLabel.font    = [UIFont systemFontOfSize:35.F];
    [btnPlus setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [btnPlus setTitleColor:[UIColor greenColor] forState:UIControlStateHighlighted];
    [btnPlus setTitleColor:[UIColor greenColor] forState:UIControlStateSelected];
    [btnPlus setTitle:@"+" forState:UIControlStateNormal];
    [btnPlus setTitleEdgeInsets:UIEdgeInsetsMake(0, 0, 8, 0)];
    [btnPlus addTarget:self action:@selector(touchedAddButton:) forControlEvents:UIControlEventTouchUpInside];
    
    [mainScroll addSubview:btnSwithOn];
    [mainScroll addSubview:btnSwithOff];
    [mainScroll addSubview:_scrollTemperature];
    [mainScroll addSubview:btnPlus];
    
    contentHeight = btnPlus.frameSumY_H;
    [mainScroll setContentSize:CGSizeMake(ScreenSize.width, contentHeight)];
}


#pragma mark 进入红外学习模式
- (void)enterStudyMode{
    mainScroll.frame = CGRectMake(0, 0, self.frameW, self.frameH - (BOTOM_VIEW_H + 10));
    btnPlus.hidden   = NO;
    isStudyMode      = YES;
    /////////////红外学习视图
    bottomView = [[UIView alloc] initWithFrame:CGRectMake(10, mainScroll.frameSumY_H + 5, self.frameW - 20.f, BOTOM_VIEW_H)];
    bottomView.layer.cornerRadius = 8.f;
    bottomView.layer.borderWidth  = 1.f;
    bottomView.layer.borderColor  = [UIColor grayColor].CGColor;
    ///1.开始学习按钮
    btnStudy                    = [[UIButton alloc] initWithFrame:CGRectMake(5, 5, BTN_WIDTH, BTN_HEIGTH_S)];
    btnStudy.titleLabel.font    = [UIFont boldSystemFontOfSize:15.f];
    [btnStudy setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [btnStudy setTitleColor:COLOR_SELECTED forState:UIControlStateHighlighted];
    [btnStudy setTitleColor:COLOR_SELECTED forState:UIControlStateSelected];
    [btnStudy setBackgroundImage:[UIImage imageNamed:@"tv_backGround2.png"] forState:UIControlStateNormal];
    [btnStudy setBackgroundImage:[UIImage imageNamed:@"tv_backGround2.png"] forState:UIControlStateHighlighted];
    [btnStudy setTitle:@"红外学习" forState:UIControlStateNormal];
    [btnStudy addTarget:self action:@selector(touchedStudyMode:) forControlEvents:UIControlEventTouchUpInside];
    
    ///2.结束学习按钮
    btnEndStudy                    = [[UIButton alloc] initWithFrame:CGRectMake(btnStudy.frameSumX_W + 5, btnStudy.frameY, BTN_WIDTH, BTN_HEIGTH_S)];
    btnEndStudy.titleLabel.font    = [UIFont boldSystemFontOfSize:15.f];
    [btnEndStudy setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [btnEndStudy setTitleColor:COLOR_SELECTED forState:UIControlStateHighlighted];
    [btnEndStudy setTitleColor:COLOR_SELECTED forState:UIControlStateSelected];
    [btnEndStudy setBackgroundImage:[UIImage imageNamed:@"tv_backGround2.png"] forState:UIControlStateNormal];
    [btnEndStudy setBackgroundImage:[UIImage imageNamed:@"tv_backGround2.png"] forState:UIControlStateHighlighted];
    [btnEndStudy setTitle:@"结束学习" forState:UIControlStateNormal];
    [btnEndStudy addTarget:self action:@selector(touchedEndStudy:) forControlEvents:UIControlEventTouchUpInside];
    
    ///3.模式选择DD
    
    
    [bottomView addSubview:btnStudy];
    [bottomView addSubview:btnEndStudy];
    
    [self addSubview:bottomView];
}

#pragma mark -
#pragma mark 控制器Action
///////////////FXW_ScrollView 事件
-(void)sendMsgwithNum:(NSInteger)temperature isMakeCold:(BOOL)isCold{
    NSString *strName = [NSString stringWithFormat:@"%@%ld℃",isCold?@"制冷":@"制热" ,(long)temperature];
    //////执行按钮事件
    [self dealWithActionWithName:strName Button:nil];
}

-(void)sendMsgwithMode:(BOOL)isCold{
    NSString *strName = [NSString stringWithFormat:@"%@",isCold?@"制冷":@"制热"];
    //////执行按钮事件
    [self dealWithActionWithName:strName Button:nil];
}
//////////////控制器按钮单击事件
- (void)touchedButtonClick:(UIButton *)sender{
    //////执行按钮事件
    NSString *strName  = sender.titleLabel.text;
    BOOL      isStuded =  NO;
    if ([strName isEqualToString:@"风速+"]) {
        strName = @"风速加";
    }
    if ([strName isEqualToString:@"风速-"]) {
        strName = @"风速减";
    }
    
    for (ControlDeviceContentValueKey *k in aryStudedKey) {
        if ([k.name isEqualToString:strName]) {
            isStuded = YES;
            break;
        }
    }
    ///改变灰色按钮 颜色
    if (!isStuded && isBeginStudy) {
        sender.alpha = 1;
    }
    [self dealWithActionWithName:strName Button:sender];
}

/////////////学习某个按钮
- (void)dealWithActionWithName:(NSString *)strName Button:(UIButton *)button{
    //////////若为演示模式
    if ([[HE_APPManager sharedManager] netState] == NET_DEMO) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            NSArray *allViews = [mainScroll subviews];
            for (UIView *v in allViews) {
                /////////////按钮
                if ([v isKindOfClass:[UIButton class]]) {
                    if([((UIButton *)v).titleLabel.text isEqualToString:strName]){
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [((UIButton *)v) setSelected:YES];
                        });
                    }
                    else{
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [((UIButton *)v) setSelected:NO];
                        });
                    }
                }
            }
        });
        return;
    }
    
    /////////如果为空调控制器类型
    if (deviceType == A4_DEVICE_AIR_CONDITION) {
        //////////////写上空调控制器的操作列表
        NSString *strBackCMD        = [[HE_APPManager sharedManager] dicRoomDeviceState][self.num];
        NSString *strDataWithoutNum = [cmdP getDataWithoutNum:strBackCMD];
        NSMutableArray *aryOp = [NSMutableArray arrayWithObjects:@"开", @"关",
                          @"制冷", @"制热", @"除湿",
                          @"自动", @"睡眠", @"送风",
                          @"低速", @"中速", @"高速",
                          @"制热16℃", @"制热17℃", @"制热18℃", @"制热19℃", @"制热20℃", @"制热21℃", @"制热22℃", @"制热23℃", @"制热24℃", @"制热25℃",
                          @"制热26℃", @"制热27℃", @"制热28℃", @"制热29℃", @"制热30℃",
                          @"制冷16℃", @"制冷17℃", @"制冷18℃", @"制冷19℃", @"制冷20℃", @"制冷21℃", @"制冷22℃", @"制冷23℃", @"制冷24℃", @"制冷25℃",
                          @"制冷26℃", @"制冷27℃", @"制冷28℃", @"制冷29℃", @"制冷30℃",nil];
        NSInteger index = 0;
        BOOL      isNotFound = YES;
        for (NSString *s in aryOp) {
            if ([s isEqualToString:strName]) {
                index = [aryOp indexOfObject:s];
                isNotFound = NO;
                break;
            }
        }
        if (isNotFound) {
            [[HE_APPManager sharedManager] hudShowMsg:@"错误操作" andInterval:1.5];
            return;
        }
        NSLog(@"将操作: %@, 实操作:%@",strName, aryOp[index]);
        NSString *strData = [NSString stringWithFormat:@"%@%@",self.num, strDataWithoutNum];
        switch (index) {
            case 0:{///开
                strData = [cmdB airConditionMode:@"03" WithData:strData];
            }break;
            case 1:{///关
                strData = [cmdB airConditionMode:@"00" WithData:strData];
            }break;
            case 2:{///制冷
                strData = [cmdB airConditionMode:@"01" WithData:strData];
            }break;
            case 3:{///制热
                strData = [cmdB airConditionMode:@"02" WithData:strData];
            }break;
            case 4:{///除湿
                strData = [cmdB airConditionMode:@"05" WithData:strData];
            }break;
            case 5:{///自动
                strData = [cmdB airConditionMode:@"03" WithData:strData];
            }break;
            case 6:{///睡眠
            }break;
            case 7:{///送风
                strData = [cmdB airConditionMode:@"04" WithData:strData];
            }break;
            case 8:{///低速
                strData = [cmdB airConditionWindSpeed:@"01" WithData:strData];
            }break;
            case 9:{///中速
                strData = [cmdB airConditionWindSpeed:@"02" WithData:strData];
            }break;
            case 10:{///高速
                strData = [cmdB airConditionWindSpeed:@"03" WithData:strData];
            }break;
            default:{///温度
                NSString *strOpear  = [aryOp[index] componentsSeparatedByString:@"℃"][0];
                if ([strOpear myContainsString:@"制热"]) {
                    strOpear = [strOpear componentsSeparatedByString:@"制热"][1];
                }
                if ([strOpear myContainsString:@"制冷"]) {
                    strOpear = [strOpear componentsSeparatedByString:@"制冷"][1];
                }
                strData   = [cmdB airConditionTemperature:[NSString stringWithFormat:@"%02X",strOpear.intValue*2]
                                                 WithData:[NSString stringWithFormat:@"%@%@",self.num, strDataWithoutNum]];
            }break;
        }
        NSString *strCMD = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType Data:strData];
        NSString *strMsg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:strCMD];
        [[HE_APPManager sharedManager] SendMsg:strMsg withNameSpace:@"control" isShowLoading:[self isNeedShowLoading:strMsg]];
        return;
    }
    
    //////////ZigBee IO
    if (deviceType == A4_DEVICE_IO) {
        NSString *strTMP = [strName isEqualToString:@"开"]?@"0300":@"0200";
        NSString *strData= [NSString stringWithFormat:@"%@%@",num,strTMP];
        NSString *strCMD = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType Data:strData];
        NSString *strMsg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:strCMD];
        [[HE_APPManager sharedManager] SendMsg:strMsg withNameSpace:@"control" isShowLoading:[self isNeedShowLoading:strMsg]];
        return;
    }
    //////////数据透传
    if (deviceType == A4_DEVICE_UART) {
        ControlDeviceContentValueKey *key = [self getValueKeyForName:strName withArray:aryKey];
        if ([key.value isNotEmptyAndNil]) {
            NSString *cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType
                                    Data:[NSString stringWithFormat:@"%@%02X%@",self.num, (int)key.value.length/2,key.value]];
            NSString *msg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:cmd];
            [[HE_APPManager sharedManager] SendMsg:msg withNameSpace:@"control" isShowLoading:[self isNeedShowLoading:msg]];
            /////如果有查询。需要发送则发送查询命令
            if([key.query isNotEmptyAndNil]  && ![key.query isEqualToString:@"null"]){
                NSString *cmdQuery = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType
                                                  Data:[NSString stringWithFormat:@"%@%02X%@",self.num, (int)key.query.length/2,key.query]];
                NSString *msgQuery = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:cmdQuery];
                // 延时发送查询消息
                NSTimeInterval time = key.time.doubleValue / 1000;
                [[HE_APPManager sharedManager] SendQueryMsg:msgQuery withNameSpace:@"control" after:time];
            }
        }
        else{
            [[HE_APPManager sharedManager] hudShowMsg:@"该键不存在" andInterval:1.];
        }
        return;
    }
    //////////三方设备
    if (deviceType == A4_DEVICE_THREE) {
        ControlDeviceContentValueKey *key = [self getValueKeyForName:strName withArray:aryKey];
        if ([key.value isNotEmptyAndNil]) {
            NSString *cmd = key.value;
            NSString *msg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:cmd];
            [[HE_APPManager sharedManager] SendMsg:msg withNameSpace:@"control" isShowLoading:[self isNeedShowLoading:msg]];
            /////如果有查询。需要发送则发送查询命令
            if([key.query isNotEmptyAndNil]  && ![key.query isEqualToString:@"null"]){
                NSString *msgQuery = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:key.query];
                // 延时发送查询消息
                NSTimeInterval time = key.time.doubleValue / 1000;
                [[HE_APPManager sharedManager] SendQueryMsg:msgQuery withNameSpace:@"control" after:time];
            }
        }
        else{
            [[HE_APPManager sharedManager] hudShowMsg:@"该键不存在" andInterval:1.];
        }
        return;
    }
    
    ///////判断是否该键已学习
    BOOL      isStuded =  NO;
    ControlDeviceContentValueKey *opKey;
    for (ControlDeviceContentValueKey *k in aryStudedKey) {
        if ([k.name isEqualToString:strName]) {
            isStuded = YES;
            opKey = k;
            break;
        }
    }
    //////未找到相等、则找相似的
//    if (isStuded == NO) {
//        for (ControlDeviceContentValueKey *k in aryStudedKey) {
//            if ([strName myContainsString:k.name] || [k.name myContainsString:strName]) {
//                isStuded = YES;
//                opKey = k;
//                NSLog(@"相似:%@, 原:%@",k.name, strName);
//                break;
//            }
//        }
//    }
    //1. 控制
    NSLog(@"处理: %@",strName);
    if (isStuded && !isBeginStudy) {
        //1.1 找到Value
        NSString *strMsg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:opKey.value];
        NSLog(@"找到的value %@",opKey.value);
        [[HE_APPManager sharedManager] SendMsg:strMsg withNameSpace:@"control" isShowLoading:[self isNeedShowLoading:strMsg]];
    }
    //2.学习 -- 从 剩余索引值数组 取得索引
    else if (isBeginStudy){
        ////2.1.得到索引后、 加入aryStudedIndex, 和aryStudedKey数组
        isModifed = YES;
        NSString *studingHexIndex;
        
        /////如果为已学习则直接发送 已学习的键值
        if (isStuded) {
            studingHexIndex = [opKey.value substringWithRange:NSMakeRange(19, 3)];
        }
        else{
            studingHexIndex = [self getMinUnusedIndexWithAry:aryStudedIndex];
            if ([studingHexIndex IntString].intValue > 999){
                [[HE_APPManager sharedManager] hudShowMsg:@"1000个键值已用完" andInterval:1.0];
                ///////则把刚刚变亮的按钮、变灰
                button.alpha = 0.4;
                return;
            }
        }
        //2.2构造学习消息
        NSString *strData     = [NSString stringWithFormat:@"%@%@%@",num, @"8",studingHexIndex];
        NSString *strCMD      = [cmdB getCMDWithAction:A4_ACTION_SIGNAL_STUDY DeviceType:A4_DEVICE_MUTIL Data:strData];
        NSString *strMsg      = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:strCMD];
        NSLog(@"构造好的学习CMD%@",strCMD);
        //2.3构造控制消息
        NSString *strCtrlData = [NSString stringWithFormat:@"%@FF%@%@", num,@"8", studingHexIndex];
        NSString *strCtrlCMD  = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:A4_DEVICE_MUTIL Data:strCtrlData];
        NSLog(@"构造好的控制CMD%@",strCtrlCMD);
        
        [[HE_APPManager sharedManager] SendMsg:strMsg withNameSpace:@"control" isShowLoading:/*[self isNeedShowLoading:strMsg]*/NO];
        ////////修改内存
        
        if (isStuded) {///已学习按钮不做 改变
            //
        }
        else{///未曾学习过的按钮-> 新增
            opKey = [[ControlDeviceContentValueKey alloc] init];
            opKey.name   = strName;
            opKey.value  = strCtrlCMD;
            opKey.time   = @"null";
            opKey.query  = @"null";
            opKey.backkey= @"null";
            [aryStudedKey addObject:opKey];
            [aryStudedIndex addObject:studingHexIndex.IntString];
            aryStudedIndex = [self orderAscWithArry:aryStudedIndex];
        }
        
        [[HE_APPManager sharedManager] hudShowMsg:[NSString stringWithFormat:@"开始学习'%@' 索引:%@",strName, studingHexIndex] andInterval:1.0];
    }
    else{
        [[HE_APPManager sharedManager] hudShowMsg:@"该键未学习" andInterval:.5];
    }
}
/////////////控制器按钮长按事件
- (void)longPressEditName:(UILongPressGestureRecognizer *)longPress{
    /////////////////1.为默认按钮 则 长按不响应任何事件
    UIButton *btnSender = (UIButton *)longPress.view;
    for (NSString* s in aryDefaultName) {
        if ([btnSender.titleLabel.text isEqualToString:s]) {
            return;
        }
    }
    ////////////////2.否则 响应长按手势开始动作
    if (longPress.state == UIGestureRecognizerStateBegan && isStudyMode == YES) {
        FXW_AlertForInfrared *alert = [[FXW_AlertForInfrared alloc] init];
        [alert setTitle:@"编辑按钮" andAlertType:FXWAlertTypeEdit];
        [alert setDefaultName:btnSender.currentTitle];
        [alert setSender:btnSender];
        [alert setAlertDelegate:self];
        [alert setTag:TAG_ALERT_EDIT];
        [self addSubview:alert];
    }
}

/////////////控制器按钮 新增事件
- (void)touchedAddButton:(UIButton *)sender{
  //  [_scrollTemperature setValue:20 isAnimate:YES];
    ///////////////添加一个按钮
    FXW_AlertForInfrared *alert = [[FXW_AlertForInfrared alloc] init];
    [alert setTitle:@"添加按钮" andAlertType:FXWAlertTypeAdd];
    [alert setSender:sender];
    [alert setAlertDelegate:self];
    [alert setTag:TAG_ALERT_NEW];
    [self addSubview:alert];
}

- (void)updateTheDeviceStateWithData:(NSString *)strData{
    if (deviceType == A4_DEVICE_AIR_CONDITION) {
        NSString *strTitleMode  = @"x";
        NSString *strTitleSpeed = @"x";
        /////////1.工作模式反馈
        NSString *strMode = [strData substringWithRange:NSMakeRange(0, 2)];
        switch (strMode.IntString.intValue) {
            case 0://关
                strTitleMode = @"关";
                break;
            case 1://制冷
                strTitleMode = @"制冷";
                break;
            case 2://制热
                strTitleMode = @"制热";
                break;
            case 3://自动/开
                strTitleMode = @"自动";
                break;
            case 4://送风
                strTitleMode = @"送风";
//                strTitleMode   = @"上下排风";
                break;
            case 5://除湿
                strTitleMode = @"除湿";
                break;
            default://自动 03
                strTitleMode = @"开";
                break;
        }
        /////////3.风速反馈
        NSString *strSpeed = [strData substringWithRange:NSMakeRange(4, 2)];
        switch (strSpeed.IntString.intValue) {
            case 1://低速
                strTitleSpeed = @"低速";
//                strTitleSpeed   = @"风速-";
                break;
            case 2://中速
                strTitleSpeed = @"中速";
//                strTitleSpeed   = @"左右排风";
                break;
            case 3://高速
                strTitleSpeed = @"高速";
//                strTitleSpeed   = @"风速+";
                break;
            default://中速 2
                strTitleSpeed = @"中速";
//                strTitleSpeed   = @"左右排风";
                break;
        }
        ////制冷/热反馈
        if ([strTitleMode isEqualToString:@"制冷"]) {
            [_scrollTemperature setMode:true];
        }
        else if ([strTitleMode isEqualToString:@"制热"]){
            [_scrollTemperature setMode:false];
        }
        else{
            NSArray *aryAllViews = [mainScroll subviews];
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                for (UIView *v in aryAllViews) {
                    //////////按钮反馈
                    if ([v isKindOfClass:[UIButton class]]) {
                        //     UIColor *backColor = [UIColor clearColor];
                        if ([((UIButton*)v).titleLabel.text isEqualToString:strTitleMode] ||
                            [((UIButton*)v).titleLabel.text isEqualToString:strTitleSpeed]) {
                            dispatch_async(dispatch_get_main_queue(), ^{
                                ((UIButton *)v).selected = YES;
                            });
                        }
                        else{
                            dispatch_async(dispatch_get_main_queue(), ^{
                                ((UIButton *)v).selected = NO;
                            });
                        }
                    }
                }
            });
        }
        /////////4.温度反馈
        CGFloat tmp = [[[strData substringWithRange:NSMakeRange(6, 2)] IntString] integerValue]/2.f;
        [_scrollTemperature setValue:(NSInteger)tmp isAnimate:YES];
        
        if (!isFristUpate) {
            [self showHint:@"操作成功"];
        }
        isFristUpate = NO;
        NSLog(@"反馈：%@%@%lf",strTitleMode,strTitleSpeed, tmp);
        return;
    }
    
    if (deviceType == A4_DEVICE_IO) {
        NSString *strState = [strData substringToIndex:2];
        UIButton *btnOn    = [mainScroll viewWithTag:TAG_BUTTON];
        UIButton *btnOff   = [mainScroll viewWithTag:TAG_BUTTON+1];
        if ([strState isEqualToString:@"02"]) {
            btnOff.selected = YES;
            btnOn.selected  = NO;
        }
        else{
            btnOff.selected = NO;
            btnOn.selected  = YES;
        }
        return;
    }
    
    /***************      由于单体空调 属于多功能控制器      ****************/
    //***           其反馈在其aryKey中必有其"控制消息"记录                **//
    if (deviceType == A4_DEVICE_MUTIL || deviceType == A4_DEVICE_UART || deviceType == A4_DEVICE_THREE) {
        /////////////多线程中得出反馈
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(){
            for (ControlDeviceContentValueKey *k in aryKey) {
                ////////有此反馈
                if ([[strData substringFromIndex:2] isEqualToString:[[cmdP getDataWithoutNum:k.value] substringFromIndex:2]]) {
                    NSLog(@"反馈：%@",k.name);
                    dispatch_async(dispatch_get_main_queue(), ^{
                        if (!isFristUpate) {
                            [self showHint:@"操作成功"];
                        }
                        isFristUpate = NO;
                    });
                    ////////////////1.滑竿温度反馈
                    if ([k.name myContainsString:@"℃"]) {
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [_scrollTemperature setValue:[[k.name substringWithRange:NSMakeRange(2, 2)] integerValue] isAnimate:YES];
                        });
                    }
                    else if([k.name isEqualToString:@"制冷"]){
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [_scrollTemperature setMode:true];
                        });
                    }
                    else if ([k.name isEqualToString:@"制热"]){
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [_scrollTemperature setMode:false];
                        });
                    }
                    ////////////////2.按钮反馈
                    else{
                        NSLog(@"name: %@", k.name);
/////////////////////////////Now  7.9
                        NSArray *allViews = [mainScroll subviews];
                        NSArray *allBackName = [self parseTxt:k.name];
                        for(NSString *tmpName in allBackName){
                            for (UIView *v in allViews) {
                                if([v isKindOfClass:[UIButton class]]){
                                    NSString *btnTitle = ((UIButton *)v).titleLabel.text;
                                    if ([btnTitle isEqualToString:@"风速-"]) {
                                        btnTitle = @"风速减";
                                    }
                                    if ([btnTitle isEqualToString:@"风速+"]) {
                                        btnTitle = @"风速加";
                                    }
                                    
                                    if ([btnTitle isEqualToString:tmpName]) {
                                        dispatch_async(dispatch_get_main_queue(), ^{
                                            ((UIButton *)v).selected = YES;
                                        });
                                    }
                                    else if (![allBackName isContainsStringObj:btnTitle]){
                                        dispatch_async(dispatch_get_main_queue(), ^{
                                            ((UIButton *)v).selected = NO;
                                        });
                                    }
                                }
                            }
                        }
///////////////////////////pre 7.9
//                        for (UIView *v in allViews) {
//                            if([v isKindOfClass:[UIButton class]]){
//                                if ([((UIButton *)v).titleLabel.text isEqualToString:k.name]) {
//                                    dispatch_async(dispatch_get_main_queue(), ^{
//                                        ((UIButton *)v).selected = YES;
//                                    });
//                                }
//                                else{
//                                    dispatch_async(dispatch_get_main_queue(), ^{
//                                        ((UIButton *)v).selected = NO;
//                                    });
//                                }
//                            }
//                        }
                    }
                    break;
                }
            }
        });
        return;
    }
}

////////////Delegate
- (void)alertView:(FXW_AlertForInfrared *)alertView
        inputText:(NSString *)aText
       actionType:(FXWAlertActionType)type
     andBtnSender:(UIButton *)btn{
    /////////////////按钮名称重复
    if (type != FXWAlertActionDelete && [self isRepateKeyNameWithStudedKey:aryStudedKey andName:aText]) {
        [[HE_APPManager sharedManager] hudShowMsg:@"按钮名称重复" andInterval:2.];
        return;
    }
    
//    if ([aText isEqualToString:@""]) {
//        [[HE_APPManager sharedManager] hudShowMsg:@"按钮名称不能为空" andInterval:1.0];
//        return;
//    }
    if (alertView.tag == TAG_ALERT_NEW && type == FXWAlertActionSave) {
        [aryCustomeName addObject:aText];
        [aryNeedDrawName addObject:aText];
        CGRect rectFrame = [self drawDeviceButton:aryNeedDrawName.count - 1 needAry:aryNeedDrawName andY: _scrollTemperature.frameSumY_H];
        [btnPlus setFrame:rectFrame];
        [mainScroll setContentSize:CGSizeMake(ScreenSize.width, btnPlus.frameSumY_H)];
//        [mainScroll setContentOffset:CGPointMake(0,  btnPlus.frameSumY_H - mainScroll.frameH ) animated:YES];
    }
    else if (alertView.tag == TAG_ALERT_EDIT){
        isModifed = YES;
        NSString *oldName = btn.titleLabel.text;
        ////更新数组数据
        if (type == FXWAlertActionSave) {
            [aryCustomeName setObject:aText atIndexedSubscript:[aryCustomeName indexOfObject:oldName]];
            [aryNeedDrawName setObject:aText atIndexedSubscript:[aryNeedDrawName indexOfObject:oldName]];
            for (ControlDeviceContentValueKey *k in aryStudedKey) {
                if (k.name == oldName) {
                    k.name = aText;
                    break;
                }
            }
            [btn setTitle:aText forState:UIControlStateNormal];
        }
        else if (type == FXWAlertActionDelete){
            NSInteger indx = [aryNeedDrawName indexOfObject:oldName];
            for (ControlDeviceContentValueKey *k in aryStudedKey) {
                if (k.name == oldName) {
                    [aryStudedKey removeObject:k];
                    break;
                }
            }
            [btn removeFromSuperview];
            ///////将该Btn之后的所有Btn Tag -1
            for (NSInteger i=indx+1; i<aryNeedDrawName.count; i++) {
                UIView *v = [mainScroll viewWithTag:TAG_BUTTON + i ];
                v.tag     = TAG_BUTTON + i - 1;
            }
            [aryCustomeName removeObject:oldName];
            [aryNeedDrawName removeObject:oldName];
            CGRect rectFrame = [self drawDeviceButton:indx  needAry:aryNeedDrawName andY: _scrollTemperature.frameSumY_H];
            [btnPlus setFrame:rectFrame];
            
        }
    }
}

#pragma mark 红外学习
- (void)touchedStudyMode:(UIButton *)sender{
    sender.selected      = YES;
    isBeginStudy          = YES;
    btnEndStudy.selected = NO;
}
- (void)touchedEndStudy:(UIButton *)sender{
    if(isBeginStudy == YES ){
        [self performSelector:@selector(showHint:) withObject:@"操作成功" afterDelay:.7];
    }
    isBeginStudy          = NO;
    sender.selected      = YES;
    btnStudy.selected    = NO;
}
//////////////////保存更改到网关
- (void)saveAsStateToGateway{
    if (isModifed) {
        ///////////1.更新至数据库
        [CYM_Engine updateContrlValueKeys:aryStudedKey ValueName:self.name];
        ///////////2.上传至网关
        NSData *roomData = [CYM_Engine generateJSONFileWithName:@"control.json"];
        [[HE_APPManager sharedManager] uploadFileWithName:@"control.json" andData:roomData isShowHUD:YES];
        NSLog(@"Save");
    }
}
#pragma mark Private Method
/////////////////计算 自定义的按钮名称 数组
- (NSMutableArray *)getCustomeWithDefault:(NSMutableArray *)aryDefault
                                   Studed:(NSMutableArray *)aryStuded{//存储当前已学习的KeyAry、 其中每个元素为ControlDeviceContentValueKey
    NSMutableArray *aryResult = [NSMutableArray array];
    
        for (ControlDeviceContentValueKey *k in aryStuded) {
            BOOL isCustome = YES;
            NSString *tmpName = k.name;
            if ([tmpName isEqualToString:@"风速减"]) {
                tmpName = @"风速-";
            }
            if ([tmpName isEqualToString:@"风速加"]) {
                tmpName = @"风速+";
            }
            for (NSString *s in aryDefault) {
                if ([tmpName isEqualToString:s] || [tmpName myContainsString:@"℃"]) {
                    isCustome = NO;
                    break;
                }
            }
            if ([tmpName isEqualToString:@"制冷"] || [tmpName isEqualToString:@"制热"] || [tmpName myContainsString:@"bw"]) {
                isCustome = NO;
            }
            
            /////////加入自定义
            if (isCustome) {
                [aryResult addObject:tmpName];
            }
        }
    return aryResult;
}
////////////////计算该设备 已学习的Key名称数组
- (NSMutableArray *)getStudedNameWithKey:(NSArray *)key{
    NSMutableArray *ary = [NSMutableArray array];
    for (ControlDeviceContentValueKey  *obj in key) {
        [ary addObject:obj.name];
    }
    return ary;
}
////////////////判断新增按钮是否重名
- (BOOL)isRepateKeyNameWithStudedKey:(NSArray *)aryStuedKey andName:(NSString *)aName{
    BOOL isRepated = NO;
    for (ControlDeviceContentValueKey *k in aryStuedKey) {
        if ([k.name isEqualToString:aName]) {
            isRepated = YES;break;
        }
    }
    return isRepated;
}
///////////////获取该多功能控制器  已学习的索引(十进制)
- (NSMutableArray *)getDeviceStudedIndex:(NSString *)muteDevName{
    NSMutableArray *aryIndex  = [NSMutableArray array];
    ControlDeviceContentValue *val = [CYM_Engine getDeviceDetailsWithDeviceName:muteDevName];
    NSArray        *aryAllKey = [CYM_Engine getCategoryAllKeyWithValue:val];
    ///1.获取到所有索引
    for (ControlDeviceContentValueKey *valueKey in aryAllKey) {
        if (valueKey.value.length >= 24) {////为一条正确的 多功能控制器的控制命令
            //////获取索引值---》转化为10进制
            NSString *hexString = [valueKey.value substringWithRange:NSMakeRange(19, 3)];
            [aryIndex addObject:hexString.IntString];
        }
    }
    ///2.升序排序
    aryIndex = [self orderAscWithArry:aryIndex];

    return aryIndex;
}
////////////////取得一个空闲索引(16进制)-aryUsed(为10进制字符)升序、则第一个不连续值、为最小空闲索引
- (NSString *)getMinUnusedIndexWithAry:(NSArray *)aryUsed{
    NSString  *strUnusedIndex = nil;
    NSInteger  idexCounter    = 0;
    
    ////////////如果没有学习过 返回索引0x00
    if (aryUsed == nil || aryUsed.count == 0) {
        idexCounter = 0;
        strUnusedIndex = [NSString stringWithFormat:@"%03lX",(long)idexCounter];
        return strUnusedIndex;
    }
    ///////////已学习
    for (NSString *s in aryUsed) {
        //////正常递增
        if (s.intValue == idexCounter || s.intValue == (idexCounter + 1)) {
            idexCounter = s.intValue;
        }
        //////找到间隙中未使用的Key
        else {///(int_s.intValue > (idexCounter + 1))
            idexCounter ++;
            strUnusedIndex = [NSString stringWithFormat:@"%03lX",(long)idexCounter];
            break;
        }
    }
    //2.全部都连续、取最后一个值+1.
    if (strUnusedIndex == nil) {
        NSString *s = [aryUsed lastObject];
        idexCounter = s.intValue + 1;
        strUnusedIndex = [NSString stringWithFormat:@"%03lX",(long)idexCounter];
    }
    return strUnusedIndex;
}
////////////////升序排序
- (NSMutableArray *)orderAscWithArry:(NSMutableArray *)ary{
    if (ary.count > 1) {
        for (int i=0; i< (ary.count - 1); i++) {
            int k = i;
            for (int j=i+1; j<ary.count; j++) {
                NSInteger ary_j = [ary[j] IntString].integerValue;
                NSInteger ary_k = [ary[k] IntString].integerValue;
                if (ary_j < ary_k) {
                    k = j;
                }
            }
            id tmp = ary[k];
            ary[k] = ary[i];
            ary[i] = tmp;
        }
    }    return ary;
}
////////////////绘制按钮  返回下一个BUtton Frame
- (CGRect)drawDeviceButton:(NSInteger)beginIndex
                 needAry:(NSArray *)aryName
                    andY:(CGFloat) beginY{
    
    for (; beginIndex < aryName.count; beginIndex ++) {
        //////先从视图上获取
        UIButton *btnTmp = (UIButton *)[mainScroll viewWithTag:beginIndex+TAG_BUTTON];
        if (btnTmp == nil) {
            btnTmp = [self getButtonWithIndex:beginIndex defaultAry:aryName studedAry:aryStudedKey];
        }
        [btnTmp setFrame:CGRectMake(BTN_MARGIN + beginIndex%2*(BTN_MARGIN + BTN_WIDTH), beginY + (beginIndex/2 - 1) * (BTN_HEIGTH + 20) + 20, BTN_WIDTH, BTN_HEIGTH)];
        [mainScroll addSubview:btnTmp];
        [btnTmp setTitleColor:[UIColor colorWithRed:110/255.0f green:220/255.0f blue:80/255.0f alpha:1] forState:UIControlStateSelected];
    }
    return CGRectMake(BTN_MARGIN + aryName.count%2*(BTN_MARGIN + BTN_WIDTH), beginY + (aryName.count/2 - 1) * (BTN_HEIGTH + 20) + 20, BTN_WIDTH, BTN_HEIGTH);
}
///////////////获取通用的Button
- (UIButton *)getButtonWithIndex:(NSInteger) btnindex
                      defaultAry:(NSArray *) aryDefault
                       studedAry:(NSArray *) aryStuded{//存储当前已学习的KeyAry、 其中每个元素为ControlDeviceContentValueKey
    UIButton *btnTmp          = [[UIButton alloc] init];
    
    btnTmp.tag                = btnindex + TAG_BUTTON;
    btnTmp.titleLabel.font    = [UIFont boldSystemFontOfSize:15.f];
    [btnTmp setTitle:aryDefault[btnindex] forState:UIControlStateNormal];
    [btnTmp setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    switch (btnindex) {
        case 0:
            [btnTmp setImage:[UIImage imageNamed:@"power_on_icon.png"] forState:UIControlStateNormal];
            [btnTmp setImage:[UIImage imageNamed:@"power_on_icon_H.png"] forState:UIControlStateSelected];
            break;
        case 1:
            [btnTmp setImage:[UIImage imageNamed:@"power_off_icon.png"] forState:UIControlStateNormal];
            [btnTmp setImage:[UIImage imageNamed:@"power_off_icon_H.png"] forState:UIControlStateSelected];
            break;
        default:
            [btnTmp setBackgroundImage:[UIImage imageNamed:@"icBtn_BackGroud.png"] forState:UIControlStateNormal];
            [btnTmp setBackgroundImage:[UIImage imageNamed:@"icBtn_BackGroud_H.png"] forState:UIControlStateHighlighted];
            [btnTmp setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
            break;
    }
    
    [btnTmp addTarget:self action:@selector(touchedButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPressEditName:)];
    longPress.minimumPressDuration          = 0.8;
    [btnTmp addGestureRecognizer:longPress];
    
    
    ////////////////////如果未学习该按钮则为灰色
    btnTmp.alpha = 0.5;
    for (ControlDeviceContentValueKey *valueKey in aryStuded) {
        NSString *tmpName = valueKey.name;
        if ([tmpName isEqualToString:@"风速减"]) {
            tmpName = @"风速-";
        }
        if ([tmpName isEqualToString:@"风速加"]) {
            tmpName = @"风速+";
        }
        
        if ([tmpName isEqualToString:aryDefault[btnindex]]) {
            ////////已学习。 改变其颜色
            btnTmp.alpha = 1;
        }
    }
    /////////若为空调控制器
    if (deviceType == A4_DEVICE_AIR_CONDITION) {
        btnTmp.alpha = 1;
    }
    /////////若为空调控制器
    if (deviceType == A4_DEVICE_IO &&
        ([aryDefault[btnindex] isEqualToString:@"开"] ||
         [aryDefault[btnindex] isEqualToString:@"关"])) {
        btnTmp.alpha = 1;
    }
    /////////若为演示模式
    if ([[HE_APPManager sharedManager] netState] == NET_DEMO) {
        btnTmp.alpha = 1;
    }
    return btnTmp;
}
@end
