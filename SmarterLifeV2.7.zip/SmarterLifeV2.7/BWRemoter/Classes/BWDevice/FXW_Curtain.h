//
//  FXW_Curtain.h
//  BWRemoter
//
//  Created by 6602_Loop on 14-12-14.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HE_UIDevice.h"
//typedef enum{
//    CurtainFrameTypeforRoom = 0,//房间
//    CurtainFrameTypeforHouse,//房型
//}CurtainFrameType;
typedef enum{
    CurtainCategoryTypeOpenClose = 0,//开合
    CurtainCategoryTypefUp_Down,//升降
}CurtainCategoryType;
@interface FXW_Curtain : HE_UIDevice
{
    NSString *strOnimg;
    NSString *strOffimg;
    NSString *type;
    BOOL isOn;
    NSInteger frame_Type;//1表示房间2表示房型
}

@property UILabel *labName;
@property UIButton *on;
@property UIButton *off;
@property UIImageView *image;

- (void)SetType:(NSString *)type;
-(void)setCategoryType:(CurtainCategoryType )categoryType andFrameType:(NSInteger)frameType;
@end
