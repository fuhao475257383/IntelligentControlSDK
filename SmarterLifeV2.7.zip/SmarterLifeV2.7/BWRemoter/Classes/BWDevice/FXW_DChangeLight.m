//
//  FXW_DChangeLight.m
//  BWRemoter
//
//  Created by 6602_Loop on 14-12-9.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "FXW_DChangeLight.h"

@implementation FXW_DChangeLight
@synthesize backImage;
@synthesize backImage2;
@synthesize labName;
@synthesize percent;
- (id)init{
    return [self initWithFrame:CGRectMake(0, 0, 1, 1)];
}

- (id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        if (backImage == nil) {
            backImage = [[UIImageView alloc]initWithFrame:CGRectMake(self.frame.size.width*0.05, 3, 0.7*self.frame.size.height , 0.7*self.frame.size.height)];
            backImage2 = [[UIImageView alloc]initWithFrame:CGRectMake(self.frame.size.width*0.45,self.frame.size.height*0.3, 0.5*self.frame.size.width , 0.6*self.frame.size.height)];
            labName = [[UILabel alloc] init];
            percent = [[UILabel alloc] init];
            
            [self addSubview:backImage];
            [self addSubview:backImage2];
            
        }
        strOffImg = @"ic_Light.png";
        strOnImg = @"ic_Light_H.png";
    }
    //灯 点击事件
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tiggleState)];
    [backImage addGestureRecognizer:tap];
    
    //滑块 滑动事件
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(touchedControlLightWith:)];
    [backImage2 addGestureRecognizer:pan];
    backImage2.userInteractionEnabled = true;
    
    // 滑块点击事件
    UITapGestureRecognizer *tapSlider = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(touchedControlLightWith:)];
    [backImage2 addGestureRecognizer:tapSlider];
    
    return self;
}

- (void)drawRect:(CGRect)rect {
    if(self.frame.size.width < 200){
        self.layer.cornerRadius = 5.f;//圆角s
    }
    else{
        self.layer.cornerRadius = 15.0f;
    }
    self.layer.borderColor = [[UIColor colorWithRed:200/255.0f green:200/255.0f blue:200/255.0f alpha:1] CGColor];//Border颜色
    self.layer.borderWidth = 1.f;//Border宽度
    [self setBackgroundColor:[UIColor whiteColor]];
    //背景 和  名称
    CGRect labFrame = rect;
    CGRect percentFrame = rect;
    labFrame.origin.y = rect.size.height * 0.75f;
    labFrame.origin.x = rect.size.width * 0.07f;
    labFrame.size.height = rect.size.height *0.25f;
    
    [labName setFont:[UIFont systemFontOfSize:12.f]];
    [labName setFrame:labFrame];
    [labName setTextAlignment:NSTextAlignmentLeft];
    
    percentFrame.size.height = rect.size.height *0.25f;
    percentFrame.origin.x=rect.size.width*0.45;
    percentFrame.origin.y=rect.size.height*0.1;
    [percent setFont:[UIFont systemFontOfSize:12.f]];
    [percent setFrame:percentFrame];
    [percent setTextAlignment:NSTextAlignmentLeft];
    [self addSubview:labName];
    [self addSubview:percent];
     backImage.userInteractionEnabled = YES;
    self.labName.numberOfLines = 0;
    self.labName.adjustsFontSizeToFitWidth = YES;
    self.clipsToBounds = YES;
}

- (void)tiggleState{
    if (isOn){
        [self turnTo:0];
    }
    else{
        [self turnTo:100];
    }
}

- (void)setName:(NSString *)str{
    [self setBackgroundColor:[UIColor whiteColor]];
    [labName setText:str];
    [backImage setImage:[UIImage imageNamed:strOffImg]];
    [backImage2 setImage:[UIImage imageNamed:@"0%.png"]];
}

- (void)touchedControlLightWith:(UIGestureRecognizer *)ges {
    CGPoint   location = [ges locationInView:ges.view];
    CGFloat   persent  = location.x / backImage2.frame.size.width;
    NSInteger postion  = [self toTenIntegerFor:persent];
    
    [self changeValueWith:postion];
    if (ges.state == UIGestureRecognizerStateEnded) {
        [self turnTo:[self toTenIntegerFor:persent]];
    }
}

- (void)changeValueWith:(NSUInteger)v {
    UIImage *img = [UIImage imageNamed:[NSString stringWithFormat:@"%lu%%.png", (unsigned long)v]];
    if (img) {
        backImage2.image = img;
    }
    percent.text = [NSString stringWithFormat:@"%lu%%", (unsigned long)v];
}

- (NSUInteger)toTenIntegerFor:(CGFloat)v {
    if (v < 0) {
        v = 0;
    } else if (v > 1) {
        v = 1;
    }
    return ((NSUInteger)(v*100) / 10 ) * 10;
}

- (void)turnTo:(NSInteger)val{
    NSString *cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType Data:[NSString stringWithFormat:@"%@%02lX",num,(long)val]];
    NSString *msg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:cmd];
    [[HE_APPManager sharedManager] SendMsg:msg withNameSpace:@"control" isShowLoading:[self isNeedShowLoading:msg]];

}
- (void)updateTheDeviceStateWithData:(NSString *)strData{
    
    NSString *endPoint = [strData IntString];
    if ([endPoint intValue] > 0) {
        isOn = true;
        [backImage setImage:[UIImage imageNamed:strOnImg]];
    }
    else{
        isOn = false;
        [backImage setImage:[UIImage imageNamed:strOffImg]];
    }
    [percent setText:[NSString stringWithFormat:@"%@%%",endPoint]];
    if (endPoint.longLongValue > 100) {
        endPoint = @"100";
    }
    else if (endPoint.longLongValue%10 > 0){
        endPoint = [NSString stringWithFormat:@"%lld", ((long long)(endPoint.longLongValue/10))*10];
    }
    [backImage2 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@%%.png",endPoint]]];
}
@end
