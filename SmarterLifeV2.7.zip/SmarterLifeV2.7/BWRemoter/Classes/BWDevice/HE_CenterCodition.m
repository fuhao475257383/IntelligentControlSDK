//
//  HE_CenterCodition.m
//  BWRemoter
//
//  Created by HeJianBo on 15/3/23.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "HE_CenterCodition.h"
#import "FXW_AlertForInfrared.h"
#import "CYM_Engine.h"
#import "HE_CustemExtend.h"
#import <objc/runtime.h>

#define ScreenSize       [UIScreen mainScreen].bounds.size
#define BTN_MARGIN_M     ScreenSize.width * 0.08
#define BTN_MARGIN_L     ScreenSize.width * 0.14
#define BTN_WIDTH        ScreenSize.width * 0.3
#define BTN_HEIGTH       80
#define BTN_HEIGTH_S     65
#define BOTOM_VIEW_H     60
#define TAG_BUTTON       1000000
#define TAG_ALERT_NEW    100001
#define TAG_ALERT_EDIT   100002

#define groupNum  1000

static char      kButtonType;

@interface HE_CenterCodition(){
    //////////Sate
    BOOL            isBeginStudy;               //按下"红外学习"按钮。 进入红外学习模式
    BOOL            isStudyMode;                //可以进行红外学习
    BOOL            isModifed;                  //判断是否进行了更改
    BOOL            isMakeHot;                  //是否为制冷
    BOOL            isFristUpate;
    //////////Data
    //
    NSString       *strDataWithoutNum;          //当前收到反馈的Data

    NSMutableArray *aryDefaultName;             //默认存在的 控制按钮名称
    NSMutableArray *aryCustomeName;             //算法计算   用户自定义的控制按钮
    NSMutableArray *aryStudedIndex;             //数据库查询 该控制器 已学习的索引(十进制) -- 用于判断 剩余索引值
    //////////////  aryKey                      //自身已学习的Key数组  ------  转为 NSMutableArray
    NSMutableArray *aryStudedKey;
    
    /////////Views
    UIScrollView   *mainScroll;                 //主 滑动视图
    UIView         *bottomView;                 //底部红外学习视图
    UIButton       *btnPlus;                    //添加按钮
    UIButton       *btnStudy;
    UIButton       *btnEndStudy;
    
    //////////Views 暂存
    UILabel *labTemperature;
    UISlider *sliderTemperature;
    UIImageView *imgViewSonw;
    NSMutableArray *aryCustomeBtn;              //已绘制的Btn
    CGFloat         defaultOffSetY;             //默认按钮的最后的SumY+H
}

@end

@implementation HE_CenterCodition
- (void)setAttrWithCtrlValue:(ControlDeviceContentValue *)val{
    [super setAttrWithCtrlValue:val];
    
    ///////////////Data Array Init
    aryDefaultName   = [NSMutableArray arrayWithObjects:@"开", @"关",
                        @"制冷", @"制热", @"除湿",
                        @"自动", @"睡眠", @"送风",
                        @"低速", @"中速", @"高速",nil];
    aryStudedIndex   = [self getDeviceStudedIndex:self.name];
    aryStudedKey     = [CYM_Engine getContrlKeyWithValueName:self.name];
    aryCustomeName   = [self getCustomeWithDefault:aryDefaultName Studed:aryStudedKey];
    aryKey           = aryStudedKey;
    isFristUpate     = YES;
    //////////////滑动视图
    mainScroll = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, self.frameW, self.frameH)];
    [self buildScrollContent];
    
    [self addSubview:mainScroll];
}

///////////////构建视图
- (void)buildScrollContent{
    int defaultIndex  = 0;
    ////////温度Lable 开关键
    labTemperature                = [[UILabel alloc] initWithFrame:CGRectMake(BTN_MARGIN_M + 10, 30, (ScreenSize.width - BTN_MARGIN_M*2)/2.f, 100)];
    labTemperature.textAlignment  = NSTextAlignmentCenter;
    labTemperature.font           = [UIFont boldSystemFontOfSize:40]; //[UIFont fontWithName:@"Helvetica-Bold" size:45];
    labTemperature.text           = @"23.0℃";
    
    UIButton *btnPowerOn  = [[UIButton alloc] initWithFrame:CGRectMake(labTemperature.frameSumX_W+BTN_MARGIN_M, labTemperature.frameY,
                                                                      (ScreenSize.width - BTN_MARGIN_M*3)/2.f, BTN_HEIGTH_S)];
    [btnPowerOn setImage:[UIImage imageNamed:@"power_on_icon.png"] forState:UIControlStateNormal];
    [btnPowerOn setImage:[UIImage imageNamed:@"power_on_icon_H.png"] forState:UIControlStateSelected];
    [btnPowerOn setTitle:aryDefaultName[defaultIndex] forState:UIControlStateNormal];
    [self enterManagerMode:btnPowerOn andTag:TAG_BUTTON+defaultIndex];
    [btnPowerOn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    defaultIndex++;
    
    
    UIButton *btnPowerOff = [[UIButton alloc] initWithFrame:CGRectMake(btnPowerOn.frameX, btnPowerOn.frameSumY_H,btnPowerOn.frameW, btnPowerOn.frameH)];
    [btnPowerOff setImage:[UIImage imageNamed:@"power_off_icon.png"] forState:UIControlStateNormal];
    [btnPowerOff setImage:[UIImage imageNamed:@"power_off_icon_H.png"] forState:UIControlStateSelected];
    [btnPowerOff setTitle:aryDefaultName[defaultIndex] forState:UIControlStateNormal];
    [self enterManagerMode:btnPowerOff andTag:TAG_BUTTON+defaultIndex];
    [btnPowerOff setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    defaultIndex++;
    
    [mainScroll addSubview:labTemperature];
    [mainScroll addSubview:btnPowerOn];
    [mainScroll addSubview:btnPowerOff];
    
    ///////温度滑动条 雪花
    sliderTemperature              = [[UISlider alloc] initWithFrame:CGRectMake(BTN_MARGIN_M + 20, btnPowerOff.frameSumY_H,
                                                                             (ScreenSize.width - 3*BTN_MARGIN_M) - BTN_HEIGTH_S, 30)];
    [sliderTemperature setMaximumTrackImage:[UIImage imageNamed:@"air_Condition_thub"] forState:UIControlStateNormal];
    [sliderTemperature setMinimumTrackImage:[UIImage imageNamed:@"air_Condition_thub"] forState:UIControlStateNormal];
    [sliderTemperature setThumbImage:[UIImage imageNamed:@"point.png"] forState:UIControlStateNormal];
    
    if (deviceType == A4_DEVICE_AIR_CONDITION) {
        sliderTemperature.maximumValue = 70.0;
        sliderTemperature.minimumValue = 32.0;
        sliderTemperature.value        = 46.f;
        labTemperature.text            = @"23.0℃";
    }
    else if (deviceType == A4_DEVICE_MUTIL){
        sliderTemperature.maximumValue = 30;
        sliderTemperature.minimumValue = 16;
        sliderTemperature.value        = 20;
        labTemperature.text            = @"20℃";
    }
    else if (deviceType == A4_DEVICE_THREE){
        sliderTemperature.maximumValue = [self getMaxTemperature:aryStudedKey];
        sliderTemperature.minimumValue = [self getMinTemperature:aryStudedKey];
        sliderTemperature.value        = sliderTemperature.minimumValue;
        labTemperature.text            = [NSString stringWithFormat:@"%d℃",(int)sliderTemperature.value]; //@"24℃"
        
    }
    else if (deviceType == A4_DEVICE_UART){
        sliderTemperature.maximumValue = [self getMaxTemperature:aryStudedKey];
        sliderTemperature.minimumValue = [self getMinTemperature:aryStudedKey];
        sliderTemperature.value        = sliderTemperature.minimumValue;
        labTemperature.text            = [NSString stringWithFormat:@"%d℃",(int)sliderTemperature.value]; //@"24℃"
    }
    else if (deviceType == A4_DEVICE_IO){
        sliderTemperature.maximumValue = 35;
        sliderTemperature.minimumValue = 16;
        sliderTemperature.value        = 20;
        sliderTemperature.alpha        = .5;
        labTemperature.text            = @"20℃";
        sliderTemperature.userInteractionEnabled = NO;
    }
    
    [sliderTemperature addTarget:self action:@selector(sliderValueChanged:) forControlEvents:UIControlEventValueChanged];
    [sliderTemperature addTarget:self action:@selector(sliderSendMsg:) forControlEvents:UIControlEventTouchUpInside];
    imgViewSonw = [[UIImageView alloc] initWithFrame:CGRectMake(sliderTemperature.frameSumX_W + 10 ,
                                                                             sliderTemperature.frameY ,
                                                                             30, 30)];
    [imgViewSonw setImage:[UIImage imageNamed:@"icAir_Sonw"]];
    [mainScroll addSubview:sliderTemperature];
    [mainScroll addSubview:imgViewSonw];
    ////////菜单 等功能键
    CGFloat OffSetY  = imgViewSonw.frameSumY_H;
    NSArray *aryICON = @[@"air_Condition_cold", @"air_Condition_warm",  @"air_Condition_wet",@"air_Condition_auto", @"air_Condition_sleep", @"air_Condition_supply",@"air_Condition_low",@"air_Condition_mid",@"air_Condition_high"];
    NSArray *aryICON_H = @[@"air_Condition_cold_H", @"air_Condition_warm_H",  @"air_Condition_wet_H",@"air_Condition_auto_H",@"air_Condition_sleep_H",@"air_Condition_supply_H",@"air_Condition_low_H",@"air_Condition_mid_H",@"air_Condition_high_H"];
    CGFloat marginX  = (ScreenSize.width - 2*BTN_MARGIN_M - 3*BTN_HEIGTH)/2.f;
    for(int i=0;i<aryICON.count; i++){
        UIButton *btnTMP = [[UIButton alloc]initWithFrame:CGRectMake(BTN_MARGIN_M + i%3 * (marginX + BTN_HEIGTH) ,
                                                                     imgViewSonw.frameSumY_H + 10 + i/3* (BTN_HEIGTH + marginX),
                                                                     BTN_HEIGTH, BTN_HEIGTH)];
        [btnTMP setImage:[UIImage imageNamed:aryICON[i]] forState:UIControlStateNormal];
        [btnTMP setImage:[UIImage imageNamed:aryICON_H[i]] forState:UIControlStateSelected];
        [btnTMP setTitle:aryDefaultName[defaultIndex] forState:UIControlStateNormal];
        [btnTMP setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
        [btnTMP.titleLabel setFont:[UIFont systemFontOfSize:14.f]];
        [btnTMP.titleLabel setTextAlignment:NSTextAlignmentCenter];
        [self enterManagerMode:btnTMP andTag:TAG_BUTTON + defaultIndex];
        [btnTMP addTarget:self action:@selector(touchedButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        
        
        OffSetY = btnTMP.frameSumY_H;
        defaultIndex ++;
        [mainScroll addSubview:btnTMP];
    }
    ////////自定义按钮
    [self buildCustomeButton:OffSetY];
    defaultOffSetY = OffSetY;
}

///////////////绘制自定义按钮
- (void)buildCustomeButton:(CGFloat)offSetY{
    
    CGFloat marginX4 = (ScreenSize.width - BTN_MARGIN_M*2 - BTN_HEIGTH*3)/2.f;
    for (UIView *v in aryCustomeBtn) {
        [v removeFromSuperview];
    }
    [aryCustomeBtn removeAllObjects];
    for (int i=0; i<aryCustomeName.count; i++) {
        UIButton *btnTMP = [[UIButton alloc] initWithFrame:CGRectMake(BTN_MARGIN_M + i%3 * (marginX4 + BTN_HEIGTH) ,
                                                                      offSetY + marginX4 + i/3* (BTN_HEIGTH + marginX4),
                                                                      BTN_HEIGTH, BTN_HEIGTH)];
        [btnTMP setBackgroundImage:[UIImage imageNamed:@"tv_backGround.png"] forState:UIControlStateNormal];
        [btnTMP setBackgroundImage:[UIImage imageNamed:@"tv_backGround.png"] forState:UIControlStateHighlighted];
        [btnTMP setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [btnTMP setTitleColor:[UIColor colorWithRed:110/255.0f green:220/255.0f blue:80/255.0f alpha:1] forState:UIControlStateHighlighted];
        [btnTMP setTitleColor:[UIColor colorWithRed:110/255.0f green:220/255.0f blue:80/255.0f alpha:1]  forState:UIControlStateSelected];
        [btnTMP setTitle:aryCustomeName[i] forState:UIControlStateNormal];
        btnTMP.titleLabel.font = [UIFont boldSystemFontOfSize:14.f];
        [self enterManagerMode:btnTMP andTag:(TAG_BUTTON + aryDefaultName.count  + i)];
        [mainScroll addSubview:btnTMP];
        
        if (!aryCustomeBtn) {
            aryCustomeBtn = [NSMutableArray array];
        }
        [aryCustomeBtn addObject:btnTMP];
    }
    //////////移动‘+’按钮
    CGRect rectPlusButton = CGRectMake(BTN_MARGIN_M + aryCustomeName.count%3*(BTN_HEIGTH + marginX4) + 7.5,
                                       offSetY+ marginX4 +aryCustomeName.count/3*(BTN_HEIGTH + marginX4) + 18,
                                       BTN_WIDTH - 15, BTN_HEIGTH_S - 10);
    if (btnPlus) {
        [btnPlus setFrame:rectPlusButton];
    }
    else{
        btnPlus          = [[UIButton alloc] initWithFrame:rectPlusButton];
        btnPlus.hidden   = YES;
        btnPlus.layer.cornerRadius = 5.f;
        btnPlus.layer.borderWidth  = 1.f;
        btnPlus.layer.borderColor  = [UIColor grayColor].CGColor;
        btnPlus.titleLabel.font    = [UIFont systemFontOfSize:35];
        [btnPlus setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [btnPlus setTitleColor:[UIColor colorWithRed:110/255.0f green:220/255.0f blue:80/255.0f alpha:1]  forState:UIControlStateHighlighted];
        [btnPlus setTitleColor:[UIColor colorWithRed:110/255.0f green:220/255.0f blue:80/255.0f alpha:1]  forState:UIControlStateSelected];
        [btnPlus setTitle:@"+" forState:UIControlStateNormal];
        [btnPlus setTitleEdgeInsets:UIEdgeInsetsMake(0, 0, 8, 0)];
        [btnPlus addTarget:self action:@selector(touchedAddButton:) forControlEvents:UIControlEventTouchUpInside];
        [mainScroll addSubview:btnPlus];
    }
    [mainScroll setContentSize:CGSizeMake(ScreenSize.width, btnPlus.frameSumY_H + 20)];
}
- (void)enterManagerMode:(UIButton *)btnTMP andTag:(NSInteger)aTag{
    ////按钮互斥分组
    switch (aTag - TAG_BUTTON) {
        case 0:case 1:
            objc_setAssociatedObject(btnTMP, &kButtonType, @(groupNum), OBJC_ASSOCIATION_COPY);
            break;
        case 2:case 3:case 4:case 5:case 6:case 7:
            objc_setAssociatedObject(btnTMP, &kButtonType, @(groupNum + 1), OBJC_ASSOCIATION_COPY);
            break;
            case 8:case 9:case 10:
            objc_setAssociatedObject(btnTMP, &kButtonType, @(groupNum + 2), OBJC_ASSOCIATION_COPY);
        default:
            break;
    }
    ////事件、
    [btnTMP setTag:aTag];
    [btnTMP addTarget:self action:@selector(touchedButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [btnTMP setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    ///////////////判断Key列表是否已有此按钮
    ////图层遮罩、表示未学习按钮
    btnTMP.alpha = 0.4;
    ////////////////如果为自定义按钮
    if (aTag >= (TAG_BUTTON + aryDefaultName.count)) {
        for (ControlDeviceContentValueKey *valueKey in aryStudedKey) {
            if ([valueKey.name isEqualToString:btnTMP.titleLabel.text]) {
                ////////已学习。 改变其颜色
                btnTMP.alpha = 1;
            }
            [btnTMP setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        }
        //////////////////添加长按手势
        UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPressEditName:)];
        longPress.minimumPressDuration          = 0.8;
        [btnTMP addGestureRecognizer:longPress];
    }
    ///////////////默认按钮
    else {
        if (deviceType != A4_DEVICE_AIR_CONDITION){
            for (ControlDeviceContentValueKey *valueKey in aryStudedKey) {
                if ([valueKey.name isEqualToString:btnTMP.titleLabel.text]) {
                    ////////已学习。 改变其颜色
                    btnTMP.alpha = 1;
                }
            }
        }
        else{
            btnTMP.alpha = 1;
        }
    }
    
    /////////若为空调控制器
    if (deviceType == A4_DEVICE_IO &&
        ([btnTMP.titleLabel.text isEqualToString:@"开"] ||
         [btnTMP.titleLabel.text isEqualToString:@"关"])) {
            btnTMP.alpha = 1;
    }
    ////////若为演示模式
    if ([[HE_APPManager sharedManager] netState] == NET_DEMO){
        btnTMP.alpha = 1;
        [btnTMP setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
}


#pragma mark 进入红外学习模式
- (void)enterStudyMode{
    mainScroll.frame = CGRectMake(0, 0, ScreenSize.width, self.frameH - (BOTOM_VIEW_H + 20));
    btnPlus.hidden   = NO;
    isStudyMode      = YES;
    /////////////红外学习视图
    bottomView = [[UIView alloc] initWithFrame:CGRectMake(10, mainScroll.frameSumY_H + 10, ScreenSize.width - 20.f, BOTOM_VIEW_H)];
    bottomView.layer.cornerRadius = 8.f;
    bottomView.layer.borderWidth  = 1.f;
    bottomView.layer.borderColor  = [UIColor grayColor].CGColor;
    ///1.开始学习按钮
    btnStudy                    = [[UIButton alloc] initWithFrame:CGRectMake(5, 5, BTN_WIDTH, 55)];
    btnStudy.titleLabel.font    = [UIFont boldSystemFontOfSize:15.f];
    [btnStudy setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [btnStudy setTitleColor:[UIColor colorWithRed:110/255.0f green:220/255.0f blue:80/255.0f alpha:1]  forState:UIControlStateHighlighted];
    [btnStudy setTitleColor:[UIColor colorWithRed:110/255.0f green:220/255.0f blue:80/255.0f alpha:1]  forState:UIControlStateSelected];
    [btnStudy setBackgroundImage:[UIImage imageNamed:@"tv_backGround2.png"] forState:UIControlStateNormal];
    [btnStudy setBackgroundImage:[UIImage imageNamed:@"tv_backGround2.png"] forState:UIControlStateHighlighted];
    [btnStudy setTitle:@"红外学习" forState:UIControlStateNormal];
    [btnStudy addTarget:self action:@selector(touchedStudyMode:) forControlEvents:UIControlEventTouchUpInside];
    
    ///2.结束学习按钮
    btnEndStudy                    = [[UIButton alloc] initWithFrame:CGRectMake(btnStudy.frameSumX_W + 5, btnStudy.frameY, BTN_WIDTH, 55)];
    btnEndStudy.titleLabel.font    = [UIFont boldSystemFontOfSize:15.f];
    [btnEndStudy setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [btnEndStudy setTitleColor:[UIColor colorWithRed:110/255.0f green:220/255.0f blue:80/255.0f alpha:1]  forState:UIControlStateHighlighted];
    [btnEndStudy setTitleColor:[UIColor colorWithRed:110/255.0f green:220/255.0f blue:80/255.0f alpha:1]  forState:UIControlStateSelected];
    [btnEndStudy setBackgroundImage:[UIImage imageNamed:@"tv_backGround2.png"] forState:UIControlStateNormal];
    [btnEndStudy setBackgroundImage:[UIImage imageNamed:@"tv_backGround2.png"] forState:UIControlStateHighlighted];
    [btnEndStudy setTitle:@"结束学习" forState:UIControlStateNormal];
    [btnEndStudy addTarget:self action:@selector(touchedEndStudy:) forControlEvents:UIControlEventTouchUpInside];
    
    ///3.模式选择DD
    
    
    [bottomView addSubview:btnStudy];
    [bottomView addSubview:btnEndStudy];
    
    [self addSubview:bottomView];
}

#pragma mark -
#pragma mark 控制器Action
//////////////温度条滑动按钮
- (void)sliderValueChanged:(UISlider *)slider{
    ///1.红外学习
    if (deviceType == A4_DEVICE_MUTIL) {
        labTemperature.text = [NSString stringWithFormat:@"%d℃",(int)slider.value];
    }
    ///2.空调控制器
    else if (deviceType == A4_DEVICE_AIR_CONDITION){
        float progressAsInt = ((int)slider.value)/2.f;
        labTemperature.text = [NSString stringWithFormat:@"%.1f℃", progressAsInt];
    }
    ///3.自定义设备->大金空调
    else{
        //直接发送Key
        labTemperature.text = [NSString stringWithFormat:@"%d℃",(int)slider.value];
    }
}
//////////////////滑动完成
-(void)sliderSendMsg:(id)sender{
    UISlider *slider = (UISlider *)sender;
    ///1.红外学习
    if (deviceType == A4_DEVICE_MUTIL) {
        [self dealWithActionWithName:[NSString stringWithFormat:@"%@%d℃", isMakeHot?@"制热":@"制冷",(int)slider.value] Button:nil];
    }
    ///2.空调控制器
    else if (deviceType == A4_DEVICE_AIR_CONDITION){
        float progressAsInt = ((int)slider.value)/2.f;
        NSString *strData   = [cmdB airConditionTemperature:[NSString stringWithFormat:@"%02X",(int)(progressAsInt*2)]
                                                   WithData:[NSString stringWithFormat:@"%@%@",num, strDataWithoutNum]];
        NSString *strCMD    = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:A4_DEVICE_AIR_CONDITION Data:strData];
        NSString *strMsg    = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:strCMD];
        [[HE_APPManager sharedManager] SendMsg:strMsg withNameSpace:@"control" isShowLoading:[self isNeedShowLoading: strMsg]];
    }
    ///3.自定义设备->大金空调
    else if (deviceType == A4_DEVICE_THREE){
        //直接发送Key
        [self dealWithActionWithName:[NSString stringWithFormat:@"%@%d℃", isMakeHot?@"制热":@"制冷",(int)slider.value] Button:nil];
    }
    ///4.数据透传
    else if (deviceType == A4_DEVICE_UART){
        NSString *strName = [NSString stringWithFormat:@"%@%d℃", isMakeHot?@"制热":@"制冷",(int)slider.value];
        for (ControlDeviceContentValueKey *obj in aryStudedKey) {
            if ([obj.name isEqualToString:strName]) {
                NSString *strData= [NSString stringWithFormat:@"%@%02X%@",self.num, (int)obj.value.length/2,obj.value];
                NSString *strCMD = [cmdB getCMDWithAction:A4_ACTION_CONTROL
                                               DeviceType:A4_DEVICE_UART
                                                     Data:strData];
                NSString *strMsg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:strCMD];
                [[HE_APPManager sharedManager] SendMsg:strMsg withNameSpace:@"control" isShowLoading:[self isNeedShowLoading: strMsg]];
                /////如果有查询。需要发送则发送查询命令
                if([obj.query isNotEmptyAndNil] && ![obj.query isEqualToString:@"null"]){
                    NSString *cmdQuery  = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType
                                                           Data:[NSString stringWithFormat:@"%@%02X%@",self.num, (int)obj.query.length/2,obj.query]];
                    
                    
                    NSString *msgQuery = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:cmdQuery];
                    // 延时发送查询消息
                    NSTimeInterval time = obj.time.doubleValue / 1000;
                    [[HE_APPManager sharedManager] SendQueryMsg:msgQuery withNameSpace:@"control" after:time];
                }
                break;
            }
        }
        
    }
}
//////////////控制器按钮单击事件
- (void)touchedButtonClick:(UIButton *)sender{
    //////执行按钮事件
    //1.为红外类
    if(deviceType == A4_DEVICE_MUTIL ){
        BOOL      isStuded =  NO;
        for (ControlDeviceContentValueKey *k in aryStudedKey) {
            if ([k.name isEqualToString:sender.titleLabel.text]) {
                isStuded = YES;
                break;
            }
        }
        ///改变灰色按钮 颜色
        if (!isStuded && isBeginStudy) {
            sender.alpha = 1;
        }
        [self dealWithActionWithName:sender.titleLabel.text Button:sender];
    }
    //2.非红外类->空调控制器
    else if(deviceType == A4_DEVICE_AIR_CONDITION){
        NSInteger btnTag = ((UIButton *)sender).tag;
        NSString *strData = [NSString stringWithFormat:@"%@%@",num, strDataWithoutNum];
        switch (btnTag) {
            case TAG_BUTTON:{///开
                strData = [cmdB airConditionMode:@"03" WithData:strData];
            }break;
            case TAG_BUTTON + 1:{///关
                strData = [cmdB airConditionMode:@"00" WithData:strData];
            }break;
            case TAG_BUTTON + 2:{///制冷
                strData = [cmdB airConditionMode:@"01" WithData:strData];
            }break;
            case TAG_BUTTON + 3:{///制热
                strData = [cmdB airConditionMode:@"02" WithData:strData];
            }break;
            case TAG_BUTTON + 4:{///除湿
                strData = [cmdB airConditionMode:@"05" WithData:strData];
            }break;
            case TAG_BUTTON + 5:{///自动
                strData = [cmdB airConditionMode:@"03" WithData:strData];
            }break;
            case TAG_BUTTON + 6:{///睡眠
            }break;
            case TAG_BUTTON + 7:{///送风
                strData = [cmdB airConditionMode:@"04" WithData:strData];
            }break;
            case TAG_BUTTON + 8:{///低速
                strData = [cmdB airConditionWindSpeed:@"01" WithData:strData];
            }break;
            case TAG_BUTTON + 9:{///中速
                strData = [cmdB airConditionWindSpeed:@"02" WithData:strData];
            }break;
            case TAG_BUTTON + 10:{///高速
                strData = [cmdB airConditionWindSpeed:@"03" WithData:strData];
            }break;
            default:
                break;
        }
        NSString *strCMD = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:A4_DEVICE_AIR_CONDITION Data:strData];
        NSString *strMsg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:strCMD];
        [[HE_APPManager sharedManager] SendMsg:strMsg withNameSpace:@"control" isShowLoading:[self isNeedShowLoading: strMsg]];
    }
    //3.自定义->大金空调
    else  if(deviceType == A4_DEVICE_THREE){
        for (ControlDeviceContentValueKey *obj in aryStudedKey) {
            if ([obj.name isEqualToString:sender.titleLabel.text]) {
                NSString *strCMD = obj.value;
                NSString *strMsg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:strCMD];
                [[HE_APPManager sharedManager] SendMsg:strMsg withNameSpace:@"control" isShowLoading:[self isNeedShowLoading: strMsg]];
                /////如果有查询。需要发送则发送查询命令
                if([obj.query isNotEmptyAndNil] && ![obj.query isEqualToString:@"null"]){
                    NSString *msgQuery = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:obj.query];
                    
                    NSTimeInterval time = obj.time.doubleValue / 1000;
                    [[HE_APPManager sharedManager] SendQueryMsg:msgQuery withNameSpace:@"control" after:time];
                }
                break;
            }
        }
    }
    ///4.数据透传
    else  if(deviceType == A4_DEVICE_UART){
        for (ControlDeviceContentValueKey *obj in aryStudedKey) {
            if ([obj.name isEqualToString:sender.titleLabel.text]) {
                NSString *strData= [NSString stringWithFormat:@"%@%02X%@",self.num, (int)obj.value.length/2,obj.value];
                NSString *strCMD = [cmdB getCMDWithAction:A4_ACTION_CONTROL
                                               DeviceType:A4_DEVICE_UART
                                                     Data:strData];
                NSString *strMsg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:strCMD];
                [[HE_APPManager sharedManager] SendMsg:strMsg withNameSpace:@"control" isShowLoading:[self isNeedShowLoading: strMsg]];
                /////如果有查询。需要发送则发送查询命令
                if([obj.query isNotEmptyAndNil] && ![obj.query isEqualToString:@"null"]){
                    NSString *cmdQuery = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType
                                                           Data:[NSString stringWithFormat:@"%@%02X%@",self.num, (int)obj.query.length/2,obj.query]];
                    NSString *msgQuery = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:cmdQuery];
                    // 延时发送查询消息
                    NSTimeInterval time = obj.time.doubleValue / 1000;
                    [[HE_APPManager sharedManager] SendQueryMsg:msgQuery withNameSpace:@"control" after:time];
                }
                break;
            }
        }
    }
    ///5.
    else if (deviceType == A4_DEVICE_IO) {
        NSString *strTMP = [sender.titleLabel.text isEqualToString:@"开"]?@"0300":@"0200";
        NSString *strData= [NSString stringWithFormat:@"%@%@",num,strTMP];
        NSString *strCMD = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType Data:strData];
        NSString *strMsg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:strCMD];
        [[HE_APPManager sharedManager] SendMsg:strMsg withNameSpace:@"control" isShowLoading:[self isNeedShowLoading: strMsg]];
        return;
    }
}

/////////////学习某个按钮
- (void)dealWithActionWithName:(NSString *)strName Button:(UIButton *) button{
    //////////若为演示模式
    if ([[HE_APPManager sharedManager] netState] == NET_DEMO) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            NSArray *allViews = [mainScroll subviews];
            for (UIView *v in allViews) {
                /////////////按钮
                if ([v isKindOfClass:[UIButton class]]) {
                    if([((UIButton *)v).titleLabel.text isEqualToString:strName]){
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [((UIButton *)v) setSelected:YES];
                        });
                    }
                    else{
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [((UIButton *)v) setSelected:NO];
                        });
                    }
                }
            }
        });
        return;
    }
    
    ///////判断是否该键已学习
    BOOL      isStuded =  NO;
    ControlDeviceContentValueKey *opKey;
    for (ControlDeviceContentValueKey *k in aryStudedKey) {
        if ([k.name isEqualToString:strName]) {
            isStuded   = YES;
            opKey = k;
            break;
        }
    }
    
    //1. 控制
    if (isStuded && !isBeginStudy) {
        //1.1 找到Value
        NSString *strMsg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:opKey.value];
        NSLog(@"找到的value %@",opKey.value);
        [[HE_APPManager sharedManager] SendMsg:strMsg withNameSpace:@"control" isShowLoading:[self isNeedShowLoading: strMsg]];
        
        /////如果有查询。需要发送则发送查询命令
        if([opKey.query isNotEmptyAndNil] && ![opKey.query isEqualToString:@"null"]){
            
            NSString *msgQuery = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:opKey.query];
            
            // 延时发送查询消息
            NSTimeInterval time = opKey.time.doubleValue / 1000;
            [[HE_APPManager sharedManager] SendQueryMsg:msgQuery withNameSpace:@"control" after:time];
        }
    }
    //2.学习 -- 从 剩余索引值数组 取得索引
    else if (isBeginStudy){
        ////2.1.得到索引后、 加入aryStudedIndex, 和aryStudedKey数组
        isModifed = YES;
        NSString *studingHexIndex;
        
        /////如果为已学习则直接发送 已学习的键值
        if (isStuded) {
            studingHexIndex = [opKey.value substringWithRange:NSMakeRange(19, 3)];
        }
        else{
            studingHexIndex = [self getMinUnusedIndexWithAry:aryStudedIndex];
            if ([studingHexIndex IntString].intValue > 999){
                [[HE_APPManager sharedManager] hudShowMsg:@"1000个键值已用完" andInterval:1.0];
                ///////则把刚刚变亮的按钮、变灰
                button.alpha = 0.4;
                return;
            }
        }
        //2.2构造学习消息
        NSString *strData     = [NSString stringWithFormat:@"%@%@%@",num, @"8",studingHexIndex];
        NSString *strCMD      = [cmdB getCMDWithAction:A4_ACTION_SIGNAL_STUDY DeviceType:A4_DEVICE_MUTIL Data:strData];
        NSString *strMsg      = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:strCMD];
        NSLog(@"构造好的学习CMD%@",strCMD);
        //2.3构造控制消息
        NSString *strCtrlData = [NSString stringWithFormat:@"%@FF%@%@", num,@"8", studingHexIndex];
        NSString *strCtrlCMD  = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:A4_DEVICE_MUTIL Data:strCtrlData];
        NSLog(@"构造好的控制CMD%@",strCtrlCMD);
        
        [[HE_APPManager sharedManager] SendMsg:strMsg withNameSpace:@"control" isShowLoading:/*[self isNeedShowLoading: strMsg]*/NO];
        ////////修改内存
        
        if (isStuded) {///已学习按钮不做 改变
            //
        }
        else{///未曾学习过的按钮-> 新增
            opKey = [[ControlDeviceContentValueKey alloc] init];
            opKey.name   = strName;
            opKey.value  = strCtrlCMD;
            opKey.time   = @"null";
            opKey.query  = @"null";
            opKey.backkey= @"null";
            [aryStudedKey addObject:opKey];
            [aryStudedIndex addObject:studingHexIndex.IntString];
            aryStudedIndex = [self orderAscWithArry:aryStudedIndex];
        }
        if ([strName isEqualToString:@"制热"]) {
            isMakeHot = YES;
            [imgViewSonw setImage:[UIImage imageNamed:@"icAir_Sun"]];
        }
        else if ([strName isEqualToString:@"制冷"]){
            isMakeHot = NO;
            [imgViewSonw setImage:[UIImage imageNamed:@"icAir_Sonw"]];
        }
        [[HE_APPManager sharedManager] hudShowMsg:[NSString stringWithFormat:@"开始学习'%@' 索引:%@",strName, studingHexIndex] andInterval:1.0];
    }
    else{
        NSString *msgAlert =  @"该键未学习";
        if (deviceType == A4_DEVICE_THREE || deviceType == A4_DEVICE_UART) {
            msgAlert =  @"该键不存在";
        }
        [[HE_APPManager sharedManager] hudShowMsg:msgAlert andInterval:.5];
    }
}
/////////////控制器按钮长按事件
- (void)longPressEditName:(UILongPressGestureRecognizer *)longPress{
    /////////////////1.为默认按钮 则 长按不响应任何事件
    UIButton *btnSender = (UIButton *)longPress.view;
    for (NSString* s in aryDefaultName) {
        if ([btnSender.titleLabel.text isEqualToString:s]) {
            return;
        }
    }
    ////////////////2.否则 响应长按手势开始动作
    if (longPress.state == UIGestureRecognizerStateBegan && isStudyMode == YES) {
        FXW_AlertForInfrared *alert = [[FXW_AlertForInfrared alloc] init];
        [alert setTitle:@"编辑按钮" andAlertType:FXWAlertTypeEdit];
        [alert setDefaultName:btnSender.currentTitle];
        [alert setSender:btnSender];
        [alert setAlertDelegate:self];
        [alert setTag:TAG_ALERT_EDIT];
        [self addSubview:alert];
    }
}

/////////////控制器按钮 新增事件
- (void)touchedAddButton:(UIButton *)sender{
    ///////////////添加一个按钮
    FXW_AlertForInfrared *alert = [[FXW_AlertForInfrared alloc] init];
    [alert setTitle:@"添加按钮" andAlertType:FXWAlertTypeAdd];
    [alert setSender:sender];
    [alert setAlertDelegate:self];
    [alert setTag:TAG_ALERT_NEW];
    [self addSubview:alert];
}

////////////Delegate
- (void)alertView:(FXW_AlertForInfrared *)alertView
        inputText:(NSString *)aText
       actionType:(FXWAlertActionType)type
     andBtnSender:(UIButton *)btn{
    /////////////////按钮名称重复
    if (type != FXWAlertActionDelete && [self isRepateKeyNameWithStudedKey:aryStudedKey andName:aText]) {
        [[HE_APPManager sharedManager] hudShowMsg:@"按钮名称重复" andInterval:2.];
        return;
    }
    
    if (alertView.tag == TAG_ALERT_NEW && type == FXWAlertActionSave) {
        [aryCustomeName addObject:aText];
        [self buildCustomeButton:defaultOffSetY];
        [mainScroll setContentOffset:CGPointMake(0,  btnPlus.frameSumY_H - mainScroll.frameH ) animated:YES];
    }
    else if (alertView.tag == TAG_ALERT_EDIT){
        NSString *oldName = btn.titleLabel.text;
        ////更新数组数据
        if (type == FXWAlertActionSave) {
            isModifed = YES;
            [aryCustomeName setObject:aText atIndexedSubscript:[aryCustomeName indexOfObject:oldName]];
            for (ControlDeviceContentValueKey *k in aryStudedKey) {
                if (k.name == oldName) {
                    k.name = aText;
                    break;
                }
            }
            [btn setTitle:aText forState:UIControlStateNormal];
        }
        else if (type == FXWAlertActionDelete){
            isModifed = YES;
            for (ControlDeviceContentValueKey *k in aryStudedKey) {
                if (k.name == oldName) {
                    [aryStudedKey removeObject:k];
                    break;
                }
            }
            [btn removeFromSuperview];
            [aryCustomeName removeObject:oldName];
            [self buildCustomeButton:defaultOffSetY];
        }
    }
}

#pragma mark -
#pragma mark BWDevice Manager
- (void)updateTheDeviceStateWithData:(NSString *)strData{
    /////.1收到多功能控制器的反馈
    if (deviceType == A4_DEVICE_MUTIL) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(){
            for (ControlDeviceContentValueKey *k in aryKey) {
                ////////有此反馈
                if ([[strData substringFromIndex:2] isEqualToString:[[cmdP getDataWithoutNum:k.value] substringFromIndex:2]]) {
                    ///////////如果是 制热/制冷 按钮反馈  更改isMakeHot
                    if ([k.name isEqualToString:@"制冷"]) {
                        isMakeHot = NO;
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [imgViewSonw setImage:[UIImage imageNamed:@"icAir_Sonw"]];
                        });
                    }
                    else if ([k.name isEqualToString:@"制热"]){
                        isMakeHot = YES;
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [imgViewSonw setImage:[UIImage imageNamed:@"icAir_Sun"]];
                        });
                        
                    }
                    ////////////
                    NSLog(@"反馈：%@",k.name);
                    dispatch_async(dispatch_get_main_queue(), ^{
                        if (!isFristUpate) {
                            [self showHint:@"操作成功"];
                        }
                        isFristUpate = NO;
                    });
                    NSArray *allViews = [mainScroll subviews];
                    ////////////////1.滑竿温度反馈
                    if ([k.name myContainsString:@"℃"]) {
                        NSString *strSeparate = [k.name myContainsString:@"制热"]?@"制热":@"制冷";
                        NSArray *aryTMP = [k.name componentsSeparatedByString:strSeparate];
                        float  val = sliderTemperature.value;
                        if (aryTMP.count >= 2) {
                            NSString *strVal = [((NSString *)aryTMP[1]) componentsSeparatedByString:@"℃"][0];
                            val              = strVal.floatValue;
                        }
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [sliderTemperature setValue:val animated:YES];
                            labTemperature.text = [NSString stringWithFormat:@"%d℃",(int)val];
                        });
                    }
                    ////////////////2.按钮反馈
                    else{
                        for (UIView *v in allViews) {
                            if([v isKindOfClass:[UIButton class]]){
                                if ([((UIButton *)v).titleLabel.text isEqualToString:k.name]) {
                                    NSNumber *selcedNum = objc_getAssociatedObject(v, &kButtonType);
                                    dispatch_async(dispatch_get_main_queue(), ^{
                                        ((UIButton *)v).selected = YES;
                                    });
                                    ////////将本组其他按钮置为 未选中
                                    for (UIView *v2 in allViews) {
                                        if ([v2 isKindOfClass:[UIButton class]]) {
                                            NSNumber *tmp = objc_getAssociatedObject(v2, &kButtonType);
                                            if (selcedNum.integerValue == tmp.integerValue && v != v2) {
                                                dispatch_async(dispatch_get_main_queue(), ^{
                                                    ((UIButton *)v2).selected = NO;
                                                });
                                            }
                                        }
                                    }
                                }
                            }
                        }
//                        for (UIView *v in allViews) {
//                            if([v isKindOfClass:[UIButton class]]){
//                                if ([((UIButton *)v).titleLabel.text isEqualToString:k.name]) {
//                                    dispatch_async(dispatch_get_main_queue(), ^{
//                                        ((UIButton*)v).selected = YES;
//                                    });
//                                }
//                                else{
//                                    dispatch_async(dispatch_get_main_queue(), ^{
//                                        ((UIButton*)v).selected = NO;
//                                    });
//                                }
//                            }
//                        }
                        
                    }
                    break;
                }
            }
        });
    }
    else if (deviceType == A4_DEVICE_IO){
        NSString *strState = [strData substringToIndex:2];
        UIButton *btnOn    = [mainScroll viewWithTag:TAG_BUTTON];
        UIButton *btnOff   = [mainScroll viewWithTag:TAG_BUTTON+1];
        if ([strState isEqualToString:@"02"]) {
            btnOff.selected = YES;
            btnOn.selected  = NO;
        }
        else{
            btnOff.selected = NO;
            btnOn.selected  = YES;
        }
        return;
    }
    /////2.收到空调控制器的反馈
    else if (deviceType == A4_DEVICE_AIR_CONDITION){
        strDataWithoutNum = strData;
        if (strDataWithoutNum) {
            NSString *strTitleMode  = @"x";
            NSString *strTitleSpeed = @"x";
            /////////1.工作模式反馈
            NSString *strMode = [strDataWithoutNum substringWithRange:NSMakeRange(0, 2)];
            switch (strMode.IntString.intValue) {
                case 0://关
                    strTitleMode = @"关";
                    break;
                case 1://制冷
                    strTitleMode = @"制冷";
                    isMakeHot    = NO;
                    break;
                case 2://制热
                    strTitleMode = @"制热";
                    isMakeHot    = YES;
                    break;
                case 3://自动/开
                    strTitleMode = @"自动";
                    break;
                case 4://送风
                    strTitleMode = @"送风";
                    break;
                case 5://除湿
                    strTitleMode = @"除湿";
                    break;
                default://自动 03
                    strTitleMode = @"开";
                    break;
            }
            /////////2.摆风反馈
            //..无
            /////////3.风速反馈
            NSString *strSpeed = [strDataWithoutNum substringWithRange:NSMakeRange(4, 2)];
            switch (strSpeed.IntString.intValue) {
                case 1://低速
                    strTitleSpeed = @"低速";
                    break;
                case 2://中速
                    strTitleSpeed = @"中速";
                    break;
                case 3://高速
                    strTitleSpeed = @"高速";
                default://中速 2
                    strTitleSpeed = @"中速";
                    break;
            }
            NSArray *aryAllViews = [mainScroll subviews];
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (!isFristUpate) {
                        [self showHint:@"操作成功"];
                    }
                    isFristUpate = NO;
                });
                for (UIView *v in aryAllViews) {
                    //////////按钮反馈
                    if ([v isKindOfClass:[UIButton class]]) {
                        //     UIColor *backColor = [UIColor clearColor];
                        if ([((UIButton*)v).titleLabel.text isEqualToString:strTitleMode] ||
                            [((UIButton*)v).titleLabel.text isEqualToString:strTitleSpeed]) {
                            dispatch_async(dispatch_get_main_queue(), ^{
                                ((UIButton *)v).selected = YES;
                            });
                        }
                        else{
                            dispatch_async(dispatch_get_main_queue(), ^{
                                ((UIButton *)v).selected = NO;
                            });
                        }
                        
                    }
                }
            });
            /////////4.温度反馈
            CGFloat tmp = [[[strDataWithoutNum substringWithRange:NSMakeRange(6, 2)] IntString] integerValue]/2.f;
            labTemperature.text = [NSString stringWithFormat:@"%.1f℃", tmp];
            [sliderTemperature setValue:tmp * 2 animated:YES];
        }
    }
    ////3.自定义设备： 大金空调的反馈 4.数据透传
    else if (deviceType == A4_DEVICE_THREE || deviceType == A4_DEVICE_UART){
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(){
            for (ControlDeviceContentValueKey *k in aryStudedKey) {
                ////////有此反馈
                if ([strData.uppercaseString myContainsString:k.backkey.uppercaseString]) {
                    ///////////如果是 制热/制冷 按钮反馈  更改isMakeHot
                    if ([k.name isEqualToString:@"制冷"]) {
                        isMakeHot = NO;
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [imgViewSonw setImage:[UIImage imageNamed:@"icAir_Sonw"]];
                        });
                    }
                    else if ([k.name isEqualToString:@"制热"]){
                        isMakeHot = YES;
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [imgViewSonw setImage:[UIImage imageNamed:@"icAir_Sun"]];
                        });
                        
                    }
                    ////////////
                    NSLog(@"反馈：%@",k.name);
                    dispatch_async(dispatch_get_main_queue(), ^{
                        if (!isFristUpate) {
                            [self showHint:@"操作成功"];
                        }
                        isFristUpate = NO;
                    });
                    ////////////////1.滑竿温度反馈
                    if ([k.name myContainsString:@"℃"]) {
                        NSString *strSeparate = [k.name myContainsString:@"制热"]?@"制热":@"制冷";
                        NSArray *aryTMP = [k.name componentsSeparatedByString:strSeparate];
                        float  val = sliderTemperature.value;
                        if (aryTMP.count >= 2) {
                            NSString *strVal = [((NSString *)aryTMP[1]) componentsSeparatedByString:@"℃"][0];
                            val              = strVal.floatValue;
                        }
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [sliderTemperature setValue:val animated:YES];
                            labTemperature.text = [NSString stringWithFormat:@"%d℃",(int)val];
                        });
                    }
                    ////////////////2.按钮反馈
                    else{
                        NSArray *allViews = [mainScroll subviews];
                        NSArray *allBackName = [self parseTxt:k.name];
                        for (NSString *tmpName in allBackName) {
                            for (UIView *v in allViews) {
                                if([v isKindOfClass:[UIButton class]]){
                                    if ([((UIButton *)v).titleLabel.text isEqualToString:tmpName]) {
                                        NSNumber *selcedNum = objc_getAssociatedObject(v, &kButtonType);
                                        dispatch_async(dispatch_get_main_queue(), ^{
                                            ((UIButton *)v).selected = YES;
                                        });
                                        ////////将本组其他按钮置为 未选中
                                        for (UIView *v2 in allViews) {
                                            if ([v2 isKindOfClass:[UIButton class]]) {
                                                NSNumber *tmp = objc_getAssociatedObject(v2, &kButtonType);
                                                if (selcedNum.integerValue == tmp.integerValue && v != v2) {
                                                    dispatch_async(dispatch_get_main_queue(), ^{
                                                        ((UIButton *)v2).selected = NO;
                                                    });
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        });
    }
    
}

#pragma mark 红外学习
- (void)touchedStudyMode:(UIButton *)sender{
    sender.selected      = YES;
    isBeginStudy          = YES;
    btnEndStudy.selected = NO;
}
- (void)touchedEndStudy:(UIButton *)sender{
    if(isBeginStudy == YES ){
        [self performSelector:@selector(showHint:) withObject:@"操作成功" afterDelay:.7];
    }
    isBeginStudy          = NO;
    sender.selected      = YES;
    btnStudy.selected    = NO;
}
//////////////////保存更改到网关
- (void)saveAsStateToGateway{
    if (isModifed) {
        ///////////1.更新至数据库
        [CYM_Engine updateContrlValueKeys:aryStudedKey ValueName:self.name];
        ///////////2.上传至网关
        NSData *roomData = [CYM_Engine generateJSONFileWithName:@"control.json"];
        [[HE_APPManager sharedManager] uploadFileWithName:@"control.json" andData:roomData isShowHUD:YES];
        NSLog(@"Save");
    }
}
#pragma mark Private Method
- (CGFloat)getMaxTemperature:(NSArray *)aArry{
    ////在遍历中找到温度最大值
    CGFloat maxTem = 0;
    for (ControlDeviceContentValueKey *k in aArry) {
        if ([k.name myContainsString:@"℃"]) {
            //
            NSString *strSeparate = [k.name myContainsString:@"制热"]?@"制热":@"制冷";
            NSArray *aryTMP = [k.name componentsSeparatedByString:strSeparate];
            if (aryTMP.count >= 2) {
                NSString *strVal = [((NSString *)aryTMP[1]) componentsSeparatedByString:@"℃"][0];
                if (maxTem < strVal.floatValue) {
                    maxTem = strVal.floatValue;
                }
            }
        }
    }
    return maxTem;
}

- (CGFloat)getMinTemperature:(NSArray *)aArry{
    ////在遍历中找到温度最大值
    CGFloat minTem = 30;
    for (ControlDeviceContentValueKey *k in aArry) {
        if ([k.name myContainsString:@"℃"]) {
            //
            NSString *strSeparate = [k.name myContainsString:@"制热"]?@"制热":@"制冷";
            NSArray *aryTMP = [k.name componentsSeparatedByString:strSeparate];
            if (aryTMP.count >= 2) {
                NSString *strVal = [((NSString *)aryTMP[1]) componentsSeparatedByString:@"℃"][0];
                if (minTem > strVal.floatValue) {
                    minTem = strVal.floatValue;
                }
            }
        }
    }
    return minTem;
}
/////////////////计算 自定义的按钮名称 数组
- (NSMutableArray *)getCustomeWithDefault:(NSMutableArray *)aryDefault
                                   Studed:(NSMutableArray *)aryStuded{//存储当前已学习的KeyAry、 其中每个元素为ControlDeviceContentValueKey
    NSMutableArray *aryResult = [NSMutableArray array];
    
    for (ControlDeviceContentValueKey *k in aryStuded) {
        BOOL isCustome = YES;
        for (NSString *s in aryDefault) {
            if ([k.name isEqualToString:s] || [k.name myContainsString:@"℃"] || [k.name myContainsString:@"bw"]) {
                isCustome = NO;
                break;
            }
        }
        if (isCustome) {
            [aryResult addObject:k.name];
        }
    }
    return aryResult;
}
////////////////计算该设备 已学习的Key名称数组
- (NSMutableArray *)getStudedNameWithKey:(NSArray *)key{
    NSMutableArray *ary = [NSMutableArray array];
    for (ControlDeviceContentValueKey  *obj in key) {
        [ary addObject:obj.name];
    }
    return ary;
}
////////////////判断新增按钮是否重名
- (BOOL)isRepateKeyNameWithStudedKey:(NSArray *)aryStuedKey andName:(NSString *)aName{
    BOOL isRepated = NO;
    for (ControlDeviceContentValueKey *k in aryStuedKey) {
        if ([k.name isEqualToString:aName]) {
            isRepated = YES;break;
        }
    }
    return isRepated;
}
////////////////获取该多功能控制器  已学习的索引(十进制)
- (NSMutableArray *)getDeviceStudedIndex:(NSString *)muteDevName{
    NSMutableArray *aryIndex  = [NSMutableArray array];
    ControlDeviceContentValue *val = [CYM_Engine getDeviceDetailsWithDeviceName:muteDevName];
    NSArray        *aryAllKey = [CYM_Engine getCategoryAllKeyWithValue:val];
    ///1.获取到所有索引
    for (ControlDeviceContentValueKey *valueKey in aryAllKey) {
        if (valueKey.value.length >= 24) {////为一条正确的 多功能控制器的控制命令
            //////获取索引值---》转化为10进制
            NSString *hexString = [valueKey.value substringWithRange:NSMakeRange(19, 3)];
            [aryIndex addObject:hexString.IntString];
        }
    }
    ///2.升序排序
    aryIndex = [self orderAscWithArry:aryIndex];
    
    return aryIndex;
}
////////////////取得一个空闲索引(16进制)-aryUsed(为10进制字符)升序、则第一个不连续值、为最小空闲索引
- (NSString *)getMinUnusedIndexWithAry:(NSArray *)aryUsed{
    NSString  *strUnusedIndex = nil;
    NSInteger  idexCounter    = 0;
    
    ////////////如果没有学习过 返回索引0x00
    if (aryUsed == nil || aryUsed.count == 0) {
        idexCounter = 0;
        strUnusedIndex = [NSString stringWithFormat:@"%03lX",(long)idexCounter];
        return strUnusedIndex;
    }
    ///////////已学习
    for (NSString *s in aryUsed) {
        //////正常递增
        if (s.intValue == idexCounter || s.intValue == (idexCounter + 1)) {
            idexCounter = s.intValue;
        }
        //////找到间隙中未使用的Key
        else {///(int_s.intValue > (idexCounter + 1))
            idexCounter ++;
            strUnusedIndex = [NSString stringWithFormat:@"%03lX",(long)idexCounter];
            break;
        }
    }
    //2.全部都连续、取最后一个值+1.
    if (strUnusedIndex == nil) {
        NSString *s = [aryUsed lastObject];
        idexCounter = s.intValue + 1;
        strUnusedIndex = [NSString stringWithFormat:@"%03lX",(long)idexCounter];
    }
    return strUnusedIndex;
}

////////////////升序排序
- (NSMutableArray *)orderAscWithArry:(NSMutableArray *)ary{
    if (ary.count > 1) {
        for (int i=0; i< (ary.count - 1); i++) {
            int k = i;
            for (int j=i+1; j<ary.count; j++) {
                NSInteger ary_j = [ary[j] IntString].integerValue;
                NSInteger ary_k = [ary[k] IntString].integerValue;
                if (ary_j < ary_k) {
                    k = j;
                }
            }
            id tmp = ary[k];
            ary[k] = ary[i];
            ary[i] = tmp;
        }
    }    return ary;
}
@end
