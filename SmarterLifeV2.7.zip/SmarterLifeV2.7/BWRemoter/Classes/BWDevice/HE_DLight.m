//
//  HE_DLight.m
//  BWRemoter
//
//  Created by JianBo He on 14/12/4.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "HE_DLight.h"


@implementation HE_DLight
@synthesize backImage;
@synthesize labName;
- (id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        if(self.frame.size.width < 50){
            self.layer.cornerRadius = 5.f;//圆角s
        }
        else{
            self.layer.cornerRadius = 15.0f;
        }
        self.layer.borderColor = [[UIColor colorWithRed:200/255.0f green:200/255.0f blue:200/255.0f alpha:1] CGColor];//Border颜色
        self.layer.borderWidth = 1.f;//Border宽度
        //背景 和  名称
        
        CGRect labFrame = self.bounds;
        CGRect backFrame = self.bounds;
        labFrame.origin.y = self.bounds.size.height * 0.72f;
        labFrame.size.height = self.bounds.size.height *0.25f;
        backFrame.size.height *= .7f;
        backFrame.size.width *= .7f;
        backFrame.origin.x = self.bounds.size.width * 0.15f;
        backFrame.origin.y = 3.f;
        labName   = [[UILabel alloc] initWithFrame:labFrame];
        backImage = [[UIImageView alloc] initWithFrame:backFrame];
        [labName setFont:[UIFont systemFontOfSize:12.f]];
        [labName setTextAlignment:NSTextAlignmentCenter];
        [self addSubview:backImage];
        [self insertSubview:labName aboveSubview:backImage];
    }
    return self;
}
- (void)setAttrWithCtrlValue:(ControlDeviceContentValue *)val{
    [super setAttrWithCtrlValue:val];
    [self setBackgroundColor:[UIColor whiteColor]];
    strOffImg = @"ic_Light.png";
    strOnImg = @"ic_Light_H.png";
    //点击事件
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tiggleState)];
    [self addGestureRecognizer:tap];
    
    self.labName.adjustsFontSizeToFitWidth = YES;
    [self.labName setText:name];
    [backImage setImage:[UIImage imageNamed:strOffImg]];
}

#pragma mark -
#pragma mark Public Method
- (void)turnOn{
    NSString *cmd = nil;
    NSString *cmdQuery = nil;
    NSTimeInterval time = 0;
    //判断设备类型
    switch (deviceType) {
        case A4_DEVICE_LIGHT:
        case A4_DEVICE_CURTAIN:
        case A4_DEVICE_SOCKET:{
             cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType Data:[NSString stringWithFormat:@"%@64", num]];
        }break;
        case A4_DEVICE_IO:{
            cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType Data:[NSString stringWithFormat:@"%@0300", num]];
        }break;
        case A4_DEVICE_UART:{
            ControlDeviceContentValueKey *key = [self getValueKeyForName:@"开" withArray:aryKey];
            if (key != nil) {
                cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType
                                        Data:[NSString stringWithFormat:@"%@%02X%@",self.num, (int)key.value.length/2,key.value]];
                /////如果有查询。需要发送则发送查询命令
                if ([key.query isNotEmptyAndNil] && ![key.query isEqualToString:@"null"]){
                    cmdQuery = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType
                                                 Data:[NSString stringWithFormat:@"%@%02X%@",self.num, (int)key.query.length/2,key.query]];
                    time = key.time.doubleValue / 1000;
                }
            }
        }break;
        case A4_DEVICE_THREE:{
            ControlDeviceContentValueKey *key = [self getValueKeyForName:@"开" withArray:aryKey];
            if (key != nil) {
                cmd = key.value;
                /////如果有查询。需要发送则发送查询命令
                cmdQuery = key.query;
                time = key.time.doubleValue / 1000;
            }
        }break;
        default:
            break;
    }
    //如果命令不为空，则执行
    if ([cmd isNotEmptyAndNil]) {
        NSString *strMsg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:cmd];
        [[HE_APPManager sharedManager] SendMsg:strMsg withNameSpace:@"control" isShowLoading:[self isNeedShowLoading:strMsg]];
    }
    if ([cmdQuery isNotEmptyAndNil]) {
        NSString *strMsg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:cmdQuery];
        
        [[HE_APPManager sharedManager] SendQueryMsg:strMsg withNameSpace:@"control" after:time];
    }
}
- (void)turnOff{
    NSString *cmd = nil;
    NSString *cmdQuery = nil;
    NSTimeInterval time = 0;
    switch (deviceType) {
        case A4_DEVICE_LIGHT:
        case A4_DEVICE_CURTAIN:
        case A4_DEVICE_SOCKET:{
            cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType Data:[NSString stringWithFormat:@"%@00", num]];
        }break;
        case A4_DEVICE_IO:{
            cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType Data:[NSString stringWithFormat:@"%@0200", num]];
        }break;
        case A4_DEVICE_UART:{
            ControlDeviceContentValueKey *key = [self getValueKeyForName:@"关" withArray:aryKey];
            if (key != nil) {
                cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType
                                        Data:[NSString stringWithFormat:@"%@%02X%@",self.num, (int)key.value.length/2,key.value]];
                /////如果有查询。需要发送则发送查询命令
                if([key.query isNotEmptyAndNil] && ![key.query isEqualToString:@"null"]){
                    cmdQuery = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType
                                                 Data:[NSString stringWithFormat:@"%@%02X%@",self.num, (int)key.query.length/2,key.query]];
                    time = key.time.doubleValue / 1000;
                }
            }
        }break;
        case A4_DEVICE_THREE:{
            ControlDeviceContentValueKey *key = [self getValueKeyForName:@"关" withArray:aryKey];
            if (key != nil) {
                cmd = key.value;
                /////如果有查询。需要发送则发送查询命令
                cmdQuery = key.query;
                time = key.time.doubleValue / 1000;
            }
        }break;
        default:
            break;
    }
    if ([cmd isNotEmptyAndNil]) {
        NSString *strMsg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:cmd];
        [[HE_APPManager sharedManager] SendMsg:strMsg withNameSpace:@"control" isShowLoading:[self isNeedShowLoading:strMsg]];
    }
    if ([cmdQuery isNotEmptyAndNil]) {
        NSString *strMsg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:cmdQuery];
        
        [[HE_APPManager sharedManager] SendQueryMsg:strMsg withNameSpace:@"control" after:time];
    }
}
- (void)tiggleState{
    if (isOn){
        [self turnOff];
    }
    else{
        [self turnOn];
    }
}


#pragma mark -
#pragma mark Private Method
- (void)updateTheDeviceStateWithData:(NSString *)strData{
    switch (deviceType) {
        case A4_DEVICE_LIGHT:
        case A4_DEVICE_CURTAIN:
        case A4_DEVICE_SOCKET:{
            NSString *strState = [strData substringToIndex:2];
            if ([strState isEqualToString:@"00"]) {
                [backImage setImage:[UIImage imageNamed:strOffImg]];
                isOn = false;
            }
            else{
                [backImage setImage:[UIImage imageNamed:strOnImg]];
                isOn = true;
            }
        }break;
        case A4_DEVICE_IO:{
            NSString *strState = [strData substringToIndex:2];
            if ([strState isEqualToString:@"02"]) {
                [backImage setImage:[UIImage imageNamed:strOffImg]];
                isOn = false;
            }
            else{
                [backImage setImage:[UIImage imageNamed:strOnImg]];
                isOn = true;
            }
        }break;
        case A4_DEVICE_THREE:
        case A4_DEVICE_UART:{
            for (ControlDeviceContentValueKey *k in aryKey) {
                ////////有此反馈
                if ([strData.uppercaseString myContainsString:k.backkey.uppercaseString]) {
                    NSLog(@"反馈按钮：%@",k.name);
                    ////////////////开 / 关
                    if ([k.name isEqualToString:@"开"]) {
                            [backImage setImage:[UIImage imageNamed:strOnImg]];
                            isOn = true;
                    }
                    else if ([k.name isEqualToString:@"关"]){
                        [backImage setImage:[UIImage imageNamed:strOffImg]];
                        isOn = false;
                    }
                    break;
                }
            }
        }break;
        default:
            break;
    }
}


@end
