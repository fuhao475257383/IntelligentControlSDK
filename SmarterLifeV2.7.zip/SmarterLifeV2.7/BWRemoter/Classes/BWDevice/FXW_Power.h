//
//  FXW_Power.h
//  BWRemoter
//
//  Created by 6602_Loop on 14-12-29.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HE_UIDevice.h"

@interface FXW_Power : HE_UIDevice
{
    NSString *strOnImg;
    NSString *strOffImg;
    BOOL isOn;
    NSString *curData;
}
@property UIImageView *backImage;
@property UILabel *labName;

- (void)turnOn;
- (void)turnOff;
- (void)tiggleState;
- (void)setName:(NSString *)str;
@end
