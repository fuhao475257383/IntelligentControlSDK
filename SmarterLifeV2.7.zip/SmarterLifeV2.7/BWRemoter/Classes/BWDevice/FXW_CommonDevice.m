//
//  FXW_CommonDevice.m
//  BWRemoter
//
//  Created by iceDiao on 15/3/13.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "FXW_CommonDevice.h"
#import "FXW_BackmusicVC.h"
#import "FXW_ScenoModeVC.h"
#import "HE_TVControlVC.h"
#import "HE_CustomeInfraredVC.h"
#import "FXW_ConditionVC.h"
#import "FXW_CenterConditionVC.h"
@implementation FXW_CommonDevice

@synthesize backImage,labName,delegate,aryMusic,aryScene,contentValue;

-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    labName = [[UILabel alloc]init];
    backImage = [[UIImageView alloc]init];
    return self;
}
- (void)drawRect:(CGRect)rect {
    self.layer.cornerRadius = 5.f;//圆角s
    self.layer.borderColor = [[UIColor grayColor] CGColor];//Border颜色
    self.layer.borderWidth = 1.f;//Border宽度
    [self setBackgroundColor:[UIColor whiteColor]];
    //背景 和  名称
    CGRect labFrame = rect;
    CGRect backFrame = rect;
    labFrame.origin.y = rect.size.height * 0.72f;
    labFrame.size.height = rect.size.height *0.25f;
    backFrame.size.height *= .7f;
    backFrame.size.width *= .7f;
    backFrame.origin.x = rect.size.width * 0.15f;
    backFrame.origin.y = 3.f;
    [labName setFont:[UIFont systemFontOfSize:12.f]];
    [backImage setFrame:backFrame];
    [backImage setImage:[UIImage imageNamed:imgName]];
    [labName setFrame:labFrame];
    [labName setTextAlignment:NSTextAlignmentCenter];
    [labName setText:title];
    labName.numberOfLines = 0;
    labName.adjustsFontSizeToFitWidth = YES;
    [self addSubview:backImage];
    self.clipsToBounds = YES;
    [self insertSubview:labName aboveSubview:backImage];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapLink)];
    if(isTap){
        for (UIGestureRecognizer *ges in self.gestureRecognizers ) {
            [tap requireGestureRecognizerToFail:ges];
        }
        [self addGestureRecognizer:tap];
    }
    if ([self.property isEqualToString:@"场景控制器"]&&![self isHavePrio:aryScene[0]]) {
        self.userInteractionEnabled = NO;
        self.alpha = 0.4;
    }
}
////点击跳转
-(void)tapLink{
    if([self.property isEqualToString:@"背景音乐"]){
        FXW_BackmusicVC *music = [[FXW_BackmusicVC alloc]init];
        if([delegate respondsToSelector:@selector(pushViewController:animated:)]){
            music.hidesBottomBarWhenPushed = YES;
            [music setAryMuiscDev:aryMusic];
            [delegate pushViewController:music animated:YES];
        }
    }
    else if ([self.property isEqualToString:@"中央空调"]){
        FXW_CenterConditionVC *CenterCondition = [[FXW_CenterConditionVC alloc]init];
        [CenterCondition setModalTransitionStyle:UIModalTransitionStyleCoverVertical];
        if ([delegate respondsToSelector:@selector(pushViewController:animated:)]) {
            CenterCondition.hidesBottomBarWhenPushed=YES;
            [CenterCondition setConditionValue:contentValue];
            [delegate pushViewController:CenterCondition animated:YES];
        }
    }
    else if([self.property isEqualToString:@"单体空调"]){
        FXW_ConditionVC *vc = [[FXW_ConditionVC alloc] init];
        [vc  setIsStudyMode:NO];
        [vc setSingleAircondition:contentValue];
        if ([delegate respondsToSelector:@selector(pushViewController:animated:)]) {
            vc.hidesBottomBarWhenPushed = YES;
            [delegate pushViewController:vc animated:YES];
        }
    }
    else if([self.property isEqualToString:@"电视/播放器/DVD"]){
        HE_TVControlVC *vc = [[HE_TVControlVC alloc] init];
        [vc setIsStudyMode:NO];
        [vc setDeviceTV:contentValue];
        if([delegate respondsToSelector:@selector(pushViewController:animated:)]){
            [vc setHidesBottomBarWhenPushed:YES];
            [delegate pushViewController:vc animated:YES];
        }
    
    }
    else if([self.property isEqualToString:@"自定义设备"]){
        HE_CustomeInfraredVC *vc = [[HE_CustomeInfraredVC alloc] init];
        if ([delegate respondsToSelector:@selector(pushViewController:animated:)]) {
            vc.hidesBottomBarWhenPushed = YES;
            vc.isStudyMode              = NO;
            vc.deviceValue              = contentValue;
            [delegate pushViewController:vc animated:YES];
        }
    }
    else if([self.property isEqualToString:@"场景控制器"]){
        FXW_ScenoModeVC *scenevc = [[FXW_ScenoModeVC alloc]init];
        if([delegate respondsToSelector:@selector(pushViewController:animated:)]){
            scenevc.hidesBottomBarWhenPushed = YES;
            [scenevc setSceneList:aryScene];
            [delegate pushViewController:scenevc animated:YES];
        }
    }
}

-(void)setBackimgName:(NSString *)imgname andTitle:(NSString *)text IsTapLink:(BOOL)istap{
    imgName = imgname;
    title = text;
    isTap = istap;
}
//这里传递权限进来，重写了父类方法
- (void)setAttrWithCtrlValue:(ControlDeviceContentValue *)val{
//    ID       = val.ID;
//    num      = [cmdP getDeviceNumWithBindCMD:val.value];
//    name     = val.name;
//    com      = val.com;
//    category = val.category;
//    property = val.property;
    prio     = val.prio;
//    value    = val.value;
//    aryKey   = val.keyArr;
}
//这里判断权限，重写了父类方法
-(BOOL)hasPermission{
    NSString *permission = [[HE_APPManager sharedManager] User].strPermission;
    if (prio == nil || [prio isEqualToString:@""] || [prio isEqualToString:@"null"] || [prio isEqualToString:@"FFFFFFFFFFFFF"]) {
        return YES;
    }
    if(![permission integerValue]==0){
        UInt64 prioH = [prio IntString].longLongValue;
        prioH =  prioH >> ([permission IntString].intValue -1);
        return prioH&1;
    }
    else{
        return YES;
    }
}
//这里是判断内部的子视图是否有权限，但是感觉不用判断
//- (BOOL)isPermissionwithDevicePrio:(NSString *)pri andPermission:(NSString *)permission{
//    if(!([permission integerValue]==0)){
//        UInt64 prioH = [pri IntString].longLongValue;
//        prioH =  prioH >> ([permission IntString].intValue -1);
//        return prioH&1;
//    }
//    else{
//        return YES;
//    }
//}
- (BOOL)isHavePrio:(Scene *)scene {
//    NSLog(@"设备名称%@",scene.name);
    for (SceneDevice *device in scene.deviceArr) {
        ControlDeviceContentValue *value1 = [CYM_Engine getDeviceDetailsWithDeviceName:device.name];
//        NSLog(@"设备权限%@",value1.prio);
        NSString *permission = [[HE_APPManager sharedManager] User].strPermission;
        if(![permission integerValue]==0){
            UInt64 prioH = [value1.prio IntString].longLongValue;
            prioH =  prioH >> ([permission IntString].intValue -1);
            if (!(prioH&1)) {
                return NO;
            }
        }
        else{
            return YES;
        }
    }
    return YES;
}

@end
