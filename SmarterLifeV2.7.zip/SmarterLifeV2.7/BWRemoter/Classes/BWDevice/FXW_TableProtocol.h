//
//  FXW_TableProtocol.h
//  DropDownDemo
//
//  Created by 6602_Loop on 15-1-12.
//  Copyright (c) . All rights reserved.
//
#import <Foundation/Foundation.h>
@protocol FXW_tableDelegate <NSObject>
@optional

//-(void) chooseAtSection:(NSInteger)section index:(NSInteger)index;
@end
@protocol FXW_tableDataSourse <NSObject>
///场景名
-(NSString *)SenceTitle:(NSInteger)index;
///时间
-(NSTimer *)SenceTime:(NSInteger)index;
-(NSString *)SenceOperaton:(NSInteger)index;
///表格总行数
-(NSInteger)numberOfRowsInSection;
@end