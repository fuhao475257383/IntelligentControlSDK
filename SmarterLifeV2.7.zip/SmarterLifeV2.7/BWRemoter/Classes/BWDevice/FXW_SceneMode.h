//
//  FXW_SceneMode.h
//  BWRemoter
//
//  Created by 6602_Loop on 15-2-12.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Scene.h"
#import "HE_UIDevice.h"
@interface FXW_SceneMode :UIView
//{
//    NSInteger index;//当前表格显示位置使用
//    NSInteger i;//用于当前表格数是否小于4
//    NSInteger rowsnum;//表格总行数
//    NSInteger sum;
//    NSMutableArray *scene_list;
//    
//    //用于标识控制的那个场景的index
//    NSInteger ctrlIndex;
//}
//背景灰
@property (nonatomic, strong) UIView *BackView;
//下面白色背景
@property (nonatomic, strong)UIView *TableBaseView;
//场景执行中...
@property (nonatomic, strong)UILabel *TableTitle;
//table
@property (nonatomic, strong) UITableView *Table;
@property (retain) Scene *scene;
@end
