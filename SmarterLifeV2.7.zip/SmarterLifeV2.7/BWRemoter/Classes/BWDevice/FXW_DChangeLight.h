//
//  FXW_DChangeLight.h
//  BWRemoter
//
//  Created by 6602_Loop on 14-12-9.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HE_UIDevice.h"

@interface FXW_DChangeLight : HE_UIDevice{
    //灯光
    NSString *strOnImg;
    NSString *strOffImg;
    BOOL isOn;

}
@property UIImageView *backImage;
@property UIImageView *backImage2;
@property UILabel *labName;
@property UILabel *percent;

- (void)turnTo:(NSInteger)val;
- (void)tiggleState;
- (void)setName:(NSString *)str;

@end
