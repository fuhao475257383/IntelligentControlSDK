//
//  FXW_BackMusic.h
//  BWRemoter
//
//  Created by 6602_Loop on 15-1-15.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HE_UIDevice.h"
#import "FXW_Slider.h"

@interface FXW_BackMusic : HE_UIDevice

@end
