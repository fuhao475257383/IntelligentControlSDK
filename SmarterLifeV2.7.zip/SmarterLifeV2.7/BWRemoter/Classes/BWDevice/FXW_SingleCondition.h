//
//  FXW_SingleCondition.h
//  BWRemoter
//
//  Created by 6602_Loop on 15-3-7.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "HE_UIDevice.h"
#import "FXW_ScrollView.h"
@interface FXW_SingleCondition : HE_UIDevice<FXW_ScrollViewDelegate>

////////////温度滚动视图
@property (nonatomic,strong) FXW_ScrollView *scrollTemperature;

////////////进入红外学习Mode
- (void)enterStudyMode;
//////////////////保存更改到网关
- (void)saveAsStateToGateway;
@end
