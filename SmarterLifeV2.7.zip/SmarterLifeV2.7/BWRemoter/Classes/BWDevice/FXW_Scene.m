//
//  FXW_Scene.m
//  BWRemoter
//
//  Created by 6602_Loop on 14-12-27.
//  Copyright (c) 2014年 . All rights reserved.
//

#import "FXW_Scene.h"

#define Screenwidth [UIScreen mainScreen].bounds.size.width
#define Screenheight [UIScreen mainScreen].bounds.size.height
@implementation FXW_Scene

- (id)initWithFrame:(CGRect)frame Delegate:(id)delegate Datasourse:(id)datasourse {
    self = [super initWithFrame:frame];
    if(self){
        i=2;
        index=1;
        self.FXW_tableDelegate = delegate;
        self.FXW_tableDataSource = datasourse;
        //背景灰
        self.BackView =[[UIView alloc]initWithFrame:CGRectMake(0, 0, Screenwidth, Screenheight)];
        [self.BackView setBackgroundColor:[UIColor grayColor]];
        self.BackView.alpha = 0.5f;
        [self addSubview:self.BackView];
        
        //底部view
        self.TableBaseView = [[UIView alloc]initWithFrame:CGRectMake(Screenwidth*0.1, Screenheight*0.7, Screenwidth*0.8, Screenheight*0.3)];
        [self.TableBaseView setBackgroundColor:[UIColor whiteColor]];
        [self addSubview:self.TableBaseView];
        //场景执行中...
        self.TableTitle =[[UILabel alloc]initWithFrame:CGRectMake(0, 2, self.TableBaseView.frame.size.width, 20)];
        [self.TableTitle setText:@"场景执行中..."];
        [self.TableTitle setTextAlignment:NSTextAlignmentCenter];
        [self.TableTitle setTextColor:[UIColor blackColor]];
        [self.TableBaseView addSubview:self.TableTitle];
        //table
        self.Table = [[UITableView alloc]initWithFrame:CGRectMake(0, (self.TableBaseView.frame.size.height)/4*3, self.TableBaseView.frame.size.width, self.TableBaseView.frame.size.height-22)];
        self.Table.delegate=self;
        self.Table.dataSource=self;
        [self.TableBaseView addSubview:self.Table];
    }
    return self;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString * cellIdentifier = @"cellIdentifier";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"123"];
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    UILabel *ListSence = (UILabel *)[cell viewWithTag:1001];
    if (!ListSence) {
        ListSence = [[UILabel alloc]initWithFrame:CGRectMake(20, 0, cell.frame.size.width*0.45-20, cell.frame.size.height)];
        ListSence.adjustsFontSizeToFitWidth=YES;
        [ListSence setText:[NSString stringWithFormat:@"%ld %@",(long)indexPath.row+1,[self.FXW_tableDataSource SenceTitle:indexPath.row]]];
        ListSence.tag =1001;
        [cell.contentView addSubview:ListSence];
    }
    UILabel *labOperation = (UILabel *)[cell viewWithTag:1003];
    if (!labOperation) {
        labOperation = [[UILabel alloc]initWithFrame:CGRectMake(cell.frame.size.width*0.45, 0,cell.frame.size.width*0.55-110, cell.frame.size.height)];
        labOperation.adjustsFontSizeToFitWidth=YES;
        [labOperation setText:[self.FXW_tableDataSource SenceOperaton:indexPath.row]];
        labOperation.tag =1003;
        [cell.contentView addSubview:labOperation];
    }
    
    UILabel *ListTime = (UILabel *)[cell viewWithTag:1002];
    if (!ListTime) {
        ListTime = [[UILabel alloc]initWithFrame:CGRectMake(cell.frame.size.width-110, 0, 110, cell.frame.size.height)];
        ListTime.adjustsFontSizeToFitWidth=YES;
        [ListTime setText:[NSString stringWithFormat:@"%@ s",(NSString *)[self.FXW_tableDataSource SenceTime:indexPath.row]]];
        ListTime.tag =1002;
        [cell.contentView addSubview:ListTime];
    }
    if(indexPath.row ==[self.FXW_tableDataSource numberOfRowsInSection]){
    }
    return cell;
}

#pragma mark --按时间执行
-(void)runtime{
    /***      执行命令     ***/
    id obj = [scene_list objectAtIndex:ctrlIndex];
    if(((Scene *)obj).deviceArr.count>0){
        if ([obj isKindOfClass:[Scene class]]){
            //type = 1
            Scene *scene = (Scene *)obj;
            SceneDevice *scenDev = [scene.deviceArr objectAtIndex:sum];
            //发送消息
            [[HE_APPManager sharedManager] SendMsg:scenDev.value withNameSpace:@"control" isShowLoading:NO];
        }
        /***       End      ***/
        if(sum!=rowsnum-1){//如果正在场景执行中。。反之执行完成  sum为执行的索引
            sum++;
            if(i<=4)
            {
                [UIView animateWithDuration:0.3 delay:0 options:UIViewAnimationOptionTransitionFlipFromLeft
                                 animations:^{
                                     CGRect rect = self.Table.frame;
                                     rect.origin.y =(rect.size.height)/4*(4-i)+22;
                                     [self.Table setFrame:rect];
                                     i++;
                                 } completion:^(BOOL finish){
                                 }];
            }
            else{
                if(index<rowsnum-3){//超过4格往上移
                    NSIndexPath *scrollIndexPath = [NSIndexPath indexPathForRow:index inSection:0];
                    [self.Table scrollToRowAtIndexPath:scrollIndexPath
                                      atScrollPosition:UITableViewScrollPositionTop animated:YES];
                    index++;
                }
            }
        }
        else{
            [UIView animateWithDuration:0.3 delay:0 options:UIViewAnimationOptionTransitionFlipFromLeft
                             animations:^{
                                 self.BackView.alpha=0.4;
                                 self.BackView.alpha=0.2;
                                 self.TableBaseView.alpha=0.7;
                                 self.TableBaseView.alpha=0.3;
                             } completion:^(BOOL finish){
                                 [self removeFromSuperview];
                             }];
        }
    }
    else{
        [UIView animateWithDuration:0.3 delay:0.7 options:UIViewAnimationOptionTransitionFlipFromLeft
                         animations:^{
                             self.BackView.alpha=0.4;
                             self.BackView.alpha=0.2;
                             self.TableBaseView.alpha=0.7;
                             self.TableBaseView.alpha=0.3;
                         } completion:^(BOOL finish){
                             [self removeFromSuperview];
                         }];
    }
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    rowsnum =[self.FXW_tableDataSource numberOfRowsInSection];
    return [self.FXW_tableDataSource numberOfRowsInSection];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return self.Table.frame.size.height/4.0;
}
-(void)SetsceneList:(NSMutableArray *)array andindex:(NSInteger)listindex{
    ctrlIndex = listindex;
    scene_list = array;
    ///////////将权限代码加上
    super.prio = ((HE_UIDevice *)scene_list[ctrlIndex]).prio;
}




@end
