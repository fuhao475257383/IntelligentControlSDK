//
//  DoorView.h
//  BWRemoter
//
//  Created by tc on 15/11/13.
//  Copyright © 2015年 ReSun. All rights reserved.
//

#import "HE_UIDevice.h"

@interface DoorView : HE_UIDevice

//门的名字
@property (nonatomic,strong) NSString *doorName;
//显示叹号警示
- (void)showExclamationMarkView;
//移除叹号
- (void)removeExclamationMarkView;
//开门
- (void)openDoor;

@end
