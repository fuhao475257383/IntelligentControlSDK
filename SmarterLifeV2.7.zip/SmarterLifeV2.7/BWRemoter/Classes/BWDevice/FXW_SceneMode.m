//
//  FXW_SceneMode.m
//  BWRemoter
//
//  Created by 6602_Loop on 15-2-12.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "FXW_SceneMode.h"
#define Screenwidth [UIScreen mainScreen].bounds.size.width
#define Screenheight [UIScreen mainScreen].bounds.size.height
@implementation FXW_SceneMode
@synthesize scene;
-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    //背景灰
    self.BackView =[[UIView alloc]initWithFrame:CGRectMake(0, 0, Screenwidth, Screenheight)];
    [self.BackView setBackgroundColor:[UIColor grayColor]];
    self.BackView.alpha = 0.5f;
    [self addSubview:self.BackView];
    
    //底部view
    self.TableBaseView = [[UIView alloc]initWithFrame:CGRectMake(Screenwidth*0.1, Screenheight*0.7, Screenwidth*0.8, Screenheight*0.3)];
    [self.TableBaseView setBackgroundColor:[UIColor whiteColor]];
    [self addSubview:self.TableBaseView];
    //场景执行中...
    self.TableTitle =[[UILabel alloc]initWithFrame:CGRectMake(0, 2, self.TableBaseView.frame.size.width, 20)];
    [self.TableTitle setText:@"场景执行中..."];
    [self.TableTitle setTextAlignment:NSTextAlignmentCenter];
    [self.TableTitle setTextColor:[UIColor blackColor]];
    [self.TableBaseView addSubview:self.TableTitle];
    //table
    self.Table = [[UITableView alloc]initWithFrame:CGRectMake(0, (self.TableBaseView.frame.size.height)/4*3, self.TableBaseView.frame.size.width, self.TableBaseView.frame.size.height-22)];
    [self.TableBaseView addSubview:self.Table];
    return self;
}
@end
