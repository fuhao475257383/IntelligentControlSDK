//
//  FXW_Curtain.m
//  BWRemoter
//
//  Created by 6602_Loop on 14-12-14.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "FXW_Curtain.h"

@implementation FXW_Curtain
@synthesize labName;
@synthesize on;
@synthesize off;
@synthesize image;

- (id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        if (!labName) {
            labName = [[UILabel alloc] init];
        }
        if(!on){
            on = [[UIButton alloc]initWithFrame:CGRectMake(0, self.frame.size.height*0.15,self.frame.size.width/3, self.frame.size.height*0.5)];
        }
        if(!off){
            off = [[UIButton alloc]initWithFrame:CGRectMake(self.frame.size.width*2/3, self.frame.size.height*0.15, self.frame.size.width/3, self.frame.size.height*0.5)];
        }
        if(!image){
            image = [[UIImageView alloc] initWithFrame:CGRectMake(self.frame.size.width/8*3, self.frame.size.height*0.1, self.frame.size.width/4,self.frame.size.width/4)];
        }
        isOn = false;
    }
    return self;
}
- (void)drawRect:(CGRect)rect {
    if(frame_Type == 1){
        self.layer.cornerRadius = 15.f;//圆角s
        [on.titleLabel setFont:[UIFont boldSystemFontOfSize:20.0f]];
         [off.titleLabel setFont:[UIFont boldSystemFontOfSize:20.0f]];
    }
    else{
        self.layer.cornerRadius = 5.f;//圆角s
        [on.titleLabel setFont:[UIFont boldSystemFontOfSize:10.0f]];
        [off.titleLabel setFont:[UIFont boldSystemFontOfSize:10.0f]];
    }
    
    self.layer.borderColor = [[UIColor colorWithRed:200/255.0f green:200/255.0f blue:200/255.0f alpha:1] CGColor];
    self.layer.borderWidth = 1.f;//Border宽度
    [self setBackgroundColor:[UIColor whiteColor]];
    
    [on addTarget:self action:@selector(clickOn) forControlEvents:UIControlEventTouchUpInside];
    [on setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self addSubview:on];

    [image setImage:[UIImage imageNamed:strOffimg]];
    [self addSubview:image];
    [off setTitleColor:[UIColor blackColor]forState:UIControlStateNormal];
    [off addTarget:self action:@selector(clickOff) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:off];

    [labName setFrame:CGRectMake(self.frame.size.width/3, self.frame.size.height*0.65, self.frame.size.width/3,self.frame.size.height*0.3)];
    
    [labName setTextAlignment:NSTextAlignmentCenter];
    [labName setFont:[UIFont systemFontOfSize:16]];
//    labName.alpha=0.8;
    [self addSubview:labName];
    [self setState:isOn];
    self.clipsToBounds = YES;
    self.on.titleLabel.numberOfLines = 0;
    self.on.titleLabel.adjustsFontSizeToFitWidth = YES;
    self.labName.numberOfLines = 0;
    self.labName.adjustsFontSizeToFitWidth = YES;
}

- (void) SetType:(NSString *)Curtype{
    if([Curtype isEqual:@"type1"]){//如果是开关型窗帘
        strOnimg = @"lon.png";
        strOffimg = @"loff.png";
        [on setTitle:@"开" forState:UIControlStateNormal];
        [off setTitle:@"合" forState:UIControlStateNormal];
    }
    else{//如果是升降的窗帘
        strOnimg = @"ton.png";
        strOffimg = @"toff.png";
        [on setTitle:@"升" forState:UIControlStateNormal];
        [off setTitle:@"降" forState:UIControlStateNormal];
    }
}
-(void)setCategoryType:(CurtainCategoryType)categoryType andFrameType:(NSInteger)frameType{
    ////如果是开合窗帘
    frame_Type = frameType;
    if(categoryType == CurtainCategoryTypeOpenClose){
        strOnimg = @"lon.png";
        strOffimg = @"loff.png";
        [on setTitle:@"开" forState:UIControlStateNormal];
        [off setTitle:@"合" forState:UIControlStateNormal];
    }
    else{
        strOnimg = @"ton.png";
        strOffimg = @"toff.png";
        [on setTitle:@"升" forState:UIControlStateNormal];
        [off setTitle:@"降" forState:UIControlStateNormal];
    }
}
-(void)clickOn{
//    NSString *strState = @"FF";
//    NSString *strData = [NSString stringWithFormat:@"%@%@",num, strState];
//    
//    NSString *cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType Data:strData];
//    NSString *msg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:cmd];
//    [[HE_APPManager sharedManager] SendMsg:msg withNameSpace:@"control" isShowLoading:self.isNeedShowLoading];
    
    NSString *cmd = nil;
    NSString *cmdQuery = nil;
    NSTimeInterval time = 0;
    switch (deviceType) {
        case A4_DEVICE_LIGHT:{
            cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType Data:[NSString stringWithFormat:@"%@64", num]];
        }break;
        case A4_DEVICE_CURTAIN:
        case A4_DEVICE_SOCKET:{
            cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType Data:[NSString stringWithFormat:@"%@FF", num]];
        }break;
        case A4_DEVICE_IO:{
            cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType Data:[NSString stringWithFormat:@"%@0300", num]];
        }break;
        case A4_DEVICE_UART:{
            ControlDeviceContentValueKey *key = [self getValueKeyForName:@"开" withArray:aryKey];
            if (key != nil) {
                cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType
                                        Data:[NSString stringWithFormat:@"%@%02X%@",self.num, (int)key.value.length/2,key.value]];
                if ([key.query isNotEmptyAndNil] && ![key.query isEqualToString:@"null"]) {
                    cmdQuery = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType
                                                 Data:[NSString stringWithFormat:@"%@%02X%@",self.num, (int)key.query.length/2,key.query]];
                    time = key.time.doubleValue / 1000;
                }
            }
        }break;
        case A4_DEVICE_THREE:{
            ControlDeviceContentValueKey *key = [self getValueKeyForName:@"开" withArray:aryKey];
            if (key != nil) {
                cmd = key.value;
                cmdQuery = key.query;
                time = key.time.doubleValue / 1000;
            }
        }break;
        default:
            break;
    }
    if ([cmd isNotEmptyAndNil]) {
        NSString *strMsg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:cmd];
        [[HE_APPManager sharedManager] SendMsg:strMsg withNameSpace:@"control" isShowLoading:[self isNeedShowLoading:strMsg]];
    }
    if ([cmdQuery isNotEmptyAndNil]) {
        NSString *strMsg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:cmdQuery];
        
        [[HE_APPManager sharedManager] SendQueryMsg:strMsg withNameSpace:@"control" after:time];
    }
}
- (void)clickOff{
    NSString *cmd = nil;
    NSString *cmdQuery = nil;
    NSTimeInterval time = 0;
    switch (deviceType) {
        case A4_DEVICE_LIGHT:
        case A4_DEVICE_CURTAIN:
        case A4_DEVICE_SOCKET:{
            cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType Data:[NSString stringWithFormat:@"%@00", num]];
        }break;
        case A4_DEVICE_IO:{
            cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType Data:[NSString stringWithFormat:@"%@0200", num]];
        }break;
        case A4_DEVICE_UART:{
            ControlDeviceContentValueKey *key = [self getValueKeyForName:@"关" withArray:aryKey];
            if (key != nil) {
                cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType
                                        Data:[NSString stringWithFormat:@"%@%02X%@",self.num, (int)key.value.length/2,key.value]];
                if ([key.query isNotEmptyAndNil]  && ![key.query isEqualToString:@"null"]) {
                    cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType
                                            Data:[NSString stringWithFormat:@"%@%02X%@",self.num, (int)key.query.length/2,key.query]];
                    time = key.time.doubleValue / 1000;
                }
            }
        }break;
        case A4_DEVICE_THREE:{
            ControlDeviceContentValueKey *key = [self getValueKeyForName:@"关" withArray:aryKey];
            if (key != nil) {
                cmd = key.value;
                cmdQuery = key.query;
                time = key.time.doubleValue / 1000;
            }
        }break;
        default:
            break;
    }
    if ([cmd isNotEmptyAndNil]) {
        NSString *strMsg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:cmd];
        [[HE_APPManager sharedManager] SendMsg:strMsg withNameSpace:@"control" isShowLoading:[self isNeedShowLoading:strMsg]];
    }
    if ([cmdQuery isNotEmptyAndNil]) {
        NSString *strMsg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:cmdQuery];
        
        [[HE_APPManager sharedManager] SendQueryMsg:strMsg withNameSpace:@"control" after:time];
    }
}
//设置状态(开或关)
-(void)setState:(BOOL)state{
    if(state){
        [off setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [on setTitleColor:[UIColor colorWithRed:29/255.0f green:164/255.0f blue:233/255.0f alpha:1] forState:UIControlStateNormal];
        [image setImage:[UIImage imageNamed:strOnimg]];
    }
    else{
        [on setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [off setTitleColor:[UIColor colorWithRed:29/255.0f green:164/255.0f blue:233/255.0f alpha:1] forState:UIControlStateNormal];
        [image setImage:[UIImage imageNamed:strOffimg]];
    }
}

- (void)setAttrWithCtrlValue:(ControlDeviceContentValue *)val{
    [super setAttrWithCtrlValue:val];
    [self.labName setText:name];
}

- (void)updateTheDeviceStateWithData:(NSString *)strData{
    switch (deviceType) {
        case A4_DEVICE_LIGHT:
        case A4_DEVICE_CURTAIN:
        case A4_DEVICE_SOCKET:{
            isOn = true;
            NSString *strState = [strData substringToIndex:2];
            if ([strState isEqualToString:@"00"]) {
                isOn = false;
            }
        }break;
        case A4_DEVICE_IO:{
            isOn = true;
            NSString *strState = [strData substringToIndex:2];
            if ([strState isEqualToString:@"02"]) {
                isOn = false;
            }
        }break;
        case A4_DEVICE_THREE:
        case A4_DEVICE_UART:{
            for (ControlDeviceContentValueKey *k in aryKey) {
                ////////有此反馈
                if ([strData.uppercaseString myContainsString:k.backkey.uppercaseString]) {
                    NSLog(@"反馈按钮：%@",k.name);
                    ////////////////开 / 关
                    if ([k.name isEqualToString:@"开"]) {
                        isOn = true;
                    }
                    else if ([k.name isEqualToString:@"关"]){
                        isOn = false;
                    }
                    break;
                }
            }
        }break;
        default:
            break;
    }
    [self setState:isOn];
}

@end
