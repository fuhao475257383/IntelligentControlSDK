//
//  DoorView.m
//  BWRemoter
//
//  Created by tc on 15/11/13.
//  Copyright © 2015年 ReSun. All rights reserved.
//

#import "DoorView.h"
#import "DoorlockMsg.h"

@interface DoorView () <UIAlertViewDelegate>
//是否是打开的
@property (nonatomic)BOOL isOpen;
//打开时图片
@property (nonatomic,strong) NSString *openImage;
//关闭时图片
@property (nonatomic,strong) NSString *closeImage;
//门的名字
@property (nonatomic,strong) UILabel *label;
//门的图片
@property (nonatomic,strong) UIImageView *door;
//叹号
@property (nonatomic,strong) UIImageView *exclamation;

//统计发送了多少条查询信息，由于发送一条查询信息，就会回复一条，发送一条send+1，收到一条，recv = send,假如发送命令的时候，recv != send则表示门锁已经不在线了。
@property (nonatomic) NSInteger sendNumber;
@property (nonatomic) NSInteger recvNumber;

@end

@implementation DoorView

- (instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        self.sendNumber = 0;
        self.recvNumber = 0;
        
        self.door = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height * 0.8)];
        self.door.image = [UIImage imageNamed:@"doorlock_off.png"];
        [self addSubview:self.door];
        
        self.label  = [[UILabel alloc]initWithFrame:CGRectMake( 0, frame.size.height * 0.8, frame.size.width, frame.size.height * 0.2)];
        self.label.text      = @"未设置名字";
        self.label.adjustsFontSizeToFitWidth = YES;
        self.label.textAlignment = NSTextAlignmentCenter;
        self.label.font      = [UIFont systemFontOfSize:15];
        self.label.textColor = [UIColor blackColor];
        [self addSubview:self.label];
        
        CGRect exclamationRect = CGRectMake(self.bounds.size.width - 15, 0, 15, 15);
        self.exclamation = [[UIImageView alloc]initWithFrame:exclamationRect];
        self.exclamation.image = [UIImage imageNamed:@"icSafeWarning.png"];
        [self.exclamation setContentMode:UIViewContentModeScaleAspectFit];
        [self.exclamation setHidden:YES];
        [self addSubview:self.exclamation];
    }
    return self;
    
}
//显示叹号
- (void)showExclamationMarkView {
    [self.exclamation setHidden:NO];
}
- (void)removeExclamationMarkView {
    [self.exclamation setHidden:YES];
}
//点击事件
- (void)changeDoorState {
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"是否开锁？" message:nil delegate:self cancelButtonTitle:@"是" otherButtonTitles:@"否", nil];
    //由于门锁的特殊性，需要先判断门锁是否激活，这里发送查询命令，如果未激活，则提示“门锁未唤醒，或网络不通”
    [self queryDoorlockState];
    
    [alert show];
    
}
//查询门锁状态
- (void)queryDoorlockState {
    NSString *strData = [NSString stringWithFormat:@"%@", num];
    //NSString *strData = [NSString stringWithFormat:@"%@", @"FFFFFF"];
    NSString *cmd = [cmdB getCMDWithAction:A4_ACTION_QUERY DeviceType:deviceType Data:strData];
    NSString *msg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:cmd];
    [[HE_APPManager sharedManager] SendMsg:msg withNameSpace:@"control" isShowLoading:NO];
}
//alert代理方法
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 0) {
        if (self.sendNumber != self.recvNumber) {
            [[HE_APPManager sharedManager] hudShowMsg:@"门锁未被唤醒，或网络不通" andInterval:1];
            return;
        }
        [self openDoor];
    }
}
//开门
- (void)openDoor {
    
    NSString *cmd = nil;
    NSString *cmdQuery = nil;
    NSTimeInterval time = 0;
    //判断设备类型
    switch (deviceType) {
        case A4_DEVICE_LIGHT:
        case A4_DEVICE_CURTAIN:
        case A4_DEVICE_SOCKET:{
            cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType Data:[NSString stringWithFormat:@"%@64", num]];
        }break;
        case A4_DEVICE_IO:{
            cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType Data:[NSString stringWithFormat:@"%@0300", num]];
        }break;
        case A4_DEVICE_UART:{
            ControlDeviceContentValueKey *key = [self getValueKeyForName:@"开" withArray:aryKey];
            if (key != nil) {
                cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType
                                        Data:[NSString stringWithFormat:@"%@%02X%@",self.num, (int)key.value.length/2,key.value]];
                /////如果有查询。需要发送则发送查询命令
                if ([key.query isNotEmptyAndNil] && ![key.query isEqualToString:@"null"]){
                    cmdQuery = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType
                                                 Data:[NSString stringWithFormat:@"%@%02X%@",self.num, (int)key.query.length/2,key.query]];
                    time = key.time.doubleValue / 1000;
                }
            }
        }break;
        case A4_DEVICE_THREE:{
            ControlDeviceContentValueKey *key = [self getValueKeyForName:@"开" withArray:aryKey];
            if (key != nil) {
                cmd = key.value;
                /////如果有查询。需要发送则发送查询命令
                cmdQuery = key.query;
                time = key.time.doubleValue / 1000;
            }
        }break;
        case A4_DEVICE_DOORLOCK:{
            cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType Data:[NSString stringWithFormat:@"%@00", num]];
        }
            break;
        default:
            break;
    }
    //如果命令不为空，则执行
    if ([cmd isNotEmptyAndNil]) {
        NSString *strMsg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:cmd];
//        [[HE_APPManager sharedManager] SendMsg:strMsg withNameSpace:@"control" isShowLoading:[self isNeedShowLoading:strMsg]];
        [[HE_APPManager sharedManager] SendMsg:strMsg withNameSpace:@"control" isShowLoading:NO];
        [[HE_APPManager sharedManager]addHUDToViewWithDetails:@"正在控制中"];
    }
    if ([cmdQuery isNotEmptyAndNil]) {
        NSString *strMsg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:cmdQuery];
        
        [[HE_APPManager sharedManager] SendQueryMsg:strMsg withNameSpace:@"control" after:time];
    }
}
#pragma mark Private Method
- (void)updateTheDeviceStateWithData:(NSString *)strData{
    NSLog(@"门锁收到的反馈:%@",strData);
    self.recvNumber = self.sendNumber;
    if (deviceType == A4_DEVICE_DOORLOCK) {
        //80 ff 00 00
        DoorlockMsg *msg = [DoorlockMsg new];
        [[HE_APPManager sharedManager] removeHUD];
        [msg getDoorlockMsgWithCMD:strData];
        if (msg.isDoorOpen == YES) {
            [self.door setImage:[UIImage imageNamed:self.openImage]];
        }
        else {
            [self.door setImage:[UIImage imageNamed:self.closeImage]];
        }
        NSLog(@"msg: %@ %@ %@ %@ %d",msg.doorState,msg.openRole,msg.powerNote,msg.alarmNote,msg.isDoorOpen);
    }
}
//数据模型初始化
- (void)setAttrWithCtrlValue:(ControlDeviceContentValue *)val{
    [super setAttrWithCtrlValue:val];
    self.openImage = @"doorlock_on.png";
    self.closeImage = @"doorlock_off.png";
    //点击事件
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(changeDoorState)];
    [self addGestureRecognizer:tap];
    
    self.label.adjustsFontSizeToFitWidth = YES;
    [self.label setText:name];
    [self.door setImage:[UIImage imageNamed:self.closeImage]];
}
#pragma mark -复写父类的方法
- (void)willMoveToWindow:(UIWindow *)newWindow{
    /////////////////////////设备权限
    if (![self hasPermission]) {
        self.userInteractionEnabled = NO;
        self.alpha = 0.4;
    }
    
    
    /////////////////////////获取设备状态
    //1. Demo 模式不需要
    if ([[HE_APPManager sharedManager] netState] == NET_DEMO){
        return;
    }
    //2. 其他模式中, 设备出现在主窗口中时:
    if ([newWindow isEqual:[[AppDelegate sharedAppDelegate] window]] ) {
        //2.1 先从缓存中拉取, 以更新设备状态
        NSString *strCatchCMD = [[HE_APPManager sharedManager] dicRoomDeviceState][self.num];
        if (strCatchCMD && ![strCatchCMD isEqualToString:@""]) {
            [self updateTheDeviceStateWithData:[cmdP getDataWithoutNum:strCatchCMD]];
            self.hasUpdate = YES;
            return;
        }
        //2.2 缓存中没有, 则发送查询消息
//        if (isNeedQuery) {   //这个不知道有神马用，设定的是YES，又没用地方可以改成NO，放这里，待后期研究
            //////2.2.1 如果aryKey不为空则查询到bwenterqu按键发送  "特定的查询命令"
            if (aryKey.count > 0) {
                ControlDeviceContentValueKey *queryKey = [self getValueKeyForName:@"bwenterqu" withArray:aryKey];
                if ([queryKey.value isNotEmptyAndNil]) {
                    NSArray *allQueryCMD = [self parseTxt:queryKey.value];
                    switch (deviceType) {
                        case A4_DEVICE_THREE:{
                            for (NSString *tmp in allQueryCMD) {
                                NSString *strMsg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:tmp];
                                [[HE_APPManager sharedManager] SendMsg:strMsg withNameSpace:@"control" isShowLoading:[self isNeedShowLoading:strMsg]];
                            }
                        }break;
                        case A4_DEVICE_UART:{
                            for (NSString *tmp in allQueryCMD) {
                                NSString *tmpCMD = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType
                                                                     Data:[NSString stringWithFormat:@"%@%02X%@",self.num, (int)tmp.length/2,tmp]];
                                NSString *strMsg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:tmpCMD];
                                [[HE_APPManager sharedManager] SendMsg:strMsg withNameSpace:@"control" isShowLoading:[self isNeedShowLoading:strMsg]];
                            }
                        }break;
                        default:{
                            //                        for (NSString *tmp in allQueryCMD) {
                            //                            NSString *tmpCMD = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType
                            //                                                                 Data:[NSString stringWithFormat:@"%@%@",self.num,tmp]];
                            //                            NSString *strMsg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:tmpCMD];
                            //                            [[HE_APPManager sharedManager] SendMsg:strMsg withNameSpace:@"control" isShowLoading:self.isNeedShowLoading];
                            //                        }
                        }break;
                    }
                    return;
                }
            } else {
                //////2.2.2 没有特定的查询命令, 则拼装 A55A 查询命令查询
                NSString *strData = [NSString stringWithFormat:@"%@", num];
                //NSString *strData = [NSString stringWithFormat:@"%@", @"FFFFFF"];
                NSString *cmd = [cmdB getCMDWithAction:A4_ACTION_QUERY DeviceType:deviceType Data:strData];
                NSString *msg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:cmd];
//                [[HE_APPManager sharedManager] SendMsg:msg withNameSpace:@"control" isShowLoading:[self isNeedShowLoading:msg]];
                [[HE_APPManager sharedManager] SendMsg:msg withNameSpace:@"control" isShowLoading:NO];
                self.sendNumber++;
                for (HE_UIDevice *d in [[HE_APPManager sharedManager] aryActiveDevice]) {
                    d.hasUpdate = NO;
                }
            }
//        }
        
    }
}
////检查用户是否有权限
-(BOOL)hasPermission{
    NSString *permission = [[HE_APPManager sharedManager] User].strPermission;
    if(![permission integerValue]==0){
        UInt64 prioH = [prio IntString].longLongValue;
        prioH =  prioH >> ([permission IntString].intValue -1);
        return prioH&1;
    }
    else{
        return YES;
    }
}

@end
