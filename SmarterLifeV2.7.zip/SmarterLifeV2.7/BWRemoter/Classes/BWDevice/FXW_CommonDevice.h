//
//  FXW_CommonDevice.h
//  BWRemoter
//
//  Created by iceDiao on 15/3/13.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "HE_UIDevice.h"

@interface FXW_CommonDevice : HE_UIDevice
{
    NSString *imgName;
    NSString *title;
    BOOL isTap;
}
@property NSArray *aryMusic;
@property NSMutableArray *aryScene;///其实只有一个
@property ControlDeviceContentValue *contentValue;///电视，自定义设备等需要
@property id delegate;
@property UIImageView *backImage;
@property UILabel *labName;
-(void)setBackimgName:(NSString *)imgname andTitle:(NSString *)text IsTapLink:(BOOL)istap;
@end
