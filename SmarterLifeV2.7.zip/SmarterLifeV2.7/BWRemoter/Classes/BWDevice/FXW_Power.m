//
//  FXW_Power.m
//  BWRemoter
//
//  Created by 6602_Loop on 14-12-29.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "FXW_Power.h"

@implementation FXW_Power
@synthesize backImage;
@synthesize labName;

-(id)init{
    return [self initWithFrame:CGRectMake(0, 0, 1, 1)];
}
- (id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        if (backImage == nil) {
            backImage = [[UIImageView alloc] init];
            labName = [[UILabel alloc] init];
        }
        strOffImg = @"Powoff.png";
        strOnImg = @"Powon.png";
        
        //点击事件
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tiggleState)];
        [self addGestureRecognizer:tap];
    }
    return self;
}

- (void)drawRect:(CGRect)rect {
    if(self.frame.size.width<50){
        self.layer.cornerRadius = 5.f;//圆角s
    }
    else{
       self.layer.cornerRadius = 15.f;//圆角s
    }
    self.layer.borderColor = [[UIColor colorWithRed:200/255.0f green:200/255.0f blue:200/255.0f alpha:1] CGColor];//Border颜色
    self.layer.borderWidth = 1.f;//Border宽度
    self.clipsToBounds = YES;
    //背景 和  名称
    CGRect labFrame = rect;
    CGRect backFrame = rect;
    labFrame.origin.y = rect.size.height * 0.70f;
    labFrame.size.height = rect.size.height *0.25f;
    backFrame.size.height *= .5f;
    backFrame.size.width *= .5f;
    backFrame.origin.x = rect.size.width * 0.25f;
    backFrame.origin.y = 10.f;
    [labName setFont:[UIFont systemFontOfSize:13.f]];
    [backImage setFrame:backFrame];
    [labName setFrame:labFrame];
    [labName setTextAlignment:NSTextAlignmentCenter];
    [self addSubview:backImage];
    [self insertSubview:labName aboveSubview:backImage];
    
    self.labName.numberOfLines = 0;
    
    self.labName.adjustsFontSizeToFitWidth = YES;
    
    
}
#pragma mark -
#pragma mark Public Method
- (void)turnOn{
    [backImage setImage:[UIImage imageNamed:strOnImg]];
    isOn = true;
}
- (void)turnOff{
    [backImage setImage:[UIImage imageNamed:strOffImg]];
    isOn = false;
}
- (void)tiggleState{
    NSString *tmp = isOn?@"00":@"64";
    NSString *tmpData =  nil;
    NSString *cmd     = nil;
    NSString *cmdQuery = nil;
    NSTimeInterval time = 0;
    /////////如果是其他类型的设备
    switch (deviceType) {
        case A4_DEVICE_LIGHT:
            tmpData = [NSString stringWithFormat:@"%@%@",num, tmp];
            cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType Data:tmpData];
            break;
        case A4_DEVICE_CURTAIN:
            tmpData = [NSString stringWithFormat:@"%@%@",num, tmp];
            cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType Data:tmpData];
            break;
        case A4_DEVICE_SOCKET:
//            tmpData = [NSString stringWithFormat:@"%@%@%@", num,tmp,[curData substringFromIndex:2]];
            tmpData = [NSString stringWithFormat:@"%@%@", num,tmp];
            cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType Data:tmpData];
            break;
        case A4_DEVICE_MUTIL:
            tmpData = [NSString stringWithFormat:@"%@%@%@",num, tmp,[curData substringFromIndex:2]];
            cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType Data:tmpData];
            break;
        case A4_DEVICE_IO:
            tmp = isOn?@"0200":@"0300";
            tmpData = [NSString stringWithFormat:@"%@%@",num, tmp];
            cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType Data:tmpData];
            break;
        case A4_DEVICE_UART:{
            NSString *strName = isOn?@"关":@"开";
            ControlDeviceContentValueKey *key = [self getValueKeyForName:strName withArray:aryKey];
            if (key != nil) {
                tmpData = [NSString stringWithFormat:@"%@%02X%@",self.num, (int)key.value.length/2,key.value];
                cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType Data:tmpData];
                if ([key.query isNotEmptyAndNil]  && ![key.query isEqualToString:@"null"]){
                    cmdQuery = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType
                                                 Data:[NSString stringWithFormat:@"%@%02X%@",self.num, (int)key.query.length/2,key.query]];
                    time = key.time.doubleValue / 1000;
                }
            }
        }break;
        case A4_DEVICE_THREE:{
            NSString *strName = isOn?@"关":@"开";
            ControlDeviceContentValueKey *key = [self getValueKeyForName:strName withArray:aryKey];
            if (key != nil) {
                cmd = key.value;
                cmdQuery = key.query;
                time = key.time.doubleValue / 1000;
            }
        }break;
        default:
            break;
    }
    if ([cmd isNotEmptyAndNil]) {
        NSString *msg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:cmd];
        [[HE_APPManager sharedManager] SendMsg:msg withNameSpace:@"control" isShowLoading:[self isNeedShowLoading:msg]];
    }
    if ([cmdQuery isNotEmptyAndNil]) {
        NSString *msg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:cmdQuery];
    
        // 延时发送 查询消息
        [[HE_APPManager sharedManager] SendQueryMsg:msg withNameSpace:@"control" after:time];
    }
}
- (void)setName:(NSString *)str{
    [self.labName setText:str];
    [self setBackgroundColor:[UIColor whiteColor]];
    [self turnOff];
}
#pragma mark -
#pragma mark DeviceManager
- (void)updateTheDeviceStateWithData:(NSString *)strData{
    switch (deviceType) {
        case A4_DEVICE_LIGHT:{
            NSString *tmp = [strData substringToIndex:2];
            if ([tmp isEqualToString:@"00"]) {//关
                [self turnOff];
            }
            else
                [self turnOn];
            
        }break;
        case A4_DEVICE_CURTAIN:{
            NSString *tmp = [strData substringToIndex:2];
            if ([tmp isEqualToString:@"00"]) {//关
                [self turnOff];
            }
            else
                [self turnOn];
        }break;
        case A4_DEVICE_SOCKET:{
            if (strData.length == 14) {
                curData = strData;
                NSString *tmp = [strData substringToIndex:2];
                if ([tmp isEqualToString:@"00"]) {//关
                    [self turnOff];
                }
                else
                    [self turnOn];
            }
        }break;
        case A4_DEVICE_MUTIL:{
            curData = strData;
            NSString *tmp = [strData substringToIndex:2];
            if ([tmp isEqualToString:@"00"]) {//关
                [self turnOff];
            }
            else
                [self turnOn];
        }break;
        case A4_DEVICE_IO:{
            NSString *tmp = [strData substringToIndex:2];
            if ([tmp isEqualToString:@"02"]) {//关
                [self turnOff];
            }
            else
                [self turnOn];
        }break;
        case A4_DEVICE_THREE:
        case A4_DEVICE_UART:{
            for (ControlDeviceContentValueKey *k in aryKey) {
                ////////有此反馈
                if ([strData.uppercaseString myContainsString:k.backkey.uppercaseString]) {
                    NSLog(@"反馈按钮：%@",k.name);
                    ////////////////开 / 关
                    if ([k.name isEqualToString:@"开"]) {
                        [self turnOn];
                        isOn = true;
                    }
                    else if ([k.name isEqualToString:@"关"]){
                        [self turnOff];
                        isOn = false;
                    }
                    break;
                }
            }
        }break;
        default:
            break;
    }
}

@end
