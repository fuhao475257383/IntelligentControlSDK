//
//  HE_TV.m
//  BWRemoter
//
//  Created by HeJianBo on 15/3/13.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "HE_TV.h"
#import "FXW_AlertForInfrared.h"
#import "CYM_Engine.h"
#import "HE_CustemExtend.h"

#define ScreenSize       [UIScreen mainScreen].bounds.size
#define COLOR_SELECTED   [UIColor colorWithRed:110/255.0f green:220/255.0f blue:80/255.0f alpha:1]
#define BTN_MARGIN_M     ScreenSize.width * 0.03
#define BTN_MARGIN_L     ScreenSize.width * 0.14
#define BTN_WIDTH        ScreenSize.width * 0.33
#define BTN_HEIGTH       ScreenSize.width * 0.2
#define BTN_HEIGHT_OK    ScreenSize.width * 0.234
#define BTN_HEIGTH_S     ScreenSize.width * 0.1875
#define BOTOM_VIEW_H     ScreenSize.width * 0.1875
#define TAG_BUTTON       1000000
#define TAG_ALERT_NEW    100001
#define TAG_ALERT_EDIT   100002

@interface HE_TV()<alertDelegate>{
    //////////Sate
    BOOL            isBeginStudy;               //按下"红外学习"按钮。 进入红外学习模式
    BOOL            isStudyMode;                //可以进行红外学习
    BOOL            isModifed;                  //判断是否进行了更改
    BOOL            isFristUpate;
    //////////Data
    //
    NSMutableArray *aryDefaultName;             //默认存在的 控制按钮名称
    NSMutableArray *aryCustomeName;             //算法计算   用户自定义的控制按钮
    NSMutableArray *aryStudedIndex;             //数据库查询 该控制器 已学习的索引(十进制) -- 用于判断 剩余索引值
    //////////////  aryKey                      //自身已学习的Key数组  ------  转为 NSMutableArray
    NSMutableArray *aryStudedKey;
    
    /////////Views
    UIScrollView   *mainScroll;                 //主 滑动视图
    UIView         *bottomView;                 //底部红外学习视图
    UIButton       *btnPlus;                    //添加按钮
    UIButton       *btnStudy;
    UIButton       *btnEndStudy;
    
    //////////Views 暂存 为新增删除所做
    NSMutableArray *aryCustomeBtn;              //已绘制的Btn
    CGFloat         defaultOffSetY;             //默认按钮的最后的SumY+H
}
@end


@implementation HE_TV

-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    
    return self;
}
-(void)setAttrWithCtrlValue:(ControlDeviceContentValue *)val{
    [super setAttrWithCtrlValue:val];
    
    ///////////////Data Array Init
    aryDefaultName   = [NSMutableArray arrayWithObjects:@"开关" ,  @"静音",
                        @"快退", @"快进", @"上一曲", @"下一曲",
                        @"进出仓", @"停止", @"暂停"  , @"播放",
                        @"音量加", @"上", @"频道加",
                        @"左", @"OK", @"右",
                        @"音量减", @"下", @"频道减",
                        @"菜单", @"返回", @"Input",
                        @"声道", @"喜爱", @"画中画",
                        @"1", @"2", @"3",
                        @"4", @"5", @"6",
                        @"7", @"8", @"9",
                        @"_/__", @"0", @"频道选择", nil];
    aryStudedIndex   = [self getDeviceStudedIndex:self.name];//[CYM_Engine getContrlKeyWithValueID:self.ID];
    aryStudedKey     = [CYM_Engine getContrlKeyWithValueName:self.name];//[NSMutableArray arrayWithArray:aryKey];
    aryCustomeName   = [self getCustomeWithDefault:aryDefaultName Studed:aryStudedKey];
    aryKey           = aryStudedKey;
    isFristUpate     = YES;
    if (deviceType == A4_DEVICE_IO) {
        aryCustomeName = [NSMutableArray arrayWithObjects:@"开",@"关", nil];
    }
    //////////////滑动视图
    mainScroll = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, ScreenSize.width, ScreenSize.height)];
    [self buildScrollContent];
    
    [self addSubview:mainScroll];
}


-(void)buildScrollContent{
    NSInteger defaultIndex  = 0;
    CGFloat   contentHeight = 0.f;
    ////////开关、静音
    UIButton *btnOn = [[UIButton alloc] initWithFrame:CGRectMake(BTN_MARGIN_M,ScreenSize.width*0.0625 , BTN_WIDTH, BTN_HEIGTH_S)];
    [btnOn setImage:[UIImage imageNamed:@"tv_powerOn.png"] forState:UIControlStateNormal];
    [btnOn setImage:[UIImage imageNamed:@"tv_powerOn_H.png"] forState:UIControlStateHighlighted];
    [btnOn setImage:[UIImage imageNamed:@"tv_powerOn_H.png"] forState:UIControlStateSelected];
    [btnOn setTitle:aryDefaultName[defaultIndex] forState:UIControlStateNormal];
    [self enterManagerMode:btnOn andTag:(TAG_BUTTON + defaultIndex)];
    defaultIndex ++;
    
    UIButton *btnVoiceOff = [[UIButton alloc] initWithFrame:CGRectMake(ScreenSize.width - BTN_HEIGTH- BTN_MARGIN_M , btnOn.frameY-5, BTN_HEIGTH, BTN_HEIGTH)];
    [btnVoiceOff setImage:[UIImage imageNamed:@"tv_voiceOff.png"] forState:UIControlStateNormal];
    [btnVoiceOff setImage:[UIImage imageNamed:@"tv_voiceOff_H.png"] forState:UIControlStateHighlighted];
    [btnVoiceOff setImage:[UIImage imageNamed:@"tv_voiceOff_H.png"] forState:UIControlStateSelected];
    [btnVoiceOff setTitle:aryDefaultName[defaultIndex] forState:UIControlStateNormal];
    [self enterManagerMode:btnVoiceOff andTag:(TAG_BUTTON + defaultIndex)];
    defaultIndex ++;
    
    contentHeight = btnVoiceOff.frameSumY_H;
    [mainScroll addSubview:btnOn];
    [mainScroll addSubview:btnVoiceOff];
    ////////快进等功能键  - 8 个
    NSArray *aryimg1 = @[@"tv_quicklyBack", @"tv_quicklyForward", @"tv_perItem", @"tv_nextItem",
                         @"tv_leaveHouse",  @"tv_stop", @"tv_pause", @"tv_play"];
    CGFloat marginX  = (ScreenSize.width - 2*BTN_MARGIN_M - 4*BTN_HEIGTH)/3.f;
    for (int i=0; i<aryimg1.count; i++) {
        UIImage  *imgNomal = [UIImage imageNamed:[NSString stringWithFormat:@"%@.png",  aryimg1[i]]];
        UIImage  *imgSeled = [UIImage imageNamed:[NSString stringWithFormat:@"%@_H.png",aryimg1[i]]];
        UIButton *btnTMP   = [[UIButton alloc] initWithFrame:CGRectMake(BTN_MARGIN_M + i%4 * (marginX + BTN_HEIGTH) ,
                                                                     btnVoiceOff.frameSumY_H + i/4* (BTN_HEIGTH+marginX/3),
                                                                      BTN_HEIGTH, BTN_HEIGTH)];
        [btnTMP setImage:imgNomal forState:UIControlStateNormal];
        [btnTMP setImage:imgSeled forState:UIControlStateHighlighted];
        [btnTMP setImage:imgSeled forState:UIControlStateSelected];
        [btnTMP setTitle:aryDefaultName[defaultIndex] forState:UIControlStateNormal];
        [self enterManagerMode:btnTMP andTag:(TAG_BUTTON + defaultIndex)];
        defaultIndex ++;
        contentHeight = btnTMP.frameSumY_H;
        
        [mainScroll addSubview:btnTMP];
    }
    ////////Pad
    /////1.
    UIButton *btnOk   = [[UIButton alloc] initWithFrame:CGRectMake((ScreenSize.width - BTN_HEIGHT_OK)/2.f, contentHeight + ScreenSize.width/4, BTN_HEIGHT_OK, BTN_HEIGHT_OK)];
    UIButton *btnLeft = [[UIButton alloc] initWithFrame:CGRectMake(btnOk.frameX-BTN_HEIGHT_OK, btnOk.frameY, BTN_HEIGHT_OK, BTN_HEIGHT_OK)];
    UIButton *btnDown = [[UIButton alloc] initWithFrame:CGRectMake(btnLeft.frameX , btnOk.frameSumY_H, BTN_HEIGHT_OK*3, BTN_HEIGHT_OK)];
    UIButton *btnRigt = [[UIButton alloc] initWithFrame:CGRectMake(btnOk.frameSumX_W, btnOk.frameY, BTN_HEIGHT_OK, BTN_HEIGHT_OK)];
    UIButton *btnUP   = [[UIButton alloc] initWithFrame:CGRectMake(btnDown.frameX, btnOk.frameY - BTN_HEIGHT_OK, BTN_HEIGHT_OK*3, BTN_HEIGHT_OK)];
    ////2.
    CGFloat   btnH        = (3*BTN_HEIGTH)/2.f;
    CGFloat   btnW        = BTN_HEIGHT_OK;
    UIButton *btnVoiceAdd = [[UIButton alloc] initWithFrame:CGRectMake(BTN_MARGIN_M, btnOk.frameY + btnOk.frameH/2 - btnH, btnW, btnH)];
    UIButton *btnVoiceSub = [[UIButton alloc] initWithFrame:CGRectMake(btnVoiceAdd.frameX, btnVoiceAdd.frameSumY_H, btnW, btnH)];
    UIButton *btnChnelAdd = [[UIButton alloc] initWithFrame:CGRectMake(ScreenSize.width - BTN_MARGIN_M - btnW, btnOk.frameY + btnOk.frameH/2 - btnH, btnW, btnH)];
    UIButton *btnChnelSub = [[UIButton alloc] initWithFrame:CGRectMake(btnChnelAdd.frameX, btnChnelAdd.frameSumY_H, btnW, btnH)];
    
    [btnVoiceAdd setImage:[UIImage imageNamed:@"tv_voiceAdd.png"] forState:UIControlStateNormal];
    [btnVoiceAdd setImage:[UIImage imageNamed:@"tv_voiceAdd_H.png"] forState:UIControlStateHighlighted];
    [btnVoiceAdd setImage:[UIImage imageNamed:@"tv_voiceAdd_H.png"] forState:UIControlStateSelected];
    
    [btnVoiceSub setImage:[UIImage imageNamed:@"tv_voiceSub.png"] forState:UIControlStateNormal];
    [btnVoiceSub setImage:[UIImage imageNamed:@"tv_voiceSub_H.png"] forState:UIControlStateHighlighted];
    [btnVoiceSub setImage:[UIImage imageNamed:@"tv_voiceSub_H.png"] forState:UIControlStateSelected];
    
    [btnChnelAdd setImage:[UIImage imageNamed:@"tv_channelAdd.png"] forState:UIControlStateNormal];
    [btnChnelAdd setImage:[UIImage imageNamed:@"tv_channelAdd_H.png"] forState:UIControlStateHighlighted];
    [btnChnelAdd setImage:[UIImage imageNamed:@"tv_channelAdd_H.png"] forState:UIControlStateSelected];
    
    [btnChnelSub setImage:[UIImage imageNamed:@"tv_channelSub.png"] forState:UIControlStateNormal];
    [btnChnelSub setImage:[UIImage imageNamed:@"tv_channelSub_H.png"] forState:UIControlStateHighlighted];
    [btnChnelSub setImage:[UIImage imageNamed:@"tv_channelSub_H.png"] forState:UIControlStateSelected];
    
    [btnOk setImage:[UIImage imageNamed:@"tv_padOK.png"] forState:UIControlStateNormal];
    [btnOk setImage:[UIImage imageNamed:@"tv_padOK_H.png"] forState:UIControlStateHighlighted];
    [btnOk setImage:[UIImage imageNamed:@"tv_padOK_H.png"] forState:UIControlStateSelected];
    
    [btnLeft setImage:[UIImage imageNamed:@"tv_padLeft.png"] forState:UIControlStateNormal];
    [btnLeft setImage:[UIImage imageNamed:@"tv_padLeft_H.png"] forState:UIControlStateHighlighted];
    [btnLeft setImage:[UIImage imageNamed:@"tv_padLeft_H.png"] forState:UIControlStateSelected];
    
    [btnDown setImage:[UIImage imageNamed:@"tv_padDown.png"] forState:UIControlStateNormal];
    [btnDown setImage:[UIImage imageNamed:@"tv_padDown_H.png"] forState:UIControlStateHighlighted];
    [btnDown setImage:[UIImage imageNamed:@"tv_padDown_H.png"] forState:UIControlStateSelected];
    
    [btnRigt setImage:[UIImage imageNamed:@"tv_padRight.png"] forState:UIControlStateNormal];
    [btnRigt setImage:[UIImage imageNamed:@"tv_padRight_H.png"] forState:UIControlStateHighlighted];
    [btnRigt setImage:[UIImage imageNamed:@"tv_padRight_H.png"] forState:UIControlStateSelected];
    
    [btnUP setImage:[UIImage imageNamed:@"tv_padUP.png"] forState:UIControlStateNormal];
    [btnUP setImage:[UIImage imageNamed:@"tv_padUP_H.png"] forState:UIControlStateHighlighted];
    [btnUP setImage:[UIImage imageNamed:@"tv_padUP_H.png"] forState:UIControlStateSelected];
    /////////////////////FuncitonSet
    [btnVoiceAdd setTitle:aryDefaultName[defaultIndex] forState:UIControlStateNormal];
    [self enterManagerMode:btnVoiceAdd andTag:(TAG_BUTTON + defaultIndex++)];
    
    [btnUP setTitle:aryDefaultName[defaultIndex] forState:UIControlStateNormal];
    [self enterManagerMode:btnUP andTag:(TAG_BUTTON + defaultIndex++)];
    
    [btnChnelAdd setTitle:aryDefaultName[defaultIndex] forState:UIControlStateNormal];
    [self enterManagerMode:btnChnelAdd andTag:(TAG_BUTTON + defaultIndex++)];
    
    [btnLeft setTitle:aryDefaultName[defaultIndex] forState:UIControlStateNormal];
    [self enterManagerMode:btnLeft andTag:(TAG_BUTTON + defaultIndex++)];
    
    [btnOk setTitle:aryDefaultName[defaultIndex] forState:UIControlStateNormal];
    [self enterManagerMode:btnOk andTag:(TAG_BUTTON + defaultIndex++)];
    
    [btnRigt setTitle:aryDefaultName[defaultIndex] forState:UIControlStateNormal];
    [self enterManagerMode:btnRigt andTag:(TAG_BUTTON + defaultIndex++)];
    
    [btnVoiceSub setTitle:aryDefaultName[defaultIndex] forState:UIControlStateNormal];
    [self enterManagerMode:btnVoiceSub andTag:(TAG_BUTTON + defaultIndex++)];
    
    [btnDown setTitle:aryDefaultName[defaultIndex] forState:UIControlStateNormal];
    [self enterManagerMode:btnDown andTag:(TAG_BUTTON + defaultIndex++)];
    
    [btnChnelSub setTitle:aryDefaultName[defaultIndex] forState:UIControlStateNormal];
    [self enterManagerMode:btnChnelSub andTag:(TAG_BUTTON + defaultIndex++)];
    
    
    [mainScroll addSubview:btnOk];
    [mainScroll addSubview:btnLeft];
    [mainScroll addSubview:btnDown];;
    [mainScroll addSubview:btnRigt];
    [mainScroll addSubview:btnUP];
    [mainScroll addSubview:btnVoiceAdd];
    [mainScroll addSubview:btnVoiceSub];
    [mainScroll addSubview:btnChnelAdd];
    [mainScroll addSubview:btnChnelSub];
    contentHeight = btnDown.frameSumY_H;
    ////////菜单 等功能键
    NSArray *aryIMG2 = @[@"tv_menu", @"tv_back", @"tv_input",
                         @"tv_soundTrack", @"tv_like", @"tv_picINPic"];
    CGFloat marginX2  = (ScreenSize.width - BTN_MARGIN_M * 2 - BTN_WIDTH*3)/2.f;
    for (int i=0; i<aryIMG2.count; i++) {
        UIImage  *imgNomal = [UIImage imageNamed:[NSString stringWithFormat:@"%@.png",  aryIMG2[i]]];
        UIImage  *imgSeled = [UIImage imageNamed:[NSString stringWithFormat:@"%@_H.png",aryIMG2[i]]];
        UIButton *btnTMP = [[UIButton alloc] initWithFrame:CGRectMake(BTN_MARGIN_M + i%3*(BTN_WIDTH + marginX2),
                                                                     btnDown.frameSumY_H+ i/3*(BTN_HEIGTH_S + 10),
                                                                      BTN_WIDTH, BTN_HEIGTH_S)];
        [btnTMP setImage:imgNomal forState:UIControlStateNormal];
        [btnTMP setImage:imgSeled forState:UIControlStateHighlighted];
        [btnTMP setImage:imgSeled forState:UIControlStateSelected];
        [btnTMP setTitle:aryDefaultName[defaultIndex] forState:UIControlStateNormal];
        [self enterManagerMode:btnTMP andTag:(TAG_BUTTON + defaultIndex++)];
        contentHeight = btnTMP.frameSumY_H;
        [mainScroll addSubview:btnTMP];
    }
    CGFloat nowOffSetY = contentHeight;
    ////////数字键盘
    NSArray *aryIMG3 = @[@"tv_1", @"tv_2", @"tv_3",
                         @"tv_4", @"tv_5", @"tv_6",
                         @"tv_7", @"tv_8", @"tv_9",
                         @"tv_leftSymbol", @"tv_0", @"tv_rightSymbol"];
    CGFloat marginX3  = (ScreenSize.width - BTN_MARGIN_L * 2 - BTN_HEIGTH*3)/2.f;
    for (int i=0; i<aryIMG3.count; i++) {
        UIImage  *imgNomal = [UIImage imageNamed:[NSString stringWithFormat:@"%@.png",  aryIMG3[i]]];
        UIImage  *imgSeled = [UIImage imageNamed:[NSString stringWithFormat:@"%@_H.png",aryIMG3[i]]];
        UIButton *btnTMP = [[UIButton alloc] initWithFrame:CGRectMake(BTN_MARGIN_L + i%3*(BTN_HEIGTH + marginX3),
                                                                      nowOffSetY+ i/3*(BTN_HEIGTH + 5),
                                                                      BTN_HEIGTH, BTN_HEIGTH)];
        [btnTMP setImage:imgNomal forState:UIControlStateNormal];
        [btnTMP setImage:imgSeled forState:UIControlStateHighlighted];
        [btnTMP setImage:imgSeled forState:UIControlStateSelected];
        [btnTMP setTitle:aryDefaultName[defaultIndex] forState:UIControlStateNormal];
        [self enterManagerMode:btnTMP andTag:(TAG_BUTTON + defaultIndex++)];
        contentHeight = btnTMP.frameSumY_H;
        [mainScroll addSubview:btnTMP];
    }
    nowOffSetY = contentHeight;
    
    ////////自定义按钮
    [self buildCustomeButton:nowOffSetY];
    defaultOffSetY = nowOffSetY;
}

///////////////绘制自定义按钮
- (void)buildCustomeButton:(CGFloat)offSetY{
    CGFloat marginX4 = (ScreenSize.width - BTN_MARGIN_M*2 - BTN_WIDTH*3)/2.f;
    for (UIView *v in aryCustomeBtn) {
        [v removeFromSuperview];
    }
    [aryCustomeBtn removeAllObjects];
    for (int i=0; i<aryCustomeName.count; i++) {
        UIButton *btnTMP = [[UIButton alloc] initWithFrame:CGRectMake(BTN_MARGIN_M + i%3*(BTN_WIDTH + marginX4),
                                                                      offSetY+ i/3*(BTN_HEIGTH_S + 5),
                                                                      BTN_WIDTH, BTN_HEIGTH_S)];
        [btnTMP setBackgroundImage:[UIImage imageNamed:@"tv_backGround2.png"] forState:UIControlStateNormal];
        [btnTMP setBackgroundImage:[UIImage imageNamed:@"tv_backGround2.png"] forState:UIControlStateHighlighted];
        [btnTMP setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [btnTMP setTitleColor:[UIColor colorWithRed:110/255.0f green:220/255.0f blue:80/255.0f alpha:1] forState:UIControlStateHighlighted];
        [btnTMP setTitleColor:[UIColor colorWithRed:110/255.0f green:220/255.0f blue:80/255.0f alpha:1] forState:UIControlStateSelected];
        [btnTMP setTitle:aryCustomeName[i] forState:UIControlStateNormal];
        btnTMP.titleLabel.font = [UIFont boldSystemFontOfSize:14.f];
        [self enterManagerMode:btnTMP andTag:(TAG_BUTTON + aryDefaultName.count  + i)];
        [mainScroll addSubview:btnTMP];
        
        if (!aryCustomeBtn) {
            aryCustomeBtn = [NSMutableArray array];
        }
        [aryCustomeBtn addObject:btnTMP];
    }
    //////////移动‘+’按钮
    CGRect rectPlusButton = CGRectMake(BTN_MARGIN_M + aryCustomeName.count%3*(BTN_WIDTH + marginX4) + 7.5,
                                       offSetY+ aryCustomeName.count/3*(BTN_HEIGTH_S + 5) + 7.5,
                                       BTN_WIDTH - 15, BTN_HEIGTH_S - 15);
    if (btnPlus) {
        [btnPlus setFrame:rectPlusButton];
    }
    else{
        btnPlus          = [[UIButton alloc] initWithFrame:rectPlusButton];
        btnPlus.hidden   = YES;
        btnPlus.layer.cornerRadius = 5.f;
        btnPlus.layer.borderWidth  = 1.f;
        btnPlus.layer.borderColor  = [UIColor grayColor].CGColor;
        btnPlus.titleLabel.font    = [UIFont systemFontOfSize:35];
        [btnPlus setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [btnPlus setTitleColor:[UIColor greenColor] forState:UIControlStateHighlighted];
        [btnPlus setTitleColor:[UIColor greenColor] forState:UIControlStateSelected];
        [btnPlus setTitle:@"+" forState:UIControlStateNormal];
        [btnPlus setTitleEdgeInsets:UIEdgeInsetsMake(0, 0, 8, 0)];
        [btnPlus addTarget:self action:@selector(touchedAddButton:) forControlEvents:UIControlEventTouchUpInside];
        [mainScroll addSubview:btnPlus];
    }
    [mainScroll setContentSize:CGSizeMake(ScreenSize.width, btnPlus.frameSumY_H)];
}
- (void)enterManagerMode:(UIButton *)btnTMP andTag:(NSInteger)aTag{
    ////事件、
    [btnTMP setTag:aTag];
    [btnTMP addTarget:self action:@selector(touchedButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [btnTMP setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    ////图层遮罩、表示为学习按钮
     btnTMP.alpha = 0.4;
    ////////////////如果为自定义按钮
    if (aTag >= (TAG_BUTTON + aryDefaultName.count)) {
        [btnTMP setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        for (ControlDeviceContentValueKey *valueKey in aryStudedKey) {
            if ([valueKey.name isEqualToString:btnTMP.titleLabel.text]) {
                ////////已学习。 改变其颜色
                btnTMP.alpha = 1;
            }
        }
        //////////////////添加长按手势
        UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPressEditName:)];
        longPress.minimumPressDuration          = 0.8;
        [btnTMP addGestureRecognizer:longPress];
    }
    ///////////////默认按钮
    else {
        for (ControlDeviceContentValueKey *valueKey in aryStudedKey) {
            if ([valueKey.name isEqualToString:btnTMP.titleLabel.text]) {
                ////////已学习。 改变其颜色
                btnTMP.alpha = 1;
            }
        }

    }
    /////////若为空调控制器
    if (deviceType == A4_DEVICE_IO &&
        ([btnTMP.titleLabel.text isEqualToString:@"开"] ||
         [btnTMP.titleLabel.text isEqualToString:@"关"])) {
            btnTMP.alpha = 1;
        }
    //////////若为演示模式
    if ([[HE_APPManager sharedManager] netState] == NET_DEMO) {
        btnTMP.alpha = 1;
    }
}

#pragma mark -
#pragma mark BWDevice Manager


#pragma mark 进入红外学习模式
- (void)enterStudyMode{
    mainScroll.frame = CGRectMake(0, 0, ScreenSize.width, ScreenSize.height - (BOTOM_VIEW_H + 20));
    btnPlus.hidden   = NO;
    isStudyMode      = YES;
    /////////////红外学习视图
    bottomView = [[UIView alloc] initWithFrame:CGRectMake(10, mainScroll.frameSumY_H + 10, ScreenSize.width - 20.f, BOTOM_VIEW_H)];
    bottomView.layer.cornerRadius = 8.f;
    bottomView.layer.borderWidth  = 1.f;
    bottomView.layer.borderColor  = [UIColor grayColor].CGColor;
    ///1.开始学习按钮
    btnStudy                    = [[UIButton alloc] initWithFrame:CGRectMake(5, 5, BTN_WIDTH, BTN_HEIGTH_S)];
    btnStudy.titleLabel.font    = [UIFont boldSystemFontOfSize:15.f];
    [btnStudy setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [btnStudy setTitleColor:COLOR_SELECTED forState:UIControlStateHighlighted];
    [btnStudy setTitleColor:COLOR_SELECTED forState:UIControlStateSelected];
    [btnStudy setBackgroundImage:[UIImage imageNamed:@"tv_backGround2.png"] forState:UIControlStateNormal];
    [btnStudy setBackgroundImage:[UIImage imageNamed:@"tv_backGround2.png"] forState:UIControlStateHighlighted];
    [btnStudy setTitle:@"红外学习" forState:UIControlStateNormal];
    [btnStudy addTarget:self action:@selector(touchedStudyMode:) forControlEvents:UIControlEventTouchUpInside];
    
    ///2.结束学习按钮
    btnEndStudy                    = [[UIButton alloc] initWithFrame:CGRectMake(btnStudy.frameSumX_W + 5, btnStudy.frameY, BTN_WIDTH, BTN_HEIGTH_S)];
    btnEndStudy.titleLabel.font    = [UIFont boldSystemFontOfSize:15.f];
    [btnEndStudy setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [btnEndStudy setTitleColor:COLOR_SELECTED forState:UIControlStateHighlighted];
    [btnEndStudy setTitleColor:COLOR_SELECTED forState:UIControlStateSelected];
    [btnEndStudy setBackgroundImage:[UIImage imageNamed:@"tv_backGround2.png"] forState:UIControlStateNormal];
    [btnEndStudy setBackgroundImage:[UIImage imageNamed:@"tv_backGround2.png"] forState:UIControlStateHighlighted];
    [btnEndStudy setTitle:@"结束学习" forState:UIControlStateNormal];
    [btnEndStudy addTarget:self action:@selector(touchedEndStudy:) forControlEvents:UIControlEventTouchUpInside];
    
    ///3.模式选择DD
    
    
    [bottomView addSubview:btnStudy];
    [bottomView addSubview:btnEndStudy];
    
    [self addSubview:bottomView];
}

#pragma mark -
#pragma mark 控制器Action
//////////////控制器按钮单击事件
- (void)touchedButtonClick:(UIButton *)sender{
    //////执行按钮事件
    NSLog(@"%ld-----%@",(long)sender.tag, sender.titleLabel.text);
    BOOL      isStuded =  NO;
    for (ControlDeviceContentValueKey *k in aryStudedKey) {
        if ([k.name isEqualToString:sender.titleLabel.text]) {
            isStuded = YES;
            break;
        }
    }
    ///改变灰色按钮 颜色
    if (!isStuded && isBeginStudy) {
        sender.alpha = 1;
    }
    [self dealWithActionWithName:sender.titleLabel.text Button:sender];
}

/////////////学习某个按钮
- (void)dealWithActionWithName:(NSString *)strName Button:(UIButton *)button{
    //////////若为演示模式
    if ([[HE_APPManager sharedManager] netState] == NET_DEMO) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            NSArray *allViews = [mainScroll subviews];
            for (UIView *v in allViews) {
                /////////////按钮
                if ([v isKindOfClass:[UIButton class]]) {
                    if([((UIButton *)v).titleLabel.text isEqualToString:strName]){
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [((UIButton *)v) setSelected:YES];
                        });
                    }
                    else{
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [((UIButton *)v) setSelected:NO];
                        });
                    }
                }
            }
        });
        return;
    }
    
    //////////ZigBee I/O
    if (deviceType == A4_DEVICE_IO) {
        NSString *strTMP = [strName isEqualToString:@"开"]?@"0300":@"0200";
        NSString *strData= [NSString stringWithFormat:@"%@%@",num,strTMP];
        NSString *strCMD = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType Data:strData];
        NSString *strMsg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:strCMD];
        [[HE_APPManager sharedManager] SendMsg:strMsg withNameSpace:@"control" isShowLoading:[self isNeedShowLoading:strMsg]];
        return;
    }
    
    //////////数据透传
    if (deviceType == A4_DEVICE_UART) {
        ControlDeviceContentValueKey *key = [self getValueKeyForName:strName withArray:aryKey];
        if ([key.value isNotEmptyAndNil]) {
            NSString *cmd = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType
                                              Data:[NSString stringWithFormat:@"%@%02X%@",self.num, (int)key.value.length/2,key.value]];
            NSString *msg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:cmd];
            [[HE_APPManager sharedManager] SendMsg:msg withNameSpace:@"control" isShowLoading:[self isNeedShowLoading:msg]];
            /////如果有查询。需要发送则发送查询命令
            if([key.query isNotEmptyAndNil]  && ![key.query isEqualToString:@"null"]){
                NSString *cmdQuery = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType
                                                       Data:[NSString stringWithFormat:@"%@%02X%@",self.num, (int)key.query.length/2,key.query]];
                NSString *msgQuery = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:cmdQuery];
                // 延时发送 查询消息
                NSTimeInterval time = key.time.doubleValue / 1000;
                [[HE_APPManager sharedManager] SendQueryMsg:msgQuery withNameSpace:@"control" after:time];
            }
        }
        else{
            [[HE_APPManager sharedManager] hudShowMsg:@"该键不存在" andInterval:1.];
        }
        return;
    }
    
    //////////三方设备
    if (deviceType == A4_DEVICE_THREE) {
        ControlDeviceContentValueKey *key = [self getValueKeyForName:strName withArray:aryKey];
        if ([key.value isNotEmptyAndNil]) {
            NSString *cmd = key.value;
            NSString *msg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:cmd];
            [[HE_APPManager sharedManager] SendMsg:msg withNameSpace:@"control" isShowLoading:[self isNeedShowLoading:msg]];
            /////如果有查询。需要发送则发送查询命令
            if([key.query isNotEmptyAndNil] && ![key.query isEqualToString:@"null"]){
                NSString *msgQuery = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:key.query];
                // 延时发送 查询消息
                NSTimeInterval time = key.time.doubleValue / 1000;
                [[HE_APPManager sharedManager] SendQueryMsg:msgQuery withNameSpace:@"control" after:time];
            }
        }
        else{
            [[HE_APPManager sharedManager] hudShowMsg:@"该键不存在" andInterval:1.];
        }
        return;
    }
    ///////判断是否该键已学习
    BOOL      isStuded =  NO;
    ControlDeviceContentValueKey *opKey;
    for (ControlDeviceContentValueKey *k in aryStudedKey) {
        if ([k.name isEqualToString:strName]) {
            isStuded   = YES;
            opKey = k;
            break;
        }
    }
    
    //1. 控制
    if (isStuded && !isBeginStudy) {
        //1.1 找到Value
        NSString *strMsg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:opKey.value];
        NSLog(@"找到的value %@",opKey.value);
        [[HE_APPManager sharedManager] SendMsg:strMsg withNameSpace:@"control" isShowLoading:[self isNeedShowLoading:strMsg]];
    }
    //2.学习 -- 从 剩余索引值数组 取得索引
    else if (isBeginStudy){
        ////2.1.得到索引后、 加入aryStudedIndex, 和aryStudedKey数组
        isModifed = YES;
        NSString *studingHexIndex;

        /////如果为已学习则直接发送 已学习的键值
        if (isStuded) {
            studingHexIndex = [opKey.value substringWithRange:NSMakeRange(19, 3)];
        }
        else{
            studingHexIndex = [self getMinUnusedIndexWithAry:aryStudedIndex];
            if ([studingHexIndex IntString].intValue > 999){
                [[HE_APPManager sharedManager] hudShowMsg:@"1000个键值已用完" andInterval:1.0];
                ///////则把刚刚变亮的按钮、变灰
                button.alpha = 0.4;
                return;
            }
        }
        //2.2构造学习消息
        NSString *strData     = [NSString stringWithFormat:@"%@%@%@",num, @"8",studingHexIndex];
        NSString *strCMD      = [cmdB getCMDWithAction:A4_ACTION_SIGNAL_STUDY DeviceType:A4_DEVICE_MUTIL Data:strData];
        NSString *strMsg      = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:strCMD];
        NSLog(@"构造好的学习CMD%@",strCMD);
        //2.3构造控制消息
        NSString *strCtrlData = [NSString stringWithFormat:@"%@FF%@%@", num,@"8", studingHexIndex];
        NSString *strCtrlCMD  = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:A4_DEVICE_MUTIL Data:strCtrlData];
        NSLog(@"构造好的控制CMD%@",strCtrlCMD);
        
        [[HE_APPManager sharedManager] SendMsg:strMsg withNameSpace:@"control" isShowLoading:/*[self isNeedShowLoading:strMsg]*/NO];
        ////////修改内存
        
        if (isStuded) {///已学习按钮不做 改变
            //
        }
        else{///未曾学习过的按钮-> 新增
            opKey = [[ControlDeviceContentValueKey alloc] init];
            opKey.name   = strName;
            opKey.value  = strCtrlCMD;
            opKey.time   = @"null";
            opKey.query  = @"null";
            opKey.backkey= @"null";
            [aryStudedKey addObject:opKey];
            [aryStudedIndex addObject:studingHexIndex.IntString];
            aryStudedIndex = [self orderAscWithArry:aryStudedIndex];
        }
        
        [[HE_APPManager sharedManager] hudShowMsg:[NSString stringWithFormat:@"开始学习'%@' 索引:%@",strName, studingHexIndex] andInterval:1.0];
    }
    else{
        [[HE_APPManager sharedManager] hudShowMsg:@"该键未学习" andInterval:.5];
    }
}
/////////////控制器按钮长按事件
- (void)longPressEditName:(UILongPressGestureRecognizer *)longPress{
    /////////////////1.为默认按钮 则 长按不响应任何事件
    UIButton *btnSender = (UIButton *)longPress.view;
    for (NSString* s in aryDefaultName) {
        if ([btnSender.titleLabel.text isEqualToString:s]) {
            return;
        }
    }
    ////////////////2.否则 响应长按手势开始动作
    if (longPress.state == UIGestureRecognizerStateBegan && isStudyMode == YES) {
        FXW_AlertForInfrared *alert = [[FXW_AlertForInfrared alloc] init];
        [alert setTitle:@"编辑按钮" andAlertType:FXWAlertTypeEdit];
        [alert setDefaultName:btnSender.currentTitle];
        [alert setSender:btnSender];
        [alert setAlertDelegate:self];
        [alert setTag:TAG_ALERT_EDIT];
        [self addSubview:alert];
    }
}

/////////////控制器按钮 新增事件
- (void)touchedAddButton:(UIButton *)sender{
    ///////////////添加一个按钮
    FXW_AlertForInfrared *alert = [[FXW_AlertForInfrared alloc] init];
    [alert setTitle:@"添加按钮" andAlertType:FXWAlertTypeAdd];
    [alert setSender:sender];
    [alert setAlertDelegate:self];
    [alert setTag:TAG_ALERT_NEW];
    [self addSubview:alert];
}

- (void)updateTheDeviceStateWithData:(NSString *)strData{
    if (deviceType == A4_DEVICE_IO) {
        NSString *strState = [strData substringToIndex:2];
        UIButton *btnOn    = [mainScroll viewWithTag:TAG_BUTTON+aryDefaultName.count];
        UIButton *btnOff   = [mainScroll viewWithTag:TAG_BUTTON+aryDefaultName.count+1];
        if ([strState isEqualToString:@"02"]) {
            btnOff.selected = YES;
            btnOn.selected  = NO;
        }
        else{
            btnOff.selected = NO;
            btnOn.selected  = YES;
        }
        return;
    }
    
    /***************      由于单体空调 属于多功能控制器      ****************/
    //***           其反馈在其aryKey中必有其"控制消息"记录                **//
    
    /////////////多线程中得出反馈
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(){
        for (ControlDeviceContentValueKey *k in aryKey) {
            ////////有此反馈
            if ([[strData substringFromIndex:2] isEqualToString:[[cmdP getDataWithoutNum:k.value] substringFromIndex:2]]) {
                NSLog(@"反馈：%@",k.name);
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (!isFristUpate) {
                        [self showHint:@"操作成功"];
                    }
                    isFristUpate = NO;
                });
///////////////////Now 7.9
                NSArray *allViews = [mainScroll subviews];
                NSArray *allBackName = [self parseTxt:k.name];
                for (NSString *tmpName in allBackName) {
                    for (UIView *v in allViews) {
                        /////////////按钮
                        if ([v isKindOfClass:[UIButton class]]) {
                            NSString *btnTitle = ((UIButton *)v).titleLabel.text;
                            if ([btnTitle isEqualToString:tmpName]) {
                                dispatch_async(dispatch_get_main_queue(), ^{
                                    ((UIButton *)v).selected = YES;
                                });
                            }
                            else if (![allBackName isContainsStringObj:btnTitle]){
                                dispatch_async(dispatch_get_main_queue(), ^{
                                    ((UIButton *)v).selected = NO;
                                });
                            }
                        }
                    }
                }
///////////////////pre 7.9
//                NSArray *allViews = [mainScroll subviews];
//                for (UIView *v in allViews) {
//                    /////////////按钮
//                    if ([v isKindOfClass:[UIButton class]]) {
//                        if([((UIButton *)v).titleLabel.text isEqualToString:k.name]){
//                            dispatch_async(dispatch_get_main_queue(), ^{
//                                [((UIButton *)v) setSelected:YES];
//                            });
//                        }
//                        else{
//                            dispatch_async(dispatch_get_main_queue(), ^{
//                                [((UIButton *)v) setSelected:NO];
//                            });
//                        }
//                    }
//                }
                break;
            }
        }
    });
    
}


////////////Delegate
- (void)alertView:(FXW_AlertForInfrared *)alertView
        inputText:(NSString *)aText
       actionType:(FXWAlertActionType)type
     andBtnSender:(UIButton *)btn{
    /////////////////按钮名称重复
    if (type != FXWAlertActionDelete && [self isRepateKeyNameWithStudedKey:aryStudedKey andName:aText]) {
        [[HE_APPManager sharedManager] hudShowMsg:@"按钮名称重复" andInterval:2.];
        return;
    }
    
    if (alertView.tag == TAG_ALERT_NEW && type == FXWAlertActionSave) {
        [aryCustomeName addObject:aText];
        [self buildCustomeButton:defaultOffSetY];
        [mainScroll setContentOffset:CGPointMake(0,  btnPlus.frameSumY_H - mainScroll.frameH ) animated:YES];
    }
    else if (alertView.tag == TAG_ALERT_EDIT){
        NSString *oldName = btn.titleLabel.text;
        ////更新数组数据
        if (type == FXWAlertActionSave) {
            isModifed = YES;
            [aryCustomeName setObject:aText atIndexedSubscript:[aryCustomeName indexOfObject:oldName]];
            for (ControlDeviceContentValueKey *k in aryStudedKey) {
                if (k.name == oldName) {
                    k.name = aText;
                    break;
                }
            }
            [btn setTitle:aText forState:UIControlStateNormal];
        }
        else if (type == FXWAlertActionDelete){
            isModifed = YES;
            for (ControlDeviceContentValueKey *k in aryStudedKey) {
                if (k.name == oldName) {
                    [aryStudedKey removeObject:k];
                    break;
                }
            }
            [btn removeFromSuperview];
            [aryCustomeName removeObject:oldName];
            [self buildCustomeButton:defaultOffSetY];
        }
    }
}

#pragma mark 红外学习
- (void)touchedStudyMode:(UIButton *)sender{
    sender.selected      = YES;
    isBeginStudy          = YES;
    btnEndStudy.selected = NO;
}
- (void)touchedEndStudy:(UIButton *)sender{
    if(isBeginStudy == YES ){
        [self performSelector:@selector(showHint:) withObject:@"操作成功" afterDelay:.7];
    }
    isBeginStudy          = NO;
    sender.selected      = YES;
    btnStudy.selected    = NO;
}
//////////////////保存更改到网关
- (void)saveAsStateToGateway{
    if (isModifed) {
        ///////////1.更新至数据库
        [CYM_Engine updateContrlValueKeys:aryStudedKey ValueName:self.name];
        ///////////2.上传至网关
        NSData *roomData = [CYM_Engine generateJSONFileWithName:@"control.json"];
        [[HE_APPManager sharedManager] uploadFileWithName:@"control.json" andData:roomData isShowHUD:YES];
        NSLog(@"Save");
    }
}
#pragma mark Private Method
/////////////////计算 自定义的按钮名称 数组
- (NSMutableArray *)getCustomeWithDefault:(NSMutableArray *)aryDefault
                                   Studed:(NSMutableArray *)aryStuded{//存储当前已学习的KeyAry、 其中每个元素为ControlDeviceContentValueKey
    NSMutableArray *aryResult = [NSMutableArray array];
    
    for (ControlDeviceContentValueKey *k in aryStuded) {
        BOOL isCustome = YES;
        for (NSString *s in aryDefault) {
            if ([k.name isEqualToString:s] || [k.name myContainsString:@"bw"]) {
                isCustome = NO;
                break;
            }
        }
        if (isCustome) {
            [aryResult addObject:k.name];
        }
    }
    return aryResult;
}
////////////////计算该设备 已学习的Key名称数组
- (NSMutableArray *)getStudedNameWithKey:(NSArray *)key{
    NSMutableArray *ary = [NSMutableArray array];
    for (ControlDeviceContentValueKey  *obj in key) {
        [ary addObject:obj.name];
    }
    return ary;
}
////////////////判断新增按钮是否重名
- (BOOL)isRepateKeyNameWithStudedKey:(NSArray *)aryStuedKey andName:(NSString *)aName{
    BOOL isRepated = NO;
    for (ControlDeviceContentValueKey *k in aryStuedKey) {
        if ([k.name isEqualToString:aName]) {
            isRepated = YES;break;
        }
    }
    return isRepated;
}
////////////////获取该多功能控制器  已学习的索引(十进制)
- (NSMutableArray *)getDeviceStudedIndex:(NSString *)muteDevName{
    NSMutableArray *aryIndex  = [NSMutableArray array];
    ControlDeviceContentValue *val = [CYM_Engine getDeviceDetailsWithDeviceName:muteDevName];
    NSArray        *aryAllKey = [CYM_Engine getCategoryAllKeyWithValue:val];
    ///1.获取到所有索引
    for (ControlDeviceContentValueKey *valueKey in aryAllKey) {
        if (valueKey.value.length >= 24) {////为一条正确的 多功能控制器的控制命令
            //////获取索引值---》转化为10进制
            NSString *hexString = [valueKey.value substringWithRange:NSMakeRange(19, 3)];
            [aryIndex addObject:hexString.IntString];

        }
    }
    
    ///2.升序排序
    aryIndex = [self orderAscWithArry:aryIndex];
    return aryIndex;
}
////////////////取得一个空闲索引(16进制)-aryUsed(为10进制字符)升序、则第一个不连续值、为最小空闲索引
- (NSString *)getMinUnusedIndexWithAry:(NSArray *)aryUsed{
    NSString  *strUnusedIndex = nil;
    NSInteger  idexCounter    = 0;
    
    ////////////如果没有学习过 返回索引0x00
    if (aryUsed == nil || aryUsed.count == 0) {
        idexCounter = 0;
        strUnusedIndex = [NSString stringWithFormat:@"%03lX",(long)idexCounter];
        return strUnusedIndex;
    }
    ///////////已学习
    for (NSString *s in aryUsed) {
        //////正常递增
        if (s.intValue == idexCounter || s.intValue == (idexCounter + 1)) {
            idexCounter = s.intValue;
        }
        //////找到间隙中未使用的Key
        else {///(int_s.intValue > (idexCounter + 1))
            idexCounter ++;
            strUnusedIndex = [NSString stringWithFormat:@"%03lX",(long)idexCounter];
            break;
        }
    }
    //2.全部都连续、取最后一个值+1.
    if (strUnusedIndex == nil) {
        NSString *s = [aryUsed lastObject];
        idexCounter = s.intValue + 1;
        strUnusedIndex = [NSString stringWithFormat:@"%03lX",(long)idexCounter];
    }
    return strUnusedIndex;
}
////////////////升序排序
- (NSMutableArray *)orderAscWithArry:(NSMutableArray *)ary{
    if (ary.count > 1) {
        for (int i=0; i< (ary.count - 1); i++) {
            int k = i;
            for (int j=i+1; j<ary.count; j++) {
                NSInteger ary_j = [ary[j] IntString].integerValue;
                NSInteger ary_k = [ary[k] IntString].integerValue;
                if (ary_j < ary_k) {
                    k = j;
                }
            }
            id tmp = ary[k];
            ary[k] = ary[i];
            ary[i] = tmp;
        }
    }    return ary;
}
@end
