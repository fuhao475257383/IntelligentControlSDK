//
//  HE_CenterCodition.h
//  BWRemoter
//
//  Created by HeJianBo on 15/3/23.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "HE_UIDevice.h"
#import "HE_MsgKit.h"
#import "FXW_AlertForInfrared.h"
@interface HE_CenterCodition : HE_UIDevice<alertDelegate>

////////////进入红外学习Mode
- (void)enterStudyMode;
//////////////////保存更改到网关
- (void)saveAsStateToGateway;

@end
