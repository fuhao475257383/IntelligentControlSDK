//
//  HE_UIDevice.m
//  BWRemoter
//
//  Created by JianBo He on 15/1/14.
//  Copyright (c) 2015年 ReSun. All rights reserved.
//

#import "HE_UIDevice.h"
#import "AppDelegate.h"

@implementation HE_UIDevice
@synthesize isNeedQuery, hasUpdate;

- (id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        msgB = [[HE_MsgBuilder alloc] init];
        msgP = [[HE_MsgParser alloc] init];
        cmdB = [[HE_CMDBuilder alloc] init];
        cmdP = [[HE_CMDParser alloc] init];
        isNeedQuery = YES;
        hasUpdate = NO;
    }
    return self;
}

- (NSString *)ID{
    return ID;
}
- (void)setID:(NSString *)str{
    ID = str;
}

- (NSString *)num{
    return num;
}
- (void)setNum:(NSString *)str{
    num = str;
}

- (void)setNumWithValue:(NSString *)val{
    num = [cmdP getDeviceNumWithBindCMD:val];
}

- (NSString *)name{
    return name;
}
- (void)setName:(NSString *)str{
    name = str;
}

- (NSString *)category{
    return category;
}
- (void)setCategory:(NSString *)str{
    category = str;
}

- (A4_DeviceTypeCode)deviceType{
    deviceType = [cmdB getDeviceTypeCodeWithCNString:category];
    return deviceType;
}

- (NSString *)property{
    return  property;
}
- (void)setProperty:(NSString *)str{
    property = str;
}

- (NSString *)com{
    return com;
}
- (void)setCom:(NSString *)str{
    com = str;
}

- (NSString *)prio{
    return prio;
}
- (void)setPrio:(NSString *)str{
    prio = str;
}

- (NSString *)value{
    return value;
}
- (void)setValue:(NSString *)str{
    value = str;
}

- (NSString *)strAns{
    return strAns;
}
- (void)setStrAns:(NSString *)str{
    strAns = str;
}
- (NSArray *)aryKey{
    return aryKey;
}
- (void)setAryKey:(NSArray *)ary{
    aryKey = ary;
}

- (HE_MsgBuilder *)msgB{
    return msgB;
}
- (HE_MsgParser *)msgP{
    return msgP;
}
- (HE_CMDBuilder *)cmdB{
    return cmdB;
}
- (HE_CMDParser *)cmdP{
    return cmdP;
}

- (BOOL)isNeedShowLoading:(NSString *)strMsg {
    if ([strMsg myContainsString:@"A55A"]) {
        return true;
    }
    return false;
}

///可以 被重载的方法
///该方法中用于 再UIView在显示  查询网络中设备的状态
- (void)setAttrWithCtrlValue:(ControlDeviceContentValue *)val{
    ID       = val.ID;
    num      = [cmdP getDeviceNumWithBindCMD:val.value];
    name     = val.name;
    com      = val.com;
    category = val.category;
    property = val.property;
    prio     = val.prio;
    value    = val.value;
    aryKey   = val.keyArr;
    deviceType = [cmdB getDeviceTypeCodeWithCNString:category];
    [self setUpNotifactionWhenIsThreeDevice];
}

- (void)willMoveToWindow:(UIWindow *)newWindow{
    /////////////////////////设备权限
    if (![self hasPermission]) {
        self.userInteractionEnabled = NO;
        self.alpha = 0.4;
    }
    
    
    /////////////////////////获取设备状态
    //1. Demo 模式不需要
    if ([[HE_APPManager sharedManager] netState] == NET_DEMO){
        return;
    }
    //2. 其他模式中, 设备出现在主窗口中时:
    if ([newWindow isEqual:[[AppDelegate sharedAppDelegate] window]] ) {
        //2.1 先从缓存中拉取, 以更新设备状态
        NSString *strCatchCMD = [[HE_APPManager sharedManager] dicRoomDeviceState][self.num];
        if (strCatchCMD && ![strCatchCMD isEqualToString:@""]) {
            [self updateTheDeviceStateWithData:[cmdP getDataWithoutNum:strCatchCMD]];
            self.hasUpdate = YES;
            if (![property isEqualToString:@"背景音乐"]) {
                return;
            }
        }
        //2.2 缓存中没有, 则发送查询消息
        if (isNeedQuery) {
            //////2.2.1 如果aryKey不为空则查询到bwenterqu按键发送  "特定的查询命令"
            if (aryKey.count > 0) {
                ControlDeviceContentValueKey *queryKey = [self getValueKeyForName:@"bwenterqu" withArray:aryKey];
                if ([queryKey.value isNotEmptyAndNil]) {
                    NSArray *allQueryCMD = [self parseTxt:queryKey.value];
                    switch (deviceType) {
                        case A4_DEVICE_THREE:{
                            for (NSString *tmp in allQueryCMD) {
                                NSString *strMsg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:tmp];
                                [[HE_APPManager sharedManager] SendMsg:strMsg withNameSpace:@"control" isShowLoading:[self isNeedShowLoading:strMsg]];
                            }
                        }break;
                        case A4_DEVICE_UART:{
                            for (NSString *tmp in allQueryCMD) {
                                NSString *tmpCMD = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType
                                                                     Data:[NSString stringWithFormat:@"%@%02X%@",self.num, (int)tmp.length/2,tmp]];
                                NSString *strMsg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:tmpCMD];
                                [[HE_APPManager sharedManager] SendMsg:strMsg withNameSpace:@"control" isShowLoading:[self isNeedShowLoading:strMsg]];
                            }
                        }break;
                        default:{
//                        for (NSString *tmp in allQueryCMD) {
//                            NSString *tmpCMD = [cmdB getCMDWithAction:A4_ACTION_CONTROL DeviceType:deviceType
//                                                                 Data:[NSString stringWithFormat:@"%@%@",self.num,tmp]];
//                            NSString *strMsg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:tmpCMD];
//                            [[HE_APPManager sharedManager] SendMsg:strMsg withNameSpace:@"control" isShowLoading:self.isNeedShowLoading];
//                        }
                        }break;
                    }
                    return;
                }
            } else {
                //////2.2.2 没有特定的查询命令, 则拼装 A55A 查询命令查询
                NSString *strData = [NSString stringWithFormat:@"%@", num];
                //NSString *strData = [NSString stringWithFormat:@"%@", @"FFFFFF"];
                NSString *cmd = [cmdB getCMDWithAction:A4_ACTION_QUERY DeviceType:deviceType Data:strData];
                NSString *msg = [msgB getMessageWithType:[com longLongValue] action:ACTION_TRANSMIT commond:cmd];
                [[HE_APPManager sharedManager] SendMsg:msg withNameSpace:@"control" isShowLoading:[self isNeedShowLoading:msg]];
                for (HE_UIDevice *d in [[HE_APPManager sharedManager] aryActiveDevice]) {
                    d.hasUpdate = NO;
                }
            }
        }
        
    }
}

- (void)updateTheDeviceStateWithData:(NSString *)strData{
    //
    NSLog(@"HE_UIDevice 子类未实现更新方法");
}


#pragma mark - 工具类方法
///根据名称获取Key 对象
- (ControlDeviceContentValueKey *)getValueKeyForName:(NSString *)strName withArray:(NSArray *)ary{
    for (ControlDeviceContentValueKey *obj in ary) {
        if ([obj.name isEqualToString:strName]) {
            return obj;
        }
    }
    return nil;
}
///解析 格式为 bw水平/制热/低速 或 水平/制热/低速  或者 010123/01341313/12341 的情况
- (NSArray *)parseTxt:(NSString *)strName{
    if ([strName myContainsString:@"/"] && ![strName isEqualToString:@"_/__"]) {
        NSMutableArray *aryResult = [NSMutableArray arrayWithArray:[strName componentsSeparatedByString:@"/"]];
        if ([[aryResult[0] substringToIndex:2] isEqualToString:@"bw"]) {
            NSMutableString *strTmp = [NSString stringWithString:aryResult[0]];
            aryResult[0] = [strTmp substringWithRange:NSMakeRange(2, ((NSString *)aryResult[0]).length - 2)];
        }
        return aryResult;
    }
    else{
        return @[strName];
    }
}

#pragma mark - Private
- (void)setUpNotifactionWhenIsThreeDevice{
    /////////如果是三方组网时。 设备的Num可能为空。 则通过通知来获取消息
    if (deviceType == A4_DEVICE_THREE && self.num == nil) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(hasANotification:) name:@"NEW_CMD_MSG" object:nil];
    }
    /////////如果是数据透传时。有可能消息过长后 分包接受会导致 后面的包是一个无num 非完整地数据
    if (deviceType == A4_DEVICE_UART) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(hasANotification:) name:@"NEW_CMD_MSG" object:nil];
    }
}

////检查用户是否有权限
-(BOOL)hasPermission{
    NSString *permission = [[HE_APPManager sharedManager] User].strPermission;
    if(![permission integerValue]==0){
        UInt64 prioH = [prio IntString].longLongValue;
        prioH =  prioH >> ([permission IntString].intValue -1);
        return prioH&1;
    }
    else{
        return YES;
    }
}

/////////处理通知
- (void)hasANotification:(NSNotification *)sender{
    [self updateTheDeviceStateWithData:sender.object];
}
/////////将监听从通知中心移除
- (void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"NEW_CMD_MSG" object:nil];
}
@end
