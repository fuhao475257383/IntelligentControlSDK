//
//  CYM_DatabaseTable.m
//  BWRemoter
//
//  Created by cym on 14-12-30.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "CYM_DatabaseTable.h"
#import "NSString+HE.h"
#import "HE_MsgBuilder.h"
#import "HE_CMDBuilder.h"

static FMDatabase * _db;
static NSLock *threadLock;

@implementation CYM_DatabaseTable

+ (void)logoutDataBase{
    _db = nil;

    [DatabaseUtil setDataBaseIsDemo:false];
}
+ (NSString *)GenerateGUID{
    int NUMBER_OF_CHARS = 10;
    char data[NUMBER_OF_CHARS];
    for(int i=0;i < NUMBER_OF_CHARS; i++){
        data[i] = ( 'A' + (arc4random_uniform(26)) );
    }
    NSString *dataPoint = [[NSString alloc] initWithBytes:data length:NUMBER_OF_CHARS encoding:NSUTF8StringEncoding];
    return dataPoint;
}

+ (void)initializeThreadLock {
    threadLock = [NSLock new];
}

//添加到room
+(void)insertToRoom:(Room *)room
{
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    
    [_db setShouldCacheStatements:YES];
    
    if ([_db tableExists:@"db_room"])
    {
        [_db executeUpdate:@"INSERT INTO db_room(_id,name,prio) VALUES(?,?,?)",room.ID ,room.name,room.prio];
    }
    [_db close];
    [threadLock unlock];
}


//添加到roomDevice

+(void)insertToRoomDevice:(RoomDevice *)roomDevice andID:(NSString *)roomId
{
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }

    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_room_device"])
    {
        [_db executeUpdate:@"INSERT INTO db_room_device(_id,property,room_id) VALUES(?,?,?)",roomDevice.ID,roomDevice.property,roomId];
//        NSLog( @"插入数据完毕");
    }
    [_db close];
    [threadLock unlock];
}
//添加到roomDeviceContent

+(void)insertToRoomDeviceContent:(NSString *)name andDeviceID:(NSString *)deviceID andRoomID:(NSString *)roomID
{
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    [_db setShouldCacheStatements:YES];
    
    if ([_db tableExists:@"db_room_device_content"])
    {
        [_db executeUpdate:@"INSERT INTO db_room_device_content(_id,name,device_id,room_id) VALUES(?,?,?,?)",[self GenerateGUID],name,deviceID,roomID];
    }
    [_db close];
    [threadLock unlock];
}

//添加到control

+(void)insertToControl:(Control *)control
{
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    
    [_db setShouldCacheStatements:YES];
    
    if ([_db tableExists:@"db_control"])
    {
        [_db executeUpdate:@"INSERT INTO db_control(_id,com) VALUES(?,?)",control.ID ,control.com];
    }
    [_db close];
    [threadLock unlock];
}

+(void)insertToControlDevice:(ControlDevice *)controlDevice andControlID:(NSString *)controlID
{
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    
    [_db setShouldCacheStatements:YES];
    
    if ([_db tableExists:@"db_control_device"])
    {
        NSLog(@"插入%@",controlDevice.category);
        [_db executeUpdate:@"INSERT INTO db_control_device(_id, type,method,category,control_id) VALUES(?,?,?,?,?)",controlDevice.ID,controlDevice.type,controlDevice.method,controlDevice.category,controlID];
    }
    [_db close];
    [threadLock unlock];
}

+(void)insertToControlDeviceContent:(ControlDeviceContent *)controlDeviceContent andDeviceID:(NSString *)deviceID andControlID:(NSString *)controlID
{
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    
    [_db setShouldCacheStatements:YES];
    
    if ([_db tableExists:@"db_control_device_content"])
    {
        [_db executeUpdate:@"INSERT INTO db_control_device_content(_id,property,device_id,control_id) VALUES(?,?,?,?)",controlDeviceContent.ID,controlDeviceContent.property,deviceID,controlID];
//        NSLog( @"插入数据完毕");
    }
    [_db close];
    [threadLock unlock];

}

+(void)insertToControlDeviceContentValue:(ControlDeviceContentValue *)controlDeviceContentValue andContentID:(NSString *)contentID andDeviceID:(NSString *)deviceID andControlID:(NSString *)controlID
{
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    
    [_db setShouldCacheStatements:YES];
    
    if ([_db tableExists:@"db_control_device_content_value"])
    {
        [_db executeUpdate:@"INSERT INTO db_control_device_content_value(_id,prio,value,name,content_id,device_id,control_id) VALUES(?,?,?,?,?,?,?)",controlDeviceContentValue.ID,controlDeviceContentValue.prio,controlDeviceContentValue.value,controlDeviceContentValue.name,contentID,deviceID,controlID];
//        NSLog( @"插入数据完毕");
    }
    [_db close];
    [threadLock unlock];
}

+(void)insertToControlDeviceContentValueKey:(ControlDeviceContentValueKey *)controlDeviceContentValueKey andValueID:(NSString *)valueID andContentID:(NSString *)contentID andDeviceID:(NSString *)deviceID andControlID:(NSString *)controlID
{
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    
    [_db setShouldCacheStatements:YES];
    
    if ([_db tableExists:@"db_control_device_content_value_key"])
    {
        [_db executeUpdate:@"INSERT INTO db_control_device_content_value_key(_id,value,backkey,query,name,value_id,content_id,device_id,control_id, time) VALUES(?,?,?,?,?,?,?,?,?,?)",controlDeviceContentValueKey.ID,controlDeviceContentValueKey.value,controlDeviceContentValueKey.backkey,controlDeviceContentValueKey.query,controlDeviceContentValueKey.name,valueID,contentID,deviceID,controlID,controlDeviceContentValueKey.time];
//        NSLog( @"插入数据完毕");
    }
    [_db close];
    [threadLock unlock];
}

+(void)insertToScene:(Scene *)scene
{
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    
    [_db setShouldCacheStatements:YES];
    
    if ([_db tableExists:@"db_scene"])
    {
        [_db executeUpdate:@"INSERT INTO db_scene(_id,id,name,isedit,status,scene,delay,prio,type,room) VALUES(?,?,?,?,?,?,?,?,?,?)",scene.ID,scene.sceneId,scene.name,scene.isedit,scene.status,scene.scene,scene.delay,scene.prio,scene.type,scene.room];
    }
    [_db close];
    [threadLock unlock];
}

+(void)insertToSceneDevice:(SceneDevice *)sceneDevice andSceneID:(NSString *)sceneID
{
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    
    [_db setShouldCacheStatements:YES];
    
    if ([_db tableExists:@"db_scene_device"])
    {
        [_db executeUpdate:@"INSERT INTO db_scene_device(_id,interval,value,operation,name,scene_id) VALUES(?,?,?,?,?,?)",sceneDevice.ID,sceneDevice.interval,sceneDevice.value,sceneDevice.operation,sceneDevice.name,sceneID];
    }
    [_db close];
    [threadLock unlock];
}

+(void)insertToIpc:(Ipc *)ipc
{
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    
    [_db setShouldCacheStatements:YES];
    
    if ([_db tableExists:@"db_ipcTable"])
    {
        [_db executeUpdate:@"INSERT INTO db_ipcTable(_id,name,android,IOS,package,androidActivity,IOS2,addState,IOSto) VALUES(?,?,?,?,?,?,?,?,?)",ipc.ID,ipc.name,ipc.android,ipc.IOS,ipc.package, ipc.androidActivity, ipc.IOS2, ipc.addState,ipc.IOSto];
    }
    [_db close];
    [threadLock unlock];
}

+(void)insertToConfig:(Config *)config
{
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    
    [_db setShouldCacheStatements:YES];
    
    if ([_db tableExists:@"db_config"])
    {
        [_db executeUpdate:@"INSERT INTO db_config(_id,name,version) VALUES(?,?,?)",config.ID ,config.name,config.version];
        //        NSLog( @"插入数据完毕");
    }
    [_db close];
    [threadLock unlock];
}

+(void)insertToCrontab:(Crontab *)crontab
{
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    
    [_db setShouldCacheStatements:YES];
    
    if ([_db tableExists:@"db_crontab"])
    {
        [_db executeUpdate:@"INSERT INTO db_crontab(_id,id,time,status,name,scene,repeat,date) VALUES(?,?,?,?,?,?,?,?)",crontab.ID ,crontab.crontabId,crontab.time,crontab.status,crontab.name,crontab.scene,crontab.repeat,crontab.date];
    }
    [_db close];
    [threadLock unlock];
}

+(void)insertToCrontabInstruction:(CrontabInstruction *)crontabInstruction andCrontabID:(NSString *)crontabID
{
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    
    [_db setShouldCacheStatements:YES];
    
    if ([_db tableExists:@"db_crontab_instructions"])
    {
        [_db executeUpdate:@"INSERT INTO db_crontab_instructions(_id,cmd,delay,crontab_id) VALUES(?,?,?,?)",crontabInstruction.ID,crontabInstruction.cmd,crontabInstruction.delay,crontabID];
    }
    [_db close];
    [threadLock unlock];
}

+(void)insertToSecurityNote:(SecurityNote *)securityNote
{
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    
    [_db setShouldCacheStatements:YES];
    
    if ([_db tableExists:@"db_securitynote"])
    {
        [_db executeUpdate:@"INSERT INTO db_securitynote(_id,alarmTime,alarmType,devMac) VALUES(?,?,?,?)",securityNote.ID,securityNote.alarmTime,securityNote.alarmType,securityNote.devMac];
        //        NSLog( @"插入数据完毕");
    }
    [_db close];
    [threadLock unlock];
}

+(void)insertToSecurity:(Security *)security
{
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    
    [_db setShouldCacheStatements:YES];
    
    if ([_db tableExists:@"db_security"])
    {
        [_db executeUpdate:@"INSERT INTO db_security(_id,type) VALUES(?,?)",security.ID,security.type];
        //        NSLog( @"插入数据完毕");
    }
    [_db close];
    [threadLock unlock];
}

+(void)insertTosecurityContentSensor:(SecurityContent_sensor *)securityContent_sensor andSecurityID:(NSString *)securityID
{
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    
    [_db setShouldCacheStatements:YES];
    
    if ([_db tableExists:@"db_security_sensor_content"])
    {
        [_db executeUpdate:@"INSERT INTO db_security_sensor_content(_id,sensorName,sensorMac,sensorType,sensorSignal,sensor24h,minValue,maxValue,ctrlValue,alarmName,alarmMac,alarmType,alarmTime,isElectromic,isAlarm,alarmMsg,powerMsg,security_id,sensorOldName,alarmOldName) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",securityContent_sensor.ID ,securityContent_sensor.sensorName,securityContent_sensor.sensorMac,securityContent_sensor.sensorType,securityContent_sensor.sensorSignal,securityContent_sensor.sensor24h,securityContent_sensor.minValue,securityContent_sensor.maxValue,securityContent_sensor.ctrlValue,securityContent_sensor.alarmName,securityContent_sensor.alarmMac,securityContent_sensor.alarmType,securityContent_sensor.alarmTime,securityContent_sensor.isElectromic,securityContent_sensor.isAlarm,securityContent_sensor.alarmMsg,securityContent_sensor.powerMsg,securityID,securityContent_sensor.sensorOldName,securityContent_sensor.alarmOldName];
    }
    [_db close];
    [threadLock unlock];
}

+(void)insertTosecurityContentZone:(SecurityContent_zone *)securityContent_zone andSecurityID:(NSString *)securityID
{
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    
    [_db setShouldCacheStatements:YES];
    
    if ([_db tableExists:@"db_security_zone_content"])
    {
        [_db executeUpdate:@"INSERT INTO db_security_zone_content(_id,name,type,state,delay,handled,security_id) VALUES(?,?,?,?,?,?,?)",securityContent_zone.ID ,securityContent_zone.name,securityContent_zone.type,securityContent_zone.state,securityContent_zone.delay, securityContent_zone.handled,securityID];
    }
    [_db close];
    [threadLock unlock];
}

+(void)insertTosecurityContentZoneSensor:(SecurityContent_zone_sensor *)securityContent_zone_sensor andContentID:(NSString *)contentID andSecurityID:(NSString *)securityID
{
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    
    [_db setShouldCacheStatements:YES];
    
    if ([_db tableExists:@"db_security_zone_content_sensor"])
    {
        [_db executeUpdate:@"INSERT INTO db_security_zone_content_sensor(_id,name,mac,type,state,content_id,security_id) VALUES(?,?,?,?,?,?,?)",securityContent_zone_sensor.ID ,securityContent_zone_sensor.name,securityContent_zone_sensor.mac,securityContent_zone_sensor.type,securityContent_zone_sensor.state,contentID,securityID];
    }
    [_db close];
    [threadLock unlock];
}

#pragma mark - 
#pragma mark Delete All Data From Table
+(void)deleteDataFromRoom{
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_room"]){
        [_db executeUpdate:@"drop table db_room"];
        [_db executeUpdate:@"CREATE TABLE db_room (_id text PRIMARY KEY ,name text,prio text)"];
    }
    if ([_db tableExists:@"db_room_device"]){
        [_db executeUpdate:@"drop table db_room_device"];
        [_db executeUpdate:@"CREATE TABLE db_room_device (_id text PRIMARY KEY ,property text,room_id text)"];
    }
    if ([_db tableExists:@"db_room_device_content"]){
        [_db executeUpdate:@"drop table db_room_device_content"];
        [_db executeUpdate:@"CREATE TABLE db_room_device_content (_id text PRIMARY KEY ,name text,device_id text, room_id text)"];
    }
    [_db close];
    [threadLock unlock];
}

+(void)deleteDataFromControl{
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_control"]){
        [_db executeUpdate:@"drop table db_control"];
        [_db executeUpdate:@"CREATE TABLE db_control (_id text PRIMARY KEY ,com integer)"];

    }
    if ([_db tableExists:@"db_control_device"]){
        [_db executeUpdate:@"drop table db_control_device"];
        [_db executeUpdate:@"CREATE TABLE db_control_device (_id text PRIMARY KEY ,type text,method text,category text,control_id text)"];

    }
    if ([_db tableExists:@"db_control_device_content"]){
        [_db executeUpdate:@"drop table db_control_device_content"];
        [_db executeUpdate:@"CREATE TABLE db_control_device_content (_id text PRIMARY KEY ,property text,device_id text, control_id text)"];
    }
    if ([_db tableExists:@"db_control_device_content_value"]){
        [_db executeUpdate:@"drop table  db_control_device_content_value"];
        [_db executeUpdate:@"CREATE TABLE db_control_device_content_value (_id text PRIMARY KEY ,prio text,value text,name text,content_id text, device_id text, control_id text)"];
    }
    if ([_db tableExists:@"db_control_device_content_value_key"]){
        [_db executeUpdate:@"drop table db_control_device_content_value_key"];
        [_db executeUpdate:@"CREATE TABLE 'db_control_device_content_value_key' (_id text PRIMARY KEY ,value text,backkey text,query text,name text,time text,value_id text, content_id text, device_id text, control_id text)"];
    }
    [_db close];
    [threadLock unlock];
}

+(void)deleteDataFromScene{
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_scene"]){
        [_db executeUpdate:@"drop table db_scene"];
        [_db executeUpdate:@"CREATE TABLE db_scene (_id text PRIMARY KEY , id TEXT, name TEXT, isedit TEXT, status TEXT, scene TEXT, delay TEXT, prio TEXT, type TEXT, room TEXT)"];
        //NSLog(@"ReCreate db_scene");
    }
    if ([_db tableExists:@"db_scene_device"]){
        [_db executeUpdate:@"drop table db_scene_device"];
        [_db executeUpdate:@"CREATE TABLE db_scene_device (_id text PRIMARY KEY ,interval text,value text,operation text,name text,scene_id text)"];
        //NSLog(@"ReCreate db_scene_device");
    }
    [_db close];
    [threadLock unlock];
}

+(void)deleteDataFromIPC{
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_ipcTable"]){
        [_db executeUpdate:@"drop table db_ipcTable"];
//        [_db executeUpdate:@"CREATE TABLE db_ipcTable (_id text PRIMARY KEY,ipc_name text, ipc_android text,ipc_IOS text,ipc_package text)"];
        [_db executeUpdate:@"CREATE TABLE db_ipcTable (_id text PRIMARY KEY, name TEXT, android TEXT, IOS TEXT, package TEXT, androidActivity TEXT, IOS2 TEXT, addState TEXT, IOSto TEXT)"];
    }
    [_db close];
    [threadLock unlock];
}

+(void)deleteDataFromConfig{
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_config"]){
        
        [_db executeUpdate:@"drop table db_config"];
        [_db executeUpdate:@"CREATE TABLE db_config (_id text PRIMARY KEY,name text,version text)"];
        //NSLog(@"ReCreate db_config");
    }
    [_db close];
    [threadLock unlock];
}

+(void)deleteDataFromCrontab{
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_crontab"]){
        [_db executeUpdate:@"drop table db_crontab"];
        [_db executeUpdate:@"CREATE TABLE db_crontab (_id text PRIMARY KEY ,id text ,time text,status text,name text,scene text,repeat text,date text)"];
    }
    if ([_db tableExists:@"db_crontab_instructions"]){
        [_db executeUpdate:@"drop table db_crontab_instructions"];
        [_db executeUpdate:@"CREATE TABLE db_crontab_instructions (_id text PRIMARY KEY ,cmd text,delay text,crontab_id text)"];
    }
    [_db close];
    [threadLock unlock];
}

+(void)deleteDataFromSecurityNote{
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_securitynote"]){
        [_db executeUpdate:@"drop table db_securitynote"];
        [_db executeUpdate:@"CREATE TABLE db_securitynote (_id text PRIMARY KEY,alarmTime DATE,alarmType text,devMac text)"];
        //NSLog(@"ReCreate db_securitynote");
    }
    [_db close];
    [threadLock unlock];
}

+(void)deleteDataFromSecurity{
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_security"]){
        [_db executeUpdate:@"drop table db_security"];
        [_db executeUpdate:@"CREATE TABLE db_security (_id text PRIMARY KEY ,type text)"];
    }
    if ([_db tableExists:@"db_security_sensor_content"]){
        [_db executeUpdate:@"drop table db_security_sensor_content"];
        [_db executeUpdate:@"CREATE TABLE db_security_sensor_content (_id text PRIMARY KEY ,sensorName text,sensorMac text,sensorType text,sensorSignal text,sensor24h text,minValue text,maxValue text,ctrlValue text,alarmName text,alarmMac text,alarmType text,alarmTime text,isElectromic text,isAlarm text,alarmMsg text,powerMsg text, sensorOldName text, alarmOldName text,security_id text)"];

    }
    if ([_db tableExists:@"db_security_zone_content"]){
        [_db executeUpdate:@"drop table db_security_zone_content"];
        [_db executeUpdate:@"CREATE TABLE db_security_zone_content (_id text PRIMARY KEY ,name text,type text,state text,delay text,handled text,security_id text)"];
    }
    if ([_db tableExists:@"db_security_zone_content_sensor"]){
        [_db executeUpdate:@"drop table db_security_zone_content_sensor"];
        [_db executeUpdate:@"CREATE TABLE db_security_zone_content_sensor (_id text PRIMARY KEY ,name text,mac text,type text,state text,content_id text, security_id text)"];
    }
    [_db close];
    [threadLock unlock];
}
//删除原有doorlock数据
+ (void)deleteDataFromDoorlock {
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_doorlock"]){
        [_db executeUpdate:@"drop table db_doorlock"];
        [_db executeUpdate:@"CREATE TABLE db_doorlock (_id text PRIMARY KEY ,number TEXT, enter_scene TEXT, leave_scene TEXT, enter_security_zone TEXT, leave_security_zone TEXT, enter_scene_enable TEXT, leave_scene_enable TEXT, enter_security_enable TEXT, leave_security_enable TEXT)"];
        NSLog(@"删除了旧的 db_doorlock");
    }
    if ([_db tableExists:@"db_doorlock_user"]){
        [_db executeUpdate:@"drop table db_doorlock_user"];
        [_db executeUpdate:@"CREATE TABLE db_doorlock_user (_id text PRIMARY KEY ,user_id TEXT, user_name TEXT, member_role TEXT)"];
        NSLog(@"删除了旧的 db_doorlock_user");
    }
    [_db close];
    [threadLock unlock];
}
//删除原有的doorlocknote数据
+ (void)deleteDataFromDoorlockNote {
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_doorlock_alarm"]){
        [_db executeUpdate:@"drop table db_doorlock_alarm"];
        [_db executeUpdate:@"CREATE TABLE db_doorlock_alarm (_id text PRIMARY KEY ,alarmTime TEXT, devID TEXT, userNumber TEXT, partNum TEXT, powerMsg TEXT, alarmMsg TEXT)"];
        NSLog(@"删除了旧的 db_doorlock_alarm");
    }
    [_db close];
    [threadLock unlock];
}

#pragma mark -
#pragma mark 数据访问接口 Room
+(NSMutableArray *)getRoom{
    [threadLock lock];
    NSMutableArray *aryRoom = [[NSMutableArray alloc] init];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_room"])
    {
        //1.ROOM
        FMResultSet *roomSet = [_db executeQuery:@"SELECT  * FROM db_room"];
        while ([roomSet next]) {
            Room *tmpRoom = [[Room alloc] init];
            tmpRoom.ID = [roomSet stringForColumn:@"_id"];
            tmpRoom.name = [roomSet stringForColumn:@"name"];
            tmpRoom.prio = [roomSet stringForColumn:@"prio"];
            tmpRoom.deviceArr = nil;
            [aryRoom addObject:tmpRoom];
            //NSLog(@"Add Room: id:%@, name:%@ prio:%@", tmpRoom.ID, tmpRoom.name, tmpRoom.prio);
        }
    }
    [_db close];
    [threadLock unlock];
    return aryRoom;
}

+(NSMutableArray *)getRoomDeviceWithRoomID:(NSString *)roomID{
    [threadLock lock];
    NSMutableArray *aryRoomDevice = [[NSMutableArray alloc] init];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_room_device"])
    {
        //2.ROOM DEVICES
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_room_device WHERE room_id = ?", roomID];
        while ([set next]) {
            RoomDevice *tmpRoomDevice = [[RoomDevice alloc] init];
            tmpRoomDevice.ID = [set stringForColumn:@"_id"];
            tmpRoomDevice.property = [set stringForColumn:@"property"];
            tmpRoomDevice.contentArr = nil;
            [aryRoomDevice addObject:tmpRoomDevice];
            //NSLog(@"Add RoomDevice: ID:%@, property: %@, roomID:%@", tmpRoomDevice.ID, tmpRoomDevice.property, roomID);
        }
    }
    [_db close];
    [threadLock unlock];
    return aryRoomDevice;
}

+(NSMutableArray *)getContentNameWithRoomDeivceID:(NSString *)roomDeviceID{
    [threadLock lock];
    NSMutableArray *aryContent = [[NSMutableArray alloc] init];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_room_device"])
    {
        //2.ROOM DEVICES
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_room_device_content WHERE device_id = ?", roomDeviceID];
        while ([set next]) {
            NSString *tmpName = [set stringForColumn:@"name"];
            [aryContent addObject:tmpName];
        }
    }
    [_db close];
    [threadLock unlock];
    return aryContent;
}

+(NSString *)getRoomNameWithRoomDeviceName:(NSString *)deviceName{
    [threadLock lock];
    Room *tmpRoom;
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_room"])
    {
        //2.ROOM DEVICES
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_room WHERE _id in (SELECT room_id FROM db_room_device_content WHERE name = ?)", deviceName];
        while ([set next]) {
            tmpRoom = [[Room alloc] init];
            tmpRoom.name = [set stringForColumn:@"name"];
            tmpRoom.prio = [set stringForColumn:@"prio"];
            tmpRoom.ID = [set stringForColumn:@"_id"];
        }
    }
    [_db close];
    [threadLock unlock];
    return tmpRoom.name;
}


+(BOOL)deleteRoomDeviceContentWithName:(NSString *)name{
    [threadLock lock];
    BOOL result = NO;
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        result = NO;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_room"]){
       result = [_db executeUpdate:@"DELETE FROM db_room_device_content WHERE name=?", name];
    }
    [_db close];
    [threadLock unlock];
    return result;
}
+(BOOL)addRoomDeviceContentWithName:(NSString *)devName room:(NSString *) roomName{
    [threadLock lock];
    BOOL result = NO;
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        result = NO;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_room_device_content"]){
        NSString *roomID = @"";
        NSString *deviceID = @"";
        //1.查询出RoomID
        FMResultSet *setRoom = [_db executeQuery:@"SELECT _id  FROM db_room WHERE name =?", roomName];
        while ([setRoom next]) {
            roomID = [setRoom stringForColumn:@"_id"];
        }
        //2.查询出该Device 的property
        //2.1 只有设备和硬场景才能在 control_device_content_value 中获取到
        NSString *property = @"";
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_control_device_content_value WHERE name = ", devName];
        
        while ([set next]) {
            ControlDeviceContentValue *tmpDeivceValue = [[ControlDeviceContentValue alloc] init];
            tmpDeivceValue.ID = [set stringForColumn:@"_id"];
            tmpDeivceValue.name = [set stringForColumn:@"name"];
            tmpDeivceValue.value = [set stringForColumn:@"value"];
            tmpDeivceValue.prio = [set stringForColumn:@"prio"];
            tmpDeivceValue.keyArr = nil;
            // 再查询 其com, catagory, poperty
            FMResultSet *setCom = [_db executeQuery:@"SELECT com FROM db_control WHERE _id=?", [set stringForColumn:@"control_id"]];
            FMResultSet *setCategory = [_db executeQuery:@"SELECT category FROM db_control_device WHERE _id=?", [set stringForColumn:@"device_id"]];
            FMResultSet *setProperty = [_db executeQuery:@"SELECT property FROM db_control_device_content WHERE _id=?", [set stringForColumn:@"content_id"]];
            
            while ([setCom next]) {
                tmpDeivceValue.com = [setCom stringForColumn:@"com"];
            }
            while ([setCategory next]) {
                tmpDeivceValue.category = [setCategory stringForColumn:@"category"];
            }
            while ([setProperty next]) {
                tmpDeivceValue.property = [setProperty stringForColumn:@"property"];
                property = tmpDeivceValue.property;
            }
        }
        //2.2没有获取到  则设备的property=场景控制器
        if (property== nil || [property isEqualToString:@""]) {
            property = @"场景控制器";
        }
        //3.得到Room_Device 的DeivceID
        //3.1 直接查询到 Room_Device 的DeivceID
        FMResultSet *setDevice = [_db executeQuery:@"SELECT _id FROM db_room_device WHERE room_id=? AND property=?", roomID, property];
        while ([setDevice next]) {
            deviceID = [setDevice stringForColumn:@"_id"];
        }
        //3.2 没有查询到 DeivceID 则需要新增DeviceID 再查询
        if (deviceID == nil || [deviceID isEqualToString:@""]) {
            if ([_db executeUpdate:@"INSERT INTO db_room_device(_id,property, room_id)  VALUES (?,?,?)", [self GenerateGUID],property, roomID]) {
                FMResultSet *setDevice = [_db executeQuery:@"SELECT _id FROM db_room_device WHERE room_id=? AND property=?", roomID, property];
                while ([setDevice next]) {
                    deviceID = [setDevice stringForColumn:@"_id"];
                }
            }
        }
        NSString *roomDeivceContentID = @"";
        FMResultSet *setDeviceContent = [_db executeQuery:@"SELECT * FROM db_room_device_content Where name=? ", devName];
        while ([setDeviceContent next]) {
            roomDeivceContentID = [setDeviceContent stringForColumn:@"_id"];
        }
        
        if (roomDeivceContentID == nil || [roomDeivceContentID isEqualToString:@""]) {
            //新增
            result = [_db executeUpdate:@"INSERT INTO db_room_device_content(_id,name,device_id,  room_id) VALUES(?,?, ?, ?)", [self GenerateGUID],devName, deviceID, roomID];
        }
        else{
            //UPDate
            result = [_db executeUpdate:@"UPDATE  db_room_device_content SET name=?, device_id=?, room_id=? WHERE _id=?", devName, deviceID, roomID, roomDeivceContentID];
        }
    }
    [_db close];
    [threadLock unlock];
    return result;
}
+ (BOOL)insertRoom:(Room *)room {
    [threadLock lock];
    BOOL isCompelete = YES;
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return false;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_room"]){
            isCompelete = [_db executeUpdate:@"INSERT INTO db_room(_id,name,prio) VALUES(?,?,?)",room.ID,room.name,room.prio];
            ////出现错误
            if (!isCompelete) {
                [threadLock unlock];
                return false;
            }
        }
    [_db close];
    [threadLock unlock];
    return isCompelete;
}
+ (void)deleteRoomWithName:(NSString *)name {
    [threadLock lock];
    NSString *ID;
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_room"])
    {
        //2.ROOM DEVICES
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_room WHERE name = ?", name];
        while ([set next]) {
            ID = [set stringForColumn:@"_id"];
        }
        [_db executeUpdate:@"DELETE FROM db_room WHERE name = ?",name];
        [_db executeUpdate:@"DELETE FROM db_room_device WHERE room_id = ?",ID];
        [_db executeUpdate:@"DELETE FROM db_room_device_content WHERE room_id = ?",ID];
    }
    
    //修改scene.json文件room名字为null
    [_db executeUpdate:@"UPDATE  db_scene SET room=? WHERE room=?", @"null",name];
    
    [_db close];
    [threadLock unlock];
}
+ (Room *)getRoomFromName:(NSString *)name {
    [threadLock lock];
    Room *room = [Room new];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_room"])
    {
        //2.ROOM DEVICES
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_room WHERE name = ?", name];
        while ([set next]) {
            room.ID = [set stringForColumn:@"_id"];
            room.name = name;
            room.prio = [set stringForColumn:@"prio"];
        }
    }
    [_db close];
    [threadLock unlock];
    return room;
}
+ (void)updataRoomWithRoom:(Room *)room withOldName:(NSString *)oldName{
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_room"])
    {
        [_db executeUpdate:@"UPDATE  db_room SET name=? WHERE _id=?", room.name,room.ID];
    }
    if ([_db tableExists:@"db_scene"])
    {
        [_db executeUpdate:@"UPDATE  db_scene SET room=? WHERE room=?", room.name,oldName];
    }
    [_db close];
    [threadLock unlock];
}

#pragma mark -
#pragma mark 数据访问接口 Control
+(NSMutableArray *)getDeviceDetailsWithDeviceID:(NSString *)deviceID{
    [threadLock lock];
    NSMutableArray *aryDeviceContent = [[NSMutableArray alloc] init];
    
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_control_device_content_value"]){
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_control_device_content_value WHERE name in (SELECT name FROM db_room_device_content WHERE db_room_device_content.device_id=? )", deviceID];
        /////////////1. 获取设备
        while ([set next]) {
            ControlDeviceContentValue *tmpDeivceValue = [[ControlDeviceContentValue alloc] init];
            tmpDeivceValue.ID = [set stringForColumn:@"_id"];
            tmpDeivceValue.name = [set stringForColumn:@"name"];
            tmpDeivceValue.value = [set stringForColumn:@"value"];
            tmpDeivceValue.prio = [set stringForColumn:@"prio"];
            tmpDeivceValue.keyArr = nil;
            // 再查询 其com, catagory, poperty
            FMResultSet *setCom = [_db executeQuery:@"SELECT com FROM db_control WHERE _id=?", [set stringForColumn:@"control_id"]];
            FMResultSet *setCategory = [_db executeQuery:@"SELECT category FROM db_control_device WHERE _id=?", [set stringForColumn:@"device_id"]];
            FMResultSet *setProperty = [_db executeQuery:@"SELECT property FROM db_control_device_content WHERE _id=?", [set stringForColumn:@"content_id"]];
            
            while ([setCom next]) {
                tmpDeivceValue.com = [setCom stringForColumn:@"com"];
            }
            while ([setCategory next]) {
                tmpDeivceValue.category = [setCategory stringForColumn:@"category"];
            }
            while ([setProperty next]) {
                tmpDeivceValue.property = [setProperty stringForColumn:@"property"];
            }
            ////////去除掉场景。 在下个循环再处理场景
            if ([tmpDeivceValue.property isEqualToString:@"场景控制器"]){
                continue;
            }
            
            [aryDeviceContent addObject:tmpDeivceValue];
            //NSLog(@"Add Details: ID: %@, name: %@, value:%@, com: %@, category: %@, property: %@, deviceID: %@", tmpDeivceValue.ID, tmpDeivceValue.name, tmpDeivceValue.value, tmpDeivceValue.com, tmpDeivceValue.category, tmpDeivceValue.property,deviceID);
        }
        /////////////2. 获取场景
        set = [_db executeQuery:@"SELECT * FROM db_scene WHERE name in (SELECT name FROM db_room_device_content WHERE db_room_device_content.device_id=?)",deviceID];
        while ([set next]) {
            Scene *tmpScene = [[Scene alloc] init];
            tmpScene.ID = [set stringForColumn:@"_id"];
            tmpScene.sceneId = [set stringForColumn:@"id"];
            tmpScene.name = [set stringForColumn:@"name"];
            tmpScene.type = [set stringForColumn:@"type"];
            tmpScene.room = [set stringForColumn:@"room"];
            tmpScene.prio = [set stringForColumn:@"prio"];
            tmpScene.status = [set stringForColumn:@"status"];
            tmpScene.isedit= [set stringForColumn:@"isedit"];
            tmpScene.delay = [set stringForColumn:@"delay"];
            tmpScene.scene = [set stringForColumn:@"scene"];
            tmpScene.deviceArr = nil;
            [aryDeviceContent addObject:tmpScene];
        }
    }
    [_db close];
    [threadLock unlock];
    return aryDeviceContent;
}
//获得所有设备setting
+ (NSMutableArray *)getAllDevice {
    [threadLock lock];
    NSMutableArray *aryDeviceContent = [[NSMutableArray alloc]init];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    
    
    if ([_db tableExists:@"db_control_device_content_value"])
    {
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_control_device_content_value ORDER BY value"];
        while ([set next]) {
            DeviceSettingModel *settingModel = [DeviceSettingModel new];
            settingModel.name = [set stringForColumn:@"name"];
            settingModel.ID = [set stringForColumn:@"value"];
            settingModel.isNewDevice = NO;
            
            NSString *deviceID = [set stringForColumn:@"device_id"];
            NSString *contentID = [set stringForColumn:@"content_id"];
            NSString *controlID = [set stringForColumn:@"control_id"];
            
            if ([_db tableExists:@"db_control"]) {
                FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_control WHERE _id = ?",controlID];
                while ([set next]) {
                    settingModel.com = [set stringForColumn:@"com"];
                }
            }
            if ([_db tableExists:@"db_control_device"]) {
                FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_control_device WHERE _id = ?",deviceID];
                while ([set next]) {
                    settingModel.type = [set stringForColumn:@"category"];
                }
            }
            if ([_db tableExists:@"db_control_device_content"]) {
                FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_control_device_content WHERE _id = ?",contentID];
                while ([set next]) {
                    settingModel.property = [set stringForColumn:@"property"];
                }
            }
            
          if (settingModel.ID == nil || [settingModel.ID isEqualToString:@"null"] || [settingModel.type isEqualToString:@"默认设备"])  {
                
            } else {
                [aryDeviceContent addObject:settingModel];
            }
        }
    }
    [_db close];
    [threadLock unlock];
    return aryDeviceContent;
}
///获取所有设备
+(NSMutableArray *)getAlldeviceContent{
    [threadLock lock];
    NSMutableArray *aryDeviceContent = [[NSMutableArray alloc]init];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_control_device_content_value"])
    {
        //3.ROOM DEVICE CONTENT DETAILS
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_control_device_content_value"];
        while ([set next]) {
//            ControlDeviceContentValue *tmpValue = [[ControlDeviceContentValue alloc] init];
//            tmpValue.name = [set stringForColumn:@"name"];
            [aryDeviceContent addObject:[set stringForColumn:@"name"]];
        }
    }
    [_db close];
    [threadLock unlock];
    return aryDeviceContent;
}
///获取所有的报警器
+(NSMutableArray *)getAlarmDevice{
    [threadLock lock];
    NSMutableArray *aryAlarm = [[NSMutableArray alloc]init];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_control_device_content_value"])
    {
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_control_device_content_value WHERE name not in (SELECT name FROM db_room_device_content)"];
        while ([set next]) {
            ControlDeviceContentValue *tmpValueKey = [[ControlDeviceContentValue alloc]init];
            tmpValueKey.ID = [set stringForColumn:@"_id"];
            tmpValueKey.name = [set stringForColumn:@"name"];
            tmpValueKey.value = [set stringForColumn:@"value"];
            tmpValueKey.prio = [set stringForColumn:@"prio"];
            tmpValueKey.keyArr = nil;
            [aryAlarm addObject:tmpValueKey];
        }
    }
    [_db close];
    [threadLock unlock];
    return aryAlarm;
}
+(ControlDeviceContentValue *)getDeviceDetailsWithDeviceName:(NSString *)deviceName{
    [threadLock lock];
    NSMutableArray *aryDeviceContent = [[NSMutableArray alloc] init];
    
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_control_device_content_value"])
    {
        //3.ROOM DEVICE CONTENT DETAILS
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_control_device_content_value WHERE name=?", deviceName];
        while ([set next]) {
            ControlDeviceContentValue *tmpDeivceValue = [[ControlDeviceContentValue alloc] init];
            tmpDeivceValue.ID = [set stringForColumn:@"_id"];
            tmpDeivceValue.name = [set stringForColumn:@"name"];
            tmpDeivceValue.value = [set stringForColumn:@"value"];
            tmpDeivceValue.prio = [set stringForColumn:@"prio"];

            tmpDeivceValue.keyArr = nil;
            
            if ([_db tableExists:@"db_control_device_content_value_key"])
            {
                NSMutableArray *tmp = [[NSMutableArray alloc]init];
                FMResultSet *se = [_db executeQuery:@"SELECT * FROM db_control_device_content_value_key WHERE value_id=?",tmpDeivceValue.ID];
                while ([se next]) {
                    ControlDeviceContentValueKey *tmpValueKey = [[ControlDeviceContentValueKey alloc] init];
                    tmpValueKey.name = [se stringForColumn:@"name"];
                    tmpValueKey.value = [se stringForColumn:@"value"];
                    tmpValueKey.query = [se stringForColumn:@"query"];
                    tmpValueKey.backkey = [se stringForColumn:@"backkey"];
                    tmpValueKey.time = [se stringForColumn:@"time"];
                    
                    [tmp addObject:tmpValueKey];
                }
                tmpDeivceValue.keyArr = tmp;
            }
            
            // 再查询 其com, catagory, poperty
            FMResultSet *setCom = [_db executeQuery:@"SELECT com FROM db_control WHERE _id=?", [set stringForColumn:@"control_id"]];
            FMResultSet *setCategory = [_db executeQuery:@"SELECT category FROM db_control_device WHERE _id=?", [set stringForColumn:@"device_id"]];
            FMResultSet *setProperty = [_db executeQuery:@"SELECT property FROM db_control_device_content WHERE _id=?", [set stringForColumn:@"content_id"]];
            
            while ([setCom next]) {
                tmpDeivceValue.com = [setCom stringForColumn:@"com"];
            }
            while ([setCategory next]) {
                tmpDeivceValue.category = [setCategory stringForColumn:@"category"];
            }
            while ([setProperty next]) {
                tmpDeivceValue.property = [setProperty stringForColumn:@"property"];
            }
            [aryDeviceContent addObject:tmpDeivceValue];
            [_db close];
            [threadLock unlock];
             return [aryDeviceContent objectAtIndex:0];
        }
       
    }
    [_db close];
    [threadLock unlock];
    return nil;
}


+(NSMutableArray *)getDeviceValueWithRoomName:(NSString *)name{
    [threadLock lock];
    NSMutableArray *aryRoomDeviceValue = [[NSMutableArray alloc] init];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_control_device_content_value"])
    {
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_control_device_content_value WHERE name in (SELECT name FROM db_room_device_content WHERE room_id in (SELECT _id FROM db_room WHERE name=?))", name];
        while ([set next]) {
            ControlDeviceContentValue *tmpDeivceValue = [[ControlDeviceContentValue alloc] init];
            tmpDeivceValue.ID = [set stringForColumn:@"_id"];
            tmpDeivceValue.name = [set stringForColumn:@"name"];
            tmpDeivceValue.value = [set stringForColumn:@"value"];
            tmpDeivceValue.prio = [set stringForColumn:@"prio"];
            tmpDeivceValue.keyArr = nil;
            // 再查询 其com, catagory, poperty
            FMResultSet *setCom = [_db executeQuery:@"SELECT com FROM db_control WHERE _id=?", [set stringForColumn:@"control_id"]];
            FMResultSet *setCategory = [_db executeQuery:@"SELECT category FROM db_control_device WHERE _id=?", [set stringForColumn:@"device_id"]];
            FMResultSet *setProperty = [_db executeQuery:@"SELECT property FROM db_control_device_content WHERE _id=?", [set stringForColumn:@"content_id"]];
            
            while ([setCom next]) {
                tmpDeivceValue.com = [setCom stringForColumn:@"com"];
            }
            while ([setCategory next]) {
                tmpDeivceValue.category = [setCategory stringForColumn:@"category"];
            }
            while ([setProperty next]) {
                tmpDeivceValue.property = [setProperty stringForColumn:@"property"];
            }
            [aryRoomDeviceValue addObject:tmpDeivceValue];
        }
    }
    [_db close];
    [threadLock unlock];
    return aryRoomDeviceValue;
}



+(NSMutableArray *)getContrlKeyWithValueID:(NSString *)valueID{
    [threadLock lock];
    NSMutableArray *aryValueKey = [[NSMutableArray alloc] init];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_control_device_content_value_key"])
    {
        //3.ROOM DEVICE CONTENT DETAILS
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_control_device_content_value_key WHERE value_id=?",valueID];
        while ([set next]) {
            ControlDeviceContentValueKey *tmpValueKey = [[ControlDeviceContentValueKey alloc] init];
            tmpValueKey.ID      = [set stringForColumn:@"_id"];
            tmpValueKey.name    = [set stringForColumn:@"name"];
            tmpValueKey.value   = [set stringForColumn:@"value"];
            tmpValueKey.query   = [set stringForColumn:@"query"];
            tmpValueKey.backkey = [set stringForColumn:@"backkey"];
            tmpValueKey.time    = [set stringForColumn:@"time"];
            [aryValueKey addObject:tmpValueKey];
        }
    }
    [_db close];
    [threadLock unlock];
    return aryValueKey;
}
+(BOOL)updateContrlValueKeys:(NSArray *)aryKey ValueName:(NSString *)valName{
    [threadLock lock];
    BOOL isCompelete = YES;
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return false;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_control_device_content_value_key"]){
        ///查询到其contentID, deviceID, controlID
        NSString *valID, *contentID, *deviceID, *controlID;
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_control_device_content_value WHERE name = ?", valName];
        while ([set next]) {
            valID     = [set stringForColumn:@"_id"];
            contentID = [set stringForColumn:@"content_id"];
            deviceID  = [set stringForColumn:@"device_id"];
            controlID = [set stringForColumn:@"control_id"];

        }
        ///先删除全部
        [_db executeUpdate:@"DELETE FROM db_control_device_content_value_key WHERE value_id = ?",valID];
        ///再将其aryKey全部插入
        for (ControlDeviceContentValueKey *k in aryKey) {
            isCompelete = [_db executeUpdate:@"INSERT INTO db_control_device_content_value_key(_id,value,backkey,query,name,value_id,content_id,device_id,control_id, time) VALUES(?,?,?,?,?,?,?,?,?,?)",[self GenerateGUID],k.value,k.backkey,k.query,k.name,valID,contentID,deviceID,controlID,k.time];
            ////出现错误
            if (!isCompelete) {
                [threadLock unlock];
                return false;
            }
        }
    }
    [_db close];
    [threadLock unlock];
    return isCompelete;
}
/////更新权限
+(BOOL)updateDevicePriowith:(NSMutableArray *)arydeviceValue{
    [threadLock lock];
    BOOL isCompelete = YES;
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return false;
    }
    if([_db tableExists:@"db_control_device_content_value"]){
        for(int i =0;i<arydeviceValue.count;i++){
            /////更改scene表中的权限  数据冗余嘛
            if([((Room *)arydeviceValue[i]).deviceArr[0] isKindOfClass:[Scene class]]){
                Scene *tmpScene = (Scene *)((Room *)arydeviceValue[i]).deviceArr[0];
                if([_db tableExists:@"db_control_device_content_value"]){
                    isCompelete = [_db executeUpdate:@"UPDATE db_scene SET prio=? WHERE name=?",tmpScene.prio,tmpScene.name];
                }
            }
            ControlDeviceContentValue *tmp = (ControlDeviceContentValue *)((Room *)arydeviceValue[i]).deviceArr[0];
            isCompelete = [_db executeUpdate:@"UPDATE db_control_device_content_value SET prio=? WHERE name=?",tmp.prio,tmp.name];
        }
    }
    [_db close];
    [threadLock unlock];
    return isCompelete;
}
/////////////// 获取所有Ctrls设备
+(NSMutableArray *)getAllContrls{
    [threadLock lock];
    NSMutableArray *aryReslut = [NSMutableArray array];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return false;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_control"]){
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_control"];
        while ([set next]) {
            Control *ctrl = [[Control alloc] init];
            ctrl.ID        = [set stringForColumn:@"_id"];
            ctrl.com       = [set stringForColumn:@"com"];
            ctrl.deviceArr = nil;
            [aryReslut addObject:ctrl];
        }
    }
    [_db close];
    [threadLock unlock];
    return aryReslut;
}
+(NSMutableArray *)getCtrlDeviceWithCtrlID:(NSString *)ctrlID{
    [threadLock lock];
    NSMutableArray *aryReslut = [NSMutableArray array];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return false;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_control_device"]){
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_control_device WHERE control_id = ?", ctrlID];
        while ([set next]) {
            ControlDevice *ctrlDevice = [[ControlDevice alloc] init];
            ctrlDevice.ID         = [set stringForColumn:@"_id"];
            ctrlDevice.type       = [set stringForColumn:@"type"];
            ctrlDevice.method     = [set stringForColumn:@"method"];
            ctrlDevice.category   = [set stringForColumn:@"category"];
            ctrlDevice.contentArr = nil;
            [aryReslut addObject:ctrlDevice];
        }
    }
    [_db close];
    [threadLock unlock];
    return aryReslut;
}
+(NSMutableArray *)getContentWithDeviceID:(NSString *)deviceID{
    [threadLock lock];
    NSMutableArray *aryReslut = [NSMutableArray array];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return false;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_control_device_content"]){
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_control_device_content  WHERE device_id = ?", deviceID];
        while ([set next]) {
            ControlDeviceContent *content = [[ControlDeviceContent alloc] init];
            content.ID       = [set stringForColumn:@"_id"];
            content.property = [set stringForColumn:@"property"];
            content.valueArr = nil;
            [aryReslut addObject:content];
        }
    }
    [_db close];
    [threadLock unlock];
    return aryReslut;
}
+(NSMutableArray *)getValuesWithContentID:(NSString *)contentID{
    [threadLock lock];
    NSMutableArray *aryReslut = [NSMutableArray array];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return false;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_control_device_content_value"]){
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_control_device_content_value  WHERE content_id = ?", contentID];
        while ([set next]) {
            ControlDeviceContentValue *vaule = [[ControlDeviceContentValue alloc] init];
            vaule.ID = [set stringForColumn:@"_id"];
            vaule.prio = [set stringForColumn:@"prio"];
            vaule.value = [set stringForColumn:@"value"];
            vaule.name = [set stringForColumn:@"name"];
            vaule.keyArr = nil;
            [aryReslut addObject:vaule];
        }
    }
    [_db close];
    [threadLock unlock];
    return aryReslut;
}
+(NSMutableArray *)getTogetherCategoryValues:(NSString *)valName{
    [threadLock lock];
    NSMutableArray *aryValues = [[NSMutableArray alloc] init];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_control_device_content_value"])
    {
        ///先获取CategoryID、再获取该Category所有的Values
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_control_device_content_value WHERE device_id in (SELECT device_id FROM db_control_device_content_value WHERE name=?)",valName];
        while ([set next]) {
            ControlDeviceContentValue *vaule = [[ControlDeviceContentValue alloc] init];
            vaule.ID = [set stringForColumn:@"_id"];
            vaule.prio = [set stringForColumn:@"prio"];
            vaule.value = [set stringForColumn:@"value"];
            vaule.name = [set stringForColumn:@"name"];
            vaule.keyArr = nil;
            [aryValues addObject:vaule];
        }
    }
    [_db close];
    [threadLock unlock];
    return aryValues;
}
+(NSMutableArray *)getContrlValueWithProperty:(NSString *) property{
    [threadLock lock];
    NSMutableArray *aryValues = [[NSMutableArray alloc] init];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_control_device_content_value"]){
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_control_device_content_value WHERE content_id in (SELECT _id FROM db_control_device_content WHERE property = ?)",property];
        while ([set next]) {
            ControlDeviceContentValue *vaule = [[ControlDeviceContentValue alloc] init];
            vaule.ID = [set stringForColumn:@"_id"];
            vaule.prio = [set stringForColumn:@"prio"];
            vaule.value = [set stringForColumn:@"value"];
            vaule.name = [set stringForColumn:@"name"];
            vaule.keyArr = nil;
            [aryValues addObject:vaule];
        }
    }
    [_db close];
    [threadLock unlock];
    return aryValues;
}

+(BOOL)isQueryValue:(NSString *)value {
    [threadLock lock];
    BOOL hasQueryed = false;
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return false;
    }
    [_db setShouldCacheStatements:true];
    if ([_db tableExists:@"db_control_device_content_value_key"]){
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_control_device_content_value_key WHERE name = 'bwenterqu'"];
        while ([set next]) {
            NSString *strVal = [set stringForColumn:@"value"];
            if ([strVal.lowercaseString myContainsString:value.lowercaseString]) {
                hasQueryed = true;
                break;
            }
        }
    }
    [_db close];
    [threadLock unlock];
    return hasQueryed;
}
#pragma mark -
#pragma mark 数据访问接口 Sence
///type>0为软场景  type=0 为硬场景
+ (NSMutableArray *)getSenceWithRoomName:(NSString *)roomName{
    [threadLock lock];
    NSMutableArray *arySence = [[NSMutableArray alloc] init];
    
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_scene"])
    {
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_scene WHERE room=? and type<2", roomName];
        while ([set next]) {
            Scene *tmpScene = [[Scene alloc] init];
            tmpScene.ID = [set stringForColumn:@"_id"];
            tmpScene.sceneId = [set stringForColumn:@"id"];
            tmpScene.name = [set stringForColumn:@"name"];
            tmpScene.type = [set stringForColumn:@"type"];
            tmpScene.room = [set stringForColumn:@"room"];
            tmpScene.prio = [set stringForColumn:@"prio"];
            tmpScene.status = [set stringForColumn:@"status"];
            tmpScene.isedit= [set stringForColumn:@"isedit"];
            tmpScene.delay = [set stringForColumn:@"delay"];
            tmpScene.scene = [set stringForColumn:@"scene"];
            tmpScene.deviceArr = nil;
            [arySence addObject:tmpScene];
        }
    }
    [_db close];
    [threadLock unlock];
    return arySence;
}
////通过名字获取场景
+(Scene *)getSenceWithSenceName:(NSString *)senceName{
    [threadLock lock];
    Scene *tmpScene = [[Scene alloc] init];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_scene"])
    {
//#warning  WHERE type < 2  Mabey Need;
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_scene WHERE type < 2 and name = ?",senceName];
        while ([set next]) {

            tmpScene.ID = [set stringForColumn:@"_id"];
            tmpScene.sceneId = [set stringForColumn:@"id"];
            tmpScene.name = [set stringForColumn:@"name"];
            tmpScene.type = [set stringForColumn:@"type"];
            tmpScene.room = [set stringForColumn:@"room"];
            tmpScene.prio = [set stringForColumn:@"prio"];
            tmpScene.status = [set stringForColumn:@"status"];
            tmpScene.isedit= [set stringForColumn:@"isedit"];
            tmpScene.delay = [set stringForColumn:@"delay"];
            tmpScene.scene = [set stringForColumn:@"scene"];

            
            FMResultSet *se = [_db executeQuery:@"SELECT * FROM db_scene_device WHERE scene_id=?",tmpScene.ID];
            NSMutableArray *arySceneDevice = [[NSMutableArray alloc]init];
            while ([se next]) {
                SceneDevice *tmpSDevice = [[SceneDevice alloc] init];
                tmpSDevice.name = [se stringForColumn:@"name"];
                tmpSDevice.value = [se stringForColumn:@"value"];
                tmpSDevice.interval = [se stringForColumn:@"interval"];
           //     tmpSDevice.ID = [se stringForColumn:@"ID"];
                tmpSDevice.operation = [se stringForColumn:@"operation"];
                [arySceneDevice addObject:tmpSDevice];
            }
            tmpScene.deviceArr = arySceneDevice;

        }
    }
    [_db close];
    [threadLock unlock];
    return tmpScene;
}
///获取所有软场景
+(NSMutableArray *)getAllSoftSence{
    [threadLock lock];
    NSMutableArray *arySoftSence = [[NSMutableArray alloc] init];
    
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_scene"])
    {
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_scene WHERE type =1"];
        while ([set next]) {
            Scene *tmpScene = [[Scene alloc] init];
            tmpScene.ID = [set stringForColumn:@"_id"];
            tmpScene.sceneId = [set stringForColumn:@"id"];
            tmpScene.name = [set stringForColumn:@"name"];
            tmpScene.type = [set stringForColumn:@"type"];
            tmpScene.room = [set stringForColumn:@"room"];
            tmpScene.prio = [set stringForColumn:@"prio"];
            tmpScene.status = [set stringForColumn:@"status"];
            tmpScene.isedit= [set stringForColumn:@"isedit"];
            tmpScene.delay = [set stringForColumn:@"delay"];
            tmpScene.scene = [set stringForColumn:@"scene"];
        
            FMResultSet *se = [_db executeQuery:@"SELECT * FROM db_scene_device WHERE scene_id=?",tmpScene.ID];
            NSMutableArray *arySceneDevice = [[NSMutableArray alloc]init];
            while ([se next]) {
                SceneDevice *tmpSDevice = [[SceneDevice alloc] init];
                tmpSDevice.name = [se stringForColumn:@"name"];
                tmpSDevice.value = [se stringForColumn:@"value"];
                tmpSDevice.interval = [se stringForColumn:@"interval"];
               // tmpSDevice.ID = [se stringForColumn:@"ID"];
                tmpSDevice.operation = [se stringForColumn:@"operation"];
                [arySceneDevice addObject:tmpSDevice];
            }
            tmpScene.deviceArr = arySceneDevice;
            
            
            [arySoftSence addObject:tmpScene];
        }
    }
    [_db close];
    [threadLock unlock];
    return arySoftSence;
}
///获取所有的软硬场景
+(NSMutableArray *)getAllSoftHardScene{
    [threadLock lock];
    NSMutableArray *arySence = [[NSMutableArray alloc] init];
    
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_scene"])
    {
//#warning  WHERE type < 2  Mabey Need;
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_scene WHERE type < 2"];
        while ([set next]) {
            Scene *tmpScene = [[Scene alloc] init];
            tmpScene.ID = [set stringForColumn:@"_id"];
            tmpScene.sceneId = [set stringForColumn:@"id"];
            tmpScene.name = [set stringForColumn:@"name"];
            tmpScene.type = [set stringForColumn:@"type"];
            tmpScene.room = [set stringForColumn:@"room"];
            tmpScene.prio = [set stringForColumn:@"prio"];
            tmpScene.status = [set stringForColumn:@"status"];
            tmpScene.isedit= [set stringForColumn:@"isedit"];
            tmpScene.delay = [set stringForColumn:@"delay"];
            tmpScene.scene = [set stringForColumn:@"scene"];
            tmpScene.deviceArr = nil;
            [arySence addObject:tmpScene];
        }
    }
    [_db close];
    [threadLock unlock];
    return arySence;
}

///获取其他场景数组
+(NSMutableArray *)getAllOtherScene{
    [threadLock lock];
    NSMutableArray *arySence = [[NSMutableArray alloc] init];
    
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_scene"])
    {
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_scene WHERE type >= 2"];
        while ([set next]) {
            Scene *tmpScene = [[Scene alloc] init];
            tmpScene.ID = [set stringForColumn:@"_id"];
            tmpScene.sceneId = [set stringForColumn:@"id"];
            tmpScene.name = [set stringForColumn:@"name"];
            tmpScene.type = [set stringForColumn:@"type"];
            tmpScene.room = [set stringForColumn:@"room"];
            tmpScene.prio = [set stringForColumn:@"prio"];
            tmpScene.status = [set stringForColumn:@"status"];
            tmpScene.isedit= [set stringForColumn:@"isedit"];
            tmpScene.delay = [set stringForColumn:@"delay"];
            tmpScene.scene = [set stringForColumn:@"scene"];
            tmpScene.deviceArr = nil;
            [arySence addObject:tmpScene];
        }
    }
    [_db close];
    [threadLock unlock];
    return arySence;
}

///根据SceneID获取 该场景的所有"场景设备"信息
+(NSMutableArray *)getSenceDeviceWithSenceID:(NSString *)scenceID{
    [threadLock lock];
    NSMutableArray *arySenceDev = [[NSMutableArray alloc] init];
    
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_scene_device"])
    {
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_scene_device WHERE scene_id = ?", scenceID];
        while ([set next]) {
            SceneDevice *tmpDev = [[SceneDevice alloc] init];
            tmpDev.ID           = [set stringForColumn:@"_id"];
            tmpDev.name         = [set stringForColumn:@"name"];
            tmpDev.operation    = [set stringForColumn:@"operation"];
            tmpDev.value        = [set stringForColumn:@"value"];
            tmpDev.interval     = [set stringForColumn:@"interval"];
            [arySenceDev addObject:tmpDev];
        }
    }
    [_db close];
    [threadLock unlock];
    return arySenceDev;
}
///删除场景
+(BOOL)deleteSceneWithSceneName:(NSString *)name{
    [threadLock lock];
    BOOL result = NO;
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        result = NO;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_scene"]){
        NSString *sceneID = @"";
        FMResultSet *setScene = [_db executeQuery:@"SELECT * FROM db_scene WHERE name=?", name];
        while ([setScene next]) {
            sceneID = [setScene stringForColumn:@"_id"];
        }
        result = [_db executeUpdate:@"DELETE FROM db_scene WHERE name=?", name];
        if (result) {
            //删除该场景下得所有设备
            //删除SceneDeivce
            [_db executeUpdate:@"DELETE FROM db_scene_device WHERE scene_id=?", sceneID];
        }
    }
    [_db close];
    [threadLock unlock];
    return result;
}
///更新OR新增场景
+(BOOL)updateSceneWithName:(Scene *)scene{
    [threadLock lock];
    BOOL result = NO;
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        result = NO;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_scene"]){
        NSString *sceneID = @"";
        FMResultSet *setScene = [_db executeQuery:@"SELECT * FROM db_scene WHERE name=?", scene.name];
        while ([setScene next]) {
            sceneID = [setScene stringForColumn:@"_id"];
        }
        //////////插入Sence
        if ([sceneID isEqualToString:@""]) {//新增
            result = [_db executeUpdate:@"INSERT INTO db_scene(_id,id,name,isedit,status,scene,delay,prio,type,room) VALUES(?,?,?,?,?,?,?,?,?,?)",
                      [self GenerateGUID],@"null",scene.name,scene.isedit,scene.status,scene.scene,scene.delay,scene.prio,scene.type,scene.room];
            //再查询到SceneID
            FMResultSet *setScene = [_db executeQuery:@"SELECT * FROM db_scene WHERE name=?", scene.name];
            while ([setScene next]) {
                sceneID = [setScene stringForColumn:@"_id"];
            }
        }
        else{//编辑
            result = [_db executeUpdate:@"UPDATE db_scene SET id=?,name=?,isedit=?,status=?,scene=?,delay=?,prio=?,type=?,room=? WHERE _id=?", scene.sceneId,scene.name,scene.isedit,scene.status,scene.scene,scene.delay,scene.prio,scene.type,scene.room, sceneID];
        }
        
        ////////插入SenceDevice
        [_db executeUpdate:@"DELETE FROM db_scene_device WHERE scene_id = ?", sceneID];
        for (SceneDevice *sd in scene.deviceArr) {
            result = [_db executeUpdate:@"INSERT INTO db_scene_device(_id ,name, operation, interval, value, scene_id) VALUES(?,?,?,?,?,?)", [self GenerateGUID],sd.name, sd.operation, sd.interval, sd.value, sceneID];
            if (result == NO)break;
        }
        /////////////获取场景个数
        NSInteger num = 0;
        setScene = [_db executeQuery:@"SELECT * FROM db_scene"];
        while ([setScene next]) {
            num ++;
        }
//        NSLog(@"当前场景个数为： %ld", num);
    }
    [_db close];
    [threadLock unlock];
    return result;
}


#pragma mark -
#pragma mark 数据访问接口 IPC
+(NSMutableArray *)getAllIPCInfo{
    [threadLock lock];
    NSMutableArray *aryIPC = [[NSMutableArray alloc] init];
    
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_ipcTable"])
    {
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_ipcTable"];
        while ([set next]) {
            Ipc *ipc = [[Ipc alloc] init];
            ipc.name     = [set stringForColumn:@"name"];
            ipc.android  = [set stringForColumn:@"android"];
            ipc.IOS      = [set stringForColumn:@"IOS"];
            ipc.package  = [set stringForColumn:@"package"];
            ipc.IOSto    = [set stringForColumn:@"IOSto"];
            ipc.IOS2     = [set stringForColumn:@"IOS2"];
            ipc.addState = [set stringForColumn:@"addState"];
            ipc.androidActivity = [set stringForColumn:@"androidActivity"];
            
            [aryIPC addObject:ipc];
        }
    }
    [_db close];
    [threadLock unlock];
    return aryIPC;
}

#pragma Config
+(Config *)getConfigWithName:(NSString *)name{
    [threadLock lock];
    Config *config = [[Config alloc] init];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_config"])
    {
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_config WHERE name = ?", name];
        while ([set next]) {
            config.name = [set stringForColumn:@"name"];
            config.version = [set stringForColumn:@"version"];
        }
    }
    [_db close];
    [threadLock unlock];
    return config;
}
#pragma mark -
#pragma mark 数据访问接口定时设置
#pragma SetTime
+(NSMutableArray *)getAllFixTime{
    [threadLock lock];
    NSMutableArray *fixTimeary = [[NSMutableArray alloc]init];
    if(!_db){
        _db = [DatabaseUtil creatOrFindDB];
    }
    if(![_db open]){
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if([_db tableExists:@"db_crontab"]){
        FMResultSet *set = [_db executeQuery:@"SELECT rowid, * FROM db_crontab"];
        while ([set next]) {
            Crontab * cron = [[Crontab alloc]init];
            cron.crontabId = [set stringForColumn:@"_id"];
            cron.ID = [set stringForColumn:@"id"];
            cron.time = [set stringForColumn:@"time"];
            cron.date = [set stringForColumn:@"date"];
            cron.status = [set stringForColumn:@"status"];
            cron.name = [set stringForColumn:@"name"];
            cron.scene = [set stringForColumn:@"scene"];
            cron.repeat = [set stringForColumn:@"repeat"];
            cron.instructionsArr = nil;
            [fixTimeary addObject:cron];
//            NSLog(@"读取的定时数据:%@,%@,%@,",cron.crontabId,cron.ID,cron.name);
        }
    }
    [_db close];
    [threadLock unlock];
    return fixTimeary;
}
+(NSMutableArray *)getCrontabInstructionbycrontabId:(NSString *)crontabId{
    [threadLock lock];
    NSMutableArray *instrctionary = [[NSMutableArray alloc] init];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_crontab_instructions"])
    {
        //2.ROOM DEVICES
        FMResultSet *set = [_db executeQuery:@"SELECT rowid, * FROM  db_crontab_instructions  where  crontab_id =?",crontabId];
        while ([set next]) {
            CrontabInstruction *tmpInstruction = [[CrontabInstruction alloc] init];
            tmpInstruction.cmd = [set stringForColumn:@"cmd"];
            tmpInstruction.delay = [set stringForColumn:@"delay"];
            [instrctionary addObject:tmpInstruction];
        }
    }
    [_db close];
    [threadLock unlock];
    return instrctionary;
}
+(BOOL)deleteCrontabByCrontabId:(NSString *)crontab_Id{
    [threadLock lock];
    BOOL result = NO;
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        result = NO;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_crontab"]){
        result = [_db executeUpdate:@"DELETE FROM db_crontab WHERE _id=?", crontab_Id];
        if (result) {
            //删除该定时下的指令信息
            [_db executeUpdate:@"DELETE FROM db_crontab_instructions WHERE crontab_id=?", crontab_Id];
        }
    }
    [_db close];
    [threadLock unlock];
    return result;
}
///新增或修改定时
+ (BOOL)addOrEditCrontabwithcrontab:(Crontab *)crontab{
    [threadLock lock];
    BOOL result = NO;
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        result = NO;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_crontab"]){
        NSString *Id = @"";
        FMResultSet *setCrontab = [_db executeQuery:@"SELECT * FROM db_crontab WHERE _id=?", crontab.crontabId];
        while ([setCrontab next]) {
            Id = [setCrontab stringForColumn:@"_id"];
        }
        //crontab
        if ([Id isEqualToString:@""]) {//新增
            result = [_db executeUpdate:@"INSERT INTO db_crontab(_id,id,time, status, name, scene,repeat,date) VALUES(?, ?, ?, ?, ?, ?, ?,?)",/*[self GenerateGUID]这里不知道为毛要用随机的字母来表示，我替换成了id*/crontab.ID,crontab.ID, crontab.time,crontab.status  ,crontab.name,crontab.scene,crontab.repeat,crontab.date];
//            NSLog(@"新增定时数据:%@,%@,%@",crontab.ID,crontab.ID,crontab.name);
            //再查询到crontabId
            FMResultSet *setCrontab = [_db executeQuery:@"SELECT * FROM db_crontab WHERE id=?", crontab.ID];
            while ([setCrontab next]) {
                Id = [setCrontab stringForColumn:@"_id"];
            }
        }
        else{//编辑
            result = [_db executeUpdate:@"UPDATE db_crontab SET time=?, status=?, scene=?, name=? , repeat=? , date=?,id=? WHERE _id=?", crontab.time,crontab.status,crontab.scene,crontab.name,crontab.repeat,crontab.date,crontab.crontabId,Id];
//            NSLog(@"编辑定时：%@,%@,%@",crontab.crontabId,Id,crontab.name);
        }
        //crontabInstructin
        [_db executeUpdate:@"DELETE FROM db_crontab_instructions WHERE crontab_id = ?", Id];
        for (CrontabInstruction *ci in crontab.instructionsArr) {
            result = [_db executeUpdate:@"INSERT INTO db_crontab_instructions(_id,cmd, delay,crontab_id) VALUES(?,?,?,?)", [self GenerateGUID],ci.cmd, ci.delay,Id];
            if (result == NO)break;
        }
    }
    [_db close];
    [threadLock unlock];
    return result;
}
///更新所有定时信息－－－定时开关处
+ (BOOL)EditAllCrontab:(NSMutableArray *)arycrontab{
    [threadLock lock];
    BOOL result = NO;
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        result = NO;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_crontab"]){
        for(int i = 0;i<arycrontab.count;i++){
            Crontab *tmpCrontab = (Crontab *)arycrontab[i];
            if([_db executeUpdate:@"UPDATE db_crontab SET time=?, status=?, scene=?, name=? , repeat=? , date=?,id=? WHERE _id=?", tmpCrontab.time,tmpCrontab.status,tmpCrontab.scene,tmpCrontab.name,tmpCrontab.repeat,tmpCrontab.date,tmpCrontab.ID,tmpCrontab.crontabId]){
            ///在更新crontabInstructin
            [_db executeUpdate:@"DELETE FROM db_crontab_instructions WHERE crontab_id = ?", tmpCrontab.crontabId];
            for (CrontabInstruction *ci in tmpCrontab.instructionsArr) {
            result = [_db executeUpdate:@"INSERT INTO db_crontab_instructions(_id,cmd, delay,crontab_id) VALUES(?,?,?,?)",[self GenerateGUID],ci.cmd, ci.delay,tmpCrontab.crontabId];
                }
            }

        }
    }
    [_db close];
    [threadLock unlock];
    return result;
}

#pragma mark 数据访问接口 安防
///查询到防区
+(NSMutableArray *)GetAllZone{
    [threadLock lock];
    NSMutableArray *aryZone = [[NSMutableArray alloc]init];
    if(!_db){
        _db = [DatabaseUtil creatOrFindDB];
    }
    if(![_db open]){
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if([_db tableExists:@"db_security_zone_content"]){
        FMResultSet *set = [_db executeQuery:@"SELECT rowid, * FROM db_security_zone_content"];
        while ([set next]) {
            SecurityContent_zone * zone = [[SecurityContent_zone alloc]init];
            zone.name = [set stringForColumn:@"name"];
            zone.type = [set stringForColumn:@"type"];
            zone.state = [set stringForColumn:@"state"];
            zone.delay = [set stringForColumn:@"delay"];
            zone.handled = [set stringForColumn:@"handled"];
            zone.ID = [set stringForColumn:@"_id"];
            [aryZone addObject:zone];
        }
    }
    [_db close];
    [threadLock unlock];
    return aryZone;
}
///获取防区内传感器
+(NSMutableArray *)getSensorFormZonewithcontentId:(NSString *)contentId{
    [threadLock lock];
    NSMutableArray *arycontent = [[NSMutableArray alloc] init];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_security_zone_content_sensor"])
    {
        //2.content
        FMResultSet *set = [_db executeQuery:@"SELECT rowid, * FROM  db_security_zone_content_sensor  where  content_id =?",contentId];
        while ([set next]) {
            SecurityContent_zone_sensor *tmpcontent = [[SecurityContent_zone_sensor alloc] init];
            tmpcontent.name = [set stringForColumn:@"name"];
            tmpcontent.mac = [set stringForColumn:@"mac"];
            tmpcontent.type = [set stringForColumn:@"type"];
            tmpcontent.state = [set stringForColumn:@"state"];
            tmpcontent.contentId = [set stringForColumn:@"content_id"];
            
            [arycontent addObject:tmpcontent];
        }
    }
    [_db close];
    [threadLock unlock];
    return arycontent;
}
///查询到传感器
+(NSMutableArray *)GetAllsensor{
    [threadLock lock];
    NSMutableArray *arySensor = [[NSMutableArray alloc]init];
    if(!_db){
        _db = [DatabaseUtil creatOrFindDB];
    }
    if(![_db open]){
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if([_db tableExists:@"db_security_sensor_content"]){
        FMResultSet *set = [_db executeQuery:@"SELECT rowid, * FROM db_security_sensor_content"];
        while ([set next]) {
            SecurityContent_sensor * sensor = [[SecurityContent_sensor alloc]init];
            sensor.sensorName = [set stringForColumn:@"sensorName"];
            sensor.sensorMac = [set stringForColumn:@"sensorMac"];
            sensor.sensorType = [set stringForColumn:@"sensorType"];
            sensor.sensorSignal = [set stringForColumn:@"sensorSignal"];
            sensor.sensor24h = [set stringForColumn:@"sensor24h"];
            sensor.minValue = [set stringForColumn:@"minValue"];
            sensor.maxValue = [set stringForColumn:@"maxValue"];
            sensor.ctrlValue = [set stringForColumn:@"ctrlValue"];
            sensor.alarmName =  [set stringForColumn:@"alarmName"];
            sensor.alarmMac = [set stringForColumn:@"alarmMac"];
            sensor.alarmType = [set stringForColumn:@"alarmType"];
            sensor.alarmTime = [set stringForColumn:@"alarmTime"];
            sensor.isElectromic = [set stringForColumn:@"isElectromic"];
            sensor.isAlarm = [set stringForColumn:@"isAlarm"];
            sensor.alarmMsg = [set stringForColumn:@"alarmMsg"];
            sensor.powerMsg = [set stringForColumn:@"powerMsg"];
            sensor.sensorOldName = [set stringForColumn:@"sensorOldName"];
            sensor.alarmOldName = [set stringForColumn:@"alarmOldName"];
            [arySensor addObject:sensor];
        }
    }
    [_db close];
    [threadLock unlock];
    return arySensor;
}
+(BOOL)updateZonewith:(SecurityContent_zone *)zone{
    [threadLock lock];
    BOOL result = NO;
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        result = NO;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_security_zone_content"]){
        NSString *contentId = @"";
        FMResultSet *setZone = [_db executeQuery:@"SELECT * FROM db_security_zone_content WHERE _id=?",zone.ID];
        while ([setZone next]) {
            contentId = [setZone stringForColumn:@"_id"];
        }
//        NSLog(@"contentID的值：%@",contentId);
        NSString *securityId=@"";
        FMResultSet *setSecurity = [_db executeQuery:@"SELECT rowid, * FROM db_security where type ='zone'"];
        while ([setSecurity next]) {
            securityId = [setSecurity stringForColumn:@"_id"];
        }
        if (![contentId isEqualToString:@""]) {
            if([zone.state isEqualToString:@"1"]){
                //先关闭所有的防区----布防
                result = [_db executeUpdate:@"UPDATE db_security_zone_content SET state=?",@"0"];
                ///再通过防区的配置信息 开启/关闭 防区下的所有sensor
                FMResultSet *setSensor = [_db executeQuery:@"SELECT * FROM db_security_zone_content_sensor WHERE content_id=?",contentId];
                while ([setSensor next]) {
                    NSString * sensorMac = [setSensor stringForColumn:@"mac"];
                    NSString * state     = [setSensor stringForColumn:@"state"];
                    if ([state isEqualToString:@"1"]){
                        result = [_db executeUpdate:@"UPDATE db_security_sensor_content SET isAlarm=? WHERE sensorMac=?", state, sensorMac];
                    }
                    else{
                        ////只非24H才能撤防
                        result = [_db executeUpdate:@"UPDATE db_security_sensor_content SET isAlarm=? WHERE sensorMac=? and sensor24h=0", state, sensorMac];
                    }
                }
            }
            else{
                ///再通过mac地址关闭所有sensor----撤防
                FMResultSet *setSensor = [_db executeQuery:@"SELECT * FROM db_security_zone_content_sensor WHERE content_id=?",contentId];
                while ([setSensor next]) {
                    NSString * sensorMac = [setSensor stringForColumn:@"mac"];
                    
                    ////24小时不能撤防
                    FMResultSet *set24device = [_db executeQuery:@"SELECT * FROM db_security_sensor_content  WHERE sensorMac=?",sensorMac];
                    while ([set24device next]) {
                        if([[set24device stringForColumn:@"sensor24h"] isEqualToString:@"0"]){
                            result = [_db executeUpdate:@"UPDATE db_security_sensor_content SET isAlarm=? WHERE sensorMac=?",@"0",sensorMac];
//                            result = [_db executeUpdate:@"UPDATE db_security_zone_content_sensor SET state=? WHERE mac=?",@"0",sensorMac];
                        }
                    }
                    
                }
            }
            result = [_db executeUpdate:@"UPDATE db_security_zone_content SET delay=?,state=?WHERE _id=?",zone.delay,zone.state,contentId];
        }
        //防区内传感器

        [_db executeUpdate:@"DELETE FROM db_security_zone_content_sensor WHERE content_id = ?", contentId];
        for (SecurityContent_zone_sensor *zs in zone.sensorArr) {
            result = [_db executeUpdate:@"INSERT INTO db_security_zone_content_sensor(_id,name, mac,type,state,content_id,security_id) VALUES(?,?,?,?,?,?,?)",[self GenerateGUID],zs.name,zs.mac,zs.type,zs.state,contentId,securityId];
            if (result == NO)break;
        }
    }
    [_db close];
    [threadLock unlock];
    return result;
}
//在防区设置界面更新防区设置或者添加防区
+ (BOOL)updateZoneSet:(SecurityContent_zone *)zone {
    [threadLock lock];
    BOOL result = NO;
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        result = NO;
    }
    [_db setShouldCacheStatements:YES];
    //打开数据库
    if ([_db tableExists:@"db_security_zone_content"]){
        NSString *contentId = @"";
        FMResultSet *setZone = [_db executeQuery:@"SELECT * FROM db_security_zone_content WHERE _id=?",zone.ID];
        while ([setZone next]) {
            contentId = [setZone stringForColumn:@"_id"];
        }
        
        NSString *securityId=@"";
        FMResultSet *setSecurity = [_db executeQuery:@"SELECT rowid, * FROM db_security where type ='zone'"];
        while ([setSecurity next]) {
            securityId = [setSecurity stringForColumn:@"_id"];
        }
        //新增防区
        if([contentId isEqualToString:@""]){//新增
            NSString *Id=[self GenerateGUID];
            result = [_db executeUpdate:@"INSERT INTO db_security_zone_content(_id,name,type, state, delay, handled,security_id) VALUES(?,?, ?, ?, ?, ?, ?)",Id,zone.name, zone.type,zone.state,zone.delay,zone.handled,securityId];
            //再查询到contentId
            FMResultSet *setZone = [_db executeQuery:@"SELECT * FROM db_security_zone_content WHERE _id=?",Id];
            while ([setZone next]) {
                contentId = [setZone stringForColumn:@"_id"];
            }
        }
        //编辑防区
        else {
            [_db executeUpdate:@"UPDATE db_security_zone_content SET delay=?WHERE _id=?",zone.delay,contentId];
        }
        //防区内传感器
        [_db executeUpdate:@"DELETE FROM db_security_zone_content_sensor WHERE content_id = ?", contentId];
        for (SecurityContent_zone_sensor *zs in zone.sensorArr) {
            result = [_db executeUpdate:@"INSERT INTO db_security_zone_content_sensor(_id,name, mac,type,state,content_id,security_id) VALUES(?,?,?,?,?,?,?)",[self GenerateGUID],zs.name,zs.mac,zs.type,zs.state,contentId,securityId];
            if (result == NO)break;
        }
    }
    [_db close];
    [threadLock unlock];
    return result;
}
//+(BOOL)addZonewith:(SecurityContent_zone *)zone{
//    BOOL result = NO;
//    if (!_db) {
//        _db = [DatabaseUtil creatOrFindDB];
//    }
//    if (![_db open]) {
//        [_db close];
//        NSLog(@"打开数据库失败");
//        result = NO;
//    }
//    [_db setShouldCacheStatements:YES];
//    if ([_db tableExists:@"db_security_zone_content"]){
//        NSString *contentId = @"";
//        FMResultSet *setZone = [_db executeQuery:@"SELECT * FROM db_security_zone_content WHERE _id=?",zone.ID];
//        while ([setZone next]) {
//            contentId = [setZone stringForColumn:@"_id"];
//        }
//        
//        NSString *securityId=@"";
//        
//        FMResultSet *setSecurity = [_db executeQuery:@"SELECT rowid, * FROM db_security where type ='zone'"];
//        while ([setSecurity next]) {
//            securityId = [setSecurity stringForColumn:@"_id"];
//        }
//        
//        if([contentId isEqualToString:@""]){//新增
//            NSString *Id=[self GenerateGUID];
//            result = [_db executeUpdate:@"INSERT INTO db_security_zone_content(_id,name,type, state, delay, handled,security_id) VALUES(?,?, ?, ?, ?, ?, ?)",Id,zone.name, zone.type,zone.state,zone.delay,zone.handled,@"2"];
//            //再查询到contentId
//            FMResultSet *setZone = [_db executeQuery:@"SELECT * FROM db_security_zone_content WHERE _id=?",Id];
//            while ([setZone next]) {
//                contentId = [setZone stringForColumn:@"_id"];
//            }
//        }
//        else
//        {//编辑
//            if([zone.state isEqualToString:@"1"]){//把所有关了先
//                result = [_db executeUpdate:@"UPDATE db_security_zone_content SET state=?",@"0"];
//            }
//            result = [_db executeUpdate:@"UPDATE db_security_zone_content SET delay=?,state=?WHERE _id=?",zone.delay,zone.state,contentId];
//        }
//
//        [_db executeUpdate:@"DELETE FROM db_security_zone_content_sensor WHERE content_id = ?", contentId];
//        for (SecurityContent_zone_sensor *zs in zone.sensorArr) {
//            result = [_db executeUpdate:@"INSERT INTO db_security_zone_content_sensor(_id,name, mac,type,state,content_id,security_id) VALUES(?,?,?,?,?,?,?)",[self GenerateGUID],zs.name,zs.mac,zs.type,zs.state,contentId,securityId];
//            if (result == NO)break;
//        }
//    }
//    [_db close];
//    return result;
//}
///更新
+(BOOL)updateSensor:(SecurityContent_sensor *)sensor{
    [threadLock lock];
    BOOL result = NO;
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        result = NO;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_security_sensor_content"]){
        NSString *sensorId = @"";
        FMResultSet *setSensor = [_db executeQuery:@"SELECT * FROM db_security_sensor_content WHERE sensorName=?",sensor.sensorName];
        while ([setSensor next]) {
            sensorId = [setSensor stringForColumn:@"_id"];
        }
        {//编辑
            result = [_db executeUpdate:@"UPDATE db_security_sensor_content SET sensor24h=?,sensorSignal=?,isAlarm=?WHERE _id=?",sensor.sensor24h,sensor.sensorSignal,sensor.isAlarm,sensorId];
        }
    }
    [_db close];
    [threadLock unlock];
    return result;
}
///删除防区
+(BOOL)deleteZoneByzoneId:(NSString *)zoneId{
    [threadLock lock];
    BOOL result = NO;
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        result = NO;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_security_zone_content"]){
        result = [_db executeUpdate:@"DELETE FROM db_security_zone_content WHERE _id=?", zoneId];
        if (result) {
            //删除该防区下传感器
            [_db executeUpdate:@"DELETE FROM db_security_zone_content_sensor WHERE content_id=?", zoneId];
        }
    }
    [_db close];
    [threadLock unlock];
    return result;
}
///查询报警信息
+(NSMutableArray *)GetAllSecurityNote{
    [threadLock lock];
    NSMutableArray *arySNote= [[NSMutableArray alloc]init];
    if(!_db){
        _db = [DatabaseUtil creatOrFindDB];
    }
    if(![_db open]){
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if([_db tableExists:@"db_securitynote"]){
        FMResultSet *set = [_db executeQuery:@"SELECT  rowid, * FROM db_securitynote order by alarmTime desc limit 0,500"];
        while ([set next]) {
            SecurityNote * snote = [[SecurityNote alloc]init];
            snote.alarmTime = [set stringForColumn:@"alarmTime"];
            snote.alarmType = [set stringForColumn:@"alarmType"];
            snote.devMac = [set stringForColumn:@"devMac"];
            [arySNote addObject:snote];
        }
    }
    [_db close];
    [threadLock unlock];
    return arySNote;
}
///查询传感器报警
+(NSString *)getSecurityNoteType:(NSString *)mac{
    [threadLock lock];
    if(!_db){
        _db = [DatabaseUtil creatOrFindDB];
    }
    if(![_db open]){
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    NSString *secName= @"";
    [_db setShouldCacheStatements:YES];
    if([_db tableExists:@"db_security_sensor_content"]){
        FMResultSet *set = [_db executeQuery:@"SELECT  rowid, * FROM db_security_sensor_content where sensorMac=?",mac];
        while ([set next]) {
            secName = [set stringForColumn:@"alarmMsg"];
        }
    }
    [_db close];
    [threadLock unlock];
    return secName;
}
+(NSString *)getDeviceNameById:(NSString *)devId{
    [threadLock lock];
    if(!_db){
        _db = [DatabaseUtil creatOrFindDB];
    }
    if(![_db open]){
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    NSString *devName= @"";
    [_db setShouldCacheStatements:YES];
    if([_db tableExists:@"db_security_sensor_content"]){
        FMResultSet *set = [_db executeQuery:@"SELECT  rowid, * FROM db_security_sensor_content where sensorMac=?",devId];
        while ([set next]) {
            devName = [set stringForColumn:@"sensorName"];
        }
    }
    [_db close];
    [threadLock unlock];
    return devName;
}

+(NSString *)getNewNoteDate{
    [threadLock lock];
    NSString *strNewDate;
    if(!_db){
        _db = [DatabaseUtil creatOrFindDB];
    }
    if(![_db open]){
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if([_db tableExists:@"db_securitynote"]){
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM 'db_securitynote' ORDER BY alarmTime DESC limit 0,1"];
        while ([set next]) {
            strNewDate = [set stringForColumn:@"alarmTime"];
        }
    }
    [_db close];
    [threadLock unlock];
    return strNewDate;
}
+(NSMutableArray *)getNewSecurtyNote:(NSString *)lastDate{
    [threadLock lock];
    NSMutableArray *result = [NSMutableArray array];
    if(!_db){
        _db = [DatabaseUtil creatOrFindDB];
    }
    if(![_db open]){
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return 0;
    }
    [_db setShouldCacheStatements:YES];
    if([_db tableExists:@"db_securitynote"]){
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM 'db_securitynote'   WHERE  alarmTime >?  ORDER BY alarmTime Desc", lastDate];
        
        while ([set next]) {

            SecurityNote *snote = [[SecurityNote alloc]init];
            snote.ID        = [set stringForColumn:@"_id"];
            snote.alarmTime = [set stringForColumn:@"alarmTime"];
            snote.alarmType = [set stringForColumn:@"alarmType"];
            snote.devMac    = [set stringForColumn:@"devMac"];
            [result addObject:snote];
        }
    }
    [_db close];
    [threadLock unlock];
    return result;
}
+(NSMutableArray *)getAlarmNameWithZoneID:(NSString *)strZoneID{
    [threadLock lock];
    NSMutableArray *aryAlarmName = [NSMutableArray array];
    if(!_db){
        _db = [DatabaseUtil creatOrFindDB];
    }
    if(![_db open]){
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return 0;
    }
    [_db setShouldCacheStatements:YES];
    if([_db tableExists:@"db_security_sensor_content"]){
        NSString *alarmName = @"";
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_security_sensor_content WHERE sensorMAC in ( SELECT mac FROM db_security_zone_content_sensor  WHERE content_id =? )", strZoneID];
        while ([set next]) {
            alarmName = [set stringForColumn:@"alarmName"];
            [aryAlarmName addObject:alarmName];
        }
    }
    [_db close];
    [threadLock unlock];
    return aryAlarmName;
}
+(NSMutableArray *)getAlarmNameWithSensorMAC:(NSString *)strSensorMAC{
    [threadLock lock];
    NSMutableArray *aryAlarmName = [NSMutableArray array];
    if(!_db){
        _db = [DatabaseUtil creatOrFindDB];
    }
    if(![_db open]){
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return 0;
    }
    [_db setShouldCacheStatements:YES];
    if([_db tableExists:@"db_security_sensor_content"]){

        NSString *alarmName = @"";
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_security_sensor_content WHERE sensorMAC = ?", strSensorMAC];
        while ([set next]) {
            alarmName = [set stringForColumn:@"alarmName"];
            [aryAlarmName addObject:alarmName];
        }
    }
    [_db close];
    [threadLock unlock];
    return aryAlarmName;
}
+(NSMutableArray *)getAlarmNameWithNot24H{
    [threadLock lock];
    NSMutableArray *aryAlarmName = [NSMutableArray array];
    if(!_db){
        _db = [DatabaseUtil creatOrFindDB];
    }
    if(![_db open]){
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return 0;
    }
    [_db setShouldCacheStatements:YES];
    if([_db tableExists:@"db_security_sensor_content"]){
        
        NSString *alarmName = @"";
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_security_sensor_content WHERE  sensor24h=0"];
        while ([set next]) {
            alarmName = [set stringForColumn:@"alarmName"];
            [aryAlarmName addObject:alarmName];
        }
    }
    [_db close];
    [threadLock unlock];
    return aryAlarmName;
}
+(void)cancelSecrityNot24H{
    [threadLock lock];
    if(!_db){
        _db = [DatabaseUtil creatOrFindDB];
    }
    if(![_db open]){
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    [_db setShouldCacheStatements:YES];
    if([_db tableExists:@"db_security_sensor_content"]){
        [_db executeUpdate:@"UPDATE  db_security_sensor_content  SET isAlarm = 0 WHERE sensor24h=0"];
        [_db executeUpdate:@"UPDATE  db_security_zone_content  SET state = 0"];
    }
    [_db close];
    [threadLock unlock];
}
+(NSString *)getSensorOrAlarmPriowithName:(NSString *)name{
    [threadLock lock];
    NSString *prio = @"";
    if(!_db){
        _db = [DatabaseUtil creatOrFindDB];
    }
    if(![_db open]){
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if([_db tableExists:@"db_control_device_content_value"]){
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_control_device_content_value WHERE name=?", name];
        while ([set next]) {
            prio = [set stringForColumn:@"prio"];
        }
    }
    [_db close];
    [threadLock unlock];
    return prio;
}
+ (NSMutableArray *)getAllAlarm {
    [threadLock lock];
    NSMutableArray *array = [NSMutableArray new];
    if(!_db){
        _db = [DatabaseUtil creatOrFindDB];
    }
    if(![_db open]){
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if([_db tableExists:@"db_control_device"]){
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_control_device WHERE category=?",@"报警设备"];
        while ([set next]) {
            NSString *ID = [set stringForColumn:@"_id"];
            FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_control_device_content_value WHERE device_id=?",ID];
            while ([set next]) {
                NSString *name = [set stringForColumn:@"name"];
                [array addObject:name];
            }
        }
    }
    [_db close];
    [threadLock unlock];
    return array;
}
+ (SecurityContent_sensor *)getsensorFromName:(NSString *)name {
    [threadLock lock];
    SecurityContent_sensor *sensor = [SecurityContent_sensor new];
    if(!_db){
        _db = [DatabaseUtil creatOrFindDB];
    }
    if(![_db open]){
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if([_db tableExists:@"db_security_sensor_content"]){
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_security_sensor_content WHERE sensorName=?",name];
        while ([set next]) {
            sensor.sensorName = [set stringForColumn:@"sensorName"];
            sensor.sensorMac = [set stringForColumn:@"sensorMac"];
            sensor.sensorType = [set stringForColumn:@"sensorType"];
            sensor.sensorSignal = [set stringForColumn:@"sensorSignal"];
            sensor.sensor24h = [set stringForColumn:@"sensor24h"];
            sensor.minValue = [set stringForColumn:@"minValue"];
            sensor.maxValue = [set stringForColumn:@"maxValue"];
            sensor.ctrlValue = [set stringForColumn:@"ctrlValue"];
            sensor.alarmName =  [set stringForColumn:@"alarmName"];
            sensor.alarmMac = [set stringForColumn:@"alarmMac"];
            sensor.alarmType = [set stringForColumn:@"alarmType"];
            sensor.alarmTime = [set stringForColumn:@"alarmTime"];
            sensor.isElectromic = [set stringForColumn:@"isElectromic"];
            sensor.isAlarm = [set stringForColumn:@"isAlarm"];
            sensor.alarmMsg = [set stringForColumn:@"alarmMsg"];
            sensor.powerMsg = [set stringForColumn:@"powerMsg"];
            sensor.sensorOldName = [set stringForColumn:@"sensorOldName"];
            sensor.alarmOldName = [set stringForColumn:@"alarmOldName"];
        }
    }
    [_db close];
    [threadLock unlock];
    return sensor;
}
#pragma mark 数据访问接口 房型
////////////////////////房型数据库
/////获取所有房间url
+(NSMutableArray *)getALLHouseUrl{
    [threadLock lock];
    NSMutableArray *aryhouse = [[NSMutableArray alloc]init];
    if(!_db){
        _db = [DatabaseUtil creatOrFindDB];
    }
//    if(![_db open]){
//        [_db close];
//        NSLog(@"打开数据库失败");
//        return nil;
//    }
    if([_db open]){
        [_db setShouldCacheStatements:YES];
        if([_db tableExists:@"db_house"]){
            FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_house"];
            while ([set next]) {
                House *tmphouse = [[House alloc]init];
                tmphouse.houseName = [set stringForColumn:@"houseName"];
                tmphouse.houseImgUrl = [set stringForColumn:@"houseImgUrl"];
                [aryhouse addObject:tmphouse];
            }
        }
    }
    [_db close];
    [threadLock unlock];
    return aryhouse;
}


/////新增房间
+(void)insertHouse:(House *)house{
    [threadLock lock];
    if(!_db){
        _db = [DatabaseUtil creatOrFindDB];
    }
    if([_db open]){
        [_db setShouldCacheStatements:YES];
        if (![_db tableExists:@"db_house"]){
            [_db executeUpdate:@"CREATE TABLE db_house (_id text PRIMARY KEY,houseName text,houseImgUrl text)"];
            NSLog(@"ReCreate db_house");
        }
            [_db executeUpdate:@"INSERT INTO db_house(houseName,houseImgUrl) VALUES(?,?)",house.houseName,house.houseImgUrl];
        }
    [_db close];
    [threadLock unlock];
}
////删除房间通过名字
+(void)deleteHouse:(NSString *)housename{
    [threadLock lock];
    if(!_db){
        _db = [DatabaseUtil creatOrFindDB];
    }
    if([_db open]){
        [_db setShouldCacheStatements:YES];
        if ([_db tableExists:@"db_house"]){
        [_db executeUpdate:@"DELETE FROM db_house WHERE houseName=?",housename];
        }
    }
    [_db close];
    [threadLock unlock];
}
////获得房间通过名字
+(House *)getHouseByHouseName:(NSString *)housename{
    [threadLock lock];
    if(!_db){
        _db = [DatabaseUtil creatOrFindDB];
    }
    if([_db open]){
        [_db setShouldCacheStatements:YES];
        if ([_db tableExists:@"db_house"]){
            FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_house WHERE houseName=?",housename];
            while ([set next]) {
                House *tmphouse = [[House alloc]init];
                tmphouse.houseName = [set stringForColumn:@"houseName"];
                tmphouse.houseImgUrl = [set stringForColumn:@"houseImgUrl"];
                [_db close];
                [threadLock unlock];
                return tmphouse;
            }
        }
    }
    [_db close];
    [threadLock unlock];
    return nil;
}

//////获得某房间内所有设备位置
+(NSMutableArray *)getAllDevicelocationByhouseName:(NSString *)houseName{
    [threadLock lock];
    NSMutableArray *aryDeviceLocation = [[NSMutableArray alloc]init];
    if(!_db){
        _db = [DatabaseUtil creatOrFindDB];
    }
    if([_db open]){
        [_db setShouldCacheStatements:YES];
        if ([_db tableExists:@"db_houseDevice"]){
            FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_houseDevice WHERE houseName=?",houseName];
            while ([set next]) {
                HouseDevice *tmphouseDevice = [[HouseDevice alloc]init];
                tmphouseDevice.houseName = [set stringForColumn:@"houseName"];
                tmphouseDevice.deviceName = [set stringForColumn:@"deviceName"];
                tmphouseDevice.pointX = [set stringForColumn:@"pointX"];
                tmphouseDevice.pointY = [set stringForColumn:@"pointY"];
                [aryDeviceLocation addObject:tmphouseDevice];
            }
        }
        
    }
    [_db close];
    [threadLock unlock];
    return aryDeviceLocation;
}

/////新增单条数据
+(void)insertHouseInfo:(HouseDevice *)houseDevice{
    [threadLock lock];
    if(!_db){
        _db = [DatabaseUtil creatOrFindDB];
    }
//    if(![_db open]){
//        [_db close];
//        NSLog(@"打开数据库失败");
//        return;
//    }
    if([_db open]){
        [_db setShouldCacheStatements:YES];
        if (![_db tableExists:@"db_houseDevice"]){
            
            [_db executeUpdate:@"drop table db_houseDevice"];
            [_db executeUpdate:@"CREATE TABLE db_houseDevice (_id text PRIMARY KEY,houseName text,deviceName text,pointX text,pointY text)"];
            NSLog(@"ReCreate db_houseDevice");
        }
        ///////先删除这个name
        if([_db executeUpdate:@"DELETE FROM db_houseDevice WHERE deviceName=?", houseDevice.deviceName]){
            [_db executeUpdate:@"INSERT INTO db_houseDevice(_id,houseName,deviceName,pointX,pointY) VALUES(?,?,?,?,?)",[self GenerateGUID],houseDevice.houseName,houseDevice.deviceName,houseDevice.pointX,houseDevice.pointY];
        }
    }
    [threadLock unlock];
    [_db close];
}


////通过设备名字去删除相关信息
+(BOOL)deleteHouseInfoByDeviceName:(NSString *)deviceName{
    [threadLock lock];
    if(!_db){
        _db = [DatabaseUtil creatOrFindDB];
    }
    if(![_db open]){
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return NO;
    }
    [_db setShouldCacheStatements:YES];
    if([_db tableExists:@"db_houseDevice"]){
        [_db executeUpdate:@"DELETE FROM db_houseDevice WHERE deviceName=?", deviceName];
        [_db close];
        [threadLock unlock];
        return YES;
    }
    else{
        [_db close];
        [threadLock unlock];
        return NO;
    }
}
+(BOOL)deleteHouseInfoByHouseName:(NSString *)houseName{
    [threadLock lock];
    if(!_db){
        _db = [DatabaseUtil creatOrFindDB];
    }
    if([_db open]){
        [_db setShouldCacheStatements:YES];
        if([_db tableExists:@"db_houseDevice"]){
            [_db executeUpdate:@"DELETE FROM db_houseDevice WHERE houseName=?", houseName];
            [_db close];
            [threadLock unlock];
            return YES;
        }
        else{
            [_db close];
            [threadLock unlock];
            return NO;
        }
    }
    else{
        [_db close];
        [threadLock unlock];
        return NO;
    }
}
#pragma mark -数据处理，门锁

+ (NSMutableArray *)getAllDoorlockName {
    [threadLock lock];
    NSMutableArray *array = [NSMutableArray new];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_control_device_content"])
    {
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_control_device_content WHERE property = '智能门锁'"];
        while ([set next]) {
            NSString *ID = [set stringForColumn:@"_id"];
            if ([_db tableExists:@"db_control_device_content_value"])
            {
                FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_control_device_content_value WHERE content_id = ? ",ID];
                while ([set next]) {
                    NSString *name = [set stringForColumn:@"name"];
                    [array addObject:name];
                }
            }
        }
    }
    [_db close];
    [threadLock unlock];
    return array;
}
+ (void)insertToDoorlock:(Door *)door {
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    
    [_db setShouldCacheStatements:YES];
    
    if ([_db tableExists:@"db_doorlock"])
    {
        for (Doorlock *doorlock in door.doorlockArr) {
            [_db executeUpdate:@"INSERT INTO db_doorlock(number,enter_scene,leave_scene,enter_security_zone,leave_security_zone) VALUES(?,?,?,?,?)",doorlock.deviceNumber,doorlock.enterScene,doorlock.leaveScene,doorlock.enterSecutityZone,doorlock.leaveSecutityZone];
            NSLog(@"door插入成功%@,%@,%@,%@,%@",doorlock.deviceNumber,doorlock.enterScene,doorlock.leaveScene,doorlock.enterSecutityZone,doorlock.leaveSecutityZone);
        }
    }
    if ([_db tableExists:@"db_doorlock_user"]) {
        
        for (DoorlockUser *doorlockUser in door.doorlockUserArr) {
            [_db executeUpdate:@"INSERT INTO db_doorlock_user(user_id, user_name, member_role) VALUES(?,?,?)",doorlockUser.userID,doorlockUser.userLandingName,doorlockUser.userAnotherName];
            NSLog(@"user插入成功%@,%@,%@",doorlockUser.userID,doorlockUser.userLandingName,doorlockUser.userAnotherName);
        }
    }
//    NSLog(@"doorlock插入完毕");
    [_db close];
    [threadLock unlock];
}
//插入门锁警告
+ (void)insertToDoorlockNote:(DoorlockNote *)note {
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    
    [_db setShouldCacheStatements:YES];
    
    if ([_db tableExists:@"db_doorlock_alarm"]) {
        [_db executeUpdate:@"INSERT INTO db_doorlock_alarm(alarmTime,devID,userNumber,partNum,powerMsg,alarmMsg) VALUES(?,?,?,?,?,?)",note.alarmTime,note.devID,note.operateNum,note.partNum,note.powerMsg,note.alarmMsg];
    }
//    NSLog(@"db_doorlock_alarm插入完毕");
    [_db close];
    [threadLock unlock];
}
//获取所有门锁
+ (NSMutableArray *)getAllDoorlockSet {
    [threadLock lock];
    NSMutableArray *array = [[NSMutableArray alloc]init];
    if(!_db){
        _db = [DatabaseUtil creatOrFindDB];
    }
    if(![_db open]){
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if([_db tableExists:@"db_doorlock"]){
        FMResultSet *set = [_db executeQuery:@"SELECT rowid, * FROM db_doorlock"];
        while ([set next]) {
            Doorlock * door = [[Doorlock alloc]init];
            door.deviceNumber = [set stringForColumn:@"number"];
            door.enterScene = [set stringForColumn:@"enter_scene"];
            door.leaveScene = [set stringForColumn:@"leave_scene"];
            door.enterSecutityZone = [set stringForColumn:@"enter_security_zone"];
            door.leaveSecutityZone = [set stringForColumn:@"leave_security_zone"];
            [array addObject:door];
            NSLog(@"门的设置信息%@,%@,%@,%@,%@",door.deviceNumber,door.enterScene,door.leaveScene,door.enterSecutityZone,door.leaveSecutityZone);
        }
    }
    [_db close];
    [threadLock unlock];
    return array;
}
+ (NSMutableArray *)getNewDoorlockNote:(NSString *)lastDate {
    [threadLock lock];
    NSMutableArray *array = [[NSMutableArray alloc]init];
    if(!_db){
        _db = [DatabaseUtil creatOrFindDB];
    }
    if(![_db open]){
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if([_db tableExists:@"db_doorlock_alarm"]){
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM 'db_doorlock_alarm'   WHERE  alarmTime >?  ORDER BY alarmTime Desc", lastDate];
        while ([set next]) {
            DoorlockNote * note = [[DoorlockNote alloc]init];
            note.alarmTime = [set stringForColumn:@"alarmTime"];
            note.devID = [set stringForColumn:@"devID"];
            note.operateNum = [set stringForColumn:@"userNumber"];
            note.partNum = [set stringForColumn:@"partNum"];
            note.powerMsg = [set stringForColumn:@"powerMsg"];
            note.alarmMsg = [set stringForColumn:@"alarmMsg"];
            [array addObject:note];
//            NSLog(@"新的报警信息%@,%@,%@,%@,%@,%@",note.alarmTime,note.devID,note.operateNum,note.partNum,note.powerMsg,note.alarmMsg);
        }
    }
    [_db close];
    [threadLock unlock];
    return array;
}
+ (NSString *)getNewDoorlockNoteDate {
    [threadLock lock];
    NSString *strNewDate;
    if(!_db){
        _db = [DatabaseUtil creatOrFindDB];
    }
    if(![_db open]){
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if([_db tableExists:@"db_doorlock_alarm"]){
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM 'db_doorlock_alarm' ORDER BY alarmTime DESC limit 0,1"];
        while ([set next]) {
            strNewDate = [set stringForColumn:@"alarmTime"];
        }
    }
    [_db close];
    [threadLock unlock];
    return strNewDate;
}
+ (NSMutableArray *)getLatest500DoorlockNote {
    [threadLock lock];
    NSMutableArray *arySNote= [[NSMutableArray alloc]init];
    if(!_db){
        _db = [DatabaseUtil creatOrFindDB];
    }
    if(![_db open]){
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if([_db tableExists:@"db_doorlock_alarm"]){
        FMResultSet *set = [_db executeQuery:@"SELECT  rowid, * FROM db_doorlock_alarm order by alarmTime desc limit 0,500"];
        while ([set next]) {
            DoorlockNote * note = [[DoorlockNote alloc]init];
            note.alarmTime = [set stringForColumn:@"alarmTime"];
            note.devID = [set stringForColumn:@"devID"];
            note.operateNum = [set stringForColumn:@"userNumber"];
            note.partNum = [set stringForColumn:@"partNum"];
            note.powerMsg = [set stringForColumn:@"powerMsg"];
            note.alarmMsg = [set stringForColumn:@"alarmMsg"];
            [arySNote addObject:note];
//            NSLog(@"报警信息%@,%@,%@,%@,%@,%@",note.alarmTime,note.devID,note.operateNum,note.partNum,note.powerMsg,note.alarmMsg);
        }
    }
    [_db close];
    [threadLock unlock];
    return arySNote;
}
+ (DoorlockUser *)getNameWithUserID:(NSString *)userID {
    [threadLock lock];
    DoorlockUser *lockUser = [[DoorlockUser alloc] init];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_doorlock_user"])
    {
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_doorlock_user WHERE user_id = ?",userID];
        while ([set next]) {
            
            lockUser.userID = [set stringForColumn:@"user_id"];
            lockUser.userLandingName = [set stringForColumn:@"user_name"];
            lockUser.userAnotherName = [set stringForColumn:@"member_role"];
            NSLog(@"获取到的用户%@,%@,%@",lockUser.userID,lockUser.userLandingName,lockUser.userAnotherName);
        }
    }
    [_db close];
    [threadLock unlock];
    return lockUser;
}
+ (NSString *)getDevNameWithDevValue:(NSString *)devValue {
    [threadLock lock];
    NSString *lockName;
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_control_device_content_value"])
    {
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_control_device_content_value WHERE value = ?",devValue];
        while ([set next]) {
            
            lockName = [set stringForColumn:@"name"];
//            NSLog(@"获取到的门锁名%@",lockName);
        }
    }
    [_db close];
    [threadLock unlock];
    return lockName;
}
+ (NSString *)getDoorlockValueWithDoorName:(NSString *)name {
    [threadLock lock];
    NSString *value;
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_control_device_content_value"])
    {
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_control_device_content_value WHERE name = ?",name];
        while ([set next]) {
            
            value = [set stringForColumn:@"value"];
            NSLog(@"获取到的门锁value:%@",value);
        }
    }
    [_db close];
    [threadLock unlock];
    return value;
}
+ (Doorlock *)getDoorlockWithDoorDevID:(NSString *)devID {
    [threadLock lock];
    Doorlock *door = [Doorlock new];;
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_doorlock"])
    {
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_doorlock WHERE number = ?",devID];
        while ([set next]) {
            door.deviceNumber = devID;
            door.enterScene = [set stringForColumn:@"enter_scene"];
            door.leaveScene = [set stringForColumn:@"leave_scene"];
            door.enterSecutityZone = [set stringForColumn:@"enter_security_zone"];
            door.leaveSecutityZone = [set stringForColumn:@"leave_security_zone"];
//            door.enter_scene_enable = [set stringForColumn:@"enter_scene_enable"];
//            door.leave_scene_enable = [set stringForColumn:@"leave_scene_enable"];
//            door.enter_secutity_enable = [set stringForColumn:@"enter_security_enable"];
//            door.leave_secutity_enable = [set stringForColumn:@"leave_security_enable"];
            NSLog(@"取出了门锁设置数据%@,%@,%@,%@,%d,%d,%d,%d",door.enterScene,door.leaveScene,door.enterSecutityZone,door.leaveSecutityZone,door.enter_scene_enable,door.leave_scene_enable,door.enter_secutity_enable,door.leave_secutity_enable);
        }
    }
    [_db close];
    [threadLock unlock];
    return door;
}
+ (DoorlockUser *)getUserWithLoadName:(NSString *)loadName {
    [threadLock lock];
    DoorlockUser *lockUser = [[DoorlockUser alloc] init];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_doorlock_user"])
    {
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_doorlock_user WHERE user_name = ?",loadName];
        while ([set next]) {
            
            lockUser.userID = [set stringForColumn:@"user_id"];
            lockUser.userLandingName = [set stringForColumn:@"user_name"];
            lockUser.userAnotherName = [set stringForColumn:@"member_role"];
            NSLog(@"获取到的用户%@,%@,%@",lockUser.userID,lockUser.userLandingName,lockUser.userAnotherName);
        }
    }
    [_db close];
    [threadLock unlock];
    return lockUser;
}
+ (BOOL)saveUserToDataBase:(DoorlockUser *)user {
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return NO;
    }
    
    [_db setShouldCacheStatements:YES];
    
    if ([_db tableExists:@"db_doorlock_user"])
    {
        //@"UPDATE db_scene SET id=?,name=?,isedit=?,status=?,scene=?,delay=?,prio=?,type=?,room=? WHERE _id=?"
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_doorlock_user WHERE user_name = ?",user.userLandingName];
        while ([set next]) {
            BOOL isSave = [_db executeUpdate:@"UPDATE db_doorlock_user SET member_role=?,user_id = ? WHERE user_name = ?", user.userAnotherName,user.userID,user.userLandingName];
            if (isSave) {
                NSLog(@"保存成功%@,%@,%@",user.userAnotherName,user.userID,user.userLandingName);
                [_db close];
                [threadLock unlock];
                return YES;
            }else {
                [_db close];
                [threadLock unlock];
                return NO;
            }
        }
    }
    
    if ([_db tableExists:@"db_doorlock_user"]) {
        
        [_db executeUpdate:@"INSERT INTO db_doorlock_user(user_id,user_name,member_role) VALUES(?,?,?)",user.userID,user.userLandingName,user.userAnotherName];
        NSLog(@"单个用户插入%@,%@,%@ 完毕",user.userID,user.userLandingName,user.userAnotherName);
    }
    
    [_db close];
    [threadLock unlock];
    return YES;
}
+ (BOOL)deleteUserWithLoadName:(NSString *)loadName {
    [threadLock lock];
    if(!_db){
        _db = [DatabaseUtil creatOrFindDB];
    }
    if(![_db open]){
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return NO;
    }
    [_db setShouldCacheStatements:YES];
    if([_db tableExists:@"db_doorlock_user"]){
        BOOL isDelete = [_db executeUpdate:@"DELETE FROM db_doorlock_user WHERE user_name=?", loadName];
        [_db close];
        if (isDelete) {
            NSLog(@"删除%@成功",loadName);
        }else {
            NSLog(@"删除失败");
        }
        [threadLock unlock];
        return YES;
    }
    else{
        [_db close];
        [threadLock unlock];
        return NO;
    }

}
+ (NSMutableArray *)getAllDoorlockUser {
    [threadLock lock];
    NSMutableArray *array = [NSMutableArray new];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_doorlock_user"])
    {
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_doorlock_user"];
        while ([set next]) {
            DoorlockUser *user = [DoorlockUser new];
            user.userID = [set stringForColumn:@"user_id"];
            user.userLandingName = [set stringForColumn:@"user_name"];
            user.userAnotherName = [set stringForColumn:@"member_role"];
            NSLog(@"获取到用户：%@,%@,%@",user.userID,user.userLandingName,user.userAnotherName);
            [array addObject:user];
        }
    }
    [_db close];
    [threadLock unlock];
    return array;
}
#pragma mark 2.7增加
+ (void)modiOldName:(NSString *)oldName toNewName:(NSString *)newName {
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_control_device_content_value"])
    {
        [_db executeUpdate:@"UPDATE  db_control_device_content_value SET name=? WHERE name=?", newName,oldName];
    }
    if ([_db tableExists:@"db_room_device_content"])
    {
        [_db executeUpdate:@"UPDATE  db_room_device_content SET name=? WHERE name=?", newName,oldName];
    }
    if ([_db tableExists:@"db_scene_device"])
    {
        [_db executeUpdate:@"UPDATE  db_scene_device SET name=? WHERE name=?", newName,oldName];
    }
    if ([_db tableExists:@"db_scene"])
    {
        [_db executeUpdate:@"UPDATE  db_scene SET name=? WHERE name=?", newName,oldName];
    }
    
    if ([_db tableExists:@"db_security_sensor_content"]) {
        [_db executeUpdate:@"UPDATE  db_security_sensor_content SET sensorName=?,sensorOldName=? WHERE sensorName=?",newName,newName,oldName];
        [_db executeUpdate:@"UPDATE  db_security_sensor_content SET alarmName=?,alarmOldName=? WHERE alarmName=?",newName,newName,oldName];
    }
    if ([_db tableExists:@"db_security_zone_content_sensor"])
    {
        [_db executeUpdate:@"UPDATE  db_security_zone_content_sensor SET name=? WHERE name=?", newName,oldName];
    }
    //db_crontab
    if ([_db tableExists:@"db_crontab"])
    {
        [_db executeUpdate:@"UPDATE  db_crontab SET scene=? WHERE scene=?", newName,oldName];
    }
    [_db close];
    [threadLock unlock];
}
+ (void)modiProperty:(NSString *)property withDevice:(DeviceSettingModel *)model withRoomName:(NSString *)roomName{
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    NSString *comID = @"";
    NSString *categoryID = @"";
    
    [_db setShouldCacheStatements:YES];
    //1.找出comID
    if ([_db tableExists:@"db_control"]) {
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_control WHERE com = ?",model.com];
        while ([set next]) {
            comID = [set stringForColumn:@"_id"];
        }
    }

    //2.通过类型找出categoryID
    if ([_db tableExists:@"db_control_device"]) {
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_control_device WHERE category = ?",model.type];
        while ([set next]) {
            if ([[set stringForColumn:@"control_id"] isEqualToString:comID]) {
                categoryID = [set stringForColumn:@"_id"];
            }
        }
    }
    
    
   //3.检查有哪些属性
    NSMutableArray *propertyArr = [NSMutableArray new];
    FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_control_device_content WHERE device_id = ?",categoryID];
    while ([set next]) {
        [propertyArr addObject:[set stringForColumn:@"property"]];
    }
    //4.判断已存储的属性里是否有要修改的属性
    BOOL isHaveProperty = NO;
    for (NSString *propertys in propertyArr) {
        if ([propertys isEqualToString:property]) {
            isHaveProperty = YES;
        }
    }
    //5.如果不存在属性，则创建
    if (!isHaveProperty) {
        [_db executeUpdate:@"INSERT INTO db_control_device_content(_id,property,device_id,control_id) VALUES(?,?,?,?)",[CYM_DatabaseTable GenerateGUID],property,categoryID,comID];
    }
    //6.通过comID和categoryID修改property
    if ([_db tableExists:@"db_control_device_content"])
    {
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_control_device_content WHERE property = ?",property];

        while ([set next]) {
            if ([[set stringForColumn:@"control_id"] isEqualToString:comID] && [[set stringForColumn:@"device_id"] isEqualToString:categoryID]) {
                
                //修改key的content_id
                NSString *valueID = @"";
                FMResultSet *set1 = [_db executeQuery:@"SELECT  * FROM db_control_device_content_value WHERE value = ? AND name=?",model.ID,model.name];
                while ([set1 next]) {
                    valueID = [set1 stringForColumn:@"_id"];
                }
                
                NSString *contentID = [set stringForColumn:@"_id"];
                [_db executeUpdate:@"UPDATE  db_control_device_content_value SET content_id=? WHERE value=? AND name=?",contentID,model.ID,model.name];
                
                [_db executeUpdate:@"UPDATE  db_control_device_content_value_key SET content_id=? WHERE value_id=?",contentID,valueID];
            }
        }
        
    }
    
    if ([model.type isEqualToString:@"传感器"]) {
        
        NSInteger typeNumber = 0;
        NSArray *typeArr = @[@"煤气",@"烟雾",@"CO探测器",@"红外探测器",@"门磁探测器",@"紧急按钮",@"窗磁探测器"];
        for (NSString *str in typeArr) {
            if ([property isEqualToString:str]) {
                typeNumber = [typeArr indexOfObject:str];
            }
        }
        
        if ([_db tableExists:@"db_security_sensor_content"])
        {
            [_db executeUpdate:@"UPDATE  db_security_sensor_content SET sensorType=?,alarmMsg=? WHERE sensorName=?", [NSString stringWithFormat:@"%ld",typeNumber],[NSString stringWithFormat:@"%@报警！",model.property],model.name];
        }
        if ([_db tableExists:@"db_security_zone_content_sensor"])
        {
            [_db executeUpdate:@"UPDATE  db_security_zone_content_sensor SET type=? WHERE name=?",[NSString stringWithFormat:@"%ld",typeNumber],model.name];
        }
        
        [_db close];
        [threadLock unlock];
        return;
    }
    if ([model.type isEqualToString:@"zigbee转TTL"] || [model.type isEqualToString:@"报警设备"]) {
        [_db close];
        [threadLock unlock];
        return;
    }
    
    if ([roomName isEqualToString:@" "]) {
        [_db close];
        [threadLock unlock];
        return;
    }
    
    //房间内设备属性
    NSString *deviceID = @"";
    NSString *roomID = @"";
    
    //1.获取roomDeviceID
    //1.1查找db_room,肯定会有
    if ([_db tableExists:@"db_room"])
    {
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_room WHERE name=?",roomName];
        while ([set next]) {
            roomID = [set stringForColumn:@"_id"];
        }
    }
    
    if ([_db tableExists:@"db_room_device"])
    {
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_room_device WHERE property = ? AND room_id =?",property,roomID];
        
        while ([set next]) {
            deviceID = [set stringForColumn:@"_id"];
        }
    }
    if ([deviceID isEqualToString:@""] || deviceID == nil) {
        
        [_db setShouldCacheStatements:YES];
        
        //2.创建新的记录
        deviceID = [CYM_DatabaseTable GenerateGUID];
        [_db executeUpdate:@"INSERT INTO db_room_device(_id,property,room_id) VALUES(?,?,?)",deviceID,property,roomID];
    }
    //修改device_id值
    [_db executeUpdate:@"UPDATE  db_room_device_content SET device_id=? WHERE name=?",deviceID,model.name];
    
    [_db close];
    [threadLock unlock];
}
+ (void)modiRoomName:(NSString *)roomName withDevice:(DeviceSettingModel *)model {
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    
    if ([roomName isEqualToString:@" "]) {
        [_db close];
        NSLog(@"房间不存在！");
        [threadLock unlock];
        return;
    }
    
    NSString *roomDeviceID = @"";
    NSString *roomID = @"";
    
    //1.获取roomDeviceID
    //1.1查找db_room,肯定会有
    if ([_db tableExists:@"db_room"])
    {
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_room WHERE name=?",roomName];
        while ([set next]) {
            roomID = [set stringForColumn:@"_id"];
        }
    }
    //1.2查找db_room_device
    if ([_db tableExists:@"db_room_device"])
    {
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_room_device WHERE property=? AND room_id = ?",model.property,roomID];
        while ([set next]) {
            roomDeviceID = [set stringForColumn:@"_id"];
        }
    }
    if (roomDeviceID==nil || [roomDeviceID isEqualToString:@""] || [roomDeviceID isEqualToString:@"null"] || [roomDeviceID isEqualToString:@"nil"]) {
        roomDeviceID = [CYM_DatabaseTable GenerateGUID];
        [_db executeUpdate:@"INSERT INTO db_room_device(_id,property,room_id) VALUES(?,?,?)",roomDeviceID,model.property,roomID];
    }
    
    //插入设备到room数据库
    if ([_db tableExists:@"db_room_device_content"])
    {
        [_db executeUpdate:@"DELETE FROM db_room_device_content WHERE name=?",model.name];
        [_db executeUpdate:@"INSERT INTO db_room_device_content(_id,name,device_id,room_id) VALUES(?,?,?,?)",[self GenerateGUID],model.name,roomDeviceID,roomID];
    }
    
    
    /***********修改scene.json房间名************/
    //1判断是否为场景控制器
    if ([model.type isEqualToString:@"场景控制器"]) {
        NSString *room1 = @"";
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_scene WHERE name=?",model.name];
        while ([set next]) {
            room1 = [set stringForColumn:@"room"];
        }
        if (room1 == nil || [room1 isEqualToString:@""] || [room1 isEqualToString:@" "]) {
            [_db executeUpdate:@"DELETE FROM db_scene WHERE name=?",model.name];
            [_db executeUpdate:@"INSERT INTO db_scene(_id,id,name,isedit,status,scene,delay,prio,type,room) VALUES(?,?,?,?,?,?,?,?,?,?)",[self GenerateGUID],[model.ID substringWithRange:NSMakeRange(12, 6)],model.name,@"1",@"on",@"null",@"0",@"FFFFFFFFFFFFF",@"0",roomName];
        }else {
            [_db executeUpdate:@"UPDATE  db_scene SET room=? WHERE name=?", roomName,model.name];
        }
    }
    //2修改对应的房间名
    
    [_db close];
    [threadLock unlock];
}
+ (void)deleteDeviceFromDevice:(DeviceSettingModel *)model withOldName:(NSString *)oldName{
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    [_db setShouldCacheStatements:YES];
    //所有设备
    if ([_db tableExists:@"db_control_device_content_value"])
    {
        [_db executeUpdate:@"DELETE FROM db_control_device_content_value WHERE value = ? AND name=?",model.ID,oldName];
    }
    //
    if ([_db tableExists:@"db_room_device_content"])
    {
        [_db executeUpdate:@"DELETE FROM db_room_device_content WHERE name = ?",oldName];
    }
    if ([_db tableExists:@"db_scene_device"])
    {
        [_db executeUpdate:@"DELETE FROM db_scene_device WHERE name = ?",oldName];
    }
    //场景控制器
    if ([_db tableExists:@"db_scene"]) {
        [_db executeUpdate:@"DELETE FROM db_scene WHERE name = ?",oldName];
    }
    if ([_db tableExists:@"db_security_sensor_content"])
    {
        [_db executeUpdate:@"DELETE FROM db_security_sensor_content WHERE sensorName = ?",oldName];
    }
    if ([_db tableExists:@"db_security_zone_content_sensor"])
    {
        [_db executeUpdate:@"DELETE FROM db_security_zone_content_sensor WHERE name = ?",oldName];
    }
    
    //删除定时
    FMResultSet *set1 = [_db executeQuery:@"SELECT  * FROM db_crontab_instructions"];
    while ([set1 next]) {
        NSString *value = [set1 stringForColumn:@"cmd"];
        if ( value.length >= 28 && [[model.ID substringWithRange:NSMakeRange(12, 6)] isEqualToString:[value substringWithRange:NSMakeRange(22, 6)]]) {
            [_db executeUpdate:@"DELETE FROM db_crontab_instructions WHERE cmd = ?",value];
        }
    }
    
    [_db close];
    [threadLock unlock];
}
+ (void)modiStateWithModel:(DeviceSettingModel *)model {
    
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    [_db setShouldCacheStatements:YES];
    
    if ([_db tableExists:@"db_security_sensor_content"]) {
        [_db executeUpdate:@"UPDATE  db_security_sensor_content SET sensor24h=?,isAlarm=?,isElectromic=? WHERE sensorName=?",model.sensor24h?@"1":@"0",model.isAlarm?@"1":@"0",model.powerMSG?@"1":@"0",model.name];
    }
    
    [_db close];
    [threadLock unlock];
    
}
+ (void)modiTrigger:(NSString *)trigger withDevice:(DeviceSettingModel *)device {
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    
    [_db setShouldCacheStatements:YES];
    
    
    if ([_db tableExists:@"db_security_sensor_content"])
    {
        [_db executeUpdate:@"UPDATE  db_security_sensor_content SET sensorSignal=? WHERE sensorName=?",trigger,device.name];
    }
    
    [_db close];
    [threadLock unlock];
}
+ (void)modiAlarm:(NSString *)alarm withDevice:(DeviceSettingModel *)device {
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    
    [_db setShouldCacheStatements:YES];
    
    
    /***********/
    
        //需要绑定报警器的信息
        NSString *BDMac = @"null";
        NSString *BDType = @"null";
        //获取报警设备信息
        
        if ([_db tableExists:@"db_control_device_content_value"])
        {//通过alarm名字找到报警器
            FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_control_device_content_value WHERE name=?",alarm];
            while ([set next]) {
                //MAC
                BDMac = [set stringForColumn:@"value"];
                FMResultSet *result = [_db executeQuery:@"SELECT * FROM db_control_device_content WHERE _id=?",[set stringForColumn:@"content_id"]];
                while ([result next]) {
                    BDType = [result stringForColumn:@"property"];
                    //TYPE  BDMSG
                    if ([BDType isEqualToString:@"声报警"]) {
                        BDType = @"0";
                    }
                    if ([BDType isEqualToString:@"光报警"]) {
                        BDType = @"1";
                    }
                    if ([BDType isEqualToString:@"声光报警"]) {
                        BDType = @"2";
                    }
                }
            }
        }
        NSString *mac = @"null";
        if (![BDMac isEqualToString:@"null"]) {
            if (BDMac.length > 18) {
                mac = [BDMac substringWithRange:NSMakeRange(12, 6)];
            }
        }
    
    if ([_db tableExists:@"db_security_sensor_content"])
    {
        [_db executeUpdate:@"UPDATE  db_security_sensor_content SET alarmMac=?,alarmType=?,alarmName=?,alarmOldName=? WHERE sensorName=?",mac,BDType,alarm,alarm,device.name];
    }

    [_db close];
    [threadLock unlock];
}


+ (DeviceSettingModel *)getSensorModelWithName:(NSString *)name {
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    [_db setShouldCacheStatements:YES];
    
    DeviceSettingModel *model = [DeviceSettingModel new];
    if ([_db tableExists:@"db_security_sensor_content"]) {
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_security_sensor_content WHERE sensorName = ?",name];
        while ([set next]) {
            model.property = [set stringForColumn:@"sensorType"];
            model.trigger = [[set stringForColumn:@"sensorSignal"] isEqualToString:@"0"]?@"常闭":@"常开";
            model.BD = [set stringForColumn:@"alarmName"];
            model.sensor24h = [[set stringForColumn:@"sensor24h"] isEqualToString:@"1"]?YES:NO;
            model.isAlarm = [[set stringForColumn:@"isAlarm"] isEqualToString:@"1"]?YES:NO;
            model.powerMSG = [[set stringForColumn:@"isElectromic"] isEqualToString:@"1"]?YES:NO;
        }
    }
    [_db close];
    [threadLock unlock];
    return model;
}
+ (NSMutableArray *)getAllCDCVKey {
    NSMutableArray *array = [NSMutableArray new];
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_control_device_content_value_key"]) {
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_control_device_content_value_key "];
        while ([set next]) {
            NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:@{@"value":[set stringForColumn:@"value"],@"backkey":[set stringForColumn:@"backkey"],@"query":[set stringForColumn:@"query"],@"name":[set stringForColumn:@"name"],@"value_id":[set stringForColumn:@"value_id"]}];
            [array addObject:dic];
        }
    }
    [_db close];
    [threadLock unlock];
    return array;
}
+ (NSMutableArray *)getAllCDCValue {
    NSMutableArray *array = [NSMutableArray new];
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_control_device_content_value"]) {
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_control_device_content_value "];
        while ([set next]) {
            NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:@{@"value":[set stringForColumn:@"value"],@"prio":[set stringForColumn:@"prio"],@"name":[set stringForColumn:@"name"],@"key":[set stringForColumn:@"_id"],@"content_id":[set stringForColumn:@"content_id"]}];
            [array addObject:dic];
        }
    }
    [_db close];
    [threadLock unlock];
    return array;
}
+ (NSMutableArray *)getAllCDContent {
    NSMutableArray *array = [NSMutableArray new];
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_control_device_content"]) {
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_control_device_content "];
        while ([set next]) {
            NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:@{@"value":[set stringForColumn:@"_id"],@"property":[set stringForColumn:@"property"],@"device_id":[set stringForColumn:@"device_id"]}];
            [array addObject:dic];
        }
    }
    [_db close];
    [threadLock unlock];
    return array;
}
+ (NSMutableArray *)getAllCDevice {
    NSMutableArray *array = [NSMutableArray new];
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_control_device"]) {
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_control_device "];
        while ([set next]) {
            NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:@{@"type":[set stringForColumn:@"type"],@"category":[set stringForColumn:@"category"],@"method":[set stringForColumn:@"method"],@"content":[set stringForColumn:@"_id"]}];
            [array addObject:dic];
        }
    }
    [_db close];
    [threadLock unlock];
    return array;
}
+ (NSMutableArray *)getAllControl {
    NSMutableArray *array = [NSMutableArray new];
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_control"]) {
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_control "];
        while ([set next]) {
            Control *control = [Control new];
            control.ID = [set stringForColumn:@"_id"];
            NSString *com = [set stringForColumn:@"com"];
            control.comNumber = com;
            control.com = [NSString stringWithFormat:@"com:%@",com];
            [array addObject:control];
        }
    }
    [_db close];
    [threadLock unlock];
    return array;
}
+ (void)clearOrderWithDeviceValue:(DeviceSettingModel *)model {
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return ;
    }
    
    [_db setShouldCacheStatements:YES];
    NSString *keyID = @"";
    if ([_db tableExists:@"db_control_device_content_value"]) {
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_control_device_content_value WHERE value=? AND name=?",model.ID,model.name];
        while ([set next]) {
            keyID = [set stringForColumn:@"_id"];
        }
    }
    if ([_db tableExists:@"db_control_device_content_value_key"]) {
        [_db executeUpdate:@"DELETE FROM db_control_device_content_value_key WHERE value_id=?",keyID];
    }
    [_db close];
    [threadLock unlock];
}
//新增
+ (void)insertDevice:(DeviceSettingModel *)model {
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    
    [_db setShouldCacheStatements:YES];
    /***************所有设备*******************/
    //control
    NSString *contentID = @"";
    NSString *deviceID = @"";
    NSString *controlID = @"";
    
    //1.获取controlID
    //1.1查找db_control
    //1.2如果有，获取
    //1.3如果没有，新建，获取
    if ([_db tableExists:@"db_control"])
    {
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_control WHERE com=?",model.com];
        while ([set next]) {
            controlID = [set stringForColumn:@"_id"];
        }
    }
    if (controlID==nil || [controlID isEqualToString:@""] || [controlID isEqualToString:@"null"] || [controlID isEqualToString:@"nil"]) {
        controlID = [CYM_DatabaseTable GenerateGUID];
        [_db executeUpdate:@"INSERT INTO db_control(_id,com) VALUES(?,?)",controlID,model.com];
    }
    
    //deviceID
    if ([_db tableExists:@"db_control_device"])
    {
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_control_device WHERE control_id=? AND category=?",controlID,model.type];
        while ([set next]) {
            deviceID = [set stringForColumn:@"_id"];
        }
    }
    if (deviceID==nil || [deviceID isEqualToString:@""] || [deviceID isEqualToString:@"null"] || [deviceID isEqualToString:@"nil"]) {
        deviceID = [CYM_DatabaseTable GenerateGUID];
        [_db executeUpdate:@"INSERT INTO db_control_device(_id,type,method,category,control_id) VALUES(?,?,?,?,?)",deviceID,@"baiwei",@"03",model.type,controlID];
    }
    
    //contentID
    if ([_db tableExists:@"db_control_device_content"])
    {
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_control_device_content WHERE device_id=? AND property=?",deviceID,model.property];
        while ([set next]) {
            contentID = [set stringForColumn:@"_id"];
        }
    }
    if (contentID==nil || [contentID isEqualToString:@""] || [contentID isEqualToString:@"null"] || [contentID isEqualToString:@"nil"]) {
        contentID = [CYM_DatabaseTable GenerateGUID];
        [_db executeUpdate:@"INSERT INTO db_control_device_content(_id,property,device_id,control_id) VALUES(?,?,?,?)",contentID,model.property,deviceID,controlID];
    }
    //插入设备到control数据库
    NSString *value_id = @"";
    if ([_db tableExists:@"db_control_device_content_value"])
    {
        value_id = [CYM_DatabaseTable GenerateGUID];
        [_db executeUpdate:@"INSERT INTO db_control_device_content_value(_id,prio,value,name,content_id,device_id,control_id) VALUES(?,?,?,?,?,?,?)",value_id,@"FFFFFFFFFFFFF",model.ID,model.name,contentID,deviceID,controlID];
        //        NSLog( @"插入数据完毕");
    }
    //插入指令
    for (ControlDeviceContentValueKey *key in model.cmdArray) {
        if ([_db tableExists:@"db_control_device_content_value_key"])
        {
            [_db executeUpdate:@"INSERT INTO db_control_device_content_value_key(_id,value,backkey,query,name,value_id,content_id,device_id,control_id, time) VALUES(?,?,?,?,?,?,?,?,?,?)",[CYM_DatabaseTable GenerateGUID],key.value,key.backkey,key.query,key.name,value_id,contentID,deviceID,controlID,key.time];
        }
    }
    
    /****************有房间设置的设备*******************/
    //zigbee转ttl并且是I端
//    if ([[model.ID substringWithRange:NSMakeRange(16, 2)] isEqualToString:@"14"]&&[model.type isEqualToString:@"zigbee转TTL"]) {
//        if ([_db tableExists:@"db_scene"])
//        {
//            [_db executeUpdate:@"INSERT INTO db_scene(_id,id,name,isedit,status,scene,delay,prio,type,room) VALUES(?,?,?,?,?,?,?,?,?,?)",[self GenerateGUID],[model.ID substringWithRange:NSMakeRange(12, 6)],model.name,@"1",@"on",@"null",@"null",@"FFFFFFFFFFFFF",@"2",model.roomName];
//        }
//    }
    //room
    if (([model.type isEqualToString:@"灯光"] || [model.type isEqualToString:@"窗帘"] || [model.type isEqualToString:@"智能插座"] || [model.type isEqualToString:@"场景控制器"] || [model.type isEqualToString:@"智能门锁"] || [model.type isEqualToString:@"多功能控制器"] || [model.type isEqualToString:@"空调控制器"] || [model.type isEqualToString:@"数据透传模块"] || ([[model.ID substringWithRange:NSMakeRange(16, 2)] isEqualToString:@"14"]&&[model.type isEqualToString:@"zigbee转TTL"])) && !([model.roomName isEqualToString:@" "]||model.roomName == nil)) {
        NSString *roomDeviceID = @"";
        NSString *roomID = @"";
        
        //1.获取roomDeviceID
        //1.1查找db_room,肯定会有
        if ([_db tableExists:@"db_room"])
        {
            FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_room WHERE name=?",model.roomName];
            while ([set next]) {
                roomID = [set stringForColumn:@"_id"];
            }
        }
        //1.2查找db_room_device
        if ([_db tableExists:@"db_room_device"])
        {
            FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_room_device WHERE property = ? AND room_id = ?",model.property,roomID];
            while ([set next]) {
                roomDeviceID = [set stringForColumn:@"_id"];
            }
        }
        if (roomDeviceID==nil || [roomDeviceID isEqualToString:@""] || [roomDeviceID isEqualToString:@"null"] || [roomDeviceID isEqualToString:@"nil"]) {
            roomDeviceID = [CYM_DatabaseTable GenerateGUID];
            [_db executeUpdate:@"INSERT INTO db_room_device(_id,property,room_id) VALUES(?,?,?)",roomDeviceID,model.property,roomID];
        }
        
        //插入设备到room数据库
        if ([_db tableExists:@"db_room_device_content"])
        {
            [_db executeUpdate:@"INSERT INTO db_room_device_content(_id,name,device_id,room_id) VALUES(?,?,?,?)",[self GenerateGUID],model.name,roomDeviceID,roomID];
        }
    }
    /****************传感器****************/
    if ([model.type isEqualToString:@"传感器"]) {
        NSString *securityID = @"";
        //1获取传感器securityID
        if ([_db tableExists:@"db_security"])
        {
            FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_security WHERE type=?",@"sensor"];
            while ([set next]) {
                securityID = [set stringForColumn:@"_id"];
            }
        }
        if (securityID==nil || [securityID isEqualToString:@""] || [securityID isEqualToString:@"null"] || [securityID isEqualToString:@"nil"]) {
            securityID = [CYM_DatabaseTable GenerateGUID];
            [_db executeUpdate:@"INSERT INTO db_security(_id,type) VALUES(?,?)",securityID,@"sensor"];
        }
        //2插入
//        NSInteger typeNumber = 0;
        NSString *typeNumber = @"null";
        NSArray *typeArr = @[@"煤气",@"烟雾",@"CO探测器",@"红外探测器",@"门磁探测器",@"紧急按钮",@"窗磁探测器"];
        for (NSString *str in typeArr) {
            if ([model.property isEqualToString:str]) {
               typeNumber = [NSString stringWithFormat:@"%lu",(unsigned long)[typeArr indexOfObject:str]];
            }
        }
        //需要绑定报警器的信息
        NSString *BDMac = @"null";
        NSString *BDType = @"null";
        //获取报警设备信息
        
        if ([_db tableExists:@"db_control_device_content_value"])
        {
            FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_control_device_content_value WHERE name=?",model.BD];
            while ([set next]) {
                //MAC
                BDMac = [set stringForColumn:@"value"];
                FMResultSet *result = [_db executeQuery:@"SELECT * FROM db_control_device_content WHERE _id=?",[set stringForColumn:@"content_id"]];
                while ([result next]) {
                    BDType = [result stringForColumn:@"property"];
                    //TYPE  BDMSG
                    if ([BDType isEqualToString:@"声报警"]) {
                        BDType = @"0";
                    }
                    if ([BDType isEqualToString:@"光报警"]) {
                        BDType = @"1";
                    }
                    if ([BDType isEqualToString:@"声光报警"]) {
                        BDType = @"2";
                    }
                }
            }
        }
        NSString *mac = @"null";
        if (![BDMac isEqualToString:@"null"]) {
            if (BDMac.length > 18) {
                mac = [BDMac substringWithRange:NSMakeRange(12, 6)];
            }
        }
        
        if ([_db tableExists:@"db_security_sensor_content"])
        {
            [_db executeUpdate:@"INSERT INTO db_security_sensor_content(_id,sensorName,sensorMac,sensorType,sensorSignal,sensor24h,minValue,maxValue,ctrlValue,alarmName,alarmMac,alarmType,alarmTime,isElectromic,isAlarm,alarmMsg,powerMsg,security_id,sensorOldName,alarmOldName) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",[CYM_DatabaseTable GenerateGUID],model.name,[model.ID substringWithRange:NSMakeRange(12, 6)],typeNumber,[model.trigger isEqualToString:@"常闭"]?@"0":@"1",model.sensor24h?@"1":@"0",@"0",@"32768",@"0",model.BD,mac,BDType,@"65534",model.powerMSG?@"1":@"0",model.isAlarm?@"1":@"0",[NSString stringWithFormat:@"%@报警！",model.property],@"探测器电量不足，请更换电池！",securityID,model.name,model.BD];
        }
    }
    
    
    /***************场景****************/
    
    //如果是场景,插入设备到scene数据库
    if ([model.type isEqualToString:@"场景控制器"]) {
        if ([_db tableExists:@"db_scene"])
        {
            [_db executeUpdate:@"INSERT INTO db_scene(_id,id,name,isedit,status,scene,delay,prio,type,room) VALUES(?,?,?,?,?,?,?,?,?,?)",[self GenerateGUID],[model.ID substringWithRange:NSMakeRange(12, 6)],model.name,@"1",@"on",@"null",@"0",@"FFFFFFFFFFFFF",@"0",model.roomName];
        }
    }
    
    [_db close];
    [threadLock unlock];
}
+ (void)relaceDeviceFrom:(DeviceSettingModel *)fresh to:(DeviceSettingModel *)old {
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return;
    }
    
    /**
     *  场景定时替换流程：
     1.通过名字查找CMD
     2.找出CMD对应的ID值
     3.比较新的ID值
     4.生成新的CMD
     5.存入数据库中
     */
    FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_scene_device WHERE name=?",old.name];
    while ([set next]) {
        NSString *value = [set stringForColumn:@"value"];
        if ( value.length >= 28 && [[old.ID substringWithRange:NSMakeRange(12, 6)] isEqualToString:[value substringWithRange:NSMakeRange(22, 6)]]) {
            NSArray *arra =[value componentsSeparatedByString:[old.ID substringWithRange:NSMakeRange(12, 6)]];
            NSMutableString *string = [NSMutableString new];
            NSMutableArray *array = [NSMutableArray arrayWithArray:arra];
            [array insertObject:[fresh.ID substringWithRange:NSMakeRange(12, 6)] atIndex:1];
            for (NSString *s in array) {
                [string appendString:s];
            }
            
            //分离出A55A
            NSArray *a1 = [string componentsSeparatedByString:@"A55A"];
            NSString *back = [a1[1] substringWithRange:NSMakeRange(0, ((NSString *)a1[1]).length-2)];
            NSString *cmd = [@"A55A" stringByAppendingString:back];
            
            //除开校验和之外的每个字节相加， 最后的和，取最后一个字节作为校验和
            NSString *tmp = [NSString stringFromHexString:cmd];
            uint sum = 0;
            for (int i=0; i<tmp.length; i++) {
                unsigned int c = [tmp characterAtIndex:i];
                sum += c;
            }
            
            [string replaceCharactersInRange:NSMakeRange(string.length - 2 , 2) withString:[self checkSumForStirng:cmd]];
            [_db executeUpdate:@"UPDATE  db_scene_device SET value=? WHERE value=?",string,value];
        }
    }
    //同理修改定时
    FMResultSet *set1 = [_db executeQuery:@"SELECT  * FROM db_crontab_instructions"];
    while ([set1 next]) {
        NSString *value = [set1 stringForColumn:@"cmd"];
        if ( value.length >= 28 && [[old.ID substringWithRange:NSMakeRange(12, 6)] isEqualToString:[value substringWithRange:NSMakeRange(22, 6)]]) {
            NSArray*arra =[value componentsSeparatedByString:[old.ID substringWithRange:NSMakeRange(12, 6)]];
            NSMutableString *string = [NSMutableString new];
            NSMutableArray *array = [NSMutableArray arrayWithArray:arra];
            [array insertObject:[fresh.ID substringWithRange:NSMakeRange(12, 6)] atIndex:1];
            for (NSString *s in array) {
                [string appendString:s];
            }
            
            //分离出A55A
            NSArray *a1 = [string componentsSeparatedByString:@"A55A"];
            NSString *back = [a1[1] substringWithRange:NSMakeRange(0, ((NSString *)a1[1]).length-2)];
            NSString *cmd = [@"A55A" stringByAppendingString:back];
            
            //除开校验和之外的每个字节相加， 最后的和，取最后一个字节作为校验和
            NSString *tmp = [NSString stringFromHexString:cmd];
            uint sum = 0;
            for (int i=0; i<tmp.length; i++) {
                unsigned int c = [tmp characterAtIndex:i];
                sum += c;
            }
            
            [string replaceCharactersInRange:NSMakeRange(string.length - 2 , 2) withString:[self checkSumForStirng:cmd]];
            
            [_db executeUpdate:@"UPDATE  db_crontab_instructions SET cmd=? WHERE cmd=?",string,value];
        }
    }
    
    //首先将老设备的值全部给新设备
    fresh.name = old.name;
    fresh.property = old.property;
    fresh.roomName = old.roomName;
    fresh.trigger = old.trigger;
    fresh.BD = old.BD;
    fresh.sensor24h = old.sensor24h;
    fresh.isAlarm = old.isAlarm;
    fresh.powerMSG = old.powerMSG;
    fresh.cmdArray = old.cmdArray;
    [_db setShouldCacheStatements:YES];
    //然后生成命令
    NSString *oldCMD = @"";
    NSString *newCMD = @"";
    A4_DeviceTypeCode typeA4 = A4_DEVICE_UNKNOW;
    if ([old.type isEqualToString:@"灯光"]) {
        typeA4 = A4_DEVICE_LIGHT;
    }
    else if ([old.type isEqualToString:@"窗帘"]) {
        typeA4 = A4_DEVICE_CURTAIN;
    }
    else if ([old.type isEqualToString:@"智能插座"]) {
        typeA4 = A4_DEVICE_SOCKET;
    }
    else if ([old.type isEqualToString:@"场景控制器"]) {
        typeA4 = A4_DEVICE_SENCE;
    }
    else if ([old.type isEqualToString:@"传感器"]) {
        typeA4 = A4_DEVICE_SENSAR;
    }
    else if ([old.type isEqualToString:@"报警设备"]) {
        typeA4 = A4_DEVICE_ALARM;
    }
    else if ([old.type isEqualToString:@"智能门锁"]) {
        typeA4 = A4_DEVICE_DOORLOCK;
    }
    if (typeA4 != A4_DEVICE_UNKNOW) {
        //新的命令
        NSString *strData = [NSString stringWithFormat:@"%@", [fresh.ID substringWithRange:NSMakeRange(12, 6)]];
        //NSString *strData = [NSString stringWithFormat:@"%@", @"FFFFFF"];
        NSString *cmd = [[HE_CMDBuilder new] getCMDWithAction:A4_ACTION_CONTROL DeviceType:typeA4 Data:strData];
        newCMD = [[HE_MsgBuilder new] getMessageWithType:[old.com longLongValue] action:ACTION_TRANSMIT commond:cmd];
        //老的命令
        NSString *oldData = [NSString stringWithFormat:@"%@", [old.ID substringWithRange:NSMakeRange(12, 6)]];
        //NSString *strData = [NSString stringWithFormat:@"%@", @"FFFFFF"];
        NSString *oldCmd = [[HE_CMDBuilder new] getCMDWithAction:A4_ACTION_CONTROL DeviceType:typeA4 Data:oldData];
        oldCMD = [[HE_MsgBuilder new] getMessageWithType:[old.com longLongValue] action:ACTION_TRANSMIT commond:oldCmd];
    }
    /***************所有设备通用***************/
    //修改control数据库
    if ([_db tableExists:@"db_control_device_content_value"]) {
        [_db executeUpdate:@"UPDATE  db_control_device_content_value SET value=? WHERE value=?",fresh.ID,old.ID];
    }
    /*****************安防***************/
    //修改security数据库
    if ([_db tableExists:@"db_security_sensor_content"]) {
        [_db executeUpdate:@"UPDATE  db_security_sensor_content SET sensorMac=? WHERE sensorMac=?",[fresh.ID substringWithRange:NSMakeRange(12, 6)] ,[old.ID substringWithRange:NSMakeRange(12, 6)]];
        [_db executeUpdate:@"UPDATE  db_security_sensor_content SET alarmMac=? WHERE alarmMac=?",[fresh.ID substringWithRange:NSMakeRange(12, 6)] ,[old.ID substringWithRange:NSMakeRange(12, 6)]];
        [_db executeUpdate:@"UPDATE  db_security_zone_content_sensor SET mac=? WHERE mac=?",[fresh.ID substringWithRange:NSMakeRange(12, 6)] ,[old.ID substringWithRange:NSMakeRange(12, 6)]];
    }
    /***************场景*************/
    //修改scene数据库
    if ([_db tableExists:@"db_scene"]) {
        [_db executeUpdate:@"UPDATE  db_scene SET id=? WHERE id=?",[fresh.ID substringWithRange:NSMakeRange(12, 6)],[old.ID substringWithRange:NSMakeRange(12, 6)]];
    }
    //插入scene
    [_db executeUpdate:@"UPDATE  db_scene_device SET value=? WHERE value=?",newCMD,oldCMD];
    
    /***************定时****************/
    //修改crontab数据库
    if ([_db tableExists:@"db_crontab_instructions"]) {
        [_db executeUpdate:@"UPDATE  db_crontab_instructions SET cmd=? WHERE cmd=?",newCMD,oldCMD];
    }
    [_db close];
    [threadLock unlock];
}

+ (NSString *)checkSumForStirng:(NSString *)str{
    int len = (int)[str length] / 2 + 1;
    unsigned char *myBuffer = (unsigned char *)malloc(len);
    bzero(myBuffer, [str length] / 2 + 1);
    for (int i = 0; i < [str length] - 1; i += 2) {
        unsigned int anInt;
        NSString * hexCharStr = [str substringWithRange:NSMakeRange(i, 2)];
        NSScanner * scanner = [[NSScanner alloc] initWithString:hexCharStr];
        [scanner scanHexInt:&anInt];
        myBuffer[i / 2] = (unsigned char)anInt;
    }
    myBuffer[len - 1] = 0;
    unsigned int sum = 0;
    for (int i=0; i<len; i++){
        sum += myBuffer[i];
    }
    NSString *ans = [NSString stringWithFormat:@"%X", sum];
    ans = [ans substringWithRange:NSMakeRange(ans.length-2, 2)];
    return ans;
}


+ (NSMutableArray *)getAllDeviceWithCategory:(NSString *)category {
    NSMutableArray *array = [NSMutableArray new];
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    //获取deviceID
    NSString *deviceID = @"";
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_control_device"]) {
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_control_device WHERE category=?",category];
        while ([set next]) {
            deviceID = [set stringForColumn:@"_id"];
            
        }
    }
    //获取comID
    NSString *comID = @"";
    if ([_db tableExists:@"db_control"]) {
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_control WHERE com=?",@"0"];
        while ([set next]) {
            comID = [set stringForColumn:@"_id"];
            
        }
    }
    //获取所有设备
    FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_control_device_content_value WHERE control_id=? AND device_id=?",comID,deviceID];
    while ([set next]) {
        NSString *name = [set stringForColumn:@"name"];
        [array addObject:name];
    }
    
    [_db close];
    [threadLock unlock];
    return array;
}
+ (void)saveKeys:(NSMutableArray *)keys ToDevice:(DeviceSettingModel *)model {
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return ;
    }
    
    /***************所有设备*******************/
    //control
    NSString *contentID = @"";
    NSString *deviceID = @"";
    NSString *controlID = @"";
    
    //1.获取controlID
    //1.1查找db_control
    //1.2如果有，获取
    //1.3如果没有，新建，获取
    if ([_db tableExists:@"db_control"])
    {
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_control WHERE com=?",model.com];
        while ([set next]) {
            controlID = [set stringForColumn:@"_id"];
        }
    }
    
    //deviceID
    if ([_db tableExists:@"db_control_device"])
    {
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_control_device WHERE control_id=? AND category=?",controlID,model.type];
        while ([set next]) {
            deviceID = [set stringForColumn:@"_id"];
        }
    }
    
    //contentID
    if ([_db tableExists:@"db_control_device_content"])
    {
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_control_device_content WHERE control_id=? AND property=?",controlID,model.property];
        while ([set next]) {
            contentID = [set stringForColumn:@"_id"];
        }
    }
    
    //valueID
    NSString *value_id = @"";
    if ([_db tableExists:@"db_control_device_content_value"])
    {
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_control_device_content_value WHERE name=?",model.name];
        while ([set next]) {
            value_id = [set stringForColumn:@"_id"];
        }
    }
    //插入指令
    for (ControlDeviceContentValueKey *key in keys) {
        if ([_db tableExists:@"db_control_device_content_value_key"])
        {
            [_db executeUpdate:@"INSERT INTO db_control_device_content_value_key(_id,value,backkey,query,name,value_id,content_id,device_id,control_id, time) VALUES(?,?,?,?,?,?,?,?,?,?)",[CYM_DatabaseTable GenerateGUID],key.value,key.backkey,key.query,key.name,value_id,contentID,deviceID,controlID,key.time];
        }
    }
    
    [_db close];
    [threadLock unlock];
}
+ (NSMutableArray *)getAllDeviceWithRoomName:(NSString *)name {
    NSMutableArray *array = [NSMutableArray new];
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
        [threadLock unlock];
        return nil;
    }
    //获取roomID
    NSString *roomID = @"";
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_room"]) {
        FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_room WHERE name=?",name];
        while ([set next]) {
            roomID = [set stringForColumn:@"_id"];
            
        }
    }
    //获取所有设备
    FMResultSet *set = [_db executeQuery:@"SELECT  * FROM db_room_device_content WHERE room_id=?",roomID];
    while ([set next]) {
        NSString *name = [set stringForColumn:@"name"];
        [array addObject:name];
    }
    
    [_db close];
    [threadLock unlock];
    return array;
}
+ (void)updataVersion {
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
    }
    [_db setShouldCacheStatements:YES];
    if ([_db tableExists:@"db_config"]){
        [_db executeUpdate:@"UPDATE db_config SET version=? WHERE name=?", @"0",@"room"];
        [_db executeUpdate:@"UPDATE db_config SET version=? WHERE name=?", @"0",@"scene"];
        [_db executeUpdate:@"UPDATE db_config SET version=? WHERE name=?", @"0",@"control"];
        [_db executeUpdate:@"UPDATE db_config SET version=? WHERE name=?", @"0",@"crontab"];
        [_db executeUpdate:@"UPDATE db_config SET version=? WHERE name=?", @"0",@"security"];
    }
    [_db close];
    [threadLock unlock];
}
+ (void)deletesensorWithName:(NSString *)name {
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
    }
    
    if ([_db tableExists:@"db_security_sensor_content"])
    {
        [_db executeUpdate:@"DELETE FROM db_security_sensor_content WHERE sensorName = ?",name];
    }
    if ([_db tableExists:@"db_security_zone_content_sensor"])
    {
        [_db executeUpdate:@"DELETE FROM db_security_zone_content_sensor WHERE name = ?",name];
    }
    
    [_db close];
    [threadLock unlock];
}
+ (void)insertSensor:(DeviceSettingModel *)model {
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
    }
    NSString *securityID = @"";
    //1获取传感器securityID
    if ([_db tableExists:@"db_security"])
    {
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_security WHERE type=?",@"sensor"];
        while ([set next]) {
            securityID = [set stringForColumn:@"_id"];
        }
    }
    if (securityID==nil || [securityID isEqualToString:@""] || [securityID isEqualToString:@"null"] || [securityID isEqualToString:@"nil"]) {
        securityID = [CYM_DatabaseTable GenerateGUID];
        [_db executeUpdate:@"INSERT INTO db_security(_id,type) VALUES(?,?)",securityID,@"sensor"];
    }
    //2插入
    //        NSInteger typeNumber = 0;
    NSString *typeNumber = @"null";
    NSArray *typeArr = @[@"煤气",@"烟雾",@"CO探测器",@"红外探测器",@"门磁探测器",@"紧急按钮",@"窗磁探测器"];
    for (NSString *str in typeArr) {
        if ([model.property isEqualToString:str]) {
            typeNumber = [NSString stringWithFormat:@"%lu",(unsigned long)[typeArr indexOfObject:str]];
        }
    }
    //需要绑定报警器的信息
    NSString *BDMac = @"null";
    NSString *BDType = @"null";
    //获取报警设备信息
    
    if ([_db tableExists:@"db_control_device_content_value"])
    {
        FMResultSet *set = [_db executeQuery:@"SELECT * FROM db_control_device_content_value WHERE name=?",model.BD];
        while ([set next]) {
            //MAC
            BDMac = [set stringForColumn:@"value"];
            FMResultSet *result = [_db executeQuery:@"SELECT * FROM db_control_device_content WHERE _id=?",[set stringForColumn:@"content_id"]];
            while ([result next]) {
                BDType = [result stringForColumn:@"property"];
                //TYPE  BDMSG
                if ([BDType isEqualToString:@"声报警"]) {
                    BDType = @"0";
                }
                if ([BDType isEqualToString:@"光报警"]) {
                    BDType = @"1";
                }
                if ([BDType isEqualToString:@"声光报警"]) {
                    BDType = @"2";
                }
            }
        }
    }
    NSString *mac = @"null";
    if (![BDMac isEqualToString:@"null"]) {
        if (BDMac.length > 18) {
            mac = [BDMac substringWithRange:NSMakeRange(12, 6)];
        }
    }
    
    if ([_db tableExists:@"db_security_sensor_content"])
    {
        [_db executeUpdate:@"INSERT INTO db_security_sensor_content(_id,sensorName,sensorMac,sensorType,sensorSignal,sensor24h,minValue,maxValue,ctrlValue,alarmName,alarmMac,alarmType,alarmTime,isElectromic,isAlarm,alarmMsg,powerMsg,security_id,sensorOldName,alarmOldName) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",[CYM_DatabaseTable GenerateGUID],model.name,[model.ID substringWithRange:NSMakeRange(12, 6)],typeNumber,[model.trigger isEqualToString:@"常闭"]?@"0":@"1",model.sensor24h?@"1":@"0",@"0",@"32768",@"0",model.BD,mac,BDType,@"65534",model.powerMSG?@"1":@"0",model.isAlarm?@"1":@"0",[NSString stringWithFormat:@"%@报警！",model.property],@"探测器电量不足，请更换电池！",securityID,model.name,model.BD];
    }
    [_db close];
    [threadLock unlock];
}
+ (void)modiSensorSensor:(DeviceSettingModel *)model{
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
    }
    
    NSInteger typeNumber = 0;
    NSArray *typeArr = @[@"煤气",@"烟雾",@"CO探测器",@"红外探测器",@"门磁探测器",@"紧急按钮",@"窗磁探测器"];
    for (NSString *str in typeArr) {
        if ([model.property isEqualToString:str]) {
            typeNumber = [typeArr indexOfObject:str];
        }
    }
    
    if ([_db tableExists:@"db_security_sensor_content"])
    {
        [_db executeUpdate:@"UPDATE  db_security_sensor_content SET sensorType=?,alarmMsg=? WHERE sensorName=?", [NSString stringWithFormat:@"%ld",typeNumber],[NSString stringWithFormat:@"%@报警！",model.property],model.name];
    }
    if ([_db tableExists:@"db_security_zone_content_sensor"])
    {
        [_db executeUpdate:@"UPDATE  db_security_zone_content_sensor SET type=? WHERE name=?",[NSString stringWithFormat:@"%ld",typeNumber],model.name];
    }
    
    
    [_db close];
    [threadLock unlock];
}
+ (void)updataAlarmZigbeeToTTLName:(NSString *)name {
    [threadLock lock];
    if (!_db) {
        _db = [DatabaseUtil creatOrFindDB];
    }
    if (![_db open]) {
        [_db close];
        NSLog(@"打开数据库失败");
    }
    
    if ([_db tableExists:@"db_security_sensor_content"])
    {
        [_db executeUpdate:@"UPDATE  db_security_sensor_content SET alarmMsg=? WHERE sensorName=?",@"zigbee转TTL报警！",name];
    }
    
    [_db close];
    [threadLock unlock];
}
@end
