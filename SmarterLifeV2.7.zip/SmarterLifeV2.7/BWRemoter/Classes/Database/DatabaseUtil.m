//
//  DatabaseUtil.m
//  BWRemoter
//
//  Created by cym on 14-12-30.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "DatabaseUtil.h"
static FMDatabase * _db;
static BOOL _isDemo;
@implementation DatabaseUtil


+(NSString *)filepath
{
    NSString *path =[NSHomeDirectory() stringByAppendingPathComponent:@"Documents/BWDatabase_V2.sqlite"];
    if (_isDemo) {
        path =[NSHomeDirectory() stringByAppendingPathComponent:@"Documents/DatabaseDEMO.sqlite"];
    }
    return path;
}
+(void)setDataBaseIsDemo:(BOOL)isDemo{
    _isDemo = isDemo;
}
+(FMDatabase *)creatOrFindDB
{
    _db = [FMDatabase databaseWithPath:[DatabaseUtil filepath]];
    return _db;
}

@end
