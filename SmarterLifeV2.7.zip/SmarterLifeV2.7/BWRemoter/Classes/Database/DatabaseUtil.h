//
//  DatabaseUtil.h
//  BWRemoter
//
//  Created by cym on 14-12-30.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDatabase.h"

@interface DatabaseUtil : NSObject

+(FMDatabase *)creatOrFindDB;
+(void)setDataBaseIsDemo:(BOOL)isDemo;

@end
