//
//  CYM_DatabaseTable.h
//  BWRemoter
//
//  Created by cym on 14-12-30.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDatabase.h"
#import "DatabaseUtil.h"
#import "FMDatabaseAdditions.h"

#import "Room.h"
#import "RoomDevice.h"
#import "Control.h"
#import "ControlDevice.h"
#import "ControlDeviceContent.h"
#import "ControlDeviceContentValue.h"
#import "ControlDeviceContentValueKey.h"
#import "Scene.h"
#import "SceneDevice.h"
#import "Ipc.h"
#import "Config.h"
#import "Crontab.h"
#import "CrontabInstruction.h"
#import "SecurityNote.h"
#import "Security.h"
#import "SecurityContent_sensor.h"
#import "SecurityContent_zone.h"
#import "SecurityContent_zone_sensor.h"
#import "HouseDevice.h"
#import "House.h"
#import "Door.h"
#import "DoorlockNote.h"
#import "DeviceSettingModel.h"

@interface CYM_DatabaseTable : NSObject

+ (void)logoutDataBase;

+ (NSString *)GenerateGUID;

//设置线程锁
+ (void)initializeThreadLock;

//room - insert
+(void)insertToRoom:(Room *)room;
+(void)insertToRoomDevice:(RoomDevice *)roomDevice andID:(NSString *)roomId;
+(void)insertToRoomDeviceContent:(NSString *)name andDeviceID:(NSString *)deviceID andRoomID:(NSString *)roomID;

//room - delete all data
+(void)deleteDataFromRoom;

//control - insert
+(void)insertToControl:(Control *)control;
+(void)insertToControlDevice:(ControlDevice *)controlDevice andControlID:(NSString *)controlID;
+(void)insertToControlDeviceContent:(ControlDeviceContent *)controlDeviceContent andDeviceID:(NSString *)deviceID andControlID:(NSString *)controlID;
+(void)insertToControlDeviceContentValue:(ControlDeviceContentValue *)controlDeviceContentValue andContentID:(NSString *)contentID andDeviceID:(NSString *)deviceID andControlID:(NSString *)controlID;
+(void)insertToControlDeviceContentValueKey:(ControlDeviceContentValueKey *)controlDeviceContentValueKey andValueID:(NSString *)valueID andContentID:(NSString *)contentID andDeviceID:(NSString *)deviceID andControlID:(NSString *)controlID;

//control - delete all data
+(void)deleteDataFromControl;

//scene - insert
+(void)insertToScene:(Scene *)scene;
+(void)insertToSceneDevice:(SceneDevice *)sceneDevice andSceneID:(NSString *)sceneID;

//scene - delete all data
+(void)deleteDataFromScene;

//zone
+ (BOOL)updateZoneSet:(SecurityContent_zone *)zone;

//ipc - insert
+(void)insertToIpc:(Ipc *)ipc;

//ipc - delete all data
+(void)deleteDataFromIPC;

//config - insert
+(void)insertToConfig:(Config *)config;

//config - delete all data
+(void)deleteDataFromConfig;

//crontab - insert
+(void)insertToCrontab:(Crontab *)crontab;
+(void)insertToCrontabInstruction:(CrontabInstruction *)crontabInstruction andCrontabID:(NSString *)crontabID;
//crontab - delete all data
+(void)deleteDataFromCrontab;

//securityNote - insert
+(void)insertToSecurityNote:(SecurityNote *)securityNote;

//securityNote - delete all data
+(void)deleteDataFromSecurityNote;

//security - insert
+(void)insertToSecurity:(Security *)security;
+(void)insertTosecurityContentSensor:(SecurityContent_sensor *)securityContent_sensor andSecurityID:(NSString *)securityID;
+(void)insertTosecurityContentZone:(SecurityContent_zone *)securityContent_zone andSecurityID:(NSString *)securityID;
+(void)insertTosecurityContentZoneSensor:(SecurityContent_zone_sensor *)securityContent_zone_sensor andContentID:(NSString *)contentID andSecurityID:(NSString *)securityID;

//security - delete all data
+(void)deleteDataFromSecurity;


/////////////////////////////   数据接口
//Room
+(NSMutableArray *)getRoom;
+(NSMutableArray *)getRoomDeviceWithRoomID:(NSString *)roomID;
+(NSMutableArray *)getContentNameWithRoomDeivceID:(NSString *)roomDeviceID;
+(NSString *)getRoomNameWithRoomDeviceName:(NSString *)deviceName;
+(BOOL)deleteRoomDeviceContentWithName:(NSString *)name;
+(BOOL)addRoomDeviceContentWithName:(NSString *)devName room:(NSString *) roomName;
+ (BOOL)insertRoom:(Room *)room;
+ (void)deleteRoomWithName:(NSString *)name;
+ (Room *)getRoomFromName:(NSString *)name;
+ (void)updataRoomWithRoom:(Room *)room withOldName:(NSString *)oldName;


//Control
+(NSMutableArray *)getDeviceDetailsWithDeviceID:(NSString *)deviceID;
+(ControlDeviceContentValue *)getDeviceDetailsWithDeviceName:(NSString *)deviceName;
+ (NSMutableArray *)getAllDevice;
+(NSMutableArray *)getAlldeviceContent;
+(NSMutableArray *)getAlarmDevice;
+(NSMutableArray *)getDeviceValueWithRoomName:(NSString *)name;
+(NSMutableArray *)getContrlKeyWithValueID:(NSString *)valueID;
+(BOOL)updateDevicePriowith:(NSMutableArray *)arydeviceValue;
+(NSMutableArray *)getTogetherCategoryValues:(NSString *)valName;

+(BOOL)updateContrlValueKeys:(NSArray *)aryKey ValueName:(NSString *)valName;

+(BOOL)isQueryValue:(NSString *)value;

////// 获取所有Ctrls
+(NSMutableArray *)getAllContrls;
+(NSMutableArray *)getCtrlDeviceWithCtrlID:(NSString *)ctrlID;
+(NSMutableArray *)getContentWithDeviceID:(NSString *)deviceID;
+(NSMutableArray *)getValuesWithContentID:(NSString *)contentID;
+(NSMutableArray *)getContrlValueWithProperty:(NSString *) property;
/////////////////END

///Sence
+ (NSMutableArray *)getSenceWithRoomName:(NSString *)roomName;
+(NSMutableArray *)getSenceDeviceWithSenceID:(NSString *)scenceID;
+(Scene *)getSenceWithSenceName:(NSString *)senceName;
+(NSMutableArray *)getAllSoftSence;
+(NSMutableArray *)getAllSoftHardScene;
+(NSMutableArray *)getAllOtherScene;
+(BOOL)deleteSceneWithSceneName:(NSString *)name;
+(BOOL)updateSceneWithName:(Scene *)scene;

///IPC
+(NSMutableArray *)getAllIPCInfo;

///Config
+(Config *)getConfigWithName:(NSString *)name;
///setting
///settime
+(NSMutableArray *)getAllFixTime;
+(NSMutableArray *)getCrontabInstructionbycrontabId:(NSString *)crontabId;
+(BOOL)deleteCrontabByCrontabId:(NSString *)crontab_Id;
+ (BOOL)addOrEditCrontabwithcrontab:(Crontab *)crontab;
+ (BOOL)EditAllCrontab:(NSMutableArray *)arycrontab;
///防区
+(NSMutableArray *)GetAllZone;
+(NSMutableArray *)getSensorFormZonewithcontentId:(NSString *)contentId;
+(NSMutableArray *)GetAllsensor;
+(BOOL)updateZonewith:(SecurityContent_zone *)zone;
+(BOOL)updateSensor:(SecurityContent_sensor *)sensor;
+(BOOL)deleteZoneByzoneId:(NSString *)zoneId;
+(NSMutableArray *)GetAllSecurityNote;
+(NSString *)getSecurityNoteType:(NSString *)mac;
+(NSString *)getDeviceNameById:(NSString *)devId;
+(NSString *)getNewNoteDate;
+(NSMutableArray *)getNewSecurtyNote:(NSString *)lastDate;
+(NSMutableArray *)getAlarmNameWithZoneID:(NSString *)strZoneID;
+(NSMutableArray *)getAlarmNameWithSensorMAC:(NSString *)strSensorMAC;
+(NSMutableArray *)getAlarmNameWithNot24H;
+(void)cancelSecrityNot24H;
+(NSString *)getSensorOrAlarmPriowithName:(NSString *)name;
//2.7增加
+ (NSMutableArray *)getAllAlarm;
+ (SecurityContent_sensor *)getsensorFromName:(NSString *)name;
+ (void)modiOldName:(NSString *)oldName toNewName:(NSString *)newName;
+ (void)modiProperty:(NSString *)property withDevice:(DeviceSettingModel *)model  withRoomName:(NSString *)roomName;
+ (void)modiRoomName:(NSString *)roomName withDevice:(DeviceSettingModel *)model;
+ (void)deleteDeviceFromDevice:(DeviceSettingModel *)model withOldName:(NSString *)oldName;
+ (void)modiStateWithModel:(DeviceSettingModel *)model;
+ (void)modiTrigger:(NSString *)trigger withDevice:(DeviceSettingModel *)device;
+ (void)modiAlarm:(NSString *)alarm withDevice:(DeviceSettingModel *)device;

///////////房型专用数据库
+(NSMutableArray *)getALLHouseUrl;
+(NSMutableArray *)getAllDevicelocationByhouseName:(NSString *)houseName;
+(House *)getHouseByHouseName:(NSString *)housename;
+(void)insertHouse:(House *)house;
+(void)deleteHouse:(NSString *)housename;
+(void)insertHouseInfo:(HouseDevice *)houseDevice;
+(BOOL)deleteHouseInfoByDeviceName:(NSString *)deviceName;
+(BOOL)deleteHouseInfoByHouseName:(NSString *)houseName;

//门锁
+ (void)deleteDataFromDoorlock;//删除门锁相关数据库
+ (void)deleteDataFromDoorlockNote;//删除门锁警告
//写入数据
+ (void)insertToDoorlock:(Door *)door;
+ (void)insertToDoorlockNote:(DoorlockNote *)note;
//获取数据
+ (NSMutableArray *)getAllDoorlockName;//获得所有门锁名字
+ (NSMutableArray *)getAllDoorlockSet;
+ (NSMutableArray *)getNewDoorlockNote:(NSString *)lastDate;
+ (NSString *)getNewDoorlockNoteDate;
+ (NSMutableArray *)getLatest500DoorlockNote;
+ (NSString *)getDevNameWithDevValue:(NSString *)devValue;
+ (NSString *)getDoorlockValueWithDoorName:(NSString *)name;
+ (Doorlock *)getDoorlockWithDoorDevID:(NSString *)devID;

//用户
+ (DoorlockUser *)getNameWithUserID:(NSString *)userID;
+ (DoorlockUser *)getUserWithLoadName:(NSString *)loadName;
+ (BOOL)saveUserToDataBase:(DoorlockUser *)user;
+ (BOOL)deleteUserWithLoadName:(NSString *)loadName;
+ (NSMutableArray *)getAllDoorlockUser;

//2.7
+ (DeviceSettingModel *)getSensorModelWithName:(NSString *)name;
+ (NSMutableArray *)getAllCDCVKey;
+ (NSMutableArray *)getAllCDCValue;
+ (NSMutableArray *)getAllCDContent;
+ (NSMutableArray *)getAllCDevice;
+ (NSMutableArray *)getAllControl;
+ (void)clearOrderWithDeviceValue:(DeviceSettingModel *)model;
+ (void)insertDevice:(DeviceSettingModel *)model;
+ (void)relaceDeviceFrom:(DeviceSettingModel *)fresh to:(DeviceSettingModel *)old;
+ (NSMutableArray *)getAllDeviceWithCategory:(NSString *)category;
+ (void)saveKeys:(NSMutableArray *)keys ToDevice:(DeviceSettingModel *)model;
+ (NSMutableArray *)getAllDeviceWithRoomName:(NSString *)name;
//2.7config
+ (void)updataVersion;
+ (void)deletesensorWithName:(NSString *)name;
+ (void)insertSensor:(DeviceSettingModel *)model;
+ (void)modiSensorSensor:(DeviceSettingModel *)model;
+ (void)updataAlarmZigbeeToTTLName:(NSString *)name;
@end
