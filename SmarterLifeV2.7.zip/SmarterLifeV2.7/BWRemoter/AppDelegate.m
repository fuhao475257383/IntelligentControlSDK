//
//  AppDelegate.m
//  BWRemoter
//
//  Created by JianBo He on 14/11/23.
//  Copyright (c) 2014年 ReSun. All rights reserved.
//

#import "AppDelegate.h"
#import "UI/FXW_ShowVC.h"
////
#import "CommondVC.h"
#import "SafeVC.h"
#import "SettingVC.h"
////
#import "HE_TabBarController.h"
#import "HE_NavgationController.h"


@implementation AppDelegate
@synthesize window;

+ (id)sharedAppDelegate{
    static AppDelegate *appDel = nil;
    if (!appDel) {
        appDel = [[super allocWithZone:nil] init];
    }
    return appDel;
}
+ (id)allocWithZone:(struct _NSZone *)zone{
    return [self sharedAppDelegate];
}

- (id) init{
    self = [super init];
    if (self) {
        ;
    }
    return self;
}


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    
    FXW_ShowVC *showVC = [[FXW_ShowVC alloc] init];
    [self.window setRootViewController:showVC];
    
    [[UITabBar appearance] setTintColor:[UIColor colorOfTurnToUIColor:@"#1DA4E9"]];
    [[UITabBar appearance] setBackgroundColor:[UIColor whiteColor]];
    
    [self moveSqliteFile];
    [self.window makeKeyAndVisible];
    
    //判断是否将修改过的配置上传
    //1取出保存的值
    NSString *result = [[NSUserDefaults standardUserDefaults] objectForKey:@"NETWORKING"];
    //2如果值==YES表示，手机存储的配置没有上传
    if ([result isEqualToString:@"YES"]) {
        //3修改config数据库值为0
        [CYM_DatabaseTable updataVersion];
        //4修改为NO
        [[NSUserDefaults standardUserDefaults] setObject:@"NO" forKey:@"NETWORKING"];
    }
    
    //注册消息推送
    @try {
        //IOS8 +
        //通知的类型
        UIUserNotificationSettings *settings = [UIUserNotificationSettings settingsForTypes:(UIRemoteNotificationTypeBadge|UIRemoteNotificationTypeSound|UIRemoteNotificationTypeAlert) categories:nil];
        [[UIApplication sharedApplication] registerUserNotificationSettings:settings];
    }
    @catch (NSException *exception) {
        //register to receive notifications
        UIRemoteNotificationType myTypes = UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeAlert | UIRemoteNotificationTypeSound;
        [[UIApplication sharedApplication] registerForRemoteNotificationTypes:myTypes];
    }
    @finally {
        // 启动时 气泡设置为零
        application.applicationIconBadgeNumber = 0;
        
        // 判断是否已开启 通知
        float sysVersion = [UIDevice currentDevice].systemVersion.floatValue;
        BOOL  notfacEnable = YES;
        if (sysVersion >= 8.0f) {
            if ([UIApplication sharedApplication].currentUserNotificationSettings.types <= 0) notfacEnable = false;
        }
        else {
            if ([[UIApplication sharedApplication] enabledRemoteNotificationTypes] <= 0) notfacEnable = false;
        }
        
        
        NSUserDefaults *usrDefault = [NSUserDefaults standardUserDefaults];
        if (!notfacEnable) {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"请在 设置->通知中心 开启提示功能, 以确保及时收到安防报警消息" message:@"" delegate:nil cancelButtonTitle:@"确认" otherButtonTitles: nil];
            [alert show];
            
            [usrDefault setObject:[NSNumber numberWithBool:false] forKey:kIsOpenNotfic];
        } else {
            [usrDefault setObject:[NSNumber numberWithBool:true] forKey:kIsOpenNotfic];
        }
    }
    

    return YES;
}

-(void)moveSqliteFile
{
    NSString *sourcePath     =[[NSBundle mainBundle]pathForResource:@"BWDatabase_V2"  ofType: @"sqlite"];
    NSString *sourcePathDemo =[[NSBundle mainBundle]pathForResource:@"DatabaseDEMO"  ofType: @"sqlite"];
    
    NSFileManager *fileManager =[NSFileManager defaultManager];
    
    NSString *documentsStr   = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    
    NSString *toFilePath     =[NSString stringWithFormat:@"%@/BWDatabase_V2.sqlite",documentsStr];
    NSString *toFilePathDemo =[NSString stringWithFormat:@"%@/DatabaseDEMO.sqlite",documentsStr];
    
    NSError *error = nil;
    
    if (![fileManager fileExistsAtPath:toFilePath])
    {
        [fileManager copyItemAtPath:sourcePathDemo toPath:toFilePathDemo error:&error];
        if ([fileManager copyItemAtPath:sourcePath toPath:toFilePath error:&error] !=YES)
        {
            NSLog(@"数据库移动失败");
        }else
        {
            NSLog(@"数据库移动成功");
        }
    }
    else
    {
        NSLog(@"文件存在");
    }
    
}

#ifdef __IPHONE_8_0
- (void)application:(UIApplication *)application didRegisterUserNotificationSettings:(UIUserNotificationSettings *)notificationSettings{
    //register to receive notifications
    [application registerForRemoteNotifications];
}

- (void)application:(UIApplication *)application handleActionWithIdentifier:(NSString *)identifier forRemoteNotification:(NSDictionary *)userInfo completionHandler:(void(^)())completionHandler{
    //handle the actions
    if ([identifier isEqualToString:@"declineAction"]){
    }
    else if ([identifier isEqualToString:@"answerAction"]){
    }
}
#endif
//获取DeviceToken成功
- (void)application:(UIApplication *)application
didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
    NSLog(@"deviceToken号：%@",deviceToken.string);
    //这里进行的操作，是将Device Token保存到plist文件中
    NSUserDefaults *userDefat = [NSUserDefaults standardUserDefaults];
    [userDefat setObject:deviceToken.string forKey:kDeviceToken];
}

//注册消息推送失败
- (void)application:(UIApplication *)application
didFailToRegisterForRemoteNotificationsWithError:(NSError *)error
{
    NSLog(@"Register Remote Notifications error:{%@}",error);
    NSUserDefaults *userDefat = [NSUserDefaults standardUserDefaults];
    [userDefat setObject:@"" forKey:kDeviceToken];
    
}

//处理收到的消息推送
- (void)application:(UIApplication *)application
didReceiveRemoteNotification:(NSDictionary *)userInfo
{
    NSLog(@"Receive remote notification : %@",userInfo);
//    UIAlertView *alert =
//    [[UIAlertView alloc] initWithTitle:@"温馨提示"
//                               message:@"推送成功！"
//                              delegate:nil
//                     cancelButtonTitle:@"确定"
//                     otherButtonTitles:nil];
//    [alert show];
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}
//进入后台后调用
- (void)applicationDidEnterBackground:(UIApplication *)application {
    [[HE_APPManager sharedManager] applicationDidEnterBackground:application];
}
//进入前台时调用
- (void)applicationWillEnterForeground:(UIApplication *)application {
    [[HE_APPManager sharedManager] applicationWillEnterForeground:application];
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
