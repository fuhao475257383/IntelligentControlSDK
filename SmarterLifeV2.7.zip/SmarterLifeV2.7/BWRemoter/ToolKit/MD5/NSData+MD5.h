//
//  Copyright iOSDeveloperTips.com All rights reserved.
//

#import "NSData+MD5.h"
 
@interface NSData(MD5)
 
- (NSString *)MD5;
 
@end