//
//  PathSelectResultProtocol.h
//  P2PCamera
//
//  Created by mac on 12-11-14.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol PathSelectResultProtocol <NSObject>

- (void) PathSelectResult: (NSString*) did Date: (NSString*) Date Path: (NSString*)  Path;

@end
