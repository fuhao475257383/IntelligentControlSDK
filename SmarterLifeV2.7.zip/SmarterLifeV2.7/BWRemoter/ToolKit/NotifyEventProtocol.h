//
//  NotifyEventProtocol.h
//  P2PCamera
//
//  Created by mac on 12-11-15.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol NotifyEventProtocol <NSObject>

- (void) NotifyReloadData;

@end
