//
//  MyAudioSession.h
//  P2PCamera
//
//  Created by mac on 12-8-7.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#ifndef P2PCamera_MyAudioSession_h
#define P2PCamera_MyAudioSession_h

void InitAudioSession();

#endif
