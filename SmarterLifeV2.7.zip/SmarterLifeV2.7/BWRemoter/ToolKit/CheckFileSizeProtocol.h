//
//  CheckFileSizeProtocol.h
//  P2PCamera
//
//  Created by Tsang on 13-3-6.
//
//

#import <Foundation/Foundation.h>

@protocol CheckFileSizeProtocol <NSObject>
-(void) isFileSizeMore128:(BOOL)bflag;
@end
